أيقونات نسق (SVG): مجموعة Lucide (ترخيص ISC) + شعارات الخدمات السحابية من Simple Icons (CC0).
نفس الملفات متحوّلة لـ Vector Drawables في app/src/main/res/drawable (ic_*.xml و cloud_*.xml)
وبتتستخدم في الكود عن طريق ui/NIcons.kt (NI.Delete, NI.Add, ...).
