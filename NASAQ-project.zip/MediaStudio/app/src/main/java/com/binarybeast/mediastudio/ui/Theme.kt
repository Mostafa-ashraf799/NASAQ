package com.binarybeast.mediastudio.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF06070B)
val Surface1 = Color(0xFF0D0F17)
val Surface2 = Color(0xFF171A26)
val Accent = Color(0xFFA99DFF)
val Silver = Color(0xFFD5D9E6)
val TextDim = Color(0xFF8D93AB)
val Danger = Color(0xFFFF6B6B)

private val Scheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF120E33),
    secondary = Silver,
    onSecondary = Color(0xFF0B0C12),
    background = Bg,
    onBackground = Color(0xFFF1F2F8),
    surface = Surface1,
    onSurface = Color(0xFFF1F2F8),
    surfaceVariant = Surface2,
    onSurfaceVariant = TextDim,
    error = Danger,
    outline = Color(0xFF30344A),
)

@Composable
fun MediaStudioTheme(content: @Composable () -> Unit) {
    @Suppress("UNUSED_VARIABLE")
    val unused = isSystemInDarkTheme()
    MaterialTheme(colorScheme = Scheme, content = content)
}
