@file:OptIn(UnstableApi::class)

package com.binarybeast.mediastudio.audio

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.binarybeast.mediastudio.Graph
import com.binarybeast.mediastudio.data.AudioData
import com.binarybeast.mediastudio.data.MediaRepository
import com.binarybeast.mediastudio.data.Project
import com.binarybeast.mediastudio.video.ExportState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class AudioEditorViewModel(app: Application, private val projectId: String) : AndroidViewModel(app) {

    private val repo = Graph.repo
    private val appCtx: Application = app

    val player: ExoPlayer = ExoPlayer.Builder(app).build()

    var project by mutableStateOf<Project?>(null)
        private set
    var data by mutableStateOf<AudioData?>(null)
        private set
    var loading by mutableStateOf(true)
        private set
    var failed by mutableStateOf(false)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    /** موضع التشغيل بالنسبة للمصدر (ms). */
    var positionMs by mutableStateOf(0L)
        private set
    var peaks by mutableStateOf<FloatArray?>(null)
        private set
    var message by mutableStateOf<String?>(null)
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set
    var exportState by mutableStateOf<ExportState>(ExportState.Idle)
        private set

    private val undoStack = ArrayDeque<AudioData>()
    private val redoStack = ArrayDeque<AudioData>()
    private var gestureBase: AudioData? = null
    private var saveJob: Job? = null
    private var transformer: Transformer? = null
    private var exportFile: File? = null

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(playing: Boolean) {
            isPlaying = playing
        }

        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
            message = "تعذّر تشغيل الملف"
        }
    }

    init {
        player.addListener(listener)
        viewModelScope.launch {
            val p = withContext(Dispatchers.IO) { repo.load(projectId) }
            val a = p?.audio
            if (p == null || a == null) {
                failed = true
                loading = false
                return@launch
            }
            project = p
            data = a
            loading = false
            player.setMediaItem(MediaItem.fromUri(Uri.parse(a.uri)))
            player.prepare()
            player.seekTo(a.startMs)
            applyPlayback()
            val pk = withContext(Dispatchers.IO) { AudioWaveform.compute(appCtx, Uri.parse(a.uri)) }
            peaks = pk
        }
        viewModelScope.launch {
            while (true) {
                delay(50)
                tick()
            }
        }
    }

    private fun tick() {
        val a = data ?: return
        val pos = player.currentPosition
        positionMs = pos
        if (player.isPlaying) {
            if (pos >= a.endMs) {
                player.pause()
                player.seekTo(a.startMs)
                positionMs = a.startMs
            } else {
                player.volume = (a.volume.coerceAtMost(1f) * AudioEffects.fadeGain(a, pos)).coerceIn(0f, 1f)
            }
        }
    }

    private fun applyPlayback() {
        val a = data ?: return
        player.playbackParameters = PlaybackParameters(a.speed, a.pitch)
        player.volume = a.volume.coerceAtMost(1f)
    }

    // ------------------------------------------------------------ transport

    fun togglePlay() {
        val a = data ?: return
        if (player.isPlaying) {
            player.pause()
        } else {
            if (player.currentPosition >= a.endMs - 50 || player.currentPosition < a.startMs) player.seekTo(a.startMs)
            player.play()
        }
    }

    fun pause() = player.pause()

    fun seekTo(ms: Long) {
        player.seekTo(ms.coerceAtLeast(0L))
        positionMs = ms
    }

    fun nudge(deltaMs: Long) {
        val a = data ?: return
        seekTo((player.currentPosition + deltaMs).coerceIn(a.startMs, a.endMs))
    }

    // ------------------------------------------------------------ edits

    fun update(live: Boolean = false, f: (AudioData) -> AudioData) {
        val old = data ?: return
        val new = f(old)
        if (new == old) return
        if (!live) {
            pushUndo(old)
        } else if (gestureBase == null) {
            gestureBase = old
        }
        data = new
        applyPlayback()
        if (new.startMs != old.startMs || new.endMs != old.endMs) {
            val p = player.currentPosition
            if (p < new.startMs || p > new.endMs) player.seekTo(new.startMs)
        }
        refreshFlags()
        scheduleSave()
    }

    fun endLive() {
        val base = gestureBase
        gestureBase = null
        if (base != null && base != data) pushUndo(base)
        refreshFlags()
    }

    private fun pushUndo(d: AudioData) {
        undoStack.addLast(d)
        if (undoStack.size > 60) undoStack.removeFirst()
        redoStack.clear()
    }

    fun undo() {
        val cur = data ?: return
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(cur)
        data = prev
        applyPlayback()
        refreshFlags()
        scheduleSave()
    }

    fun redo() {
        val cur = data ?: return
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(cur)
        data = next
        applyPlayback()
        refreshFlags()
        scheduleSave()
    }

    private fun refreshFlags() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    // ------------------------------------------------------------ save

    private fun snapshot(): Project? {
        val p = project ?: return null
        val a = data ?: return null
        val u = p.copy(audio = a, updatedAt = System.currentTimeMillis())
        project = u
        return u
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(900)
            val u = snapshot() ?: return@launch
            withContext(Dispatchers.IO) { repo.save(u) }
        }
    }

    fun saveNow() {
        val u = snapshot() ?: return
        repo.save(u)
    }

    fun rename(name: String) {
        val p = project ?: return
        project = p.copy(name = name)
        scheduleSave()
    }

    // ------------------------------------------------------------ export

    fun startExport() {
        val a = data ?: return
        player.pause()
        saveNow()
        val file = File(appCtx.cacheDir, "nasaq_audio_${System.currentTimeMillis()}.m4a")
        exportFile = file
        exportState = ExportState.Running(0)
        try {
            val mib = MediaItem.Builder().setUri(Uri.parse(a.uri))
            if (a.startMs > 0L || a.endMs < a.srcDurationMs) {
                mib.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(a.startMs)
                        .setEndPositionMs(a.endMs)
                        .build()
                )
            }
            val item = EditedMediaItem.Builder(mib.build())
                .setRemoveVideo(true)
                .setEffects(Effects(AudioEffects.processors(a), emptyList()))
                .build()
            val t = Transformer.Builder(appCtx)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        viewModelScope.launch {
                            try {
                                val uri = withContext(Dispatchers.IO) {
                                    MediaRepository.saveAudio(appCtx, file).also { file.delete() }
                                }
                                exportState = ExportState.Done(uri)
                            } catch (e: Exception) {
                                exportState = ExportState.Failed("تم التصدير لكن تعذّر الحفظ")
                            }
                        }
                    }

                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        file.delete()
                        exportState = ExportState.Failed(exportException.message ?: "فشل التصدير")
                    }
                })
                .build()
            transformer = t
            t.start(item, file.absolutePath)
            viewModelScope.launch {
                val holder = ProgressHolder()
                while (exportState is ExportState.Running) {
                    if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                        exportState = ExportState.Running(holder.progress)
                    }
                    delay(300)
                }
            }
        } catch (e: Throwable) {
            file.delete()
            exportState = ExportState.Failed(e.message ?: "فشل بدء التصدير")
        }
    }

    fun cancelExport() {
        transformer?.cancel()
        exportFile?.delete()
        exportState = ExportState.Idle
    }

    fun resetExport() {
        exportState = ExportState.Idle
    }

    override fun onCleared() {
        saveNow()
        runCatching { transformer?.cancel() }
        player.release()
        super.onCleared()
    }
}
