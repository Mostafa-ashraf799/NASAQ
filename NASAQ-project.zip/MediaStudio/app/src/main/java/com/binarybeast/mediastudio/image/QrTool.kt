package com.binarybeast.mediastudio.image

import android.graphics.Bitmap
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter

/** توليد QR Code (ZXing). */
object QrTool {
    fun make(text: String, size: Int = 768, fg: Int = 0xFF000000.toInt(), bg: Int = 0xFFFFFFFF.toInt()): Bitmap? = try {
        val hints = HashMap<EncodeHintType, Any>()
        hints[EncodeHintType.MARGIN] = 1
        hints[EncodeHintType.CHARACTER_SET] = "UTF-8"
        val bm = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
        val px = IntArray(size * size) { i -> if (bm.get(i % size, i / size)) fg else bg }
        Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
    } catch (t: Throwable) { null }

    /** يحفظ الـ QR في ملف PNG مؤقت ويرجّعه. */
    fun makeFile(ctx: android.content.Context, text: String): java.io.File? {
        val b = make(text) ?: return null
        val f = java.io.File(ctx.cacheDir, "qr_${System.currentTimeMillis()}.png")
        return runCatching { f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }; f }.getOrNull()
    }
}
