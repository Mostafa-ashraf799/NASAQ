package com.binarybeast.mediastudio.image

import android.graphics.Bitmap
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo

/** أدوات احترافية بمكتبة OpenCV (ترميم/إزالة ضوضاء/تفاصيل/كرتون/رسم رصاص). */
object CvTools {
    @Volatile private var ready: Boolean? = null

    fun init(): Boolean {
        ready?.let { return it }
        val ok = try { OpenCVLoader.initLocal() } catch (t: Throwable) { false }
        ready = ok
        return ok
    }

    private fun toRgb(b: Bitmap): Mat {
        val rgba = Mat()
        Utils.bitmapToMat(b, rgba)
        val rgb = Mat()
        Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
        rgba.release()
        return rgb
    }

    /** يكتب النتيجة في نفس الـ Bitmap مع الحفاظ على الشفافية الأصلية. */
    private fun writeBack(rgb: Mat, target: Bitmap, alpha: IntArray) {
        val rgba = Mat()
        Imgproc.cvtColor(rgb, rgba, Imgproc.COLOR_RGB2RGBA)
        Utils.matToBitmap(rgba, target)
        rgba.release()
        val w = target.width; val h = target.height
        val px = IntArray(w * h)
        target.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) px[i] = (alpha[i] shl 24) or (px[i] and 0xFFFFFF)
        target.setPixels(px, 0, w, 0, 0, w, h)
    }

    private fun alphaOf(b: Bitmap): IntArray {
        val w = b.width; val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        return IntArray(px.size) { px[it] ushr 24 }
    }

    /** kind: 0 إزالة ضوضاء، 1 تعزيز التفاصيل، 2 كرتون، 3 رسم رصاص، 4 تنعيم يحافظ على الحواف. */
    fun apply(b: Bitmap, kind: Int, strength: Float): Boolean {
        if (!init()) return false
        val alpha = alphaOf(b)
        val src = toRgb(b)
        val out = Mat()
        try {
            when (kind) {
                0 -> { val h = 3f + strength * 12f; Photo.fastNlMeansDenoisingColored(src, out, h, h, 7, 21) }
                1 -> Photo.detailEnhance(src, out, 10f, 0.1f + strength * 0.25f)
                2 -> Photo.stylization(src, out, 60f, 0.2f + strength * 0.5f)
                3 -> {
                    val gray = Mat()
                    Photo.pencilSketch(src, gray, out, 60f, 0.07f, 0.02f + strength * 0.06f)
                    gray.release()
                }
                else -> Photo.edgePreservingFilter(src, out, 1, 40f + strength * 40f, 0.3f + strength * 0.3f)
            }
            writeBack(out, b, alpha)
        } finally {
            src.release(); out.release()
        }
        return true
    }

    /** ترميم بخوارزمية Telea. mask: بايتات (>100 = منطقة الحذف). */
    fun inpaint(b: Bitmap, mask: ByteArray): Boolean {
        if (!init()) return false
        val w = b.width; val h = b.height
        if (mask.size != w * h) return false
        val alpha = alphaOf(b)
        val src = toRgb(b)
        val m = Mat(h, w, CvType.CV_8UC1)
        val bin = ByteArray(mask.size) { if ((mask[it].toInt() and 255) > 100) 255.toByte() else 0 }
        m.put(0, 0, bin)
        val k = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(7.0, 7.0))
        Imgproc.dilate(m, m, k)
        val out = Mat()
        try {
            Photo.inpaint(src, m, out, 5.0, Photo.INPAINT_TELEA)
            writeBack(out, b, alpha)
        } finally {
            src.release(); m.release(); k.release(); out.release()
        }
        return true
    }
}
