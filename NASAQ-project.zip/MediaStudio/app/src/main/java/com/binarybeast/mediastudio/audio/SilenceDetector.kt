package com.binarybeast.mediastudio.audio

import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

/** اكتشاف الصمت في PCM 16-bit. */
object SilenceDetector {
    /**
     * يرجّع فترات الصمت [from,to] بالميلي ثانية (نسبة لبداية الـ PCM).
     * thresholdDb مثلًا -38، minMs أقل مدة صمت تعتبر صمت.
     */
    fun find(p: AudioPcm.Pcm, thresholdDb: Float, minMs: Long): List<Pair<Long, Long>> {
        val frameMs = 20
        val frameLen = (p.rate / 1000f * frameMs).toInt().coerceAtLeast(1) * p.ch
        val thr = Math.pow(10.0, thresholdDb / 20.0).toFloat() * 32768f
        val out = ArrayList<Pair<Long, Long>>()
        var silentFrom = -1L
        var i = 0
        var idx = 0L
        while (i + frameLen <= p.data.size) {
            var sum = 0.0
            for (k in i until i + frameLen) { val v = p.data[k].toDouble(); sum += v * v }
            val rms = sqrt(sum / frameLen).toFloat()
            val t = idx * frameMs
            if (rms < thr) { if (silentFrom < 0) silentFrom = t }
            else if (silentFrom >= 0) {
                if (t - silentFrom >= minMs) out.add(silentFrom to t)
                silentFrom = -1
            }
            i += frameLen; idx++
        }
        if (silentFrom >= 0) {
            val end = idx * frameMs
            if (end - silentFrom >= minMs) out.add(silentFrom to end)
        }
        return out
    }

    @Suppress("unused")
    private fun db(v: Float) = 20f * log10(abs(v).coerceAtLeast(1e-6f))
}
