package com.binarybeast.mediastudio.image

import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** ترجمة النصوص على الجهاز (ML Kit). أول استخدام للغة بيحمّل نموذجها من الإنترنت. */
object TextTranslate {
    val languages = listOf("ar" to "العربية", "en" to "English", "fr" to "Français", "es" to "Español", "de" to "Deutsch", "tr" to "Türkçe")

    private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { c ->
        addOnSuccessListener { r -> if (c.isActive) c.resume(r) }
        addOnFailureListener { e -> if (c.isActive) c.resumeWithException(e) }
    }

    /** يترجم كل نص للغة الهدف (بيكتشف لغة المصدر تلقائيًا). بيرجّع null لو فشل (مفيش نت مثلًا). */
    suspend fun translate(texts: List<String>, target: String): List<String>? {
        val li = LanguageIdentification.getClient()
        val cache = HashMap<String, Translator>()
        return try {
            val out = ArrayList<String>()
            for (t in texts) {
                if (t.isBlank()) { out.add(t); continue }
                val code = li.identifyLanguage(t).await()
                val s = TranslateLanguage.fromLanguageTag(if (code == "und") "en" else code)
                val d = TranslateLanguage.fromLanguageTag(target)
                if (s == null || d == null || s == d) { out.add(t); continue }
                val tr = cache.getOrPut(s) {
                    Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(s).setTargetLanguage(d).build())
                }
                tr.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
                out.add(tr.translate(t).await())
            }
            out
        } catch (e: Throwable) {
            null
        } finally {
            cache.values.forEach { runCatching { it.close() } }
            runCatching { li.close() }
        }
    }
}
