package com.binarybeast.mediastudio.ui

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private const val DESKTOP_FREE_UA =
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

fun cloudStartUrl(p: CloudProvider, custom: String?): String = when (p.id) {
    "drive" -> "https://drive.google.com/drive/my-drive"
    "dropbox" -> "https://www.dropbox.com/login"
    "onedrive" -> "https://onedrive.live.com/"
    "mega" -> "https://mega.nz/login"
    "box" -> "https://account.box.com/login"
    else -> custom?.trim()?.let { if (it.startsWith("http")) it else "https://$it" } ?: "https://nextcloud.com/"
}

private fun guessKind(mime: String?, name: String): CloudOpenKind? {
    val m = (mime ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "")
    return when {
        m.startsWith("image/") -> CloudOpenKind.IMAGE
        m.startsWith("video/") -> CloudOpenKind.VIDEO
        m.startsWith("audio/") -> CloudOpenKind.AUDIO
        else -> null
    }
}

private fun downloadFile(ctx: Context, url: String, ua: String?, mime: String?, disposition: String?): File? {
    val conn = URL(url).openConnection() as HttpURLConnection
    return try {
        conn.instanceFollowRedirects = true
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        CookieManager.getInstance().getCookie(url)?.let { conn.setRequestProperty("Cookie", it) }
        if (ua != null) conn.setRequestProperty("User-Agent", ua)
        var name = android.webkit.URLUtil.guessFileName(url, disposition, mime)
        val dir = File(ctx.filesDir, "cloud").apply { mkdirs() }
        var f = File(dir, name)
        var n = 1
        while (f.exists()) { f = File(dir, "${n++}_$name") }
        conn.inputStream.use { ins -> f.outputStream().use { ins.copyTo(it) } }
        f
    } catch (e: Exception) { null } finally { conn.disconnect() }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun CloudBrowser(
    title: String,
    startUrl: String,
    onClose: () -> Unit,
    onOpenAs: (CloudOpenKind, List<Uri>) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var web by remember { mutableStateOf<WebView?>(null) }
    var progress by remember { mutableStateOf(0) }
    var canBack by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var chooser by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        chooser?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
        chooser = null
    }

    BackHandler {
        if (web?.canGoBack() == true) web?.goBack() else onClose()
    }
    DisposableEffect(Unit) { onDispose { web?.apply { stopLoading(); destroy() } } }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, "إغلاق") }
            Text(title, fontSize = 16.sp, modifier = Modifier.weight(1f), maxLines = 1)
            IconButton(onClick = { web?.goBack() }, enabled = canBack) { Icon(Icons.Default.ArrowBack, "رجوع") }
            IconButton(onClick = { web?.reload() }) { Icon(Icons.Default.Refresh, "تحديث") }
        }
        if (progress in 1..99) {
            LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Accent)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                val wv = try { WebView(c) } catch (t: Throwable) { null }
                if (wv == null) {
                    toast(c, "المتصفح المدمج (WebView) مش متاح على جهازك. استخدم الاستيراد من المنتقي.")
                    onClose()
                    return@factory android.view.View(c)
                }
                wv.apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.databaseEnabled = true
                    settings.loadWithOverviewMode = true
                    settings.useWideViewPort = true
                    settings.setSupportZoom(true)
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false
                    settings.javaScriptCanOpenWindowsAutomatically = true
                    settings.setSupportMultipleWindows(false)
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                    settings.userAgentString = DESKTOP_FREE_UA
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                            val u = r.url.toString()
                            return !(u.startsWith("http://") || u.startsWith("https://"))
                        }
                        override fun onPageFinished(v: WebView, url: String?) { loaded = true }
                        override fun onReceivedError(v: WebView, r: WebResourceRequest, e: android.webkit.WebResourceError) {
                            if (r.isForMainFrame) error = "تعذّر فتح الصفحة (${e.description}). اتأكد من الإنترنت."
                        }
                        override fun doUpdateVisitedHistory(v: WebView, url: String?, isReload: Boolean) {
                            canBack = v.canGoBack()
                        }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(v: WebView, p: Int) { progress = p }
                        override fun onShowFileChooser(
                            v: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
                        ): Boolean {
                            chooser?.onReceiveValue(null)
                            chooser = cb
                            val types = params.acceptTypes.filter { it.isNotBlank() }.ifEmpty { listOf("*/*") }
                            return try { picker.launch(types.toTypedArray()); true } catch (e: Exception) { chooser = null; false }
                        }
                    }
                    setDownloadListener { url, ua, disp, mime, _ ->
                        if (url.startsWith("blob:") || url.startsWith("data:")) {
                            toast(ctx, "الموقع ده بيحمّل بطريقة مش مدعومة هنا. جرّب الاستيراد من المنتقي.")
                        } else {
                            Transfers.download(ctx, url, ua, mime, disp)
                            toast(ctx, "بدأ التحميل في الخلفية، تابعه من الشريط فوق")
                        }
                    }
                    web = this
                    loadUrl(startUrl)
                }
            }
        )
        if (!loaded && error == null) {
            Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    androidx.compose.material3.CircularProgressIndicator(color = Accent)
                    Text("جاري تحميل $title...", color = TextDim, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp))
                }
            }
        }
        error?.let { msg ->
            Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                    Text(msg, color = TextDim, fontSize = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    Row(Modifier.padding(top = 12.dp), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                        SmallButton("إعادة المحاولة", { error = null; loaded = false; web?.loadUrl(startUrl) })
                        SmallButton("فتح في المتصفح", {
                            runCatching {
                                ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(startUrl)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                            }
                        })
                    }
                }
            }
        }
        }
    }
}
