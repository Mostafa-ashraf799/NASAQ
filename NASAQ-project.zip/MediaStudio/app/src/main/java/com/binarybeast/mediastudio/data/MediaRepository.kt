package com.binarybeast.mediastudio.data

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import java.io.File

data class MediaEntry(
    val id: Long,
    val uri: Uri,
    val isVideo: Boolean,
    val name: String,
    val durationMs: Long,
    val dateAdded: Long,
    val bucket: String,
    val width: Int,
    val height: Int,
    val size: Long,
)

data class VideoInfo(val durationMs: Long, val width: Int, val height: Int)

enum class ExportFormat(val label: String, val mime: String, val ext: String) {
    JPG("JPG", "image/jpeg", "jpg"),
    PNG("PNG", "image/png", "png"),
    WEBP("WEBP", "image/webp", "webp"),
}

object MediaRepository {

    fun requiredPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= 34 -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED,
        )
        Build.VERSION.SDK_INT >= 33 -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
        )
        Build.VERSION.SDK_INT >= 29 -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        else -> arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
        )
    }

    fun hasPermission(ctx: Context): Boolean = requiredPermissions().any {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }

    // ---------------------------------------------------------------- query

    fun query(ctx: Context): List<MediaEntry> {
        val out = ArrayList<MediaEntry>()
        runCatching { queryTable(ctx, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false, out) }
        runCatching { queryTable(ctx, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, out) }
        out.sortByDescending { it.dateAdded }
        return out
    }

    private fun queryTable(ctx: Context, base: Uri, video: Boolean, out: MutableList<MediaEntry>) {
        val proj = mutableListOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.WIDTH,
            MediaStore.MediaColumns.HEIGHT,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
        )
        if (video) proj += MediaStore.Video.Media.DURATION
        ctx.contentResolver.query(
            base, proj.toTypedArray(), null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iDate = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
            val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val iW = c.getColumnIndexOrThrow(MediaStore.MediaColumns.WIDTH)
            val iH = c.getColumnIndexOrThrow(MediaStore.MediaColumns.HEIGHT)
            val iB = c.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            val iD = if (video) c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION) else -1
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                out.add(
                    MediaEntry(
                        id = id,
                        uri = ContentUris.withAppendedId(base, id),
                        isVideo = video,
                        name = c.getString(iName) ?: "",
                        durationMs = if (iD >= 0) c.getLong(iD) else 0L,
                        dateAdded = c.getLong(iDate),
                        bucket = c.getString(iB) ?: "غير معروف",
                        width = c.getInt(iW),
                        height = c.getInt(iH),
                        size = c.getLong(iSize),
                    )
                )
            }
        }
    }

    // ---------------------------------------------------------------- probing

    fun isVideoUri(ctx: Context, uri: Uri): Boolean {
        val mime = ctx.contentResolver.getType(uri)
        if (mime != null) return mime.startsWith("video/")
        val p = uri.path?.lowercase() ?: return false
        return p.endsWith(".mp4") || p.endsWith(".mov") || p.endsWith(".webm") || p.endsWith(".mkv") || p.endsWith(".3gp")
    }

    /** المدة والأبعاد كما تظهر (بعد تطبيق تدوير الميتاداتا). */
    fun probeVideo(ctx: Context, uri: Uri): VideoInfo {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) {
                val t = w; w = h; h = t
            }
            VideoInfo(dur, w, h)
        } catch (e: Exception) {
            VideoInfo(0L, 0, 0)
        } finally {
            runCatching { r.release() }
        }
    }

    fun probeAudioDuration(ctx: Context, uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            runCatching { r.release() }
        }
    }

    fun frameAt(ctx: Context, uri: Uri, positionMs: Long): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            r.getFrameAtTime(positionMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
        } catch (e: Exception) {
            null
        } finally {
            runCatching { r.release() }
        }
    }

    // ---------------------------------------------------------------- saving

    fun saveImage(ctx: Context, bmp: Bitmap, fmt: ExportFormat, quality: Int): Uri {
        val name = "NSQ_${System.currentTimeMillis()}.${fmt.ext}"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, fmt.mime)
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/NASAQ")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "NASAQ")
                dir.mkdirs()
                @Suppress("DEPRECATION")
                put(MediaStore.MediaColumns.DATA, File(dir, name).absolutePath)
            }
        }
        val cr = ctx.contentResolver
        val uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("تعذر إنشاء الملف")
        cr.openOutputStream(uri)?.use { os ->
            val cf = when (fmt) {
                ExportFormat.JPG -> Bitmap.CompressFormat.JPEG
                ExportFormat.PNG -> Bitmap.CompressFormat.PNG
                ExportFormat.WEBP ->
                    if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY
                    else @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP
            }
            val src = if (fmt == ExportFormat.JPG && bmp.hasAlpha()) flattenOnWhite(bmp) else bmp
            src.compress(cf, quality, os)
        } ?: throw IllegalStateException("تعذر الكتابة")
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            cr.update(uri, v, null, null)
        }
        return uri
    }

    private fun flattenOnWhite(b: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(out)
        c.drawColor(android.graphics.Color.WHITE)
        c.drawBitmap(b, 0f, 0f, null)
        return out
    }

    fun saveAudio(ctx: Context, file: File): Uri {
        val name = "NSQ_${System.currentTimeMillis()}.m4a"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Music/NASAQ")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), "NASAQ")
                dir.mkdirs()
                @Suppress("DEPRECATION")
                put(MediaStore.MediaColumns.DATA, File(dir, name).absolutePath)
            }
        }
        val cr = ctx.contentResolver
        val uri = cr.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("تعذر إنشاء الملف")
        cr.openOutputStream(uri)?.use { os -> file.inputStream().use { it.copyTo(os) } }
            ?: throw IllegalStateException("تعذر الكتابة")
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            cr.update(uri, v, null, null)
        }
        return uri
    }

    fun saveVideo(ctx: Context, file: File): Uri {
        val name = "NSQ_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/NASAQ")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "NASAQ")
                dir.mkdirs()
                @Suppress("DEPRECATION")
                put(MediaStore.MediaColumns.DATA, File(dir, name).absolutePath)
            }
        }
        val cr = ctx.contentResolver
        val uri = cr.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("تعذر إنشاء الملف")
        cr.openOutputStream(uri)?.use { os -> file.inputStream().use { it.copyTo(os) } }
            ?: throw IllegalStateException("تعذر الكتابة")
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            cr.update(uri, v, null, null)
        }
        return uri
    }
}
