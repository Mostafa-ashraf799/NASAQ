package com.binarybeast.mediastudio.ui

import android.content.Context
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binarybeast.mediastudio.R
import com.binarybeast.mediastudio.data.Brand
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

/** سطر الصانع الصغير. */
@Composable
fun MadeBy(modifier: Modifier = Modifier) {
    Text(
        "${Brand.MADE_BY} ✦",
        color = TextDim, fontSize = 11.sp, letterSpacing = 1.sp,
        textAlign = TextAlign.Center, modifier = modifier
    )
}

/** الشاشة الافتتاحية: أيقونة التطبيق + الاسم + الصانع. */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        a.animateTo(1f, tween(900))
        delay(1100)
        onDone()
    }
    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Image(
                painterResource(R.drawable.nasaq_mark), null,
                modifier = Modifier.size(150.dp).alpha(a.value).scale(0.8f + 0.2f * a.value),
                contentScale = ContentScale.Fit
            )
            Text("نسق", fontSize = 40.sp, color = Silver, modifier = Modifier.padding(top = 16.dp).alpha(a.value))
            Text("NASAQ", fontSize = 14.sp, letterSpacing = 6.sp, color = TextDim, modifier = Modifier.alpha(a.value))
        }
        Column(
            Modifier.fillMaxSize().navigationBarsPadding().padding(bottom = 28.dp),
            verticalArrangement = Arrangement.Bottom, horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(Brand.MADE_BY, fontSize = 13.sp, color = TextDim, modifier = Modifier.alpha(a.value))
            Text(Brand.NAME, fontSize = 18.sp, letterSpacing = 5.sp, color = Accent, modifier = Modifier.alpha(a.value))
        }
    }
}

private fun dirSize(f: File): Long =
    if (f.isFile) f.length() else (f.listFiles()?.sumOf { dirSize(it) } ?: 0L)

/** عن التطبيق: الصانع + حجم التخزين + مسح الكاش. */
@Composable
fun AboutDialog(onDismiss: () -> Unit) {
    val ctx: Context = LocalContext.current
    var projectsBytes by remember { mutableStateOf(-1L) }
    var cacheBytes by remember { mutableStateOf(-1L) }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            projectsBytes = dirSize(File(ctx.filesDir, "projects"))
            cacheBytes = dirSize(ctx.cacheDir)
        }
    }
    fun mb(b: Long) = if (b < 0) "..." else "%.1f MB".format(b / 1048576.0)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface1,
        title = { Text("نسق • NASAQ") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Image(painterResource(R.drawable.nasaq_mark), null, modifier = Modifier.size(72.dp).align(Alignment.CenterHorizontally))
                Text(
                    "استوديو تحرير الصور والفيديو والصوت",
                    color = TextDim, fontSize = 13.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
                Text(
                    Brand.MADE_BY, fontSize = 16.sp, color = Accent, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                )
                Text(Brand.NAME, fontSize = 22.sp, letterSpacing = 6.sp, color = Silver, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                SectionLabel("التخزين")
                Text("المشاريع: ${mb(projectsBytes)}", fontSize = 13.sp)
                Text("ملفات مؤقتة: ${mb(cacheBytes)}", fontSize = 13.sp)
                SmallButton("مسح الملفات المؤقتة", {
                    kotlin.concurrent.thread {
                        runCatching { ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() } }
                        cacheBytes = dirSize(ctx.cacheDir)
                    }
                }, modifier = Modifier.padding(top = 8.dp))
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("تمام", color = Accent) } }
    )
}
