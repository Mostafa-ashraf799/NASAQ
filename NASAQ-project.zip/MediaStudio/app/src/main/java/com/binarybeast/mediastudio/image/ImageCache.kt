package com.binarybeast.mediastudio.image

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.LruCache
import com.binarybeast.mediastudio.data.TextLayer

/** كاش لصور الطبقات (لوجو/صور فوق الصورة أو الفيديو). الرسم بيقرأ من الكاش بس، والتحميل بيتم قبلها. */
object ImageCache {
    private val cache = object : LruCache<String, Bitmap>(96 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun get(uri: String): Bitmap? = cache.get(uri)

    /** تحميل متزامن (استدعيه من خيط خلفي). */
    fun load(ctx: Context, uri: String, maxSide: Int = 2048): Bitmap? {
        cache.get(uri)?.let { return it }
        val b = BitmapLoader.load(ctx, Uri.parse(uri), maxSide) ?: return null
        cache.put(uri, b)
        return b
    }

    fun preload(ctx: Context, layers: List<TextLayer>) {
        layers.forEach { l -> l.imageUri?.let { runCatching { load(ctx, it) } } }
    }
}
