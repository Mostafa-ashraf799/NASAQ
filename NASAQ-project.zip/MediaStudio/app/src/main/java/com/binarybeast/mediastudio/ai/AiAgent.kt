package com.binarybeast.mediastudio.ai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlin.coroutines.coroutineContext

/** حدث بيظهر في واجهة الشات. kind: assistant | tool | image | error */
class AiEvent(val kind: String, val text: String = "", val images: List<String> = emptyList())

object AiAgent {
    private val block = Regex("```(?:nasaq|json)?\\s*(\\{[\\s\\S]*?\\})\\s*```")

    private fun parseCalls(reply: String): List<JSONObject> =
        block.findAll(reply).mapNotNull { m -> runCatching { JSONObject(m.groupValues[1]) }.getOrNull() }
            .filter { it.has("tool") }.toList()

    fun strip(reply: String): String = block.replace(reply) { m -> if (runCatching { JSONObject(m.groupValues[1]).has("tool") }.getOrDefault(false)) "" else m.value }.trim()

    /** حلقة الوكيل: بيطلب من الموديل، ينفّذ الأدوات، ويرجّع النتايج لحد ما يخلص (أقصى 8 خطوات). */
    suspend fun run(
        ctx: Context, cfg: AiConfig, tools: AiTools, history: MutableList<AiMsg>, emit: suspend (AiEvent) -> Unit
    ) = withContext(Dispatchers.IO) {
        val mcp = if (cfg.mcpUrl.isNotBlank()) McpClient(cfg.mcpUrl, cfg.mcpToken) else null
        var mcpTools: List<McpTool> = emptyList()
        if (mcp != null) {
            mcpTools = try { mcp.tools() } catch (t: Throwable) { emit(AiEvent("error", "MCP: ${t.message}")); emptyList() }
        }
        for (step in 0 until 8) {
            coroutineContext.ensureActive()
            val sys = AiPrompts.system(cfg, mcpTools, tools.info())
            val reply = try { AiClient.chat(cfg, sys, history) } catch (t: Throwable) {
                emit(AiEvent("error", t.message ?: "فشل الاتصال")); return@withContext
            }
            history.add(AiMsg("assistant", reply))
            val calls = parseCalls(reply)
            val shown = strip(reply)
            if (shown.isNotBlank()) emit(AiEvent("assistant", shown))
            if (calls.isEmpty()) return@withContext
            val results = StringBuilder("TOOL_RESULTS:\n")
            val imgs = ArrayList<String>()
            for (c in calls.take(8)) {
                coroutineContext.ensureActive()
                val name = c.optString("tool")
                val args = c.optJSONObject("args") ?: JSONObject()
                emit(AiEvent("tool", name))
                if (name.startsWith("mcp:")) {
                    val r = try {
                        if (mcp == null) McpResult("ERROR: no MCP server configured", emptyList()) else mcp.call(name.removePrefix("mcp:"), args)
                    } catch (t: Throwable) { McpResult("ERROR: ${t.message}", emptyList()) }
                    results.append("[$name] ${r.text}\n")
                    if (r.images.isNotEmpty()) {
                        emit(AiEvent("image", name, r.images))
                        if (cfg.sendImages) imgs.addAll(r.images.take(2))
                    }
                } else {
                    val r = tools.run(name, args)
                    results.append("[$name] ${r.text}\n")
                    imgs.addAll(r.images)
                }
            }
            history.add(AiMsg("user", results.toString().trim(), imgs))
        }
        emit(AiEvent("error", "وصلت لأقصى عدد خطوات في الطلب الواحد. اكتب 'كمّل' لو عايزه يكمل."))
    }
}
