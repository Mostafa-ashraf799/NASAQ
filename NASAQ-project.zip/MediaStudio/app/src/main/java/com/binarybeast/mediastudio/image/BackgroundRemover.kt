package com.binarybeast.mediastudio.image

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** عزل الشخص عن الخلفية بنموذج ML Kit للـ Selfie Segmentation (يشتغل على الجهاز بدون إنترنت). */
object BackgroundRemover {

    /** يرجّع صورة شفافة الخلفية، أو null لو فشل. */
    suspend fun cutout(src: Bitmap): Bitmap? {
        val m = mask(src) ?: return null
        val (conf, mw, mh) = m
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        for (y in 0 until h) {
            val my = (y.toLong() * mh / h).toInt().coerceIn(0, mh - 1)
            for (x in 0 until w) {
                val mx = (x.toLong() * mw / w).toInt().coerceIn(0, mw - 1)
                val c = conf[my * mw + mx]
                // smoothstep بين 0.3 و 0.7 لحواف ناعمة
                val t = ((c - 0.3f) / 0.4f).coerceIn(0f, 1f)
                val a = t * t * (3f - 2f * t)
                val i = y * w + x
                val oldA = (px[i] ushr 24) and 0xFF
                px[i] = (px[i] and 0x00FFFFFF) or (((a * oldA).toInt().coerceIn(0, 255)) shl 24)
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    private suspend fun mask(bmp: Bitmap): Triple<FloatArray, Int, Int>? = suspendCancellableCoroutine { cont ->
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .enableRawSizeMask()
            .build()
        val segmenter = Segmentation.getClient(options)
        cont.invokeOnCancellation { runCatching { segmenter.close() } }
        segmenter.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { m ->
                try {
                    val w = m.width
                    val h = m.height
                    val buf = m.buffer
                    buf.rewind()
                    val arr = FloatArray(w * h)
                    for (i in arr.indices) arr[i] = buf.float
                    runCatching { segmenter.close() }
                    if (cont.isActive) cont.resume(Triple(arr, w, h))
                } catch (e: Throwable) {
                    runCatching { segmenter.close() }
                    if (cont.isActive) cont.resume(null)
                }
            }
            .addOnFailureListener {
                runCatching { segmenter.close() }
                if (cont.isActive) cont.resume(null)
            }
    }
}
