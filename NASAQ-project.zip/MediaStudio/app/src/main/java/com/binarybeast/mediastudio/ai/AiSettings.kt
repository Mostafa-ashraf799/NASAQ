package com.binarybeast.mediastudio.ai

import android.content.Context

/** إعدادات مساعد الذكاء الاصطناعي (بيتا). البيانات بتتخزن على الجهاز بس. */
data class AiConfig(
    /** 0 = OpenAI-compatible (OpenAI, Gemini، OpenRouter، Groq، Ollama، LM Studio...)، 1 = Anthropic */
    val proto: Int = 0,
    val baseUrl: String = "",
    val apiKey: String = "",
    val model: String = "",
    val mcpUrl: String = "",
    val mcpToken: String = "",
    val allowEdits: Boolean = true,
    val sendImages: Boolean = true,
    val extraPrompt: String = "",
) {
    val effectiveBase: String
        get() = baseUrl.trim().trimEnd('/').ifBlank { if (proto == 1) "https://api.anthropic.com" else "https://api.openai.com/v1" }

    val apiReady: Boolean get() = model.isNotBlank() && (apiKey.isNotBlank() || baseUrl.isNotBlank())
}

object AiSettings {
    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences("nasaq_ai", Context.MODE_PRIVATE)

    fun load(ctx: Context): AiConfig {
        val s = p(ctx)
        return AiConfig(
            proto = s.getInt("proto", 0), baseUrl = s.getString("base", "") ?: "", apiKey = s.getString("key", "") ?: "",
            model = s.getString("model", "") ?: "", mcpUrl = s.getString("mcpUrl", "") ?: "", mcpToken = s.getString("mcpToken", "") ?: "",
            allowEdits = s.getBoolean("edits", true), sendImages = s.getBoolean("images", true), extraPrompt = s.getString("extra", "") ?: ""
        )
    }

    fun save(ctx: Context, c: AiConfig) {
        p(ctx).edit()
            .putInt("proto", c.proto).putString("base", c.baseUrl.trim()).putString("key", c.apiKey.trim())
            .putString("model", c.model.trim()).putString("mcpUrl", c.mcpUrl.trim()).putString("mcpToken", c.mcpToken.trim())
            .putBoolean("edits", c.allowEdits).putBoolean("images", c.sendImages).putString("extra", c.extraPrompt)
            .apply()
    }
}
