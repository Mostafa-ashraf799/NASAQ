package com.binarybeast.mediastudio.data

import android.content.Context
import android.net.Uri
import android.graphics.BitmapFactory
import com.binarybeast.mediastudio.Graph
import com.binarybeast.mediastudio.image.BitmapLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** إنشاء المشاريع الجديدة (بيتنفذ على IO لأنه بيقرأ ملفات). */
object ProjectFactory {

    fun defaultName(prefix: String): String =
        "$prefix ${SimpleDateFormat("d/M HH:mm", Locale.getDefault()).format(Date())}"

    private var idSeed = System.nanoTime()
    fun nextId(): Long = ++idSeed

    suspend fun createImageProject(ctx: Context, name: String, uri: Uri): Project = withContext(Dispatchers.IO) {
        val repo = Graph.repo
        val id = repo.newId()
        val local = repo.importIfNeeded(id, uri)
        val now = System.currentTimeMillis()
        val p = Project(
            id = id, name = name.ifBlank { defaultName("صورة") }, type = ProjectType.IMAGE,
            createdAt = now, updatedAt = now,
            image = ImageData(sourceUri = local.toString())
        )
        repo.save(p)
        // مصغّر مبدئي
        BitmapLoader.load(ctx, local, 480)?.let { repo.saveThumb(id, it) }
        p
    }

    suspend fun createBlankProject(name: String, w: Int, h: Int, color: Int): Project = withContext(Dispatchers.IO) {
        val repo = Graph.repo
        val id = repo.newId()
        val now = System.currentTimeMillis()
        val p = Project(
            id = id, name = name.ifBlank { defaultName("لوحة") }, type = ProjectType.IMAGE,
            createdAt = now, updatedAt = now,
            image = ImageData(sourceUri = null, blankW = w, blankH = h, blankColor = color)
        )
        repo.save(p)
        p
    }

    /** مشروع صوتي من ملف صوت (أو فيديو لاستخراج صوته). */
    suspend fun createAudioProject(ctx: Context, name: String, uri: Uri): Project? = withContext(Dispatchers.IO) {
        val repo = Graph.repo
        val id = repo.newId()
        val local = repo.importIfNeeded(id, uri, forceCopy = true)
        val dur = MediaRepository.probeAudioDuration(ctx, local)
        if (dur <= 0L) { repo.delete(id); return@withContext null }
        val label = repo.displayName(uri).substringBeforeLast('.')
        val now = System.currentTimeMillis()
        val p = Project(
            id = id, name = name.ifBlank { label.ifBlank { defaultName("صوت") } }, type = ProjectType.AUDIO,
            createdAt = now, updatedAt = now,
            audio = AudioData(uri = local.toString(), name = label, srcDurationMs = dur, startMs = 0L, endMs = dur)
        )
        repo.save(p)
        p
    }

    suspend fun createVideoProject(ctx: Context, name: String, uris: List<Uri>): Project = withContext(Dispatchers.IO) {
        val repo = Graph.repo
        val id = repo.newId()
        val clips = uris.mapNotNull { makeClip(ctx, id, it) }
        val now = System.currentTimeMillis()
        val p = Project(
            id = id, name = name.ifBlank { defaultName("فيديو") }, type = ProjectType.VIDEO,
            createdAt = now, updatedAt = now,
            video = VideoData(clips = clips)
        )
        repo.save(p)
        clips.firstOrNull()?.let { c ->
            val u = Uri.parse(c.uri)
            val bmp = if (c.isImage) BitmapLoader.load(ctx, u, 480) else MediaRepository.frameAt(ctx, u, c.startMs)
            bmp?.let { repo.saveThumb(id, it) }
        }
        p
    }

    /** يحوّل ملف (فيديو أو صورة) إلى مقطع في التايم لاين. */
    fun makeClip(ctx: Context, projectId: String, uri: Uri): VideoClip? {
        val local = Graph.repo.importIfNeeded(projectId, uri)
        return if (MediaRepository.isVideoUri(ctx, local)) {
            val info = MediaRepository.probeVideo(ctx, local)
            if (info.durationMs <= 0L) return null
            VideoClip(
                id = nextId(), uri = local.toString(), isImage = false,
                srcDurationMs = info.durationMs, startMs = 0L, endMs = info.durationMs,
                width = info.width, height = info.height
            )
        } else {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            runCatching { ctx.contentResolver.openInputStream(local)?.use { BitmapFactory.decodeStream(it, null, o) } }
            VideoClip(
                id = nextId(), uri = local.toString(), isImage = true,
                srcDurationMs = 30_000L, startMs = 0L, endMs = 3_000L,
                width = o.outWidth.coerceAtLeast(1), height = o.outHeight.coerceAtLeast(1),
                fill = true
            )
        }
    }
}
