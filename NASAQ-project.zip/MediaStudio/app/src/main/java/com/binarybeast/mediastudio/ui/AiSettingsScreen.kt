package com.binarybeast.mediastudio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Cable
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binarybeast.mediastudio.ai.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class Preset(val name: String, val proto: Int, val base: String, val model: String)

private val presets = listOf(
    Preset("Anthropic (Claude)", 1, "https://api.anthropic.com", "claude-sonnet-5-5"),
    Preset("OpenAI", 0, "https://api.openai.com/v1", "gpt-4o-mini"),
    Preset("Gemini", 0, "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.0-flash"),
    Preset("OpenRouter", 0, "https://openrouter.ai/api/v1", "openai/gpt-4o-mini"),
    Preset("Ollama محلي", 0, "http://192.168.1.10:11434/v1", "llava"),
)

@Composable
private fun SettingsCard(icon: ImageVector, title: String, desc: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surface1).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(Surface2), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Accent, modifier = Modifier.size(20.dp))
            }
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        }
        Text(desc, fontSize = 13.sp, lineHeight = 19.sp, color = TextDim)
        content()
    }
}

@Composable
private fun Field(label: String, value: String, onChange: (String) -> Unit, secret: Boolean = false, hint: String = "", lines: Int = 1) {
    OutlinedTextField(
        value, onChange, Modifier.fillMaxWidth(), singleLine = lines == 1, minLines = lines, maxLines = if (lines == 1) 1 else 6,
        label = { Text(label) }, placeholder = { if (hint.isNotEmpty()) Text(hint, color = TextDim) },
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None
    )
}

@Composable
private fun SwitchRow(title: String, desc: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(desc, fontSize = 12.sp, color = TextDim, lineHeight = 17.sp)
        }
        Switch(on, onChange)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiSettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    var c by remember { mutableStateOf(AiSettings.load(ctx)) }
    var apiMsg by remember { mutableStateOf("") }
    var apiBusy by remember { mutableStateOf(false) }
    var mcpMsg by remember { mutableStateOf("") }
    var mcpBusy by remember { mutableStateOf(false) }

    fun save(close: Boolean) {
        AiSettings.save(ctx, c); McpControl.apply(ctx, c)
        toast(ctx, "اتحفظت الإعدادات")
        if (close) onBack()
    }

    Scaffold(
        containerColor = Bg,
        topBar = {
            TopAppBar(
                title = { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { Text("إعدادات NASAQ Ai"); BetaBadge() } },
                navigationIcon = { IconButton(onClick = { save(true) }) { Icon(Icons.Default.ArrowBack, "رجوع") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Surface1)
            )
        },
        bottomBar = {
            Box(Modifier.fillMaxWidth().background(Surface1).navigationBarsPadding().padding(12.dp)) {
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Accent)
                        .androidxClickable { save(true) }.padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center
                ) { Text("حفظ ورجوع", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary) }
            }
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp).widthIn(max = 900.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ------------------------------------------------------------ 1) API
            SettingsCard(
                Icons.Default.AutoAwesome, "1) مزوّد الذكاء الاصطناعي (API)",
                "ده اللي بيخلي الشات يرد عليك. اختار المزوّد، وحط مفتاح الـ API بتاعك والموديل. المفتاح بيتخزن على جهازك بس وبيتبعت للمزوّد اللي تحدده بس. الموديل لازم يدعم الصور لو هتبعتله صور."
            ) {
                Text("إعداد سريع (بيملا الخانات تحت):", fontSize = 12.sp, color = TextDim)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    presets.forEach { p -> Chip(p.name, false, { c = c.copy(proto = p.proto, baseUrl = p.base, model = p.model) }) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("OpenAI-compatible", c.proto == 0, { c = c.copy(proto = 0) })
                    Chip("Anthropic", c.proto == 1, { c = c.copy(proto = 1) })
                }
                Field("عنوان الـ API (Base URL)", c.baseUrl, { c = c.copy(baseUrl = it) }, hint = c.effectiveBase)
                Field("مفتاح الـ API", c.apiKey, { c = c.copy(apiKey = it) }, secret = true)
                Field("اسم الموديل", c.model, { c = c.copy(model = it) }, hint = "مثال: claude-sonnet-5-5")
                SmallButton(if (apiBusy) "بيختبر..." else "اختبار الاتصال", {
                    if (apiBusy) return@SmallButton
                    apiBusy = true; apiMsg = ""
                    scope.launch {
                        apiMsg = withContext(Dispatchers.IO) {
                            if (!c.apiReady) "ناقص الموديل أو المفتاح"
                            else try { "✓ شغّال: " + AiClient.chat(c, "Reply with the single word: ok", listOf(AiMsg("user", "ping"))).take(40) } catch (t: Throwable) { "✗ ${t.message}" }
                        }
                        apiBusy = false
                    }
                })
                if (apiMsg.isNotBlank()) Text(apiMsg, fontSize = 13.sp)
            }

            // ------------------------------------------------------------ 2) permissions
            SettingsCard(
                Icons.Default.Security, "2) صلاحيات الـ AI",
                "تتحكم في اللي الـ AI يقدر يعمله. الـ AI ملوش أي وصول لمعرض الصور أو ملفات الجهاز في كل الأحوال، بيشوف المشروع اللي انت تختاره بس."
            ) {
                SwitchRow("يعدّل المشروع", "يسمح للـ AI يغيّر الألوان والفلاتر ويضيف نصوص وغيره. لو مقفول بيكتفي بالنصايح.", c.allowEdits) { c = c.copy(allowEdits = it) }
                SwitchRow("يستقبل صور المشروع", "يسمح بإرسال صورة المشروع للمزوّد عشان يحلّلها. لو مقفول مفيش أي صورة بتخرج من الجهاز.", c.sendImages) { c = c.copy(sendImages = it) }
            }

            // ------------------------------------------------------------ 3) MCP client
            SettingsCard(
                Icons.Default.Cable, "3) ربط أدوات خارجية (MCP)",
                "لو عندك سيرفر MCP (مثلًا لتوليد صور أو بحث)، حط رابطه هنا، ونسق هيخلّي الـ AI يستخدم أدواته جنب أدوات التطبيق. الصور اللي بيرجّعها السيرفر بتظهر في الشات وتقدر تفتحها كمشروع. اختياري."
            ) {
                Field("رابط سيرفر MCP (HTTP)", c.mcpUrl, { c = c.copy(mcpUrl = it) }, hint = "https://example.com/mcp")
                Field("توكن السيرفر (اختياري)", c.mcpToken, { c = c.copy(mcpToken = it) }, secret = true)
                SmallButton(if (mcpBusy) "بيختبر..." else "اختبار MCP", {
                    if (mcpBusy) return@SmallButton
                    mcpBusy = true; mcpMsg = ""
                    scope.launch {
                        mcpMsg = withContext(Dispatchers.IO) {
                            if (c.mcpUrl.isBlank()) "اكتب الرابط الأول"
                            else try { "✓ اتصل: ${McpClient(c.mcpUrl, c.mcpToken).tools().size} أداة" } catch (t: Throwable) { "✗ ${t.message}" }
                        }
                        mcpBusy = false
                    }
                })
                if (mcpMsg.isNotBlank()) Text(mcpMsg, fontSize = 13.sp)
            }

            // ------------------------------------------------------------ 4) server
            SettingsCard(
                Icons.Default.Dns, "4) نسق كسيرفر MCP (ربط AI خارجي بالتطبيق)",
                "العكس: بتخلّي نسق نفسه سيرفر، فأي AI على الكمبيوتر (Claude Code أو Claude Desktop أو Cursor) يتوصل بالتطبيق ويستخدم أدواته مباشرة. الموبايل والكمبيوتر على نفس الواي فاي، والتطبيق يفضل شغال (هيظهر إشعار)."
            ) {
                SwitchRow("تشغيل السيرفر", "بيفتح منفذ على الموبايل ومحمي بتوكن سري.", c.serverOn) { on ->
                    c = c.copy(serverOn = on, serverToken = c.serverToken.ifBlank { McpControl.newToken() })
                }
                if (c.serverOn) {
                    val addr = McpServer.addresses().firstOrNull() ?: "IP-الموبايل"
                    val url = "http://$addr:${c.serverPort}/mcp"
                    Field("المنفذ (Port)", c.serverPort.toString(), { v -> v.filter { it.isDigit() }.toIntOrNull()?.let { n -> c = c.copy(serverPort = n.coerceIn(1024, 65535)) } })
                    Field("التوكن (سر الاتصال)", c.serverToken, { c = c.copy(serverToken = it) })
                    Text("الرابط: $url", fontSize = 13.sp)
                    Text("ملحوظة: الاتصال HTTP عادي، فاستخدمه على شبكة بيتك بس. لو شاركت التوكن اعمل توكن جديد.", fontSize = 12.sp, color = TextDim)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmallButton("أمر Claude Code", {
                            clip.setText(AnnotatedString("claude mcp add --transport http nasaq $url --header \"Authorization: Bearer ${c.serverToken}\"")); toast(ctx, "اتنسخ")
                        })
                        SmallButton("إعداد Claude Desktop", {
                            clip.setText(AnnotatedString("{\"mcpServers\":{\"nasaq\":{\"command\":\"npx\",\"args\":[\"mcp-remote\",\"$url\",\"--allow-http\",\"--header\",\"Authorization: Bearer ${c.serverToken}\"]}}}")); toast(ctx, "اتنسخ")
                        })
                        SmallButton("الرابط", { clip.setText(AnnotatedString(url)); toast(ctx, "اتنسخ") })
                        SmallButton("توكن جديد", { c = c.copy(serverToken = McpControl.newToken()) })
                    }
                }
            }

            // ------------------------------------------------------------ 5) extra prompt
            SettingsCard(
                Icons.Default.Edit, "5) تعليمات مخصصة",
                "أي حاجة تكتبها هنا بتتضاف لتعليمات الـ AI في كل محادثة. مثلًا: «رد بالمصري»، أو «خلّي التعديلات خفيفة دايمًا»، أو «أنا مصمم سوشيال ميديا»."
            ) {
                Field("تعليماتك", c.extraPrompt, { c = c.copy(extraPrompt = it) }, lines = 3)
            }

            // ------------------------------------------------------------ 6) guide
            SettingsCard(
                Icons.Default.MenuBook, "6) دليل الأدوات للـ AI",
                "ملف شرح بيعرّف أي AI كل أدوات نسق (صور، فيديو، صوت، كانفس) وإزاي يستخدمها بقيم محددة. نسق بيبعته للـ AI تلقائي، وتقدر تنسخه لو بتستخدم AI تاني."
            ) {
                SmallButton("نسخ دليل الأدوات", { clip.setText(AnnotatedString(AiPrompts.toolGuide)); toast(ctx, "اتنسخ دليل الأدوات") })
                Text("وفي مكتبة جاهزة من ${AiPrompts.library.sumOf { it.second.size }} برومت في صفحة الشات (زر المكتبة).", fontSize = 12.sp, color = TextDim)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

private fun Modifier.androidxClickable(onClick: () -> Unit): Modifier = this.then(Modifier.clickable(onClick = onClick))
