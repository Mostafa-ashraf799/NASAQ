package com.binarybeast.mediastudio.image

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** اكتشاف الوجوه (ML Kit، على الجهاز) وتجميل البشرة. */
object FaceTools {

    suspend fun detect(bmp: Bitmap): List<Rect>? = suspendCancellableCoroutine { cont ->
        val opts = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .build()
        val det = FaceDetection.getClient(opts)
        cont.invokeOnCancellation { runCatching { det.close() } }
        det.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { faces ->
                runCatching { det.close() }
                if (cont.isActive) cont.resume(faces.map { it.boundingBox })
            }
            .addOnFailureListener {
                runCatching { det.close() }
                if (cont.isActive) cont.resume(null)
            }
    }

    private fun lum(c: Int): Float = 0.299f * ((c shr 16) and 255) + 0.587f * ((c shr 8) and 255) + 0.114f * (c and 255)

    /** تنعيم بشرة يحافظ على الحواف (العين/الفم/الشعر) داخل بيضاوي الوجه + تفتيح خفيف. */
    fun smooth(b: Bitmap, faces: List<Rect>, strength: Float, brighten: Float) {
        for (f in faces) {
            val padX = (f.width() * 0.08f).toInt(); val padY = (f.height() * 0.12f).toInt()
            val x0 = max(0, f.left - padX); val y0 = max(0, f.top - padY)
            val x1 = min(b.width, f.right + padX); val y1 = min(b.height, f.bottom + padY)
            val rw = x1 - x0; val rh = y1 - y0
            if (rw < 16 || rh < 16) continue
            val crop = Bitmap.createBitmap(b, x0, y0, rw, rh)
            val k = max(2, rw / 40)
            val small = Bitmap.createScaledBitmap(crop, max(1, rw / k), max(1, rh / k), true)
            val blur = Bitmap.createScaledBitmap(small, rw, rh, true)
            val po = IntArray(rw * rh); val pb = IntArray(rw * rh)
            crop.getPixels(po, 0, rw, 0, 0, rw, rh)
            blur.getPixels(pb, 0, rw, 0, 0, rw, rh)
            val cx = rw / 2f; val cy = rh / 2f
            for (y in 0 until rh) for (x in 0 until rw) {
                val nx = (x - cx) / cx; val ny = (y - cy) / cy
                val d2 = nx * nx + ny * ny
                if (d2 >= 1f) continue
                val m = (1f - d2).coerceIn(0f, 1f).let { it * it * (3f - 2f * it) }
                val i = y * rw + x
                val o = po[i]; val bl = pb[i]
                val diff = abs(lum(o) - lum(bl))
                val e = (1f - ((diff - 10f) / 26f).coerceIn(0f, 1f))
                val t = strength.coerceIn(0f, 1f) * m * e
                val br = 1f + brighten * m * 0.15f
                fun ch(s: Int): Int {
                    val ov = (o shr s) and 255; val bv = (bl shr s) and 255
                    return ((ov + (bv - ov) * t) * br).toInt().coerceIn(0, 255)
                }
                po[i] = (o and -16777216) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
            }
            b.setPixels(po, 0, rw, x0, y0, rw, rh)
            crop.recycle(); small.recycle(); blur.recycle()
        }
    }
}
