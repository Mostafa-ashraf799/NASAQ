package com.binarybeast.mediastudio.image

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import jp.co.cyberagent.android.gpuimage.GPUImage
import jp.co.cyberagent.android.gpuimage.filter.GPUImageBulgeDistortionFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageCrosshatchFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageGlassSphereFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageHalftoneFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageKuwaharaFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImagePinchDistortionFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageSketchFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageSobelEdgeDetectionFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageStretchDistortionFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageSwirlFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageToonFilter
import jp.co.cyberagent.android.gpuimage.filter.GPUImageZoomBlurFilter

/** مؤثرات GPU جاهزة بمكتبة GPUImage. */
object GpuFx {
    val names = listOf(
        "دوامة", "انتفاخ", "قرص", "كرة زجاجية", "كرتون", "رسم زيتي (Kuwahara)",
        "تظليل متقاطع", "هاف-تون", "رسم حبر", "تمدّد", "تمويه زووم", "كشف الحواف",
    )

    private fun make(kind: Int): GPUImageFilter = when (kind) {
        0 -> GPUImageSwirlFilter()
        1 -> GPUImageBulgeDistortionFilter()
        2 -> GPUImagePinchDistortionFilter()
        3 -> GPUImageGlassSphereFilter()
        4 -> GPUImageToonFilter()
        5 -> GPUImageKuwaharaFilter()
        6 -> GPUImageCrosshatchFilter()
        7 -> GPUImageHalftoneFilter()
        8 -> GPUImageSketchFilter()
        9 -> GPUImageStretchDistortionFilter()
        10 -> GPUImageZoomBlurFilter()
        else -> GPUImageSobelEdgeDetectionFilter()
    }

    /** يطبّق المؤثر على الـ Bitmap نفسه (لازم يكون قابل للتعديل) ويحافظ على الشفافية. */
    fun apply(ctx: Context, b: Bitmap, kind: Int): Boolean {
        return try {
            val w = b.width; val h = b.height
            val before = IntArray(w * h)
            b.getPixels(before, 0, w, 0, 0, w, h)
            val g = GPUImage(ctx)
            g.setImage(b)
            g.setFilter(make(kind))
            val r = g.bitmapWithFilterApplied ?: return false
            val p = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC) }
            Canvas(b).drawBitmap(r, 0f, 0f, p)
            if (r !== b) r.recycle()
            val after = IntArray(w * h)
            b.getPixels(after, 0, w, 0, 0, w, h)
            for (i in after.indices) after[i] = (before[i] and -16777216) or (after[i] and 0xFFFFFF)
            b.setPixels(after, 0, w, 0, 0, w, h)
            true
        } catch (t: Throwable) { false }
    }
}
