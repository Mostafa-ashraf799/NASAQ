package com.binarybeast.mediastudio.image

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import com.binarybeast.mediastudio.data.ImageFx
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * المؤثرات المتقدمة للصور. كل الدوال بتشتغل على IntArray من getPixels/setPixels
 * (من غير أي نداء per-pixel على الـ Bitmap)، وبترجّع نفس الـ Bitmap فورًا لو مفيش تأثير.
 */
object ImageFxProcessor {

    private const val A_MASK = -16777216 // 0xFF000000

    val creativeNames = listOf(
        0 to "بدون", 1 to "عكس الألوان", 2 to "بوستر", 3 to "سولار", 4 to "أبيض/أسود حاد",
        5 to "نقش", 6 to "سكتش", 7 to "جليتش", 8 to "دوتون غروب", 9 to "دوتون محيط",
        10 to "دوتون نيون", 11 to "هاف-تون", 12 to "مرآة أفقية", 13 to "مرآة رأسية",
        14 to "كاليدوسكوب", 15 to "رسم زيتي",
    )

    // ---------------------------------------------------------------- stages

    /** المرحلة الأولى: ضوضاء → إضاءة/لون → وضوح → فلتر إبداعي. */
    fun stageA(b: Bitmap, f: ImageFx): Bitmap {
        val needTone = f.toneActive
        val needClarity = abs(f.clarity) > 0.01f
        val needDenoise = f.denoise > 0.01f
        val needFilter = f.filter != 0 && f.filterAmount > 0.01f
        if (!needTone && !needClarity && !needDenoise && !needFilter) return b
        return try {
            val w = b.width
            val h = b.height
            var px = IntArray(w * h)
            b.getPixels(px, 0, w, 0, 0, w, h)
            if (needDenoise) denoise(px, w, h, f.denoise)
            if (needTone) tone(px, f)
            if (needClarity) clarity(px, w, h, f.clarity)
            if (needFilter) px = creative(px, w, h, f.filter, f.filterAmount)
            val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            res.setPixels(px, 0, w, 0, 0, w, h)
            res
        } catch (t: OutOfMemoryError) {
            b
        }
    }

    /** المرحلة الثانية: تيلت-شيفت (تركيز) ثم انحراف لوني. */
    fun stageB(b: Bitmap, f: ImageFx): Bitmap {
        val needFocus = f.focus > 0.01f
        val needChroma = f.chroma > 0.01f
        if (!needFocus && !needChroma) return b
        return try {
            val w = b.width
            val h = b.height
            var px = IntArray(w * h)
            b.getPixels(px, 0, w, 0, 0, w, h)
            if (needFocus) px = tiltShift(px, w, h, f)
            if (needChroma) px = chromatic(px, w, h, f.chroma)
            val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            res.setPixels(px, 0, w, 0, 0, w, h)
            res
        } catch (t: OutOfMemoryError) {
            b
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun cl(v: Int): Int = if (v < 0) 0 else if (v > 255) 255 else v

    private fun q(v: Float): Int {
        val x = (v * 255f + 0.5f).toInt()
        return if (x < 0) 0 else if (x > 255) 255 else x
    }

    private fun lum(c: Int): Int =
        ((((c shr 16) and 255) * 77) + (((c shr 8) and 255) * 150) + ((c and 255) * 29)) shr 8

    private fun gray(src: Int, v: Int): Int = (src and A_MASK) or (v shl 16) or (v shl 8) or v

    private fun mix(a: Int, b: Int, t: Float): Int {
        val ar = (a shr 16) and 255
        val ag = (a shr 8) and 255
        val ab = a and 255
        val r = (ar + ((((b shr 16) and 255) - ar) * t)).toInt()
        val g = (ag + ((((b shr 8) and 255) - ag) * t)).toInt()
        val bl = (ab + (((b and 255) - ab) * t)).toInt()
        return (a and A_MASK) or (r shl 16) or (g shl 8) or bl
    }

    private fun smooth(x: Float): Float {
        val t = if (x < 0f) 0f else if (x > 1f) 1f else x
        return t * t * (3f - 2f * t)
    }

    private fun cx(v: Int, w: Int): Int = if (v < 0) 0 else if (v >= w) w - 1 else v

    /** نسخة مموّهة من الصورة (تصغير تدريجي ثم تكبير بفلتر). factor = درجة التمويه. */
    private fun blurred(px: IntArray, w: Int, h: Int, factor: Float): IntArray {
        val src = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        src.setPixels(px, 0, w, 0, 0, w, h)
        val f = if (factor < 1.5f) 1.5f else factor
        val tw = max(1, (w / f).toInt())
        val th = max(1, (h / f).toInt())
        var cur = src
        var cw = w
        var ch = h
        while (cw / 2 >= tw && ch / 2 >= th && cw >= 2 && ch >= 2) {
            cw /= 2
            ch /= 2
            cur = Bitmap.createScaledBitmap(cur, cw, ch, true)
        }
        if (cw > tw || ch > th) cur = Bitmap.createScaledBitmap(cur, min(cw, tw), min(ch, th), true)
        val back = Bitmap.createScaledBitmap(cur, w, h, true)
        val out = IntArray(w * h)
        back.getPixels(out, 0, w, 0, 0, w, h)
        return out
    }

    private fun lutApply(px: IntArray, lut: IntArray): IntArray {
        val out = IntArray(px.size)
        for (i in px.indices) {
            val c = px[i]
            out[i] = (c and A_MASK) or (lut[(c shr 16) and 255] shl 16) or
                (lut[(c shr 8) and 255] shl 8) or lut[c and 255]
        }
        return out
    }

    // ---------------------------------------------------------------- tone

    /** إضاءة/تعريض + هايلايت + شادو + وايتس + بلاكس + تينت + فيبرانس + ديهيز في مرور واحد. */
    private fun tone(px: IntArray, f: ImageFx) {
        val mult = 2f.pow(f.exposure * 1.3f)
        val hi = f.highlights * 0.35f
        val sh = f.shadows * 0.35f
        val bp = -f.blacks * 0.12f
        val wp = 1f - f.whites * 0.12f
        val invRange = 1f / (wp - bp)
        val doRange = f.blacks != 0f || f.whites != 0f
        val doSh = hi != 0f || sh != 0f
        val tr = f.tint * 0.06f
        val tg = -f.tint * 0.08f
        val vib = f.vibrance
        val dz = f.dehaze
        val dzK = 1f + dz * 0.4f
        val dzS = 1f + dz * 0.25f
        for (i in px.indices) {
            val c = px[i]
            var r = ((c shr 16) and 255) / 255f
            var g = ((c shr 8) and 255) / 255f
            var b = (c and 255) / 255f
            if (mult != 1f) {
                r *= mult; g *= mult; b *= mult
            }
            if (doSh) {
                val l = 0.299f * r + 0.587f * g + 0.114f * b
                val lc = if (l < 0f) 0f else if (l > 1f) 1f else l
                val inv = 1f - lc
                val d = sh * inv * inv + hi * lc * lc
                r += d; g += d; b += d
            }
            if (doRange) {
                r = (r - bp) * invRange
                g = (g - bp) * invRange
                b = (b - bp) * invRange
            }
            if (tr != 0f) {
                r += tr; g += tg; b += tr
            }
            if (vib != 0f) {
                val mx = max(r, max(g, b))
                val mn = min(r, min(g, b))
                var s = mx - mn
                if (s < 0f) s = 0f else if (s > 1f) s = 1f
                val k = 1f + vib * (1f - s)
                val l = 0.299f * r + 0.587f * g + 0.114f * b
                r = l + (r - l) * k
                g = l + (g - l) * k
                b = l + (b - l) * k
            }
            if (dz != 0f) {
                val off = 0.5f - dz * 0.05f
                r = (r - 0.5f) * dzK + off
                g = (g - 0.5f) * dzK + off
                b = (b - 0.5f) * dzK + off
                val l = 0.299f * r + 0.587f * g + 0.114f * b
                r = l + (r - l) * dzS
                g = l + (g - l) * dzS
                b = l + (b - l) * dzS
            }
            px[i] = (c and A_MASK) or (q(r) shl 16) or (q(g) shl 8) or q(b)
        }
    }

    /** وضوح: تباين محلي على الدرجات الوسطى (سالب = تنعيم). */
    private fun clarity(px: IntArray, w: Int, h: Int, amt: Float) {
        val bl = blurred(px, w, h, max(4f, max(w, h) / 80f))
        val k = amt * 1.4f
        for (i in px.indices) {
            val c = px[i]
            val lc = lum(c)
            val d = (lc - lum(bl[i])).toFloat()
            val mid = 1f - abs(lc - 128) / 160f
            val add = (k * d * mid).toInt()
            val r = cl(((c shr 16) and 255) + add)
            val g = cl(((c shr 8) and 255) + add)
            val b = cl((c and 255) + add)
            px[i] = (c and A_MASK) or (r shl 16) or (g shl 8) or b
        }
    }

    /** تقليل ضوضاء / تنعيم بشرة: تمويه بيحافظ على الحواف القوية. */
    private fun denoise(px: IntArray, w: Int, h: Int, amt: Float) {
        val a = amt.coerceIn(0f, 1f)
        val bl = blurred(px, w, h, 1.5f + a * 2.5f)
        val edge = 30f + 40f * a
        for (i in px.indices) {
            val c = px[i]
            val d = abs(lum(c) - lum(bl[i])).toFloat()
            val ratio = d / edge
            val wgt = a * (1f - (if (ratio > 1f) 1f else ratio))
            if (wgt > 0.004f) px[i] = mix(c, bl[i], wgt)
        }
    }

    // ---------------------------------------------------------------- creative filters

    private fun creative(px: IntArray, w: Int, h: Int, kind: Int, amt: Float): IntArray {
        val a = amt.coerceIn(0f, 1f)
        var intrinsic = false
        val out: IntArray = when (kind) {
            1 -> lutApply(px, IntArray(256) { 255 - it })
            2 -> {
                intrinsic = true
                val n = (9f - a * 7f).roundToInt().coerceIn(2, 8)
                val step = 255f / (n - 1)
                lutApply(px, IntArray(256) { ((it / step).roundToInt() * step).roundToInt().coerceIn(0, 255) })
            }
            3 -> {
                intrinsic = true
                val thr = 255 - (a * 155f).toInt()
                lutApply(px, IntArray(256) { if (it > thr) 255 - it else it })
            }
            4 -> IntArray(px.size) { gray(px[it], if (lum(px[it]) > 128) 255 else 0) }
            5 -> emboss(px, w, h)
            6 -> sketch(px, w, h)
            7 -> {
                intrinsic = true
                glitch(px, w, h, a)
            }
            8 -> duotone(px, 0x2D1B69, 0xFFB347)
            9 -> duotone(px, 0x03264C, 0x6DD5ED)
            10 -> duotone(px, 0x240046, 0xFF2E93)
            11 -> halftone(px, w, h)
            12 -> mirror(px, w, h, true)
            13 -> mirror(px, w, h, false)
            14 -> kaleido(px, w, h)
            15 -> paint(px, w, h)
            else -> px
        }
        if (!intrinsic && out !== px) {
            for (i in px.indices) out[i] = mix(px[i], out[i], a)
        }
        return out
    }

    private fun emboss(px: IntArray, w: Int, h: Int): IntArray {
        val out = IntArray(px.size) { gray(px[it], 128) }
        if (w < 3 || h < 3) return out
        val l = IntArray(px.size) { lum(px[it]) }
        for (y in 1 until h - 1) {
            var i = y * w + 1
            for (x in 1 until w - 1) {
                val d = (l[i - w - 1] - l[i + w + 1]) * 3 / 2
                out[i] = gray(px[i], cl(128 + d))
                i++
            }
        }
        return out
    }

    private fun sketch(px: IntArray, w: Int, h: Int): IntArray {
        val out = IntArray(px.size) { gray(px[it], 255) }
        if (w < 3 || h < 3) return out
        val l = IntArray(px.size) { lum(px[it]) }
        for (y in 1 until h - 1) {
            var i = y * w + 1
            for (x in 1 until w - 1) {
                val gx = l[i + 1] - l[i - 1]
                val gy = l[i + w] - l[i - w]
                out[i] = gray(px[i], cl(255 - (abs(gx) + abs(gy)) * 2))
                i++
            }
        }
        return out
    }

    private fun glitch(px: IntArray, w: Int, h: Int, a: Float): IntArray {
        val out = IntArray(px.size)
        val rowOff = IntArray(h)
        val rnd = java.util.Random(7L)
        repeat(7) {
            val y0 = rnd.nextInt(h)
            val bh = 1 + rnd.nextInt(max(1, h / 18))
            val off = ((rnd.nextFloat() - 0.5f) * 2f * w * 0.07f * a).toInt()
            var y = y0
            while (y < min(h, y0 + bh)) {
                rowOff[y] = off
                y++
            }
        }
        val s = (w * 0.015f * a).toInt() + 1
        for (y in 0 until h) {
            val base = y * w
            val off = rowOff[y]
            for (x in 0 until w) {
                val cg = px[base + cx(x + off, w)]
                val cr = px[base + cx(x + off + s, w)]
                val cb = px[base + cx(x + off - s, w)]
                out[base + x] = (px[base + x] and A_MASK) or (((cr shr 16) and 255) shl 16) or
                    (((cg shr 8) and 255) shl 8) or (cb and 255)
            }
        }
        return out
    }

    private fun duotone(px: IntArray, dark: Int, light: Int): IntArray {
        val lr = IntArray(256)
        val lg = IntArray(256)
        val lb = IntArray(256)
        for (i in 0 until 256) {
            val t = i / 255f
            lr[i] = (((dark shr 16) and 255) + ((((light shr 16) and 255) - ((dark shr 16) and 255)) * t)).toInt()
            lg[i] = (((dark shr 8) and 255) + ((((light shr 8) and 255) - ((dark shr 8) and 255)) * t)).toInt()
            lb[i] = ((dark and 255) + (((light and 255) - (dark and 255)) * t)).toInt()
        }
        val out = IntArray(px.size)
        for (i in px.indices) {
            val c = px[i]
            val l = lum(c)
            out[i] = (c and A_MASK) or (lr[l] shl 16) or (lg[l] shl 8) or lb[l]
        }
        return out
    }

    private fun halftone(px: IntArray, w: Int, h: Int): IntArray {
        val s = max(5, max(w, h) / 100)
        val paper = 0xF4EFE6
        val out = IntArray(px.size)
        for (y in 0 until h) {
            val cyc = min(h - 1, (y / s) * s + s / 2)
            val dy = y - ((y / s) * s + s / 2f)
            for (x in 0 until w) {
                val cxc = min(w - 1, (x / s) * s + s / 2)
                val dx = x - ((x / s) * s + s / 2f)
                val cc = px[cyc * w + cxc]
                val rad = sqrt(1f - lum(cc) / 255f) * s * 0.72f
                val i = y * w + x
                out[i] = if (dx * dx + dy * dy <= rad * rad) {
                    (px[i] and A_MASK) or (cc and 0x00FFFFFF)
                } else {
                    (px[i] and A_MASK) or paper
                }
            }
        }
        return out
    }

    private fun mirror(px: IntArray, w: Int, h: Int, horizontal: Boolean): IntArray {
        val out = IntArray(px.size)
        for (y in 0 until h) {
            val sy = if (!horizontal && y >= h / 2) h - 1 - y else y
            for (x in 0 until w) {
                val sx = if (horizontal && x >= w / 2) w - 1 - x else x
                out[y * w + x] = px[sy * w + sx]
            }
        }
        return out
    }

    private fun kaleido(px: IntArray, w: Int, h: Int): IntArray {
        if (w < 2 || h < 2) return px
        val out = IntArray(px.size)
        val hw = w / 2f
        val hh = h / 2f
        for (y in 0 until h) {
            val v = if (y < hh) y.toFloat() else (h - 1 - y).toFloat()
            var nv = v / hh
            for (x in 0 until w) {
                val u = if (x < hw) x.toFloat() else (w - 1 - x).toFloat()
                var nu = u / hw
                var nvv = nv
                if (nu > nvv) {
                    val t = nu; nu = nvv; nvv = t
                }
                val sx = min(w - 1, (nu * hw).toInt())
                val sy = min(h - 1, (nvv * hh).toInt())
                out[y * w + x] = px[sy * w + sx]
            }
        }
        return out
    }

    private fun paint(px: IntArray, w: Int, h: Int): IntArray {
        val bl = blurred(px, w, h, 2.5f)
        val step = 255f / 9f
        val lut = IntArray(256) { ((it / step).roundToInt() * step).roundToInt().coerceIn(0, 255) }
        val out = lutApply(bl, lut)
        for (i in out.indices) out[i] = mix(out[i], px[i], 0.25f)
        return out
    }

    // ---------------------------------------------------------------- focus / chroma

    private fun tiltShift(px: IntArray, w: Int, h: Int, f: ImageFx): IntArray {
        val bl = blurred(px, w, h, 3f + f.focus.coerceIn(0f, 1f) * 16f)
        val out = IntArray(px.size)
        val fy = f.focusY.coerceIn(0f, 1f)
        val fxx = f.focusX.coerceIn(0f, 1f)
        if (f.focusMode != 1) {
            for (y in 0 until h) {
                val d = abs(y / h.toFloat() - fy)
                val t = smooth((d - 0.10f) / 0.30f)
                val base = y * w
                if (t <= 0.003f) {
                    System.arraycopy(px, base, out, base, w)
                } else {
                    for (x in 0 until w) out[base + x] = mix(px[base + x], bl[base + x], t)
                }
            }
        } else {
            val m = min(w, h).toFloat()
            val ccx = fxx * w
            val ccy = fy * h
            for (y in 0 until h) {
                val dy = (y - ccy) / m
                val base = y * w
                for (x in 0 until w) {
                    val dx = (x - ccx) / m
                    val t = smooth((sqrt(dx * dx + dy * dy) - 0.15f) / 0.35f)
                    out[base + x] = if (t <= 0.003f) px[base + x] else mix(px[base + x], bl[base + x], t)
                }
            }
        }
        return out
    }

    private fun chromatic(px: IntArray, w: Int, h: Int, amt: Float): IntArray {
        val out = IntArray(px.size)
        val s = amt.coerceIn(0f, 1f) * 0.02f * w
        val ccx = (w - 1) / 2f
        val ccy = (h - 1) / 2f
        val ix = 1f / max(ccx, 1f)
        val iy = 1f / max(ccy, 1f)
        for (y in 0 until h) {
            val ny = (y - ccy) * iy
            val oy = (ny * s).toInt()
            for (x in 0 until w) {
                val nx = (x - ccx) * ix
                val ox = (nx * s).toInt()
                val rr = px[cx(y + oy, h) * w + cx(x + ox, w)]
                val bb = px[cx(y - oy, h) * w + cx(x - ox, w)]
                val i = y * w + x
                val c = px[i]
                out[i] = (c and A_MASK) or (((rr shr 16) and 255) shl 16) or (c and 0x0000FF00) or (bb and 255)
            }
        }
        return out
    }

    // ---------------------------------------------------------------- overlays

    /** تسريب ضوء (Screen blend) بأربع أنماط. */
    fun drawLeak(c: Canvas, w: Int, h: Int, amt: Float, style: Int) {
        val a = (amt.coerceIn(0f, 1f) * 0.85f * 255f).toInt()
        val wf = w.toFloat()
        val hf = h.toFloat()
        val big = max(wf, hf)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
        p.shader = when (style) {
            1 -> RadialGradient(
                wf * 0.92f, hf * 0.08f, big * 0.75f,
                intArrayOf((a shl 24) or 0xFF3D81, 0x00FF3D81), null, Shader.TileMode.CLAMP
            )
            2 -> LinearGradient(
                0f, hf, 0f, hf * 0.45f,
                (a shl 24) or 0x19D3C5, 0x0019D3C5, Shader.TileMode.CLAMP
            )
            3 -> RadialGradient(
                wf * 0.5f, 0f, big * 0.8f,
                intArrayOf((a shl 24) or 0xFFC93C, ((a / 3) shl 24) or 0xFF8A3D, 0x00FF8A3D),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
            )
            else -> LinearGradient(
                0f, 0f, wf * 0.55f, 0f,
                (a shl 24) or 0xFF7A18, 0x00FF7A18, Shader.TileMode.CLAMP
            )
        }
        c.drawRect(0f, 0f, wf, hf, p)
    }

    /** غبار وخدوش فيلم (ثابتة بالـ seed عشان المعاينة والتصدير يطلعوا زي بعض). */
    fun drawDust(c: Canvas, w: Int, h: Int, amt: Float) {
        val a = amt.coerceIn(0f, 1f)
        val sc = max(w, h) / 1280f
        val rnd = java.util.Random(99L)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val n = (20 + a * 140f).toInt()
        for (i in 0 until n) {
            val x = rnd.nextFloat() * w
            val y = rnd.nextFloat() * h
            val r = (0.6f + rnd.nextFloat() * rnd.nextFloat() * 3f) * sc
            p.color = if (rnd.nextFloat() < 0.3f) 0xFF101010.toInt() else 0xFFF5F5F0.toInt()
            p.alpha = 110 + rnd.nextInt(120)
            c.drawCircle(x, y, r, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = max(1f, 0.8f * sc)
        val hairs = (3 + a * 18f).toInt()
        for (i in 0 until hairs) {
            val x = rnd.nextFloat() * w
            val y = rnd.nextFloat() * h
            val path = Path()
            path.moveTo(x, y)
            path.quadTo(
                x + (rnd.nextFloat() - 0.5f) * 60f * sc, y + (rnd.nextFloat() - 0.5f) * 60f * sc,
                x + (rnd.nextFloat() - 0.5f) * 90f * sc, y + (rnd.nextFloat() - 0.5f) * 90f * sc
            )
            p.color = 0xFFF5F5F0.toInt()
            p.alpha = 70 + rnd.nextInt(110)
            c.drawPath(path, p)
        }
    }
}
