package com.binarybeast.mediastudio.audio

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/** اكتشاف الإيقاع (Onsets) من PCM: بيرجّع أزمنة الضربات بالميلي ثانية. */
object BeatDetector {
    fun find(p: AudioPcm.Pcm, minGapMs: Long = 350L): List<Long> {
        val hop = (p.rate / 50).coerceAtLeast(1)          // 20ms
        val frames = p.data.size / p.ch / hop
        if (frames < 20) return emptyList()
        val e = FloatArray(frames)
        for (f in 0 until frames) {
            var s = 0.0
            val start = f * hop * p.ch
            var k = 0
            while (k < hop * p.ch && start + k < p.data.size) { s += abs(p.data[start + k].toInt()); k += p.ch }
            e[f] = (s / hop).toFloat()
        }
        val flux = FloatArray(frames)
        for (i in 8 until frames) {
            var m = 0f
            for (j in i - 8 until i) m += e[j]
            m /= 8f
            flux[i] = max(0f, e[i] - m)
        }
        var mean = 0.0
        for (v in flux) mean += v
        mean /= frames
        var sd = 0.0
        for (v in flux) sd += (v - mean) * (v - mean)
        sd = sqrt(sd / frames)
        val thr = (mean + 1.3 * sd).toFloat()
        val out = ArrayList<Long>()
        var last = -minGapMs
        for (i in 9 until frames - 1) {
            if (flux[i] > thr && flux[i] >= flux[i - 1] && flux[i] >= flux[i + 1]) {
                val t = i * 20L
                if (t - last >= minGapMs) { out.add(t); last = t }
            }
        }
        return out
    }
}
