package com.binarybeast.mediastudio.image

import android.content.Context
import com.binarybeast.mediastudio.data.ImageEdit
import com.binarybeast.mediastudio.data.ProjectJson
import org.json.JSONObject

/** حفظ إعدادات التعديل (ألوان/فلاتر/تأثيرات) كـ Presets وتطبيقها على أي صورة. */
object PresetStore {
    private const val FILE = "nasaq_presets"
    private const val KEY = "list"

    private fun load(ctx: Context): JSONObject =
        runCatching { JSONObject(ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY, "{}") ?: "{}") }
            .getOrDefault(JSONObject())

    fun names(ctx: Context): List<String> {
        val o = load(ctx)
        return o.keys().asSequence().toList().sorted()
    }

    /** بنحفظ الجزء اللوني/التأثيري بس (من غير القص والنصوص والرسم). */
    fun save(ctx: Context, name: String, e: ImageEdit) {
        val clean = ImageEdit(
            adjust = e.adjust, lookId = e.lookId, lookStrength = e.lookStrength, sharpen = e.sharpen,
            blur = e.blur, vignette = e.vignette, fade = e.fade, grain = e.grain, pixelate = e.pixelate, fx = e.fx
        )
        val o = load(ctx)
        o.put(name.trim(), ProjectJson.imageEdit(clean))
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    fun delete(ctx: Context, name: String) {
        val o = load(ctx)
        o.remove(name)
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    /** يطبّق الـ Preset على التعديل الحالي ويحافظ على القص والطبقات. */
    fun apply(ctx: Context, name: String, cur: ImageEdit): ImageEdit {
        val o = load(ctx).optJSONObject(name) ?: return cur
        val p = runCatching { ProjectJson.readImageEdit(o) }.getOrNull() ?: return cur
        return cur.copy(
            adjust = p.adjust, lookId = p.lookId, lookStrength = p.lookStrength, sharpen = p.sharpen,
            blur = p.blur, vignette = p.vignette, fade = p.fade, grain = p.grain, pixelate = p.pixelate, fx = p.fx
        )
    }
}
