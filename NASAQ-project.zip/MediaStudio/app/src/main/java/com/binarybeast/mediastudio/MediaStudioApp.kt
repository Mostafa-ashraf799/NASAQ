package com.binarybeast.mediastudio

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.binarybeast.mediastudio.data.ProjectRepository

object Graph {
    lateinit var repo: ProjectRepository
        private set

    fun init(app: Application) {
        repo = ProjectRepository(app)
    }
}

class MediaStudioApp : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        Graph.init(this)
        runCatching { com.binarybeast.mediastudio.ai.McpControl.apply(this, com.binarybeast.mediastudio.ai.AiSettings.load(this)) }
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                java.io.File(filesDir, "crash.txt").writeText(
                    "NASAQ crash ${java.util.Date()}\nthread=${t.name}\n" + android.util.Log.getStackTraceString(e)
                )
            }
            prev?.uncaughtException(t, e)
        }
    }

    /** Coil مع دعم استخراج لقطات من الفيديو للمصغّرات. */
    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .components { add(VideoFrameDecoder.Factory()) }
            .crossfade(true)
            .build()
}
