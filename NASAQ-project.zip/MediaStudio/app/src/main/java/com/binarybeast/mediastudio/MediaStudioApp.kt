package com.binarybeast.mediastudio

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.binarybeast.mediastudio.data.ProjectRepository

object Graph {
    lateinit var repo: ProjectRepository
        private set

    fun init(app: Application) {
        repo = ProjectRepository(app)
    }
}

class MediaStudioApp : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        Graph.init(this)
    }

    /** Coil مع دعم استخراج لقطات من الفيديو للمصغّرات. */
    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .components { add(VideoFrameDecoder.Factory()) }
            .crossfade(true)
            .build()
}
