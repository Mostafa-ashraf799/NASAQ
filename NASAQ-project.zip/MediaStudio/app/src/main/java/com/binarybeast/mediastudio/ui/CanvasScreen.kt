package com.binarybeast.mediastudio.ui

import android.graphics.BitmapFactory
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.binarybeast.mediastudio.Graph
import com.binarybeast.mediastudio.data.CanvasExport
import com.binarybeast.mediastudio.data.CanvasStore
import com.binarybeast.mediastudio.data.Project
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CanvasScreen(id: String, onBack: () -> Unit, onEditPage: (String) -> Unit, onOpenProject: (Project) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var canvas by remember { mutableStateOf<Project?>(null) }
    var pages by remember { mutableStateOf<List<Project>>(emptyList()) }
    var reload by remember { mutableStateOf(0) }
    var showExport by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Project?>(null) }
    var busyMsg by remember { mutableStateOf<String?>(null) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) reload++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    LaunchedEffect(reload) {
        withContext(Dispatchers.IO) {
            canvas = Graph.repo.load(id)
            pages = CanvasStore.pages(id)
        }
    }
    BackHandler(onBack = onBack)

    fun mutate(block: () -> Unit) {
        scope.launch { withContext(Dispatchers.IO) { block() }; reload++ }
    }

    val c = canvas?.canvas
    Scaffold(
        containerColor = Bg,
        topBar = {
            TopAppBar(
                title = { Text(canvas?.name ?: "كانفس", maxLines = 1) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    Row(
                        Modifier.padding(end = 8.dp).clip(RoundedCornerShape(14.dp)).background(Accent)
                            .clickable { showExport = true }.padding(horizontal = 18.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.FileDownload, null, tint = MaterialTheme.colorScheme.onPrimary)
                        Text("تصدير", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Surface1)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (c != null) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    SectionLabel("مقاس الصفحات (${c.w}×${c.h})")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CanvasStore.sizes.forEach { (label, w, h) ->
                            Chip(label, c.w == w && c.h == h, { mutate { CanvasStore.restyle(id, w, h, null) } })
                        }
                    }
                    SectionLabel("لون خلفية الصفحات")
                    ColorRow(c.bg, onPick = { col -> mutate { CanvasStore.restyle(id, null, null, col) } })
                }
            }
            LazyVerticalGrid(
                columns = GridCells.Adaptive(170.dp),
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(pages.size, key = { pages[it].id }) { i ->
                    val pg = pages[i]
                    PageCard(
                        index = i, count = pages.size, page = pg, ratio = c?.let { it.w.toFloat() / it.h } ?: 1f,
                        onEdit = { onEditPage(pg.id) },
                        onDup = { mutate { CanvasStore.addPage(id, i, duplicateOf = pg.id) } },
                        onDelete = { deleting = pg },
                        onLeft = { mutate { CanvasStore.movePage(id, i, i - 1) } },
                        onRight = { mutate { CanvasStore.movePage(id, i, i + 1) } },
                        stamp = reload
                    )
                }
                item {
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(c?.let { it.w.toFloat() / it.h } ?: 1f).clip(RoundedCornerShape(14.dp))
                            .background(Surface2).clickable { mutate { CanvasStore.addPage(id, pages.lastIndex) } },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Add, null, tint = Accent, modifier = Modifier.size(44.dp))
                            Text("صفحة جديدة", fontSize = 16.sp, color = Accent, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    deleting?.let { pg ->
        AlertDialog(
            onDismissRequest = { deleting = null }, containerColor = Surface1,
            title = { Text("حذف الصفحة؟") },
            text = { Text(if (pages.size <= 1) "لازم يفضل صفحة واحدة على الأقل." else "الصفحة هتتمسح نهائيًا.") },
            confirmButton = { TextButton(onClick = { deleting = null; mutate { CanvasStore.deletePage(id, pg.id) } }) { Text("حذف", color = Danger) } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("إلغاء", color = TextDim) } }
        )
    }

    if (showExport && canvas != null) {
        ExportDialog(
            canvas = canvas!!, pageCount = pages.size,
            onDismiss = { showExport = false },
            onOpenVideo = { showExport = false; onOpenProject(it) }
        )
    }
    busyMsg?.let { LoadingDialog(it) }
}

@Composable
private fun PageCard(
    index: Int, count: Int, page: Project, ratio: Float, stamp: Int,
    onEdit: () -> Unit, onDup: () -> Unit, onDelete: () -> Unit, onLeft: () -> Unit, onRight: () -> Unit
) {
    val repo = Graph.repo
    val bmp = remember(page.id, page.updatedAt, stamp) {
        runCatching { BitmapFactory.decodeFile(repo.thumbFile(page.id).absolutePath)?.asImageBitmap() }.getOrNull()
    }
    Column(Modifier.clip(RoundedCornerShape(14.dp)).background(Surface1).border(1.dp, Surface2, RoundedCornerShape(14.dp))) {
        Box(Modifier.fillMaxWidth().aspectRatio(ratio).background(Color.White).clickable(onClick = onEdit)) {
            if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            Text(
                "${index + 1}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(6.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xAA000000)).padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        Row(Modifier.fillMaxWidth().padding(4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onLeft, enabled = index > 0) { Icon(Icons.Default.ArrowForward, "قبل", tint = if (index > 0) Silver else TextDim.copy(0.3f)) }
            IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "تحرير", tint = Accent) }
            IconButton(onClick = onDup) { Icon(Icons.Default.ContentCopy, "نسخ", tint = Silver) }
            IconButton(onClick = onDelete, enabled = count > 1) { Icon(Icons.Default.Delete, "حذف", tint = if (count > 1) Danger else TextDim.copy(0.3f)) }
            IconButton(onClick = onRight, enabled = index < count - 1) { Icon(Icons.Default.ArrowBack, "بعد", tint = if (index < count - 1) Silver else TextDim.copy(0.3f)) }
        }
    }
}

@Composable
private fun ExportDialog(canvas: Project, pageCount: Int, onDismiss: () -> Unit, onOpenVideo: (Project) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var fmt by remember { mutableStateOf(CanvasExport.Fmt.PDF) }
    var wm by remember { mutableStateOf(true) }
    var secs by remember { mutableStateOf(3f) }
    var ken by remember { mutableStateOf(true) }
    var running by remember { mutableStateOf(false) }
    var prog by remember { mutableStateOf(0 to pageCount) }
    var result by remember { mutableStateOf<CanvasExport.Result?>(null) }

    AlertDialog(
        onDismissRequest = { if (!running) onDismiss() },
        containerColor = Surface1,
        title = { Text("تصدير الكانفس ($pageCount صفحة)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                val r = result
                if (r != null) {
                    Text(r.message, fontSize = 15.sp)
                    if (r.shareUri != null) {
                        Spacer(Modifier.height(12.dp))
                        SmallButton("مشاركة", { shareUri(ctx, r.shareUri, r.mime) }, Modifier.fillMaxWidth())
                    }
                    if (r.video != null) {
                        Spacer(Modifier.height(12.dp))
                        SmallButton("افتح في محرر الفيديو", { onOpenVideo(r.video) }, Modifier.fillMaxWidth())
                    }
                } else if (running) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp), color = Accent, strokeWidth = 3.dp)
                        Text("جاري تجهيز الصفحة ${prog.first} من ${prog.second}...")
                    }
                } else {
                    SectionLabel("الصيغة")
                    CanvasExport.Fmt.values().toList().chunked(2).forEach { row ->
                        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { f ->
                                val sel = fmt == f
                                Box(
                                    Modifier.weight(1f).height(64.dp).clip(RoundedCornerShape(14.dp))
                                        .background(if (sel) Accent else Surface2).clickable { fmt = f },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(f.label, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                                        color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface)
                                }
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                    Chip(if (wm) "علامة NASAQ مفعّلة (اضغط لإلغائها)" else "إضافة علامة NASAQ", wm, { wm = !wm })
                    if (fmt == CanvasExport.Fmt.VIDEO) {
                        SectionLabel("مدة كل صفحة: ${"%.1f".format(secs)} ثانية")
                        Slider(value = secs, onValueChange = { secs = it }, valueRange = 1f..10f)
                        Chip(if (ken) "حركة زووم بطيئة: شغّالة" else "حركة زووم بطيئة: مقفولة", ken, { ken = !ken })
                        Text("الفيديو هيتفتح في محرر الفيديو، وتقدر تضيف موسيقى وانتقالات وتصدّره منه (العلامة بتتضاف عند تصدير الفيديو).",
                            fontSize = 12.sp, color = TextDim, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
        },
        confirmButton = {
            if (result == null && !running) {
                TextButton(onClick = {
                    running = true
                    scope.launch {
                        val r = CanvasExport.export(ctx, canvas, fmt, wm, secs, ken) { a, b -> prog = a to b }
                        result = r; running = false
                    }
                }) { Text("تصدير", color = Accent, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            } else if (!running) TextButton(onClick = onDismiss) { Text("تم", color = Accent) }
        },
        dismissButton = { if (!running && result == null) TextButton(onClick = onDismiss) { Text("إلغاء", color = TextDim) } }
    )
}
