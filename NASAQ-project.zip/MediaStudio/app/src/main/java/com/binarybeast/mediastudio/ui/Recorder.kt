package com.binarybeast.mediastudio.ui

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binarybeast.mediastudio.data.formatDuration
import kotlinx.coroutines.delay
import java.io.File

/** نافذة تسجيل صوت من المايك. بترجّع ملف M4A محفوظ في فولدر التطبيق. */
@Composable
fun RecordDialog(onRecorded: (Uri) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var hasPerm by remember {
        mutableStateOf(ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    var recording by remember { mutableStateOf(false) }
    var elapsed by remember { mutableStateOf(0L) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var file by remember { mutableStateOf<File?>(null) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasPerm = it }

    fun start() {
        val dir = File(ctx.filesDir, "recordings").apply { mkdirs() }
        val f = File(dir, "rec_${System.currentTimeMillis()}.m4a")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128_000)
            r.setAudioSamplingRate(44_100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            file = f
            elapsed = 0L
            recording = true
        } catch (e: Throwable) {
            runCatching { r.release() }
            toast(ctx, "تعذّر بدء التسجيل")
        }
    }

    /** يوقف التسجيل. بيرجع true لو الملف سليم. */
    fun stop(): Boolean {
        val r = recorder ?: return false
        recorder = null
        recording = false
        return try {
            r.stop(); r.release(); true
        } catch (e: Throwable) {
            runCatching { r.release() }
            file?.delete()
            false
        }
    }

    LaunchedEffect(recording) {
        while (recording) {
            delay(250)
            elapsed += 250
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            recorder?.let { runCatching { it.stop() }; runCatching { it.release() } }
            recorder = null
        }
    }

    AlertDialog(
        onDismissRequest = { if (!recording) onDismiss() },
        containerColor = Surface1,
        title = { Text("تسجيل صوت") },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(formatDuration(elapsed), fontSize = 34.sp)
                Box(
                    Modifier
                        .padding(top = 16.dp)
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(if (recording) Danger else Accent)
                        .clickable {
                            when {
                                !hasPerm -> permLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                !recording -> start()
                                else -> {
                                    val f = file
                                    if (stop() && f != null && f.length() > 0) onRecorded(Uri.fromFile(f))
                                    else toast(ctx, "التسجيل قصير جدًا")
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    NIc(if (recording) NI.Stop else NI.Mic, "تسجيل", tint = Color.White, modifier = Modifier.size(38.dp))
                }
                Text(
                    when {
                        !hasPerm -> "اضغط للسماح باستخدام المايك"
                        recording -> "جاري التسجيل... اضغط للإيقاف والحفظ"
                        else -> "اضغط لبدء التسجيل"
                    },
                    color = TextDim, fontSize = 12.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 12.dp)
                )
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = {
                if (recording) { stop(); file?.delete() }
                onDismiss()
            }) { Text("إلغاء", color = TextDim) }
        }
    )
}
