package com.binarybeast.mediastudio.image

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * أدوات ريتوش بكسلية (زي أدوات فوتوشوب) بتشتغل مباشرة على Bitmap قابلة للتعديل.
 * كل الإحداثيات بالبكسل، والـ radius نصف قطر الفرشاة، hard = صلابة الحافة 0..1، k = القوة 0..1.
 */
object Retouch {

    class Region(val x0: Int, val y0: Int, val w: Int, val h: Int, val px: IntArray)

    private fun region(b: Bitmap, cx: Float, cy: Float, rad: Float): Region? {
        val x0 = max(0, (cx - rad).toInt())
        val y0 = max(0, (cy - rad).toInt())
        val x1 = min(b.width, (cx + rad).toInt() + 1)
        val y1 = min(b.height, (cy + rad).toInt() + 1)
        val w = x1 - x0
        val h = y1 - y0
        if (w <= 0 || h <= 0) return null
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, x0, y0, w, h)
        return Region(x0, y0, w, h, px)
    }

    private fun commit(b: Bitmap, r: Region) = b.setPixels(r.px, 0, r.w, r.x0, r.y0, r.w, r.h)

    private fun weight(d: Float, rad: Float, hard: Float): Float {
        val t = d / rad
        if (t >= 1f) return 0f
        val hh = hard.coerceIn(0f, 0.98f)
        if (t <= hh) return 1f
        val u = (1f - t) / (1f - hh)
        return u * u * (3f - 2f * u)
    }

    private fun cl(v: Int) = if (v < 0) 0 else if (v > 255) 255 else v
    private fun pack(a: Int, r: Int, g: Int, b: Int) = (cl(a) shl 24) or (cl(r) shl 16) or (cl(g) shl 8) or cl(b)
    private fun mix(c1: Int, c2: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        fun ch(s: Int) = (((c1 shr s) and 255) + ((((c2 shr s) and 255) - ((c1 shr s) and 255)) * k)).toInt()
        return pack(ch(24), ch(16), ch(8), ch(0))
    }
    private fun lum(c: Int) = (((c shr 16) and 255) * 77 + ((c shr 8) and 255) * 150 + (c and 255) * 29) shr 8

    /** يمر على كل بكسل جوه الدائرة ويطبّق op(pixel, weight). */
    private inline fun each(r: Region, cx: Float, cy: Float, rad: Float, hard: Float, op: (Int, Int, Float) -> Int) {
        for (yy in 0 until r.h) for (xx in 0 until r.w) {
            val f = weight(hypot(r.x0 + xx - cx, r.y0 + yy - cy), rad, hard)
            if (f > 0f) {
                val i = yy * r.w + xx
                r.px[i] = op(i, r.px[i], f)
            }
        }
    }

    // ------------------------------------------------------------ brush tools

    fun erase(b: Bitmap, cx: Float, cy: Float, rad: Float, hard: Float, k: Float) {
        val r = region(b, cx, cy, rad) ?: return
        each(r, cx, cy, rad, hard) { _, c, f ->
            val a = ((c ushr 24) * (1f - f * k)).toInt()
            (c and 0x00FFFFFF) or (cl(a) shl 24)
        }
        commit(b, r)
    }

    private fun boxAvg(r: Region, rr: Int): IntArray {
        val out = IntArray(r.px.size)
        for (y in 0 until r.h) for (x in 0 until r.w) {
            var sa = 0; var sr = 0; var sg = 0; var sb = 0; var n = 0
            for (yy in max(0, y - rr)..min(r.h - 1, y + rr)) for (xx in max(0, x - rr)..min(r.w - 1, x + rr)) {
                val c = r.px[yy * r.w + xx]
                sa += c ushr 24; sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255; n++
            }
            out[y * r.w + x] = pack(sa / n, sr / n, sg / n, sb / n)
        }
        return out
    }

    fun blur(b: Bitmap, cx: Float, cy: Float, rad: Float, hard: Float, k: Float) {
        val r = region(b, cx, cy, rad) ?: return
        val avg = boxAvg(r, 2)
        each(r, cx, cy, rad, hard) { i, c, f -> mix(c, avg[i], f * k) }
        commit(b, r)
    }

    fun sharpen(b: Bitmap, cx: Float, cy: Float, rad: Float, hard: Float, k: Float) {
        val r = region(b, cx, cy, rad) ?: return
        val avg = boxAvg(r, 1)
        each(r, cx, cy, rad, hard) { i, c, f ->
            val a = avg[i]
            val s = f * k * 1.6f
            fun sh(sft: Int) = ((c shr sft) and 255) + ((((c shr sft) and 255) - ((a shr sft) and 255)) * s).toInt()
            pack(c ushr 24, sh(16), sh(8), sh(0))
        }
        commit(b, r)
    }

    /** تلطيخ: بيسحب الألوان من مكان الفرشاة السابق (dx,dy = حركة الفرشاة). */
    fun smudge(b: Bitmap, cx: Float, cy: Float, rad: Float, hard: Float, k: Float, dx: Float, dy: Float) {
        val m = rad + abs(dx) + abs(dy) + 2f
        val big = region(b, cx, cy, m) ?: return
        val copy = big.px.copyOf()
        val r = Region(big.x0, big.y0, big.w, big.h, big.px)
        each(r, cx, cy, rad, hard) { i, c, f ->
            val xx = i % r.w
            val yy = i / r.w
            val sx = (xx - dx).toInt().coerceIn(0, r.w - 1)
            val sy = (yy - dy).toInt().coerceIn(0, r.h - 1)
            mix(c, copy[sy * r.w + sx], f * (0.35f + k * 0.6f))
        }
        commit(b, r)
    }

    /** dodge: amount موجب = تفتيح، سالب = تعتيم. */
    fun exposure(b: Bitmap, cx: Float, cy: Float, rad: Float, hard: Float, k: Float, dodge: Boolean) {
        val r = region(b, cx, cy, rad) ?: return
        each(r, cx, cy, rad, hard) { _, c, f ->
            val s = f * k * 0.22f
            val m = if (dodge) 1f + s else 1f - s
            val add = if (dodge) (s * 40f).toInt() else 0
            pack(c ushr 24, (((c shr 16) and 255) * m).toInt() + add, (((c shr 8) and 255) * m).toInt() + add, ((c and 255) * m).toInt() + add)
        }
        commit(b, r)
    }

    fun sponge(b: Bitmap, cx: Float, cy: Float, rad: Float, hard: Float, k: Float, saturate: Boolean) {
        val r = region(b, cx, cy, rad) ?: return
        each(r, cx, cy, rad, hard) { _, c, f ->
            val l = lum(c)
            val s = 1f + (if (saturate) 1f else -1f) * f * k * 0.35f
            pack(
                c ushr 24,
                (l + (((c shr 16) and 255) - l) * s).toInt(),
                (l + (((c shr 8) and 255) - l) * s).toInt(),
                (l + ((c and 255) - l) * s).toInt()
            )
        }
        commit(b, r)
    }

    /** فرشاة استبدال اللون: بتحافظ على الإضاءة وتغيّر اللون للون المختار. */
    fun colorReplace(b: Bitmap, cx: Float, cy: Float, rad: Float, hard: Float, k: Float, color: Int) {
        val r = region(b, cx, cy, rad) ?: return
        val tl = max(1, lum(color))
        each(r, cx, cy, rad, hard) { _, c, f ->
            val l = lum(c)
            val kf = l / tl.toFloat()
            val t = pack(
                c ushr 24,
                (((color shr 16) and 255) * kf).toInt(),
                (((color shr 8) and 255) * kf).toInt(),
                ((color and 255) * kf).toInt()
            )
            mix(c, t, f * (0.3f + k * 0.7f))
        }
        commit(b, r)
    }

    /** استنساخ: بينسخ من (cx+ox, cy+oy). heal = true يطابق اللون المحيط (ترميم). */
    fun clone(b: Bitmap, cx: Float, cy: Float, rad: Float, hard: Float, k: Float, ox: Float, oy: Float, heal: Boolean) {
        val sx = cx + ox
        val sy = cy + oy
        val src = region(b, sx, sy, rad) ?: return
        val dst = region(b, cx, cy, rad) ?: return
        var dr = 0; var dg = 0; var db = 0; var sr = 0; var sg = 0; var sb = 0; var n = 0
        if (heal) {
            for (i in dst.px.indices step 3) {
                val c = dst.px[i]
                dr += (c shr 16) and 255; dg += (c shr 8) and 255; db += c and 255; n++
            }
            for (i in src.px.indices step 3) {
                val c = src.px[i]
                sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
            }
        }
        val shR = if (n > 0) (dr - sr) / n else 0
        val shG = if (n > 0) (dg - sg) / n else 0
        val shB = if (n > 0) (db - sb) / n else 0
        // الإزاحة بين مناطق القراءة والكتابة بعد القص على حدود الصورة
        val offX = dst.x0 + ox.toInt() - src.x0
        val offY = dst.y0 + oy.toInt() - src.y0
        each(dst, cx, cy, rad, hard) { i, c, f ->
            val xx = i % dst.w
            val yy = i / dst.w
            val px = xx + offX
            val py = yy + offY
            if (px in 0 until src.w && py in 0 until src.h) {
                val s = src.px[py * src.w + px]
                val t = if (heal) pack(s ushr 24, ((s shr 16) and 255) + shR, ((s shr 8) and 255) + shG, (s and 255) + shB) else s
                mix(c, t, f * (if (heal) 0.4f + k * 0.6f else 0.55f + k * 0.45f))
            } else c
        }
        commit(b, dst)
    }

    /** سيولة (Liquify): بيزق البكسلات في اتجاه الحركة. */
    fun liquify(b: Bitmap, cx: Float, cy: Float, rad: Float, hard: Float, k: Float, dx: Float, dy: Float) {
        val m = rad + abs(dx) + abs(dy) + 2f
        val r = region(b, cx, cy, m) ?: return
        val copy = r.px.copyOf()
        each(r, cx, cy, rad, hard) { i, c, f ->
            val xx = i % r.w
            val yy = i / r.w
            val s = f * (0.5f + k * 0.5f)
            val sx = (xx - dx * s).toInt().coerceIn(0, r.w - 1)
            val sy = (yy - dy * s).toInt().coerceIn(0, r.h - 1)
            copy[sy * r.w + sx]
        }
        commit(b, r)
    }

    // ------------------------------------------------------------ tap tools

    /** ترميم نقطي: بيملا الدائرة بتدرّج من الألوان اللي حواليها (بيشيل البثور/الشوائب). */
    fun spotHeal(b: Bitmap, cx: Float, cy: Float, rad: Float) {
        val out = rad * 1.9f
        val r = region(b, cx, cy, out) ?: return
        val steps = 24
        val ring = IntArray(steps)
        val rx = FloatArray(steps)
        val ry = FloatArray(steps)
        for (s in 0 until steps) {
            val ang = s * 2.0 * Math.PI / steps
            rx[s] = cx + (cos(ang) * rad * 1.35).toFloat()
            ry[s] = cy + (sin(ang) * rad * 1.35).toFloat()
            ring[s] = b.getPixel(rx[s].toInt().coerceIn(0, b.width - 1), ry[s].toInt().coerceIn(0, b.height - 1))
        }
        each(r, cx, cy, rad, 0.7f) { i, c, f ->
            val x = r.x0 + (i % r.w)
            val y = r.y0 + (i / r.w)
            var wa = 0f; var ra = 0f; var ga = 0f; var ba = 0f
            for (s in 0 until steps) {
                val d = hypot(x - rx[s], y - ry[s]) + 1f
                val w = 1f / (d * d)
                wa += w
                ra += w * ((ring[s] shr 16) and 255); ga += w * ((ring[s] shr 8) and 255); ba += w * (ring[s] and 255)
            }
            mix(c, pack(255, (ra / wa).toInt(), (ga / wa).toInt(), (ba / wa).toInt()), f)
        }
        commit(b, r)
    }

    fun redEye(b: Bitmap, cx: Float, cy: Float, rad: Float) {
        val r = region(b, cx, cy, rad) ?: return
        each(r, cx, cy, rad, 0.6f) { _, c, f ->
            val rr = (c shr 16) and 255
            val gg = (c shr 8) and 255
            val bb = c and 255
            if (rr > max(gg, bb) * 1.25f && rr > 60) {
                val fixed = ((gg + bb) / 2f * 0.85f).toInt()
                mix(c, pack(c ushr 24, fixed, gg, bb), f)
            } else c
        }
        commit(b, r)
    }

    private fun dist(c1: Int, c2: Int): Int {
        val dr = ((c1 shr 16) and 255) - ((c2 shr 16) and 255)
        val dg = ((c1 shr 8) and 255) - ((c2 shr 8) and 255)
        val db = (c1 and 255) - (c2 and 255)
        return (abs(dr) + abs(dg) + abs(db)) / 3
    }

    /** ملء بالفيضان (دلو الطلاء / الممحاة السحرية). color = 0 → شفاف. */
    fun flood(b: Bitmap, sx: Int, sy: Int, tol: Float, color: Int) {
        val w = b.width
        val h = b.height
        if (sx !in 0 until w || sy !in 0 until h) return
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        val seed = px[sy * w + sx]
        val t = (tol * 120f).toInt() + 4
        val seen = BooleanArray(w * h)
        val q = IntArray(w * h)
        var head = 0; var tail = 0
        q[tail++] = sy * w + sx; seen[sy * w + sx] = true
        while (head < tail) {
            val i = q[head++]
            val x = i % w
            val y = i / w
            px[i] = color
            if (x > 0 && !seen[i - 1] && dist(px[i - 1], seed) <= t) { seen[i - 1] = true; q[tail++] = i - 1 }
            if (x < w - 1 && !seen[i + 1] && dist(px[i + 1], seed) <= t) { seen[i + 1] = true; q[tail++] = i + 1 }
            if (y > 0 && !seen[i - w] && dist(px[i - w], seed) <= t) { seen[i - w] = true; q[tail++] = i - w }
            if (y < h - 1 && !seen[i + w] && dist(px[i + w], seed) <= t) { seen[i + w] = true; q[tail++] = i + w }
        }
        b.setPixels(px, 0, w, 0, 0, w, h)
    }

    fun gradient(b: Bitmap, x0: Float, y0: Float, x1: Float, y1: Float, c0: Int, c1: Int) {
        if (abs(x1 - x0) + abs(y1 - y0) < 4f) return
        val p = Paint()
        p.shader = LinearGradient(x0, y0, x1, y1, c0, c1, Shader.TileMode.CLAMP)
        Canvas(b).drawRect(0f, 0f, b.width.toFloat(), b.height.toFloat(), p)
    }

    fun pick(b: Bitmap, x: Int, y: Int): Int = b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))

    @Suppress("unused")
    private fun angle(dx: Float, dy: Float) = atan2(dy, dx)
}
