package com.binarybeast.mediastudio.image

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.exifinterface.media.ExifInterface

/** تحليل الصورة: هيستوجرام، تحذير القص، العين الحمراء، بيانات الملف. */
object ImageAnalysis {

    /** 768 قيمة: R(0..255) ثم G ثم B. بياخد عينة (كل خطوة) لسرعة الحساب. */
    fun histogram(b: Bitmap): IntArray {
        val h = IntArray(768)
        val w = b.width; val ht = b.height
        val step = maxOf(1, maxOf(w, ht) / 400)
        var y = 0
        val row = IntArray(w)
        while (y < ht) {
            b.getPixels(row, 0, w, 0, y, w, 1)
            var x = 0
            while (x < w) {
                val c = row[x]
                if ((c ushr 24) > 8) {
                    h[(c shr 16) and 255]++
                    h[256 + ((c shr 8) and 255)]++
                    h[512 + (c and 255)]++
                }
                x += step
            }
            y += step
        }
        return h
    }

    /** نسبة (ظلال مفقودة، إضاءات محروقة) من البكسلات المعتمة. */
    fun clipStats(h: IntArray): Pair<Float, Float> {
        var total = 0L; var lo = 0L; var hi = 0L
        for (c in 0 until 3) {
            for (i in 0..255) total += h[c * 256 + i]
            lo += h[c * 256] + h[c * 256 + 1]
            hi += h[c * 256 + 254] + h[c * 256 + 255]
        }
        if (total == 0L) return 0f to 0f
        return lo * 100f / total to hi * 100f / total
    }

    /** نسخة من الصورة بتلوّن المحروق بالأحمر والظلال المفقودة بالأزرق. */
    fun clipOverlay(b: Bitmap): Bitmap {
        val w = b.width; val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val bl = c and 255
            if (r >= 253 || g >= 253 || bl >= 253) px[i] = (c and -16777216) or 0xFF2222
            else if (r <= 2 && g <= 2 && bl <= 2) px[i] = (c and -16777216) or 0x2266FF
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    /** تصحيح العين الحمراء: أي بكسل الأحمر فيه غالب بوضوح بيتعدّل لمتوسط الأخضر والأزرق (مع تغميق خفيف). يرجّع عدد البكسلات المعدّلة. */
    fun redEye(b: Bitmap): Int {
        val w = b.width; val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        var n = 0
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val bl = c and 255
            val gb = (g + bl) / 2
            if (r > 90 && r > gb * 2 && r - gb > 70) {
                val nr = (gb * 0.9f).toInt()
                px[i] = (c and -16777216) or (nr shl 16) or (g shl 8) or bl
                n++
            }
        }
        if (n > 0) b.setPixels(px, 0, w, 0, 0, w, h)
        return n
    }

    /** بيانات الملف: الأبعاد، الحجم، الكاميرا، التاريخ، الموقع، إلخ. */
    fun metadata(ctx: Context, uri: String?, w: Int, h: Int): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        if (uri == null) { out.add("الأبعاد" to "$w × $h (لوحة فارغة)"); return out }
        val u = Uri.parse(uri)
        try {
            ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex("_display_name"); val si = c.getColumnIndex("_size")
                    if (ni >= 0) out.add("الاسم" to c.getString(ni))
                    if (si >= 0) out.add("الحجم" to "%.2f MB".format(c.getLong(si) / 1048576.0))
                }
            }
        } catch (_: Throwable) {}
        try {
            ctx.contentResolver.openInputStream(u)?.use { ins ->
                val e = ExifInterface(ins)
                val iw = e.getAttributeInt(ExifInterface.TAG_IMAGE_WIDTH, 0)
                val ih = e.getAttributeInt(ExifInterface.TAG_IMAGE_LENGTH, 0)
                out.add("الأبعاد" to if (iw > 0 && ih > 0) "$iw × $ih" else "$w × $h (معاينة)")
                fun add(label: String, tag: String) { e.getAttribute(tag)?.takeIf { it.isNotBlank() }?.let { out.add(label to it) } }
                val mk = e.getAttribute(ExifInterface.TAG_MAKE)?.trim().orEmpty()
                val md = e.getAttribute(ExifInterface.TAG_MODEL)?.trim().orEmpty()
                if (mk.isNotEmpty() || md.isNotEmpty()) out.add("الكاميرا" to "$mk $md".trim())
                add("العدسة", ExifInterface.TAG_LENS_MODEL)
                add("تاريخ الالتقاط", ExifInterface.TAG_DATETIME_ORIGINAL)
                add("فتحة العدسة", ExifInterface.TAG_F_NUMBER)
                add("سرعة الغالق", ExifInterface.TAG_EXPOSURE_TIME)
                add("ISO", ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY)
                add("البعد البؤري", ExifInterface.TAG_FOCAL_LENGTH)
                add("الفلاش", ExifInterface.TAG_FLASH)
                add("اتجاه الصورة", ExifInterface.TAG_ORIENTATION)
                add("برنامج", ExifInterface.TAG_SOFTWARE)
                add("فضاء الألوان", ExifInterface.TAG_COLOR_SPACE)
                val ll = e.latLong
                if (ll != null) out.add("الموقع (GPS)" to "%.5f, %.5f".format(ll[0], ll[1]))
            }
        } catch (_: Throwable) {}
        if (out.none { it.first == "الأبعاد" }) out.add("الأبعاد" to "$w × $h")
        return out
    }
}
