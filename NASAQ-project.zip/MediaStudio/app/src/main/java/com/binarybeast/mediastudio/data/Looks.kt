package com.binarybeast.mediastudio.data

/**
 * فلتر جاهز. نفس التعريف بيستخدم للصور (ColorMatrix) وللفيديو (Media3 effects)
 * عشان الشكل يطلع متقارب في الاتنين.
 */
data class Look(
    val id: String,
    val name: String,
    val adjust: Adjust = Adjust(),
    val mono: Boolean = false,
    val sepia: Boolean = false,
    val r: Float = 1f,
    val g: Float = 1f,
    val b: Float = 1f,
)

object Looks {
    val all: List<Look> = listOf(
        Look("original", "الأصلي"),
        Look("vivid", "حيوي", Adjust(contrast = 0.15f, saturation = 0.45f)),
        Look("pop", "ساطع", Adjust(contrast = 0.25f, saturation = 0.7f)),
        Look("bright", "مشرق", Adjust(brightness = 0.12f, contrast = 0.05f, saturation = 0.1f)),
        Look("warm", "دافئ", Adjust(saturation = 0.1f, warmth = 0.5f)),
        Look("cool", "بارد", Adjust(warmth = -0.5f)),
        Look("sunset", "غروب", Adjust(saturation = 0.3f, warmth = 0.6f), r = 1.1f, g = 0.95f, b = 0.9f),
        Look("mint", "نعناع", Adjust(saturation = 0.1f, warmth = -0.1f), r = 0.9f, g = 1.05f, b = 1.0f),
        Look("dream", "حالم", Adjust(brightness = 0.08f, contrast = -0.15f, saturation = 0.15f), r = 1.04f, b = 1.06f),
        Look("vintage", "كلاسيك", Adjust(brightness = 0.03f, contrast = -0.1f, saturation = -0.25f, warmth = 0.3f), r = 1.05f, b = 0.88f),
        Look("fade", "باهت", Adjust(brightness = 0.1f, contrast = -0.25f, saturation = -0.2f)),
        Look("matte", "مطفي", Adjust(brightness = 0.06f, contrast = -0.2f, saturation = -0.1f)),
        Look("cinema", "سينمائي", Adjust(contrast = 0.2f, saturation = -0.1f), r = 1.04f, g = 0.98f, b = 0.94f),
        Look("moody", "كئيب", Adjust(brightness = -0.1f, contrast = 0.25f, saturation = -0.25f), r = 0.95f, b = 1.05f),
        Look("dramatic", "درامي", Adjust(brightness = -0.05f, contrast = 0.4f, saturation = -0.15f)),
        Look("sepia", "سيبيا", Adjust(contrast = 0.05f), sepia = true),
        Look("bw", "أبيض وأسود", mono = true),
        Look("noir", "نوار", Adjust(contrast = 0.45f), mono = true),
        Look("tealorange", "تيل وبرتقالي", Adjust(contrast = 0.25f, saturation = 0.2f), r = 1.08f, g = 0.98f, b = 0.92f),
        Look("golden", "ساعة ذهبية", Adjust(brightness = 0.04f, contrast = 0.1f, saturation = 0.25f, warmth = 0.7f), r = 1.08f, g = 1.0f, b = 0.85f),
        Look("cyber", "سايبر", Adjust(contrast = 0.3f, saturation = 0.6f, hue = 20f), r = 0.95f, g = 0.95f, b = 1.15f),
        Look("forest", "غابة", Adjust(contrast = 0.1f, saturation = 0.2f, warmth = -0.1f), r = 0.92f, g = 1.08f, b = 0.95f),
        Look("rose", "وردي", Adjust(brightness = 0.06f, saturation = 0.1f, warmth = 0.15f), r = 1.08f, g = 0.95f, b = 1.04f),
        Look("ice", "جليدي", Adjust(brightness = 0.05f, contrast = 0.1f, saturation = -0.1f, warmth = -0.7f), r = 0.92f, g = 1.0f, b = 1.1f),
        Look("lomo", "لومو", Adjust(contrast = 0.35f, saturation = 0.4f), r = 1.05f, g = 1.0f, b = 0.9f),
        Look("kodak", "كوداك", Adjust(brightness = 0.03f, contrast = 0.12f, saturation = 0.15f, warmth = 0.35f), r = 1.06f, b = 0.9f),
        Look("hdr", "HDR", Adjust(contrast = 0.5f, saturation = 0.35f)),
        Look("pastel", "باستيل", Adjust(brightness = 0.14f, contrast = -0.3f, saturation = -0.05f), r = 1.03f, b = 1.04f),
    )

    fun byId(id: String): Look = all.firstOrNull { it.id == id } ?: all.first()
}
