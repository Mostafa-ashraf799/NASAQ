package com.binarybeast.mediastudio.data

/**
 * فلتر جاهز. نفس التعريف بيستخدم للصور (ColorMatrix) وللفيديو (Media3 effects)
 * عشان الشكل يطلع متقارب في الاتنين.
 */
data class Look(
    val id: String,
    val name: String,
    val adjust: Adjust = Adjust(),
    val mono: Boolean = false,
    val sepia: Boolean = false,
    val r: Float = 1f,
    val g: Float = 1f,
    val b: Float = 1f,
)

object Looks {
    val all: List<Look> = listOf(
        Look("original", "الأصلي"),
        Look("vivid", "حيوي", Adjust(contrast = 0.15f, saturation = 0.45f)),
        Look("pop", "ساطع", Adjust(contrast = 0.25f, saturation = 0.7f)),
        Look("bright", "مشرق", Adjust(brightness = 0.12f, contrast = 0.05f, saturation = 0.1f)),
        Look("warm", "دافئ", Adjust(saturation = 0.1f, warmth = 0.5f)),
        Look("cool", "بارد", Adjust(warmth = -0.5f)),
        Look("sunset", "غروب", Adjust(saturation = 0.3f, warmth = 0.6f), r = 1.1f, g = 0.95f, b = 0.9f),
        Look("mint", "نعناع", Adjust(saturation = 0.1f, warmth = -0.1f), r = 0.9f, g = 1.05f, b = 1.0f),
        Look("dream", "حالم", Adjust(brightness = 0.08f, contrast = -0.15f, saturation = 0.15f), r = 1.04f, b = 1.06f),
        Look("vintage", "كلاسيك", Adjust(brightness = 0.03f, contrast = -0.1f, saturation = -0.25f, warmth = 0.3f), r = 1.05f, b = 0.88f),
        Look("fade", "باهت", Adjust(brightness = 0.1f, contrast = -0.25f, saturation = -0.2f)),
        Look("matte", "مطفي", Adjust(brightness = 0.06f, contrast = -0.2f, saturation = -0.1f)),
        Look("cinema", "سينمائي", Adjust(contrast = 0.2f, saturation = -0.1f), r = 1.04f, g = 0.98f, b = 0.94f),
        Look("moody", "كئيب", Adjust(brightness = -0.1f, contrast = 0.25f, saturation = -0.25f), r = 0.95f, b = 1.05f),
        Look("dramatic", "درامي", Adjust(brightness = -0.05f, contrast = 0.4f, saturation = -0.15f)),
        Look("sepia", "سيبيا", Adjust(contrast = 0.05f), sepia = true),
        Look("bw", "أبيض وأسود", mono = true),
        Look("noir", "نوار", Adjust(contrast = 0.45f), mono = true),
    )

    fun byId(id: String): Look = all.firstOrNull { it.id == id } ?: all.first()
}
