package com.binarybeast.mediastudio.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.PhotoLibrary
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.binarybeast.mediastudio.data.Project
import com.binarybeast.mediastudio.data.ProjectFactory
import com.binarybeast.mediastudio.data.ProjectType
import com.binarybeast.mediastudio.audio.AudioEditorScreen
import com.binarybeast.mediastudio.image.ImageEditorScreen
import com.binarybeast.mediastudio.video.VideoEditorScreen
import kotlinx.coroutines.launch

private fun NavHostController.openProject(p: Project, replaceUntilHome: Boolean) {
    val route = when (p.type) {
        ProjectType.VIDEO -> "video/${p.id}"
        ProjectType.AUDIO -> "audio/${p.id}"
        ProjectType.CANVAS -> "canvas/${p.id}"
        else -> "image/${p.id}"
    }
    navigate(route) {
        if (replaceUntilHome) popUpTo("home") { inclusive = false }
    }
}

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }

    /** ينشئ مشروع من ملفات محددة ثم يفتح المحرر المناسب. */
    fun createFrom(uris: List<Uri>, asVideo: Boolean, name: String, fromPicker: Boolean) {
        if (uris.isEmpty() || busy) return
        scope.launch {
            busy = true
            val p: Project? = try {
                if (asVideo) ProjectFactory.createVideoProject(ctx, name, uris)
                else ProjectFactory.createImageProject(ctx, name, uris.first())
            } catch (e: Throwable) {
                null
            }
            busy = false
            if (p == null || (asVideo && p.video?.clips.isNullOrEmpty())) {
                toast(ctx, "تعذّر قراءة الملفات المختارة")
            } else {
                nav.openProject(p, replaceUntilHome = fromPicker)
            }
        }
    }

    /** ينشئ مشروع صوتي من ملف صوت/فيديو. */
    fun createAudio(uri: Uri, name: String) {
        if (busy) return
        scope.launch {
            busy = true
            val p = try { ProjectFactory.createAudioProject(ctx, name, uri) } catch (e: Throwable) { null }
            busy = false
            if (p == null) toast(ctx, "تعذّر قراءة الملف الصوتي") else nav.openProject(p, false)
        }
    }

    var collageName by remember { mutableStateOf("") }
    var collageUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var showRecord by remember { mutableStateOf(false) }
    var recordName by remember { mutableStateOf("") }
    val collagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(9)) { uris ->
        if (uris.size >= 2) collageUris = uris else if (uris.isNotEmpty()) toast(ctx, "اختار صورتين على الأقل")
    }
    var pendingAudioName by remember { mutableStateOf("") }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) createAudio(uri, pendingAudioName)
    }

    var showSplash by rememberSaveable { mutableStateOf(true) }

    NavHost(navController = nav, startDestination = "home") {
        composable("home") {
            HomeScreen(
                onOpen = { nav.openProject(it, false) },
                onNew = { req ->
                    when (req) {
                        is NewProjectRequest.Pick ->
                            nav.navigate("pick/${req.type.name}/${Uri.encode(req.name.ifBlank { "_" })}")
                        is NewProjectRequest.PickCollage -> {
                            collageName = req.name
                            collagePicker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }
                        is NewProjectRequest.Record -> {
                            recordName = req.name
                            showRecord = true
                        }
                        is NewProjectRequest.PickAudio -> {
                            pendingAudioName = req.name
                            audioPicker.launch(arrayOf("audio/*", "video/*"))
                        }
                        is NewProjectRequest.Canvas -> scope.launch {
                            busy = true
                            val p = try { com.binarybeast.mediastudio.data.CanvasStore.create(req.name, req.w, req.h, req.color, req.template) } catch (e: Throwable) { null }
                            busy = false
                            if (p == null) toast(ctx, "تعذّر إنشاء الكانفس") else nav.openProject(p, false)
                        }
                        is NewProjectRequest.Blank -> scope.launch {
                            busy = true
                            val p = ProjectFactory.createBlankProject(req.name, req.w, req.h, req.color)
                            busy = false
                            nav.openProject(p, false)
                        }
                    }
                },
                onGalleryChosen = { uris, asVideo -> createFrom(uris, asVideo, "", fromPicker = false) },
                onCloudOpen = { kind, uris ->
                    when (kind) {
                        CloudOpenKind.IMAGE -> createFrom(uris.take(1), false, "", fromPicker = false)
                        CloudOpenKind.VIDEO -> createFrom(uris, true, "", fromPicker = false)
                        CloudOpenKind.AUDIO -> createAudio(uris.first(), "")
                    }
                }
            )
        }
        composable(
            "pick/{type}/{name}",
            arguments = listOf(
                navArgument("type") { type = NavType.StringType },
                navArgument("name") { type = NavType.StringType }
            )
        ) { entry ->
            val type = ProjectType.valueOf(entry.arguments?.getString("type") ?: "IMAGE")
            val rawName = Uri.decode(entry.arguments?.getString("name") ?: "")
            val name = if (rawName == "_") "" else rawName
            GalleryScreen(
                pickType = type,
                onUrisChosen = { uris, asVideo -> createFrom(uris, asVideo, name, fromPicker = true) },
                onBack = { nav.popBackStack() }
            )
        }
        composable("image/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { entry ->
            ImageEditorScreen(entry.arguments?.getString("id") ?: "", onBack = { nav.popBackStack() })
        }
        composable("canvas/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { entry ->
            CanvasScreen(
                entry.arguments?.getString("id") ?: "",
                onBack = { nav.popBackStack() },
                onEditPage = { nav.navigate("image/$it") },
                onOpenProject = { nav.openProject(it, false) }
            )
        }
        composable("audio/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { entry ->
            AudioEditorScreen(entry.arguments?.getString("id") ?: "", onBack = { nav.popBackStack() })
        }
        composable("video/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { entry ->
            VideoEditorScreen(entry.arguments?.getString("id") ?: "", onBack = { nav.popBackStack() })
        }
    }

    if (busy) LoadingDialog("جاري تجهيز المشروع...")
    if (showRecord) {
        RecordDialog(
            onRecorded = { uri -> showRecord = false; createAudio(uri, recordName) },
            onDismiss = { showRecord = false }
        )
    }
    if (collageUris.isNotEmpty()) {
        CollageDialog(
            count = collageUris.size,
            onDismiss = { collageUris = emptyList() },
            onCreate = { layout, ratio, gap, bg ->
                val uris = collageUris
                collageUris = emptyList()
                scope.launch {
                    busy = true
                    val p = try {
                        com.binarybeast.mediastudio.data.Collage.createProject(ctx, collageName, uris, layout, ratio, gap, bg)
                    } catch (e: Throwable) { null }
                    busy = false
                    if (p == null) toast(ctx, "تعذّر إنشاء الكولاج") else nav.openProject(p, false)
                }
            }
        )
    }
    TransferOverlay { kind, uris ->
        when (kind) {
            CloudOpenKind.IMAGE -> createFrom(uris.take(1), false, "", fromPicker = false)
            CloudOpenKind.VIDEO -> createFrom(uris, true, "", fromPicker = false)
            CloudOpenKind.AUDIO -> createAudio(uris.first(), "")
        }
    }
    androidx.compose.animation.AnimatedVisibility(
        visible = showSplash,
        enter = androidx.compose.animation.EnterTransition.None,
        exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(400))
    ) { SplashScreen(onDone = { showSplash = false }) }
}

@Composable
private fun HomeScreen(
    onOpen: (Project) -> Unit,
    onNew: (NewProjectRequest) -> Unit,
    onGalleryChosen: (List<Uri>, Boolean) -> Unit,
    onCloudOpen: (CloudOpenKind, List<Uri>) -> Unit,
) {
    // 0 = المعرض، 1 = مساحة العمل، 2 = السحابة
    var tab by rememberSaveable { mutableStateOf(1) }
    val items = listOf(
        Triple("المعرض", Icons.Default.PhotoLibrary, 0),
        Triple("الشغل", Icons.Default.Dashboard, 1),
        Triple("السحابة", Icons.Default.Cloud, 2),
    )
    val wide = isWideLayout()
    val content: @Composable () -> Unit = {
        when (tab) {
            0 -> GalleryScreen(pickType = null, onUrisChosen = onGalleryChosen, onBack = null)
            1 -> WorkspaceScreen(onOpen = onOpen, onNew = onNew)
            else -> CloudScreen(onOpenAs = onCloudOpen)
        }
    }
    if (wide) {
        // تابلت: شريط تنقل جانبي
        Row(Modifier.fillMaxSize().background(Bg)) {
            NavigationRail(containerColor = Surface1, modifier = Modifier.fillMaxHeight().statusBarsPadding()) {
                val colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = Accent, selectedTextColor = Accent,
                    indicatorColor = Surface2, unselectedIconColor = TextDim, unselectedTextColor = TextDim
                )
                items.forEach { (label, icon, i) ->
                    NavigationRailItem(
                        selected = tab == i, onClick = { tab = i }, colors = colors,
                        icon = { Icon(icon, null) }, label = { Text(label) }
                    )
                }
            }
            Box(Modifier.weight(1f).fillMaxHeight()) { content() }
        }
    } else {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Surface1) {
                    val colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Accent, selectedTextColor = Accent,
                        indicatorColor = Surface2, unselectedIconColor = TextDim, unselectedTextColor = TextDim
                    )
                    items.forEach { (label, icon, i) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i }, colors = colors,
                            icon = { Icon(icon, null) }, label = { Text(label) }
                        )
                    }
                }
            }
        ) { pad -> Box(Modifier.fillMaxSize().padding(pad)) { content() } }
    }
}
