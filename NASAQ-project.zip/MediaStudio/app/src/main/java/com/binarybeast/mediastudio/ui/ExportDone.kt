package com.binarybeast.mediastudio.ui

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import java.io.File

private class ShareTarget(val label: String, val cn: ComponentName, val icon: androidx.compose.ui.graphics.ImageBitmap?)

private fun fileUri(ctx: Context, f: File): Uri =
    FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)

private fun loadTargets(ctx: Context, mime: String): List<ShareTarget> {
    val pm = ctx.packageManager
    val probe = Intent(Intent.ACTION_SEND).setType(mime)
    return try {
        pm.queryIntentActivities(probe, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .take(14)
            .map {
                ShareTarget(
                    it.loadLabel(pm).toString(),
                    ComponentName(it.activityInfo.packageName, it.activityInfo.name),
                    runCatching { it.loadIcon(pm).toBitmap(96, 96).asImageBitmap() }.getOrNull()
                )
            }
    } catch (e: Exception) { emptyList() }
}

private fun sendTo(ctx: Context, uri: Uri, mime: String, cn: ComponentName?) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        if (cn != null) component = cn
    }
    val out = if (cn != null) i else Intent.createChooser(i, "مشاركة عبر")
    try { ctx.startActivity(out.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { toast(ctx, "تعذّرت المشاركة") }
}

/**
 * شاشة ما بعد التصدير: زر "حفظ" كبير، وتحته أزرار صغيرة للمشاركة لتطبيقات الجهاز والسحابة.
 * الملف لسه في الكاش لحد ما المستخدم يدوس حفظ.
 */
@Composable
fun ExportDoneDialog(
    file: File,
    mime: String,
    savedUri: Uri?,
    label: String,
    onSave: () -> Unit,
    onCloud: (Uri) -> Unit,
    onDismiss: () -> Unit,
) {
    val ctx = LocalContext.current
    val targets = remember(mime) { loadTargets(ctx, mime) }
    val shareUri = remember(file) { runCatching { fileUri(ctx, file) }.getOrNull() }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface1,
        title = { Text("تم التصدير") },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Button(
                    onClick = { if (savedUri == null) onSave() },
                    modifier = Modifier.fillMaxWidth().height(58.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) {
                    Icon(if (savedUri == null) Icons.Default.Save else Icons.Default.Check, null)
                    Text(
                        if (savedUri == null) "  حفظ" else "  اتحفظ في $label",
                        fontSize = 18.sp
                    )
                }
                Text("شارك الملف مباشرة", color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (shareUri != null) {
                        MiniShare(Icons.Default.CloudUpload, null, "السحابة") { onCloud(shareUri) }
                        targets.forEach { t ->
                            MiniShare(null, t.icon, t.label) { sendTo(ctx, shareUri, mime, t.cn) }
                        }
                        MiniShare(Icons.Default.MoreHoriz, null, "المزيد") { sendTo(ctx, shareUri, mime, null) }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("إغلاق", color = TextDim) } }
    )
}

@Composable
private fun MiniShare(
    vec: androidx.compose.ui.graphics.vector.ImageVector?,
    bmp: androidx.compose.ui.graphics.ImageBitmap?,
    label: String,
    onClick: () -> Unit,
) {
    Column(
        Modifier.width(60.dp).clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Surface2), contentAlignment = Alignment.Center) {
            if (bmp != null) Image(bmp, label, Modifier.size(30.dp))
            else if (vec != null) Icon(vec, label, tint = Accent, modifier = Modifier.size(22.dp))
        }
        Text(label, fontSize = 10.sp, color = TextDim, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}
