package com.binarybeast.mediastudio.data

import kotlin.math.hypot

enum class ProjectType { IMAGE, VIDEO, AUDIO, CANVAS }

/** تعديلات الألوان الأساسية (كلها من -1 إلى 1 ما عدا hue بالدرجات). */
data class Adjust(
    val brightness: Float = 0f,
    val contrast: Float = 0f,
    val saturation: Float = 0f,
    val warmth: Float = 0f,
    val hue: Float = 0f,
) {
    operator fun plus(o: Adjust) = Adjust(
        brightness + o.brightness, contrast + o.contrast, saturation + o.saturation,
        warmth + o.warmth, hue + o.hue
    )

    operator fun times(k: Float) = Adjust(brightness * k, contrast * k, saturation * k, warmth * k, hue * k)

    val isIdentity: Boolean
        get() = brightness == 0f && contrast == 0f && saturation == 0f && warmth == 0f && hue == 0f
}

/** طبقة نص أو ستيكر (إيموجي). الإحداثيات طبيعية 0..1 والحجم نسبة من ارتفاع الصورة/الفيديو. */
data class TextLayer(
    val id: Long,
    val text: String,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val size: Float = 0.07f,
    val rotation: Float = 0f,
    val color: Int = 0xFFFFFFFF.toInt(),
    val bgColor: Int = 0,
    val bold: Boolean = true,
    val italic: Boolean = false,
    val font: Int = 0,
    val shadow: Boolean = true,
    val outline: Boolean = false,
    val opacity: Float = 1f,
    /** للفيديو فقط: زمن الظهور على التايم لاين بالميلي ثانية. */
    val startMs: Long = 0L,
    val endMs: Long = -1L,
    /** 0 = نص، 1 مستطيل، 2 مستطيل مدوّر، 3 دائرة/بيضاوي، 4 مثلث، 5 نجمة، 6 قلب، 7 خط، 8 سهم، 9 صورة، 10 طبقة لون (ملء الكانفس)، 11 طبقة تدرّج. */
    val shape: Int = 0,
    /** عرض/ارتفاع للأشكال والصور (الارتفاع = size × ارتفاع الكانفس). */
    val aspect: Float = 1f,
    val imageUri: String? = null,
    /** نمط الدمج: 0 عادي، 1 ضرب، 2 شاشة، 3 أوفرلاي، 4 أغمق، 5 أفتح، 6 إضافة. */
    val blend: Int = 0,
    /** لون ثانٍ (نهاية التدرّج لطبقة التدرّج). */
    val color2: Int = 0,
    /** قناع الطبقة: 0 بدون، 1 بيضاوي، 2 مدوّر، 3 تلاشي لأسفل، 4 تلاشي لأعلى، 5 تلاشي لليمين، 6 تلاشي لليسار، 7 شعاعي. */
    val mask: Int = 0,
    val maskInvert: Boolean = false,
    /** توهّج حول الطبقة (نسبة من الحجم، 0 = بدون). */
    val glow: Float = 0f,
    val hidden: Boolean = false,
    /** حركة الدخول/الخروج في الفيديو: 0 بدون، 1 تلاشي، 2 انزلاق لأعلى، 3 ظهور بتكبير (Pop)، 4 انزلاق من الشمال، 5 انزلاق من اليمين. */
    val anim: Int = 0,
    val animMs: Long = 450L,
)

/** خط رسم بالفرشاة. pts = [x0,y0,x1,y1,...] طبيعية 0..1. width نسبة من أصغر بُعد. */
data class Stroke(
    val color: Int,
    val width: Float,
    val alpha: Float,
    val pts: List<Float>,
)

data class ImageEdit(
    val adjust: Adjust = Adjust(),
    val lookId: String = "original",
    val lookStrength: Float = 1f,
    val sharpen: Float = 0f,
    val blur: Float = 0f,
    val vignette: Float = 0f,
    val fade: Float = 0f,
    val border: Float = 0f,
    val borderColor: Int = 0xFFFFFFFF.toInt(),
    val rotation: Int = 0,
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    /** 0 = بدون تغيير نسبة الأبعاد. */
    val cropAspect: Float = 0f,
    val cropZoom: Float = 1f,
    val cropCx: Float = 0.5f,
    val cropCy: Float = 0.5f,
    /** تسوية الصورة بالدرجات (-45..45). */
    val straighten: Float = 0f,
    val grain: Float = 0f,
    val pixelate: Float = 0f,
    /** تدوير الزوايا (0..0.5 من أصغر بُعد). */
    val corner: Float = 0f,
    /** تصحيح المنظور: أفقي ورأسي (-1..1). */
    val perspH: Float = 0f,
    val perspV: Float = 0f,
    /** توسيع الكانفس (Canvas Size): هامش حوالين الصورة بنسبة من أصغر بُعد، ولونه (0 = شفاف). */
    val expand: Float = 0f,
    val expandColor: Int = 0xFFFFFFFF.toInt(),
    /** المؤثرات المتقدمة (تفاصيل/إضاءة/فلاتر إبداعية). */
    val fx: ImageFx = ImageFx(),
    val texts: List<TextLayer> = emptyList(),
    val strokes: List<Stroke> = emptyList(),
)

/** مؤثرات الصور المتقدمة. كل القيم الافتراضية = بدون تأثير. */
data class ImageFx(
    val exposure: Float = 0f,
    val highlights: Float = 0f,
    val shadows: Float = 0f,
    val whites: Float = 0f,
    val blacks: Float = 0f,
    /** -1 أخضر .. +1 ماجنتا. */
    val tint: Float = 0f,
    val vibrance: Float = 0f,
    val clarity: Float = 0f,
    val dehaze: Float = 0f,
    /** انحراف لوني (chromatic aberration) 0..1. */
    val chroma: Float = 0f,
    /** تقليل ضوضاء / تنعيم بشرة 0..1. */
    val denoise: Float = 0f,
    /** تيلت-شيفت: قوة البلور 0..1، النمط 0 خطي / 1 دائري، ومركز التركيز. */
    val focus: Float = 0f,
    val focusMode: Int = 0,
    val focusX: Float = 0.5f,
    val focusY: Float = 0.5f,
    /** فلتر إبداعي واحد: 0 بدون، 1 عكس، 2 بوستر، 3 سولار، 4 أبيض/أسود حاد، 5 نقش، 6 سكتش،
     *  7 جليتش، 8-10 دوتون، 11 هاف-تون، 12 مرآة أفقية، 13 مرآة رأسية، 14 كاليدوسكوب، 15 رسم زيتي. */
    val filter: Int = 0,
    val filterAmount: Float = 1f,
    val vignetteColor: Int = 0xFF000000.toInt(),
    /** تسريب ضوء 0..1 ونمطه 0..3. */
    val leak: Float = 0f,
    val leakStyle: Int = 0,
    /** غبار فيلم 0..1. */
    val dust: Float = 0f,
    /** مستويات Levels: نقطة السواد/البياض (0..1) وجاما. */
    val lvBlack: Float = 0f,
    val lvWhite: Float = 1f,
    val lvGamma: Float = 1f,
    /** منحنيات Curves: ماستر (ظلال/وسط/إضاءات) + وسط كل قناة، كلها إزاحة -0.25..0.25. */
    val cvS: Float = 0f, val cvM: Float = 0f, val cvH: Float = 0f,
    val cvR: Float = 0f, val cvG: Float = 0f, val cvB: Float = 0f,
    /** أبيض وأسود بمازج قنوات. */
    val bwOn: Boolean = false,
    val bwR: Float = 0.30f, val bwG: Float = 0.59f, val bwB: Float = 0.11f,
    /** فلتر الصورة Photo Filter: لون (0 = بدون) وكثافة. */
    val pfColor: Int = 0,
    val pfDensity: Float = 0.3f,
    /** توازن الألوان: ظلال/وسط/إضاءات × (أحمر، أخضر، أزرق) من -1..1. */
    val cbShR: Float = 0f, val cbShG: Float = 0f, val cbShB: Float = 0f,
    val cbMiR: Float = 0f, val cbMiG: Float = 0f, val cbMiB: Float = 0f,
    val cbHiR: Float = 0f, val cbHiG: Float = 0f, val cbHiB: Float = 0f,
    /** Gradient Map: يحوّل الإضاءة لتدرّج بين لونين. */
    val gmOn: Boolean = false,
    val gmDark: Int = 0xFF1B1464.toInt(),
    val gmLight: Int = 0xFFFFD27F.toInt(),
    /** ألوان محددة (Selective Color): النطاق 0..7 (أحمر، برتقالي، أصفر، أخضر، سيان، أزرق، بنفسجي، ماجنتا) أو -1. */
    val scRange: Int = -1,
    val scSat: Float = 0f, val scHue: Float = 0f, val scLum: Float = 0f,
) {
    val gradeActive: Boolean
        get() = lvBlack != 0f || lvWhite != 1f || lvGamma != 1f ||
            cvS != 0f || cvM != 0f || cvH != 0f || cvR != 0f || cvG != 0f || cvB != 0f ||
            bwOn || pfColor != 0 || gmOn || (scRange >= 0 && (scSat != 0f || scHue != 0f || scLum != 0f)) ||
            cbShR != 0f || cbShG != 0f || cbShB != 0f || cbMiR != 0f || cbMiG != 0f || cbMiB != 0f ||
            cbHiR != 0f || cbHiG != 0f || cbHiB != 0f

    val toneActive: Boolean
        get() = exposure != 0f || highlights != 0f || shadows != 0f || whites != 0f || blacks != 0f ||
            tint != 0f || vibrance != 0f || dehaze != 0f
}

data class ImageData(
    val sourceUri: String?,
    val blankW: Int = 1080,
    val blankH: Int = 1080,
    val blankColor: Int = 0xFFFFFFFF.toInt(),
    val edit: ImageEdit = ImageEdit(),
    /** نسخة معدّلة بكسليًا (أدوات الريتوش) بتحل محل المصدر لو موجودة. */
    val retouchUri: String? = null,
)

/** كي فريم: t = موضع المقطع (0..1)، zoom 1..4، x/y إزاحة -1..1، ease = تنعيم الحركة. */
data class Keyframe(val t: Float, val zoom: Float, val x: Float, val y: Float, val ease: Boolean = true)

data class VideoClip(
    val id: Long,
    val uri: String,
    val isImage: Boolean,
    /** مدة المصدر الكاملة (للصور: أقصى مدة مسموحة). */
    val srcDurationMs: Long,
    val startMs: Long,
    val endMs: Long,
    /** الأبعاد كما تظهر (بعد تطبيق تدوير الميتاداتا). */
    val width: Int,
    val height: Int,
    val speed: Float = 1f,
    val volume: Float = 1f,
    val muted: Boolean = false,
    val rotation: Int = 0,
    val flipH: Boolean = false,
    /** true = ملء الإطار مع القص، false = احتواء مع أشرطة سوداء. */
    val fill: Boolean = false,
    val lookId: String = "original",
    val lookStrength: Float = 1f,
    val adjust: Adjust = Adjust(),
    /** تلاشي من/إلى الأسود بالميلي ثانية. */
    val fadeInMs: Long = 0L,
    val fadeOutMs: Long = 0L,
    /** تكبير ثابت (1..4) وإزاحة (-1..1). */
    val zoom: Float = 1f,
    val panX: Float = 0f,
    val panY: Float = 0f,
    /** 0 = بدون، 1 = تقريب تدريجي، 2 = تبعيد تدريجي. */
    val kenBurns: Int = 0,
    /** فلتر ألوان خاص: 0 بدون، 1 رؤية ليلية، 2 سيانوتايب، 3 ذهبي، 4 وردي، 5 أحمر، 6 تبديل أحمر/أزرق، 7 تبديل أحمر/أخضر، 8 سيبيا قوي، 9 تشبّع عالي. */
    val vfx: Int = 0,
    val flipV: Boolean = false,
    /** صبغة -1 أخضر .. +1 ماجنتا. */
    val tint: Float = 0f,
    /** كي فريم للحركة (تكبير/إزاحة) على امتداد المقطع. */
    val kfs: List<Keyframe> = emptyList(),
    /** ملف LUT (.cube) للمقطع، أو null. */
    val lutUri: String? = null,
) {
    val effectiveMs: Long get() = ((endMs - startMs) / speed).toLong().coerceAtLeast(1L)

    val displayAspect: Float
        get() {
            val a = if (height == 0) 1.7778f else width.toFloat() / height
            return if (rotation % 180 != 0) 1f / a else a
        }
}

data class VideoData(
    val clips: List<VideoClip> = emptyList(),
    val texts: List<TextLayer> = emptyList(),
    val musicUri: String? = null,
    val musicName: String = "",
    val musicDurationMs: Long = 0L,
    val musicVolume: Float = 1f,
    /** 0 = تلقائي (حسب أول مقطع)، وإلا قيمة النسبة w/h. */
    val aspect: Float = 0f,
    /** ارتفاع/عرض الإخراج الأقصر: 480 / 720 / 1080. */
    val resolution: Int = 720,
    /** علامات (Markers) على التايم لاين بالميلي ثانية. */
    val markers: List<Long> = emptyList(),
) {
    val totalMs: Long get() = clips.sumOf { it.effectiveMs }

    val canvasAspect: Float
        get() = if (aspect > 0f) aspect else clips.firstOrNull()?.displayAspect ?: 1.7778f

    /** مقاس الإخراج (أرقام زوجية). */
    fun outputSize(): Pair<Int, Int> {
        val a = canvasAspect
        val short = resolution
        val w: Int
        val h: Int
        if (a >= 1f) {
            h = short
            w = (short * a).toInt()
        } else {
            w = short
            h = (short / a).toInt()
        }
        return Pair(w / 2 * 2, h / 2 * 2)
    }

    fun clipStartMs(index: Int): Long {
        var t = 0L
        for (i in 0 until index.coerceAtMost(clips.size)) t += clips[i].effectiveMs
        return t
    }
}

/** مشروع صوتي: ملف واحد (صوت أو فيديو يتم استخراج صوته) مع قص وسرعة وطبقة صوت وتلاشي. */
data class AudioData(
    val uri: String,
    val name: String = "",
    val srcDurationMs: Long = 0L,
    val startMs: Long = 0L,
    val endMs: Long = 0L,
    val speed: Float = 1f,
    /** درجة الصوت (pitch) مستقلة عن السرعة. */
    val pitch: Float = 1f,
    /** 0..2 (2 = تضخيم للضعف). */
    val volume: Float = 1f,
    val fadeInMs: Long = 0L,
    val fadeOutMs: Long = 0L,
    /** صدى (0..1) بتأخير ثابت 250ms. */
    val echo: Float = 0f,
    /** تطبيع الذروة: normalize=true يعني تضخيم بمعامل normGain (بيتحسب من تحليل العينات). */
    val normalize: Boolean = false,
    val normGain: Float = 1f,
    /** معادل 5 نطاقات (60Hz, 230Hz, 910Hz, 3.6kHz, 14kHz) بالديسيبل -12..12. */
    val eq: List<Float> = listOf(0f, 0f, 0f, 0f, 0f),
    /** تعزيز الباس / التريبل بالديسيبل 0..12. */
    val bass: Float = 0f,
    val treble: Float = 0f,
    /** 0 = بدون، 1 = تليفون، 2 = راديو. */
    val voiceFilter: Int = 0,
    /** صوت روبوت (ring modulator) 0..1. */
    val robot: Float = 0f,
    /** ريفيرب 0..1. */
    val reverb: Float = 0f,
    /** كورس/فلانجر 0..1، chorusMode: 0 = كورس، 1 = فلانجر. */
    val chorus: Float = 0f,
    val chorusMode: Int = 0,
    /** ترمولو (تذبذب مستوى الصوت) 0..1. */
    val tremolo: Float = 0f,
    /** فلتر قطع الترددات العالية (low-pass) بالهرتز؛ >= 19500 يعني مقفول. */
    val lowPassHz: Float = 20000f,
    /** فلتر قطع الترددات المنخفضة (high-pass) بالهرتز؛ <= 25 يعني مقفول. */
    val highPassHz: Float = 20f,
    /** بوابة ضوضاء 0..1. */
    val gate: Float = 0f,
    /** كومبريسور 0..1. */
    val comp: Float = 0f,
    val limiter: Boolean = false,
    /** 0 = عادي، 1 = مونو، 2 = ستيريو واسع. */
    val channelMode: Int = 0,
    /** بان -1 (شمال) .. 1 (يمين). */
    val pan: Float = 0f,
    val reverse: Boolean = false,
    val loops: Int = 1,
    /** إزالة طنين الكهرباء: 0 مقفول، 50 أو 60 هرتز (مع التوافقيات). */
    val humHz: Int = 0,
    /** ديسر (تقليل السين/الشين) 0..1. */
    val deEss: Float = 0f,
    /** إزالة النقرات والفرقعات. */
    val declick: Boolean = false,
    val padStartMs: Long = 0L,
    val padEndMs: Long = 0L,
    /** 0 = خطي، 1 = أُسّي (منحنى التلاشي). */
    val fadeCurve: Int = 0,
    /** مقاطع محذوفة من النص (بزمن المصدر)، مرتّبة وغير متداخلة. */
    val cuts: List<Pair<Long, Long>> = emptyList(),
    /** جودة التصدير AAC بالكيلوبت/ث. */
    val bitrateKbps: Int = 128,
) {
    /** مجموع المقاطع المحذوفة داخل نطاق القص. */
    val cutTotalMs: Long
        get() = cuts.sumOf { (minOf(it.second, endMs) - maxOf(it.first, startMs)).coerceAtLeast(0L) }

    /** مدة المعاينة (بعد القص والسرعة، بدون تكرار/صمت مضاف). */
    val previewMs: Long get() = ((endMs - startMs - cutTotalMs) / speed).toLong().coerceAtLeast(1L)

    val effectiveMs: Long
        get() = previewMs * loops.coerceAtLeast(1) + padStartMs.coerceAtLeast(0L) + padEndMs.coerceAtLeast(0L)

    /** فيه أي تأثير DSP (غير هيكلي) مفعّل؟ */
    val hasFx: Boolean
        get() = normalize || eq.any { it != 0f } || bass != 0f || treble != 0f || voiceFilter != 0 ||
            robot > 0.01f || reverb > 0.01f || chorus > 0.01f || tremolo > 0.01f ||
            lowPassHz < 19500f || highPassHz > 25f || gate > 0.01f || comp > 0.01f || limiter ||
            channelMode != 0 || pan != 0f
}

data class Project(
    val id: String,
    val name: String,
    val type: ProjectType,
    val createdAt: Long,
    val updatedAt: Long,
    val image: ImageData? = null,
    val video: VideoData? = null,
    val audio: AudioData? = null,
    val pinned: Boolean = false,
    /** بيانات الكانفس (صفحات متعددة). كل صفحة مشروع صورة تابع (parentId). */
    val canvas: CanvasData? = null,
    /** لو المشروع ده صفحة تابعة لكانفس: id الكانفس. بيتخفى من قائمة الشغل. */
    val parentId: String? = null,
) {
    val summary: String
        get() = when (type) {
            ProjectType.IMAGE -> {
                val e = image?.edit
                val layers = (e?.texts?.size ?: 0) + (e?.strokes?.size ?: 0)
                if (layers > 0) "$layers طبقة" else "صورة"
            }
            ProjectType.AUDIO -> {
                val a = audio
                if (a == null) "صوت" else "صوت • ${formatDuration(a.effectiveMs)}"
            }
            ProjectType.VIDEO -> {
                val v = video
                if (v == null) "فيديو" else "${v.clips.size} مقطع • ${formatDuration(v.totalMs)}"
            }
            ProjectType.CANVAS -> {
                val c = canvas
                if (c == null) "كانفس" else "كانفس • ${c.pages.size} صفحة • ${c.w}×${c.h}"
            }
        }
}

/** مستند كانفس: صفحات (مشاريع صور تابعة) بنفس المقاس. */
data class CanvasData(
    val pages: List<String> = emptyList(),
    val w: Int = 1080,
    val h: Int = 1080,
    val bg: Int = 0xFFFFFFFF.toInt(),
)

fun formatDuration(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val m = total / 60
    val s = total % 60
    return "%02d:%02d".format(m, s)
}

@Suppress("unused")
fun distance(x1: Float, y1: Float, x2: Float, y2: Float) = hypot(x2 - x1, y2 - y1)

/** هوية الصانع: تظهر في الشاشة الافتتاحية وعن التطبيق وكعلامة اختيارية على التصدير. */
object Brand {
    const val NAME = "VARQONX"
    const val MADE_BY = "from VARQONX"

    const val APP_NAME = "NASAQ"

    private const val BADGE_H = 150

    /** شارة العلامة المائية: لوجو التطبيق + NASAQ على خلفية شفافة غامقة (بتبان على أي خلفية). بترجع الملف وعرضه/ارتفاعه. */
    private fun badge(ctx: android.content.Context): Pair<java.io.File, Float>? {
        val f = java.io.File(ctx.cacheDir, "nasaq_wm_badge_v2.png")
        val logo = android.graphics.BitmapFactory.decodeResource(ctx.resources, com.binarybeast.mediastudio.R.drawable.nasaq_mark) ?: return null
        val tp = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE; textSize = 66f; typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            letterSpacing = 0.1f
        }
        val logoH = 110f
        val logoW = logoH * logo.width / logo.height
        val textW = tp.measureText(APP_NAME)
        val w = (24f + logoW + 18f + textW + 34f).toInt()
        val aspect = w.toFloat() / BADGE_H
        if (!f.exists() || f.length() < 100) {
            val bmp = android.graphics.Bitmap.createBitmap(w, BADGE_H, android.graphics.Bitmap.Config.ARGB_8888)
            val c = android.graphics.Canvas(bmp)
            val bg = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.argb(150, 0, 0, 0) }
            c.drawRoundRect(android.graphics.RectF(0f, 0f, w.toFloat(), BADGE_H.toFloat()), BADGE_H / 2f, BADGE_H / 2f, bg)
            c.drawBitmap(logo, null, android.graphics.RectF(24f, (BADGE_H - logoH) / 2f, 24f + logoW, (BADGE_H + logoH) / 2f), android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
            val fm = tp.fontMetrics
            c.drawText(APP_NAME, 24f + logoW + 18f, BADGE_H / 2f - (fm.ascent + fm.descent) / 2f, tp)
            runCatching { f.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) } }
        }
        return if (f.exists()) f to aspect else null
    }

    /** علامة مائية: لوجو التطبيق + اسمه بالإنجليزي (NASAQ) أسفل يمين الصورة/الفيديو/الكانفس. aspect = عرض/ارتفاع الإخراج. */
    fun watermarkLayers(ctx: android.content.Context, aspect: Float): List<TextLayer> {
        val a = aspect.coerceIn(0.2f, 5f)
        val (f, ba) = badge(ctx) ?: return emptyList()
        val size = (0.22f * a / ba).coerceIn(0.04f, 0.09f)       // ارتفاع الشارة كنسبة من ارتفاع الإخراج
        val wFrac = size * ba / a                                 // عرضها كنسبة من العرض
        return listOf(
            TextLayer(
                id = -78L, text = "", shape = 9, imageUri = android.net.Uri.fromFile(f).toString(),
                aspect = ba, x = 1f - 0.025f - wFrac / 2f, y = 1f - 0.02f - size / 2f, size = size,
                opacity = 0.92f, shadow = false, bold = false, startMs = 0L, endMs = -1L
            )
        )
    }
}
