package com.binarybeast.mediastudio.data

import kotlin.math.hypot

enum class ProjectType { IMAGE, VIDEO, AUDIO }

/** تعديلات الألوان الأساسية (كلها من -1 إلى 1 ما عدا hue بالدرجات). */
data class Adjust(
    val brightness: Float = 0f,
    val contrast: Float = 0f,
    val saturation: Float = 0f,
    val warmth: Float = 0f,
    val hue: Float = 0f,
) {
    operator fun plus(o: Adjust) = Adjust(
        brightness + o.brightness, contrast + o.contrast, saturation + o.saturation,
        warmth + o.warmth, hue + o.hue
    )

    operator fun times(k: Float) = Adjust(brightness * k, contrast * k, saturation * k, warmth * k, hue * k)

    val isIdentity: Boolean
        get() = brightness == 0f && contrast == 0f && saturation == 0f && warmth == 0f && hue == 0f
}

/** طبقة نص أو ستيكر (إيموجي). الإحداثيات طبيعية 0..1 والحجم نسبة من ارتفاع الصورة/الفيديو. */
data class TextLayer(
    val id: Long,
    val text: String,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val size: Float = 0.07f,
    val rotation: Float = 0f,
    val color: Int = 0xFFFFFFFF.toInt(),
    val bgColor: Int = 0,
    val bold: Boolean = true,
    val italic: Boolean = false,
    val font: Int = 0,
    val shadow: Boolean = true,
    val outline: Boolean = false,
    val opacity: Float = 1f,
    /** للفيديو فقط: زمن الظهور على التايم لاين بالميلي ثانية. */
    val startMs: Long = 0L,
    val endMs: Long = -1L,
    /** 0 = نص، 1 مستطيل، 2 مستطيل مدوّر، 3 دائرة/بيضاوي، 4 مثلث، 5 نجمة، 6 قلب، 7 خط، 8 سهم، 9 صورة. */
    val shape: Int = 0,
    /** عرض/ارتفاع للأشكال والصور (الارتفاع = size × ارتفاع الكانفس). */
    val aspect: Float = 1f,
    val imageUri: String? = null,
)

/** خط رسم بالفرشاة. pts = [x0,y0,x1,y1,...] طبيعية 0..1. width نسبة من أصغر بُعد. */
data class Stroke(
    val color: Int,
    val width: Float,
    val alpha: Float,
    val pts: List<Float>,
)

data class ImageEdit(
    val adjust: Adjust = Adjust(),
    val lookId: String = "original",
    val lookStrength: Float = 1f,
    val sharpen: Float = 0f,
    val blur: Float = 0f,
    val vignette: Float = 0f,
    val fade: Float = 0f,
    val border: Float = 0f,
    val borderColor: Int = 0xFFFFFFFF.toInt(),
    val rotation: Int = 0,
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    /** 0 = بدون تغيير نسبة الأبعاد. */
    val cropAspect: Float = 0f,
    val cropZoom: Float = 1f,
    val cropCx: Float = 0.5f,
    val cropCy: Float = 0.5f,
    /** تسوية الصورة بالدرجات (-45..45). */
    val straighten: Float = 0f,
    val grain: Float = 0f,
    val pixelate: Float = 0f,
    /** تدوير الزوايا (0..0.5 من أصغر بُعد). */
    val corner: Float = 0f,
    /** المؤثرات المتقدمة (تفاصيل/إضاءة/فلاتر إبداعية). */
    val fx: ImageFx = ImageFx(),
    val texts: List<TextLayer> = emptyList(),
    val strokes: List<Stroke> = emptyList(),
)

/** مؤثرات الصور المتقدمة. كل القيم الافتراضية = بدون تأثير. */
data class ImageFx(
    val exposure: Float = 0f,
    val highlights: Float = 0f,
    val shadows: Float = 0f,
    val whites: Float = 0f,
    val blacks: Float = 0f,
    /** -1 أخضر .. +1 ماجنتا. */
    val tint: Float = 0f,
    val vibrance: Float = 0f,
    val clarity: Float = 0f,
    val dehaze: Float = 0f,
    /** انحراف لوني (chromatic aberration) 0..1. */
    val chroma: Float = 0f,
    /** تقليل ضوضاء / تنعيم بشرة 0..1. */
    val denoise: Float = 0f,
    /** تيلت-شيفت: قوة البلور 0..1، النمط 0 خطي / 1 دائري، ومركز التركيز. */
    val focus: Float = 0f,
    val focusMode: Int = 0,
    val focusX: Float = 0.5f,
    val focusY: Float = 0.5f,
    /** فلتر إبداعي واحد: 0 بدون، 1 عكس، 2 بوستر، 3 سولار، 4 أبيض/أسود حاد، 5 نقش، 6 سكتش،
     *  7 جليتش، 8-10 دوتون، 11 هاف-تون، 12 مرآة أفقية، 13 مرآة رأسية، 14 كاليدوسكوب، 15 رسم زيتي. */
    val filter: Int = 0,
    val filterAmount: Float = 1f,
    val vignetteColor: Int = 0xFF000000.toInt(),
    /** تسريب ضوء 0..1 ونمطه 0..3. */
    val leak: Float = 0f,
    val leakStyle: Int = 0,
    /** غبار فيلم 0..1. */
    val dust: Float = 0f,
) {
    val toneActive: Boolean
        get() = exposure != 0f || highlights != 0f || shadows != 0f || whites != 0f || blacks != 0f ||
            tint != 0f || vibrance != 0f || dehaze != 0f
}

data class ImageData(
    val sourceUri: String?,
    val blankW: Int = 1080,
    val blankH: Int = 1080,
    val blankColor: Int = 0xFFFFFFFF.toInt(),
    val edit: ImageEdit = ImageEdit(),
)

data class VideoClip(
    val id: Long,
    val uri: String,
    val isImage: Boolean,
    /** مدة المصدر الكاملة (للصور: أقصى مدة مسموحة). */
    val srcDurationMs: Long,
    val startMs: Long,
    val endMs: Long,
    /** الأبعاد كما تظهر (بعد تطبيق تدوير الميتاداتا). */
    val width: Int,
    val height: Int,
    val speed: Float = 1f,
    val volume: Float = 1f,
    val muted: Boolean = false,
    val rotation: Int = 0,
    val flipH: Boolean = false,
    /** true = ملء الإطار مع القص، false = احتواء مع أشرطة سوداء. */
    val fill: Boolean = false,
    val lookId: String = "original",
    val lookStrength: Float = 1f,
    val adjust: Adjust = Adjust(),
    /** تلاشي من/إلى الأسود بالميلي ثانية. */
    val fadeInMs: Long = 0L,
    val fadeOutMs: Long = 0L,
    /** تكبير ثابت (1..4) وإزاحة (-1..1). */
    val zoom: Float = 1f,
    val panX: Float = 0f,
    val panY: Float = 0f,
    /** 0 = بدون، 1 = تقريب تدريجي، 2 = تبعيد تدريجي. */
    val kenBurns: Int = 0,
    /** فلتر ألوان خاص: 0 بدون، 1 رؤية ليلية، 2 سيانوتايب، 3 ذهبي، 4 وردي، 5 أحمر، 6 تبديل أحمر/أزرق، 7 تبديل أحمر/أخضر، 8 سيبيا قوي، 9 تشبّع عالي. */
    val vfx: Int = 0,
    val flipV: Boolean = false,
    /** صبغة -1 أخضر .. +1 ماجنتا. */
    val tint: Float = 0f,
) {
    val effectiveMs: Long get() = ((endMs - startMs) / speed).toLong().coerceAtLeast(1L)

    val displayAspect: Float
        get() {
            val a = if (height == 0) 1.7778f else width.toFloat() / height
            return if (rotation % 180 != 0) 1f / a else a
        }
}

data class VideoData(
    val clips: List<VideoClip> = emptyList(),
    val texts: List<TextLayer> = emptyList(),
    val musicUri: String? = null,
    val musicName: String = "",
    val musicDurationMs: Long = 0L,
    val musicVolume: Float = 1f,
    /** 0 = تلقائي (حسب أول مقطع)، وإلا قيمة النسبة w/h. */
    val aspect: Float = 0f,
    /** ارتفاع/عرض الإخراج الأقصر: 480 / 720 / 1080. */
    val resolution: Int = 720,
) {
    val totalMs: Long get() = clips.sumOf { it.effectiveMs }

    val canvasAspect: Float
        get() = if (aspect > 0f) aspect else clips.firstOrNull()?.displayAspect ?: 1.7778f

    /** مقاس الإخراج (أرقام زوجية). */
    fun outputSize(): Pair<Int, Int> {
        val a = canvasAspect
        val short = resolution
        val w: Int
        val h: Int
        if (a >= 1f) {
            h = short
            w = (short * a).toInt()
        } else {
            w = short
            h = (short / a).toInt()
        }
        return Pair(w / 2 * 2, h / 2 * 2)
    }

    fun clipStartMs(index: Int): Long {
        var t = 0L
        for (i in 0 until index.coerceAtMost(clips.size)) t += clips[i].effectiveMs
        return t
    }
}

/** مشروع صوتي: ملف واحد (صوت أو فيديو يتم استخراج صوته) مع قص وسرعة وطبقة صوت وتلاشي. */
data class AudioData(
    val uri: String,
    val name: String = "",
    val srcDurationMs: Long = 0L,
    val startMs: Long = 0L,
    val endMs: Long = 0L,
    val speed: Float = 1f,
    /** درجة الصوت (pitch) مستقلة عن السرعة. */
    val pitch: Float = 1f,
    /** 0..2 (2 = تضخيم للضعف). */
    val volume: Float = 1f,
    val fadeInMs: Long = 0L,
    val fadeOutMs: Long = 0L,
    /** صدى (0..1) بتأخير ثابت 250ms. */
    val echo: Float = 0f,
    /** تطبيع الذروة: normalize=true يعني تضخيم بمعامل normGain (بيتحسب من تحليل العينات). */
    val normalize: Boolean = false,
    val normGain: Float = 1f,
    /** معادل 5 نطاقات (60Hz, 230Hz, 910Hz, 3.6kHz, 14kHz) بالديسيبل -12..12. */
    val eq: List<Float> = listOf(0f, 0f, 0f, 0f, 0f),
    /** تعزيز الباس / التريبل بالديسيبل 0..12. */
    val bass: Float = 0f,
    val treble: Float = 0f,
    /** 0 = بدون، 1 = تليفون، 2 = راديو. */
    val voiceFilter: Int = 0,
    /** صوت روبوت (ring modulator) 0..1. */
    val robot: Float = 0f,
    /** ريفيرب 0..1. */
    val reverb: Float = 0f,
    /** كورس/فلانجر 0..1، chorusMode: 0 = كورس، 1 = فلانجر. */
    val chorus: Float = 0f,
    val chorusMode: Int = 0,
    /** ترمولو (تذبذب مستوى الصوت) 0..1. */
    val tremolo: Float = 0f,
    /** فلتر قطع الترددات العالية (low-pass) بالهرتز؛ >= 19500 يعني مقفول. */
    val lowPassHz: Float = 20000f,
    /** فلتر قطع الترددات المنخفضة (high-pass) بالهرتز؛ <= 25 يعني مقفول. */
    val highPassHz: Float = 20f,
    /** بوابة ضوضاء 0..1. */
    val gate: Float = 0f,
    /** كومبريسور 0..1. */
    val comp: Float = 0f,
    val limiter: Boolean = false,
    /** 0 = عادي، 1 = مونو، 2 = ستيريو واسع. */
    val channelMode: Int = 0,
    /** بان -1 (شمال) .. 1 (يمين). */
    val pan: Float = 0f,
    val reverse: Boolean = false,
    val loops: Int = 1,
    val padStartMs: Long = 0L,
    val padEndMs: Long = 0L,
    /** 0 = خطي، 1 = أُسّي (منحنى التلاشي). */
    val fadeCurve: Int = 0,
    /** مقاطع محذوفة من النص (بزمن المصدر)، مرتّبة وغير متداخلة. */
    val cuts: List<Pair<Long, Long>> = emptyList(),
    /** جودة التصدير AAC بالكيلوبت/ث. */
    val bitrateKbps: Int = 128,
) {
    /** مجموع المقاطع المحذوفة داخل نطاق القص. */
    val cutTotalMs: Long
        get() = cuts.sumOf { (minOf(it.second, endMs) - maxOf(it.first, startMs)).coerceAtLeast(0L) }

    /** مدة المعاينة (بعد القص والسرعة، بدون تكرار/صمت مضاف). */
    val previewMs: Long get() = ((endMs - startMs - cutTotalMs) / speed).toLong().coerceAtLeast(1L)

    val effectiveMs: Long
        get() = previewMs * loops.coerceAtLeast(1) + padStartMs.coerceAtLeast(0L) + padEndMs.coerceAtLeast(0L)

    /** فيه أي تأثير DSP (غير هيكلي) مفعّل؟ */
    val hasFx: Boolean
        get() = normalize || eq.any { it != 0f } || bass != 0f || treble != 0f || voiceFilter != 0 ||
            robot > 0.01f || reverb > 0.01f || chorus > 0.01f || tremolo > 0.01f ||
            lowPassHz < 19500f || highPassHz > 25f || gate > 0.01f || comp > 0.01f || limiter ||
            channelMode != 0 || pan != 0f
}

data class Project(
    val id: String,
    val name: String,
    val type: ProjectType,
    val createdAt: Long,
    val updatedAt: Long,
    val image: ImageData? = null,
    val video: VideoData? = null,
    val audio: AudioData? = null,
    val pinned: Boolean = false,
) {
    val summary: String
        get() = when (type) {
            ProjectType.IMAGE -> {
                val e = image?.edit
                val layers = (e?.texts?.size ?: 0) + (e?.strokes?.size ?: 0)
                if (layers > 0) "$layers طبقة" else "صورة"
            }
            ProjectType.AUDIO -> {
                val a = audio
                if (a == null) "صوت" else "صوت • ${formatDuration(a.effectiveMs)}"
            }
            ProjectType.VIDEO -> {
                val v = video
                if (v == null) "فيديو" else "${v.clips.size} مقطع • ${formatDuration(v.totalMs)}"
            }
        }
}

fun formatDuration(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val m = total / 60
    val s = total % 60
    return "%02d:%02d".format(m, s)
}

@Suppress("unused")
fun distance(x1: Float, y1: Float, x2: Float, y2: Float) = hypot(x2 - x1, y2 - y1)

/** هوية الصانع: تظهر في الشاشة الافتتاحية وعن التطبيق وكعلامة اختيارية على التصدير. */
object Brand {
    const val NAME = "VARQONX"
    const val MADE_BY = "from VARQONX"

    fun watermark() = TextLayer(
        id = -77L, text = NAME, x = 0.84f, y = 0.955f, size = 0.035f,
        color = 0xFFFFFFFF.toInt(), bold = true, shadow = true, opacity = 0.75f,
        startMs = 0L, endMs = -1L
    )
}
