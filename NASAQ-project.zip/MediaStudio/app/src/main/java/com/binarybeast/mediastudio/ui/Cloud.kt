package com.binarybeast.mediastudio.ui

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binarybeast.mediastudio.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** مزوّدو التخزين السحابي. الاستيراد/الرفع بيتم عبر منتقي ملفات النظام (SAF)، فبيظهروا فيه لو تطبيقاتهم منصّبة ومسجّل دخول. */
data class CloudProvider(val id: String, val label: String, val icon: Int, val packages: List<String>)

object CloudProviders {
    val all = listOf(
        CloudProvider("drive", "Google Drive", R.drawable.cloud_googledrive, listOf("com.google.android.apps.docs")),
        CloudProvider("dropbox", "Dropbox", R.drawable.cloud_dropbox, listOf("com.dropbox.android")),
        CloudProvider("onedrive", "OneDrive", R.drawable.cloud_onedrive, listOf("com.microsoft.skydrive")),
        CloudProvider("mega", "MEGA", R.drawable.cloud_mega, listOf("mega.privacy.android.app")),
        CloudProvider("box", "Box", R.drawable.cloud_box, listOf("com.box.android")),
        CloudProvider("nextcloud", "Nextcloud", R.drawable.cloud_nextcloud, listOf("com.nextcloud.client")),
    )

    fun isInstalled(ctx: Context, p: CloudProvider): Boolean = p.packages.any {
        runCatching { ctx.packageManager.getPackageInfo(it, 0) }.isSuccess
    }
}

object CloudUploader {
    fun displayName(ctx: Context, uri: Uri): String {
        runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.let { return it }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "file_${System.currentTimeMillis()}"
    }

    /** ينسخ الملفات داخل فولدر مختار (ممكن يكون في Drive/Dropbox/...). بيرجع عدد الملفات اللي اترفعت. */
    fun uploadToTree(ctx: Context, tree: Uri, files: List<Uri>): Int {
        val cr = ctx.contentResolver
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        var ok = 0
        for (src in files) {
            runCatching {
                val name = displayName(ctx, src)
                val mime = cr.getType(src) ?: "application/octet-stream"
                val dst = DocumentsContract.createDocument(cr, parent, mime, name) ?: error("create failed")
                cr.openInputStream(src)!!.use { ins -> cr.openOutputStream(dst)!!.use { ins.copyTo(it) } }
                ok++
            }
        }
        return ok
    }
}

/** يرجّع دالة: ابدأ رفع ملفات → المستخدم يختار فولدر سحابي → الرفع. */
@Composable
fun rememberCloudUpload(): (List<Uri>) -> Unit {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf<List<Uri>>(emptyList()) }
    val tree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { dir ->
        val files = pending
        pending = emptyList()
        if (dir == null || files.isEmpty()) return@rememberLauncherForActivityResult
        toast(ctx, "جاري الرفع...")
        scope.launch {
            val n = withContext(Dispatchers.IO) { CloudUploader.uploadToTree(ctx, dir, files) }
            toast(ctx, if (n == files.size) "تم رفع $n ملف" else "اترفع $n من ${files.size} ملف")
        }
    }
    return { files ->
        pending = files
        tree.launch(null)
    }
}

enum class CloudOpenKind { IMAGE, VIDEO, AUDIO }

@Composable
fun CloudScreen(onOpenAs: (CloudOpenKind, List<Uri>) -> Unit) {
    val ctx = LocalContext.current
    var imported by remember { mutableStateOf<List<Uri>>(emptyList()) }
    val upload = rememberCloudUpload()

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) imported = uris
    }
    val uploadPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) upload(uris)
    }
    val mimes = arrayOf("image/*", "video/*", "audio/*")

    val kinds = remember(imported) {
        val types = imported.map { ctx.contentResolver.getType(it) ?: "" }
        Triple(
            types.any { it.startsWith("image/") },
            types.any { it.startsWith("video/") },
            types.any { it.startsWith("audio/") || it.startsWith("video/") },
        )
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(150.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize().background(Bg).statusBarsPadding()
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                Text("السحابة", fontSize = 26.sp, color = MaterialTheme.colorScheme.onBackground)
                Text(
                    "استورد ملفاتك من خدمات التخزين السحابي، وارفع شغلك عليها.",
                    color = TextDim, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) { SectionLabel("استيراد من السحابة") }
        items(CloudProviders.all) { p ->
            val installed = remember(p.id) { CloudProviders.isInstalled(ctx, p) }
            ProviderCard(p, installed, NI.CloudDownload) { importPicker.launch(mimes) }
        }

        if (imported.isNotEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surface1).padding(14.dp)
                ) {
                    Text("تم اختيار ${imported.size} ملف. افتحهم في:", fontSize = 14.sp)
                    Row(
                        Modifier.padding(top = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (kinds.first) SmallButton("محرر الصور", { onOpenAs(CloudOpenKind.IMAGE, imported.also { imported = emptyList() }) })
                        SmallButton("محرر الفيديو", { onOpenAs(CloudOpenKind.VIDEO, imported.also { imported = emptyList() }) })
                        if (kinds.third) SmallButton("محرر الصوت", { onOpenAs(CloudOpenKind.AUDIO, imported.also { imported = emptyList() }) })
                    }
                }
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) { SectionLabel("رفع إلى السحابة") }
        items(CloudProviders.all) { p ->
            val installed = remember(p.id) { CloudProviders.isInstalled(ctx, p) }
            ProviderCard(p, installed, NI.CloudUpload) { uploadPicker.launch(mimes) }
        }
        item(span = { GridItemSpan(maxLineSpan) }) { MadeBy(Modifier.fillMaxWidth().padding(top = 8.dp)) }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
                "اختار الملفات من جهازك، وبعدين اختار فولدر جوّه الخدمة السحابية اللي عايزها. " +
                    "الخدمة بتظهر في قايمة منتقي الملفات لو تطبيقها منصّب ومسجّل دخول. " +
                    "تقدر كمان ترفع أي تصدير مباشرة من شاشة التصدير في المحررات.",
                color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp).widthIn(max = 700.dp)
            )
        }
    }
}

@Composable
private fun ProviderCard(p: CloudProvider, installed: Boolean, actionIcon: NIcon, onClick: () -> Unit) {
    Column(
        Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Surface1)
            .clickable(onClick = onClick)
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box {
            Image(painterResource(p.icon), p.label, modifier = Modifier.size(48.dp), contentScale = ContentScale.Fit)
        }
        Text(p.label, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp), textAlign = TextAlign.Center)
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
            NIc(actionIcon, null, tint = Accent, modifier = Modifier.size(14.dp))
            Text(
                if (installed) "  مثبّت" else "  عبر المنتقي",
                fontSize = 11.sp, color = if (installed) Accent else TextDim
            )
        }
    }
}
