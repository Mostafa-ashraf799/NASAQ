package com.binarybeast.mediastudio.ui

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.ui.graphics.vector.ImageVector
import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binarybeast.mediastudio.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** مزوّدو التخزين السحابي. الاستيراد/الرفع بيتم عبر منتقي ملفات النظام (SAF)، فبيظهروا فيه لو تطبيقاتهم منصّبة ومسجّل دخول. */
data class CloudProvider(val id: String, val label: String, val icon: Int, val packages: List<String>, val domain: String) {
    val iconUrl: String get() = "https://www.google.com/s2/favicons?domain=$domain&sz=128"
}

object CloudProviders {
    val all = listOf(
        CloudProvider("drive", "Google Drive", R.drawable.cloud_googledrive, listOf("com.google.android.apps.docs"), "drive.google.com"),
        CloudProvider("dropbox", "Dropbox", R.drawable.cloud_dropbox, listOf("com.dropbox.android"), "dropbox.com"),
        CloudProvider("onedrive", "OneDrive", R.drawable.cloud_onedrive, listOf("com.microsoft.skydrive"), "onedrive.live.com"),
        CloudProvider("mega", "MEGA", R.drawable.cloud_mega, listOf("mega.privacy.android.app"), "mega.nz"),
        CloudProvider("box", "Box", R.drawable.cloud_box, listOf("com.box.android"), "box.com"),
        CloudProvider("nextcloud", "Nextcloud", R.drawable.cloud_nextcloud, listOf("com.nextcloud.client"), "nextcloud.com"),
    )

    fun isInstalled(ctx: Context, p: CloudProvider): Boolean = p.packages.any {
        runCatching { ctx.packageManager.getPackageInfo(it, 0) }.isSuccess
    }
}

object CloudUploader {
    fun displayName(ctx: Context, uri: Uri): String {
        runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.let { return it }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "file_${System.currentTimeMillis()}"
    }

    /** ينسخ الملفات داخل فولدر مختار (ممكن يكون في Drive/Dropbox/...). بيرجع عدد الملفات اللي اترفعت. */
    fun uploadToTree(ctx: Context, tree: Uri, files: List<Uri>): Int {
        val cr = ctx.contentResolver
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        var ok = 0
        for (src in files) {
            runCatching {
                val name = displayName(ctx, src)
                val mime = cr.getType(src) ?: "application/octet-stream"
                val dst = DocumentsContract.createDocument(cr, parent, mime, name) ?: error("create failed")
                cr.openInputStream(src)!!.use { ins -> cr.openOutputStream(dst)!!.use { ins.copyTo(it) } }
                ok++
            }
        }
        return ok
    }
}

/** يرجّع دالة: ابدأ رفع ملفات → المستخدم يختار فولدر سحابي → الرفع. */
@Composable
fun rememberCloudUpload(): (List<Uri>) -> Unit {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf<List<Uri>>(emptyList()) }
    val tree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { dir ->
        val files = pending
        pending = emptyList()
        if (dir == null || files.isEmpty()) return@rememberLauncherForActivityResult
        toast(ctx, "بدأ الرفع في الخلفية (تابعه من الشريط فوق)")
        Transfers.upload(ctx, dir, files)
    }
    return { files ->
        pending = files
        tree.launch(null)
    }
}

enum class CloudOpenKind { IMAGE, VIDEO, AUDIO }

@Composable
fun CloudScreen(onOpenAs: (CloudOpenKind, List<Uri>) -> Unit) {
    val ctx = LocalContext.current
    var browsing by remember { mutableStateOf<CloudProvider?>(null) }
    var customUrl by remember { mutableStateOf<String?>(null) }
    var askServer by remember { mutableStateOf(false) }
    browsing?.let { bp ->
        CloudBrowser(
            title = bp.label,
            startUrl = cloudStartUrl(bp, customUrl),
            onClose = { browsing = null },
            onOpenAs = { k, u -> browsing = null; onOpenAs(k, u) }
        )
        return
    }
    if (askServer) {
        TextInputDialog(
            title = "رابط سيرفر Nextcloud", hint = "cloud.example.com",
            onConfirm = { customUrl = it; askServer = false; browsing = CloudProviders.all.first { p -> p.id == "nextcloud" } },
            onDismiss = { askServer = false }
        )
    }
    var imported by remember { mutableStateOf<List<Uri>>(emptyList()) }
    val upload = rememberCloudUpload()

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) imported = uris
    }
    val uploadPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) upload(uris)
    }
    val mimes = arrayOf("image/*", "video/*", "audio/*")

    val kinds = remember(imported) {
        val types = imported.map { ctx.contentResolver.getType(it) ?: "" }
        Triple(
            types.any { it.startsWith("image/") },
            types.any { it.startsWith("video/") },
            types.any { it.startsWith("audio/") || it.startsWith("video/") },
        )
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(150.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize().background(Bg).statusBarsPadding()
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                Text("السحابة", fontSize = 26.sp, color = MaterialTheme.colorScheme.onBackground)
                Text(
                    "استورد ملفاتك من خدمات التخزين السحابي، وارفع شغلك عليها.",
                    color = TextDim, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) { SectionLabel("افتح الخدمة جوّه التطبيق") }
        items(CloudProviders.all) { p ->
            val installed = remember(p.id) { CloudProviders.isInstalled(ctx, p) }
            ProviderCard(p, installed, Icons.Default.CloudDownload) {
                if (p.id == "nextcloud") askServer = true else browsing = p
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
                "سجّل دخول في الصفحة اللي هتفتح، ولما تدوس تحميل لأي صورة/فيديو/صوت هيتفتح في المحرر. " +
                    "ملحوظة: جوجل أحيانًا بترفض تسجيل الدخول جوّه المتصفحات المدمجة، ولو حصل استخدم الاستيراد من المنتقي تحت.",
                color = TextDim, fontSize = 12.sp, modifier = Modifier.widthIn(max = 700.dp)
            )
        }
        item(span = { GridItemSpan(maxLineSpan) }) { SectionLabel("أو عن طريق منتقي ملفات النظام") }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallButton("استيراد ملفات", { importPicker.launch(mimes) })
                SmallButton("رفع ملفات من الجهاز", { uploadPicker.launch(mimes) })
            }
        }

        if (imported.isNotEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surface1).padding(14.dp)
                ) {
                    Text("تم اختيار ${imported.size} ملف. افتحهم في:", fontSize = 14.sp)
                    Row(
                        Modifier.padding(top = 10.dp).horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (kinds.first) SmallButton("محرر الصور", { onOpenAs(CloudOpenKind.IMAGE, imported.also { imported = emptyList() }) })
                        SmallButton("محرر الفيديو", { onOpenAs(CloudOpenKind.VIDEO, imported.also { imported = emptyList() }) })
                        if (kinds.third) SmallButton("محرر الصوت", { onOpenAs(CloudOpenKind.AUDIO, imported.also { imported = emptyList() }) })
                    }
                }
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
                "اختار الملفات من جهازك، وبعدين اختار فولدر جوّه الخدمة السحابية اللي عايزها. " +
                    "الخدمة بتظهر في قايمة منتقي الملفات لو تطبيقها منصّب ومسجّل دخول. " +
                    "تقدر كمان ترفع أي تصدير مباشرة من شاشة التصدير في المحررات.",
                color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp).widthIn(max = 700.dp)
            )
        }
    }
}

@Composable
private fun ProviderCard(p: CloudProvider, installed: Boolean, actionIcon: ImageVector, onClick: () -> Unit) {
    Column(
        Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Surface1)
            .clickable(onClick = onClick)
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box {
            val local = painterResource(p.icon)
            coil.compose.AsyncImage(
                model = p.iconUrl, contentDescription = p.label,
                placeholder = local, error = local, fallback = local,
                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Fit
            )
        }
        Text(p.label, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp), textAlign = TextAlign.Center)
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
            Icon(actionIcon, null, tint = Accent, modifier = Modifier.size(14.dp))
            Text(
                if (installed) "  مثبّت" else "  افتح",
                fontSize = 11.sp, color = if (installed) Accent else TextDim
            )
        }
    }
}
