package com.binarybeast.mediastudio.image

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import com.binarybeast.mediastudio.data.Adjust
import com.binarybeast.mediastudio.data.ImageEdit
import com.binarybeast.mediastudio.data.Looks
import com.binarybeast.mediastudio.data.Stroke
import com.binarybeast.mediastudio.data.TextLayer
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** خط المعالجة الكامل للصور: اتجاه → قص → ألوان/فلتر → بلور → حدة → فينيت → إطار. */
object ImageProcessor {

    private val IDENT = floatArrayOf(
        1f, 0f, 0f, 0f, 0f,
        0f, 1f, 0f, 0f, 0f,
        0f, 0f, 1f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f,
    )

    private val SEPIA = floatArrayOf(
        0.393f, 0.769f, 0.189f, 0f, 0f,
        0.349f, 0.686f, 0.168f, 0f, 0f,
        0.272f, 0.534f, 0.131f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f,
    )

    private fun lerp(a: FloatArray, b: FloatArray, t: Float) = FloatArray(20) { a[it] + (b[it] - a[it]) * t }

    private fun scaleMatrix(r: Float, g: Float, b: Float) = ColorMatrix(
        floatArrayOf(
            r, 0f, 0f, 0f, 0f,
            0f, g, 0f, 0f, 0f,
            0f, 0f, b, 0f, 0f,
            0f, 0f, 0f, 1f, 0f,
        )
    )

    private fun hueMatrix(deg: Float): ColorMatrix {
        val rad = Math.toRadians(deg.toDouble())
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()
        val lr = 0.213f
        val lg = 0.715f
        val lb = 0.072f
        return ColorMatrix(
            floatArrayOf(
                lr + c * (1 - lr) + s * -lr, lg + c * -lg + s * -lg, lb + c * -lb + s * (1 - lb), 0f, 0f,
                lr + c * -lr + s * 0.143f, lg + c * (1 - lg) + s * 0.140f, lb + c * -lb + s * -0.283f, 0f, 0f,
                lr + c * -lr + s * -(1 - lr), lg + c * -lg + s * lg, lb + c * (1 - lb) + s * lb, 0f, 0f,
                0f, 0f, 0f, 1f, 0f,
            )
        )
    }

    fun colorMatrix(adjust: Adjust, lookId: String, strength: Float, fade: Float): ColorMatrix {
        val look = Looks.byId(lookId)
        val k = strength.coerceIn(0f, 1f)
        val eff = look.adjust * k + adjust
        val result = ColorMatrix()

        // 1) البنية الأساسية للفلتر (أبيض/أسود، سيبيا، قنوات لونية) مخلوطة بالقوة
        var structural = ColorMatrix()
        if (look.mono) structural = ColorMatrix().apply { setSaturation(0f) }
        if (look.sepia) structural = ColorMatrix(SEPIA)
        if (look.r != 1f || look.g != 1f || look.b != 1f) structural.postConcat(scaleMatrix(look.r, look.g, look.b))
        result.set(ColorMatrix(lerp(IDENT, structural.array, k)))

        // 2) تعديلات المستخدم
        if (eff.saturation != 0f) {
            result.postConcat(ColorMatrix().apply { setSaturation((1f + eff.saturation).coerceIn(0f, 3f)) })
        }
        if (eff.hue != 0f) result.postConcat(hueMatrix(eff.hue))
        if (eff.warmth != 0f) {
            result.postConcat(scaleMatrix(1f + 0.25f * eff.warmth, 1f + 0.03f * eff.warmth, 1f - 0.25f * eff.warmth))
        }
        if (eff.contrast != 0f) {
            val c = (1f + eff.contrast).coerceIn(0f, 3f)
            val t = 127.5f * (1f - c)
            result.postConcat(
                ColorMatrix(
                    floatArrayOf(
                        c, 0f, 0f, 0f, t,
                        0f, c, 0f, 0f, t,
                        0f, 0f, c, 0f, t,
                        0f, 0f, 0f, 1f, 0f,
                    )
                )
            )
        }
        if (eff.brightness != 0f) {
            val o = eff.brightness * 255f
            result.postConcat(
                ColorMatrix(
                    floatArrayOf(
                        1f, 0f, 0f, 0f, o,
                        0f, 1f, 0f, 0f, o,
                        0f, 0f, 1f, 0f, o,
                        0f, 0f, 0f, 1f, 0f,
                    )
                )
            )
        }
        if (fade > 0f) {
            val s = 1f - 0.22f * fade
            val o = 45f * fade
            result.postConcat(
                ColorMatrix(
                    floatArrayOf(
                        s, 0f, 0f, 0f, o,
                        0f, s, 0f, 0f, o,
                        0f, 0f, s, 0f, o,
                        0f, 0f, 0f, 1f, 0f,
                    )
                )
            )
        }
        return result
    }

    fun orient(src: Bitmap, rotation: Int, flipH: Boolean, flipV: Boolean): Bitmap {
        if (rotation % 360 == 0 && !flipH && !flipV) return src
        val m = Matrix()
        m.postRotate(rotation.toFloat())
        if (flipH) m.postScale(-1f, 1f)
        if (flipV) m.postScale(1f, -1f)
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    fun cropRect(w: Int, h: Int, e: ImageEdit): Rect {
        if (e.cropAspect <= 0f && e.cropZoom <= 1.001f) return Rect(0, 0, w, h)
        val a = if (e.cropAspect > 0f) e.cropAspect else w.toFloat() / h
        var cw: Float
        var ch: Float
        if (w.toFloat() / h > a) {
            ch = h.toFloat(); cw = ch * a
        } else {
            cw = w.toFloat(); ch = cw / a
        }
        cw /= e.cropZoom.coerceAtLeast(1f)
        ch /= e.cropZoom.coerceAtLeast(1f)
        val cx = (e.cropCx * w).coerceIn(cw / 2f, w - cw / 2f)
        val cy = (e.cropCy * h).coerceIn(ch / 2f, h - ch / 2f)
        val l = (cx - cw / 2f).roundToInt().coerceIn(0, w - 1)
        val t = (cy - ch / 2f).roundToInt().coerceIn(0, h - 1)
        val r = (cx + cw / 2f).roundToInt().coerceIn(l + 1, w)
        val b = (cy + ch / 2f).roundToInt().coerceIn(t + 1, h)
        return Rect(l, t, r, b)
    }

    /** المعالجة الأساسية بدون الطبقات (نصوص/رسم). تُرجع Bitmap قابلة للتعديل. */
    fun render(src: Bitmap, e: ImageEdit): Bitmap {
        var bmp = orient(src, e.rotation, e.flipH, e.flipV)
        if (kotlin.math.abs(e.straighten) > 0.05f) bmp = straighten(bmp, e.straighten)
        val r = cropRect(bmp.width, bmp.height, e)
        if (r.width() != bmp.width || r.height() != bmp.height) {
            bmp = Bitmap.createBitmap(bmp, r.left, r.top, r.width(), r.height())
        }

        var res = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.colorFilter = ColorMatrixColorFilter(colorMatrix(e.adjust, e.lookId, e.lookStrength, e.fade))
        Canvas(res).drawBitmap(bmp, 0f, 0f, paint)

        val fx = e.fx
        res = ImageFxProcessor.stageA(res, fx)
        if (e.pixelate > 0.01f) res = pixelate(res, e.pixelate)
        if (e.blur > 0.01f) res = blur(res, e.blur)
        if (e.sharpen > 0.01f) res = sharpen(res, e.sharpen)
        res = ImageFxProcessor.stageB(res, fx)
        if (e.grain > 0.01f) res = grain(res, e.grain)
        if (!res.isMutable) res = res.copy(Bitmap.Config.ARGB_8888, true)
        if (e.vignette > 0.01f) drawVignette(Canvas(res), res.width, res.height, e.vignette, fx.vignetteColor)
        if (fx.leak > 0.01f) ImageFxProcessor.drawLeak(Canvas(res), res.width, res.height, fx.leak, fx.leakStyle)
        if (fx.dust > 0.01f) ImageFxProcessor.drawDust(Canvas(res), res.width, res.height, fx.dust)
        if (e.border > 0.001f) drawBorder(Canvas(res), res.width, res.height, e.border, e.borderColor)
        if (e.corner > 0.005f) res = roundCorners(res, e.corner)
        return res
    }

    /** المعالجة الكاملة بما فيها الطبقات (للتصدير). */
    fun renderFull(src: Bitmap, e: ImageEdit): Bitmap {
        val base = render(src, e)
        drawOverlays(Canvas(base), base.width.toFloat(), base.height.toFloat(), e.strokes, e.texts)
        return base
    }

    // ---------------------------------------------------------------- effects

    /** تدوير الصورة بزاوية صغيرة مع تكبير كافي عشان مفيش زوايا فاضية. */
    private fun straighten(src: Bitmap, deg: Float): Bitmap {
        val w = src.width
        val h = src.height
        val rad = Math.toRadians(kotlin.math.abs(deg).toDouble())
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()
        val scale = max(c + (h.toFloat() / w) * s, c + (w.toFloat() / h) * s)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val m = Matrix()
        m.postTranslate(-w / 2f, -h / 2f)
        m.postRotate(deg)
        m.postScale(scale, scale)
        m.postTranslate(w / 2f, h / 2f)
        Canvas(out).drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    private fun pixelate(b: Bitmap, amount: Float): Bitmap {
        val f = 1f + amount.coerceIn(0f, 1f) * (max(b.width, b.height) / 18f)
        val sw = max(1, (b.width / f).toInt())
        val sh = max(1, (b.height / f).toInt())
        val small = Bitmap.createScaledBitmap(b, sw, sh, false)
        val back = Bitmap.createScaledBitmap(small, b.width, b.height, false)
        return back.copy(Bitmap.Config.ARGB_8888, true)
    }

    private fun grain(b: Bitmap, amount: Float): Bitmap {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        val rnd = java.util.Random(42L)
        val k = amount.coerceIn(0f, 1f) * 70f
        for (i in px.indices) {
            val n = ((rnd.nextFloat() - 0.5f) * k).toInt()
            val c = px[i]
            var r = ((c shr 16) and 255) + n
            var g = ((c shr 8) and 255) + n
            var bl = (c and 255) + n
            if (r < 0) r = 0 else if (r > 255) r = 255
            if (g < 0) g = 0 else if (g > 255) g = 255
            if (bl < 0) bl = 0 else if (bl > 255) bl = 255
            px[i] = (c and 0xFF000000.toInt()) or (r shl 16) or (g shl 8) or bl
        }
        val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        res.setPixels(px, 0, w, 0, 0, w, h)
        return res
    }

    private fun roundCorners(b: Bitmap, corner: Float): Bitmap {
        val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = android.graphics.BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val r = corner.coerceIn(0f, 0.5f) * min(b.width, b.height)
        Canvas(out).drawRoundRect(android.graphics.RectF(0f, 0f, b.width.toFloat(), b.height.toFloat()), r, r, p)
        return out
    }

    private fun blur(b: Bitmap, amount: Float): Bitmap {
        val f = 1f + amount.coerceIn(0f, 1f) * 14f
        val sw = max(1, (b.width / f).toInt())
        val sh = max(1, (b.height / f).toInt())
        val small = Bitmap.createScaledBitmap(b, sw, sh, true)
        val tiny = Bitmap.createScaledBitmap(small, max(1, sw / 2), max(1, sh / 2), true)
        val back = Bitmap.createScaledBitmap(tiny, b.width, b.height, true)
        return back.copy(Bitmap.Config.ARGB_8888, true)
    }

    private fun sharpen(b: Bitmap, amount: Float): Bitmap {
        val w = b.width
        val h = b.height
        if (w < 3 || h < 3) return b
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        val out = px.copyOf()
        val a = amount.coerceIn(0f, 1f) * 0.8f
        val center = 1f + 4f * a
        for (y in 1 until h - 1) {
            var i = y * w + 1
            for (x in 1 until w - 1) {
                val c = px[i]
                val l = px[i - 1]
                val r = px[i + 1]
                val u = px[i - w]
                val d = px[i + w]
                var rr = (((c shr 16) and 255) * center -
                    a * (((l shr 16) and 255) + ((r shr 16) and 255) + ((u shr 16) and 255) + ((d shr 16) and 255))).toInt()
                var gg = (((c shr 8) and 255) * center -
                    a * (((l shr 8) and 255) + ((r shr 8) and 255) + ((u shr 8) and 255) + ((d shr 8) and 255))).toInt()
                var bb = ((c and 255) * center -
                    a * ((l and 255) + (r and 255) + (u and 255) + (d and 255))).toInt()
                if (rr < 0) rr = 0 else if (rr > 255) rr = 255
                if (gg < 0) gg = 0 else if (gg > 255) gg = 255
                if (bb < 0) bb = 0 else if (bb > 255) bb = 255
                out[i] = (c and 0xFF000000.toInt()) or (rr shl 16) or (gg shl 8) or bb
                i++
            }
        }
        val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        res.setPixels(out, 0, w, 0, 0, w, h)
        return res
    }

    private fun drawVignette(c: Canvas, w: Int, h: Int, amount: Float, color: Int = 0xFF000000.toInt()) {
        val rgb = color and 0x00FFFFFF
        val alpha = (amount.coerceIn(0f, 1f) * 0.85f * 255).toInt()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(
            w / 2f, h / 2f, hypot(w.toFloat(), h.toFloat()) / 2f,
            intArrayOf(rgb, rgb, (alpha shl 24) or rgb),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
    }

    private fun drawBorder(c: Canvas, w: Int, h: Int, amount: Float, color: Int) {
        val t = amount * min(w, h)
        val p = Paint().apply { this.color = color }
        c.drawRect(0f, 0f, w.toFloat(), t, p)
        c.drawRect(0f, h - t, w.toFloat(), h.toFloat(), p)
        c.drawRect(0f, t, t, h - t, p)
        c.drawRect(w - t, t, w.toFloat(), h - t, p)
    }

    // ---------------------------------------------------------------- overlays

    fun drawOverlays(c: Canvas, w: Float, h: Float, strokes: List<Stroke>, texts: List<TextLayer>) {
        strokes.forEach { drawStroke(c, it, w, h) }
        texts.forEach { TextRenderer.draw(c, it, w, h) }
    }

    fun drawStroke(c: Canvas, s: Stroke, w: Float, h: Float) {
        if (s.pts.size < 2) return
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = s.color
            alpha = (s.alpha.coerceIn(0f, 1f) * 255).toInt()
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            strokeWidth = (s.width * min(w, h)).coerceAtLeast(1f)
        }
        val n = s.pts.size / 2
        if (n == 1) {
            p.style = Paint.Style.FILL
            c.drawCircle(s.pts[0] * w, s.pts[1] * h, p.strokeWidth / 2f, p)
            return
        }
        val path = Path()
        path.moveTo(s.pts[0] * w, s.pts[1] * h)
        for (i in 1 until n) {
            val px = s.pts[(i - 1) * 2] * w
            val py = s.pts[(i - 1) * 2 + 1] * h
            val x = s.pts[i * 2] * w
            val y = s.pts[i * 2 + 1] * h
            path.quadTo(px, py, (px + x) / 2f, (py + y) / 2f)
        }
        path.lineTo(s.pts[(n - 1) * 2] * w, s.pts[(n - 1) * 2 + 1] * h)
        c.drawPath(path, p)
    }
}
