@file:OptIn(UnstableApi::class)

package com.binarybeast.mediastudio.audio

import android.graphics.Bitmap
import androidx.media3.common.util.UnstableApi
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** ديسر ديناميكي: بيقلّل ترددات السين والشين (>~5.5kHz) لما تعلى عن حد معيّن. */
class DeEsserProcessor(private val amount: Float) : PcmProcessor() {
    private var lp = FloatArray(0)
    private var env = 0f
    private var a = 0.5f
    override fun setup() {
        lp = FloatArray(ch)
        a = (1.0 - exp(-2.0 * PI * 5500.0 / rate)).toFloat()
    }
    override fun clear() { lp.fill(0f); env = 0f }
    override fun frame(s: FloatArray) {
        var hpMax = 0f
        val hp = FloatArray(ch)
        for (c in 0 until ch) {
            lp[c] += a * (s[c] - lp[c])
            hp[c] = s[c] - lp[c]
            hpMax = max(hpMax, abs(hp[c]))
        }
        env += (hpMax - env) * (if (hpMax > env) 0.02f else 0.0008f)
        val thr = 0.06f - 0.045f * amount
        val red = if (env > thr) (thr / env).pow(0.5f + amount) else 1f
        for (c in 0 until ch) s[c] = lp[c] + hp[c] * red
    }
}

/** إزالة النقرات والفرقعات القصيرة: أي عينة معزولة بتقفز بشكل حاد بتتبدّل بمتوسط جيرانها (تأخير عينة واحدة). */
class DeClickProcessor : PcmProcessor() {
    private var h1 = FloatArray(0)
    private var h2 = FloatArray(0)
    override fun setup() { h1 = FloatArray(ch); h2 = FloatArray(ch) }
    override fun clear() { h1.fill(0f); h2.fill(0f) }
    override fun frame(s: FloatArray) {
        val thr = 0.28f
        for (c in 0 until ch) {
            val x = s[c]; val p1 = h1[c]; val p2 = h2[c]
            var y = p1
            val d1 = p1 - p2; val d2 = p1 - x
            if (abs(d1) > thr && abs(d2) > thr && d1 * d2 > 0f) y = (p2 + x) / 2f
            h2[c] = y; h1[c] = x
            s[c] = y
        }
    }
}

/** تحليل صوتي: جهارة تقريبية (RMS بعد استبعاد الصمت) + طيف زمني (Spectrogram). */
object AudioAnalysis {

    /** مستوى RMS بالديسيبل (dBFS) على الأجزاء غير الصامتة. */
    fun loudnessDb(p: AudioPcm.Pcm): Float? {
        val frame = (p.rate / 10) * p.ch
        var sum = 0.0; var n = 0L
        var i = 0
        while (i + frame <= p.data.size) {
            var s = 0.0
            for (k in i until i + frame) { val v = p.data[k] / 32768.0; s += v * v }
            val rms = sqrt(s / frame)
            if (rms > 0.003) { sum += s; n += frame }      // أعلى من -50 dB تقريبًا
            i += frame
        }
        if (n == 0L) return null
        return (20.0 * log10(sqrt(sum / n))).toFloat()
    }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val t = re[i]; re[i] = re[j]; re[j] = t; val u = im[i]; im[i] = im[j]; im[j] = u }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wr = cos(ang); val wi = sin(ang)
            var i = 0
            while (i < n) {
                var cr = 1.0; var ci = 0.0
                for (k in 0 until len / 2) {
                    val ur = re[i + k]; val ui = im[i + k]
                    val vr = re[i + k + len / 2] * cr - im[i + k + len / 2] * ci
                    val vi = re[i + k + len / 2] * ci + im[i + k + len / 2] * cr
                    re[i + k] = ur + vr; im[i + k] = ui + vi
                    re[i + k + len / 2] = ur - vr; im[i + k + len / 2] = ui - vi
                    val ncr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }

    /** صورة طيف: المحور الأفقي الزمن والرأسي التردد (تحت = باس). بتساعد تشوف الطنين (خط أفقي ثابت) والضوضاء. */
    fun spectrogram(p: AudioPcm.Pcm, w: Int = 640, h: Int = 256): Bitmap {
        val n = 1024
        val mono = FloatArray(p.data.size / p.ch) { i ->
            var s = 0f; for (c in 0 until p.ch) s += p.data[i * p.ch + c]; s / p.ch / 32768f
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val px = IntArray(w * h)
        val hop = max(1, (mono.size - n) / w)
        val re = DoubleArray(n); val im = DoubleArray(n)
        val win = DoubleArray(n) { 0.5 - 0.5 * cos(2.0 * PI * it / (n - 1)) }
        val maxF = min(p.rate / 2.0, 12000.0)
        val bins = (maxF / (p.rate / 2.0) * (n / 2)).toInt().coerceAtLeast(8)
        for (x in 0 until w) {
            val start = x * hop
            for (k in 0 until n) { re[k] = if (start + k < mono.size) mono[start + k] * win[k] else 0.0; im[k] = 0.0 }
            fft(re, im)
            for (y in 0 until h) {
                val bin = ((h - 1 - y).toDouble() / (h - 1)).pow(1.6) * (bins - 1)
                val b = bin.toInt().coerceIn(1, n / 2 - 1)
                val mag = sqrt(re[b] * re[b] + im[b] * im[b]) / n
                val db = 20.0 * log10(mag + 1e-9)
                val t = ((db + 100.0) / 70.0).coerceIn(0.0, 1.0)
                // لوحة ألوان: أسود → بنفسجي → أحمر → أصفر → أبيض
                val r = (255 * min(1.0, t * 2.0)).toInt()
                val g = (255 * max(0.0, min(1.0, (t - 0.45) * 2.2))).toInt()
                val bl = (255 * (if (t < 0.5) t * 1.6 else max(0.0, 1.2 - t * 1.4))).toInt().coerceIn(0, 255)
                px[y * w + x] = (255 shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or bl
            }
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
        return bmp
    }
}
