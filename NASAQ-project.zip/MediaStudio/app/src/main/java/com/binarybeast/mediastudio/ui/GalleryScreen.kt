@file:OptIn(UnstableApi::class)

package com.binarybeast.mediastudio.ui

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.binarybeast.mediastudio.data.MediaEntry
import com.binarybeast.mediastudio.data.MediaRepository
import com.binarybeast.mediastudio.data.ProjectType
import com.binarybeast.mediastudio.data.formatDuration
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private enum class MediaFilter(val label: String) { ALL("الكل"), IMAGES("صور"), VIDEOS("فيديو") }

/**
 * صفحة المعرض: بتعرض صور وفيديوهات الجهاز.
 * - pickType == null  → وضع التصفح: اضغط للمعاينة، اضغط مطولاً للتحديد المتعدد.
 * - pickType != null  → وضع اختيار ميديا لمشروع جديد (صورة واحدة / عدة مقاطع).
 * onUrisChosen(uris, asVideo) بيتنادى لما المستخدم يقرر.
 */
@Composable
fun GalleryScreen(
    pickType: ProjectType?,
    onUrisChosen: (List<Uri>, Boolean) -> Unit,
    onBack: (() -> Unit)? = null,
) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(MediaRepository.hasPermission(ctx)) }
    var items by remember { mutableStateOf<List<MediaEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var reloadKey by remember { mutableStateOf(0) }
    var filter by remember { mutableStateOf(if (pickType == ProjectType.IMAGE) MediaFilter.IMAGES else MediaFilter.ALL) }
    var album by remember { mutableStateOf<String?>(null) }
    val selected: SnapshotStateList<Uri> = remember { mutableStateListOf() }
    var viewer by remember { mutableStateOf<MediaEntry?>(null) }
    val picking = pickType != null
    val multi = pickType != ProjectType.IMAGE

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = MediaRepository.hasPermission(ctx)
        reloadKey++
    }
    val systemPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(30)) { uris ->
        if (uris.isNotEmpty()) {
            val asVideo = pickType == ProjectType.VIDEO || uris.size > 1 || uris.any { MediaRepository.isVideoUri(ctx, it) }
            onUrisChosen(uris, asVideo)
        }
    }

    LaunchedEffect(granted, reloadKey) {
        if (granted) {
            loading = true
            items = withContext(Dispatchers.IO) { MediaRepository.query(ctx) }
            loading = false
        }
    }

    var sort by remember { mutableStateOf(0) }
    val sortLabels = listOf("الأحدث", "الأقدم", "الأكبر حجمًا", "الاسم")
    val visible = remember(items, filter, album, pickType, sort) {
        items.filter { e ->
            val typeOk = when (filter) {
                MediaFilter.ALL -> true
                MediaFilter.IMAGES -> !e.isVideo
                MediaFilter.VIDEOS -> e.isVideo
            }
            val pickOk = pickType != ProjectType.IMAGE || !e.isVideo
            typeOk && pickOk && (album == null || e.bucket == album)
        }.let { l ->
            when (sort) {
                1 -> l.sortedBy { it.dateAdded }
                2 -> l.sortedByDescending { it.size }
                3 -> l.sortedBy { it.name.lowercase() }
                else -> l.sortedByDescending { it.dateAdded }
            }
        }
    }
    val albums = remember(items) {
        items.groupingBy { it.bucket }.eachCount().entries.sortedByDescending { it.value }
    }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding()) {
        // ---------------- header
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onBack != null) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "رجوع") }
            }
            Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                Text(
                    when (pickType) {
                        ProjectType.IMAGE -> "اختر صورة"
                        ProjectType.VIDEO -> "اختر مقاطع أو صور"
                        ProjectType.AUDIO -> "اختر ملفات"
                        ProjectType.CANVAS, null -> "المعرض"
                    },
                    fontSize = 20.sp
                )
                Text(
                    if (selected.isNotEmpty()) "تم تحديد ${selected.size}" else "${visible.size} عنصر",
                    fontSize = 12.sp, color = TextDim
                )
            }
            IconButton(onClick = {
                systemPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
            }) { Icon(Icons.Default.PhotoLibrary, "منتقي النظام") }
            IconButton(onClick = { reloadKey++ }) { Icon(Icons.Default.Refresh, "تحديث") }
        }

        if (!granted) {
            PermissionState(
                onGrant = { permLauncher.launch(MediaRepository.requiredPermissions()) },
                onSettings = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
                onSystemPicker = {
                    systemPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                }
            )
        } else {
            // ---------------- filters
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MediaFilter.values().forEach { f ->
                    if (!(pickType == ProjectType.IMAGE && f == MediaFilter.VIDEOS)) {
                        Chip(f.label, filter == f, { filter = f })
                    }
                }
                Chip("ترتيب: ${sortLabels[sort]}", false, { sort = (sort + 1) % sortLabels.size })
            }
            if (albums.size > 1) {
                LazyRow(
                    Modifier.padding(top = 8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item { Chip("كل الألبومات", album == null, { album = null }) }
                    items(albums.take(30)) { a -> Chip("${a.key} (${a.value})", album == a.key, { album = a.key }) }
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp)) {
                when {
                    loading && items.isEmpty() -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Accent)
                    visible.isEmpty() -> Text(
                        "مفيش ميديا هنا لسه.", color = TextDim,
                        modifier = Modifier.align(Alignment.Center)
                    )
                    else -> LazyVerticalGrid(
                        columns = GridCells.Adaptive(104.dp),
                        contentPadding = PaddingValues(horizontal = 3.dp, vertical = 3.dp),
                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(visible, key = { it.uri.toString() }) { e ->
                            val idx = selected.indexOf(e.uri)
                            MediaCell(
                                e, idx,
                                selectionMode = selected.isNotEmpty() || picking,
                                onClick = {
                                    if (picking) {
                                        if (!multi) {
                                            selected.clear(); selected.add(e.uri)
                                        } else if (idx >= 0) selected.remove(e.uri) else selected.add(e.uri)
                                    } else if (selected.isNotEmpty()) {
                                        if (idx >= 0) selected.remove(e.uri) else selected.add(e.uri)
                                    } else viewer = e
                                },
                                onLongClick = {
                                    if (!picking && idx < 0) selected.add(e.uri)
                                }
                            )
                        }
                    }
                }
            }

            // ---------------- action bar
            if (selected.isNotEmpty()) {
                val selectedEntries = selected.mapNotNull { u -> items.firstOrNull { it.uri == u } }
                val oneImage = selectedEntries.size == 1 && !selectedEntries[0].isVideo
                Row(
                    Modifier.fillMaxWidth().background(Surface1).navigationBarsPadding().padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { selected.clear() }) { Icon(Icons.Default.Close, "إلغاء التحديد") }
                    Text("${selected.size} محدد", Modifier.weight(1f), color = TextDim)
                    if (picking) {
                        Button(
                            onClick = { onUrisChosen(selected.toList(), pickType == ProjectType.VIDEO) },
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = MaterialTheme.colorScheme.onPrimary)
                        ) { Text("تأكيد") }
                    } else {
                        if (oneImage) {
                            SmallButton("تحرير صورة", { onUrisChosen(selected.toList(), false); selected.clear() }, icon = Icons.Default.Edit)
                        }
                        Button(
                            onClick = { onUrisChosen(selected.toList(), true); selected.clear() },
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = MaterialTheme.colorScheme.onPrimary)
                        ) { Text("مشروع فيديو") }
                    }
                }
            }
        }
    }

    viewer?.let { e ->
        MediaViewer(
            e, onDismiss = { viewer = null },
            onEdit = {
                viewer = null
                onUrisChosen(listOf(e.uri), e.isVideo)
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MediaCell(e: MediaEntry, selectedIndex: Int, selectionMode: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    Box(
        Modifier
            .aspectRatio(1f)
            .background(Surface2)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        AsyncImage(
            model = e.uri, contentDescription = e.name,
            modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
        )
        if (e.isVideo) {
            Row(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(4.dp)
                    .background(Color(0x99000000), RoundedCornerShape(6.dp))
                    .padding(horizontal = 5.dp, vertical = 1.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(12.dp))
                Text(formatDuration(e.durationMs), fontSize = 10.sp, color = Color.White)
            }
        }
        if (selectedIndex >= 0) {
            Box(Modifier.fillMaxSize().background(Accent.copy(alpha = 0.28f)))
        }
        if (selectionMode) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(5.dp)
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(if (selectedIndex >= 0) Accent else Color(0x66000000))
                    .border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (selectedIndex >= 0) {
                    Text("${selectedIndex + 1}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimary, textAlign = TextAlign.Center)
                }
            }
        }
    }
}

@Composable
private fun PermissionState(onGrant: () -> Unit, onSettings: () -> Unit, onSystemPicker: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.PhotoLibrary, null, tint = Accent, modifier = Modifier.size(56.dp))
        Text("محتاج إذن الوصول للصور والفيديو", fontSize = 18.sp, modifier = Modifier.padding(top = 16.dp), textAlign = TextAlign.Center)
        Text(
            "عشان نعرض ملفات جهازك ونفتحها في المحرر.",
            color = TextDim, fontSize = 13.sp, textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp, bottom = 20.dp)
        )
        Button(
            onClick = onGrant,
            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = MaterialTheme.colorScheme.onPrimary)
        ) { Text("السماح بالوصول") }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallButton("فتح الإعدادات", onSettings)
            SmallButton("منتقي النظام", onSystemPicker)
        }
    }
}

@Composable
private fun MediaViewer(e: MediaEntry, onDismiss: () -> Unit, onEdit: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (e.isVideo) {
                VideoPlayerBox(e.uri)
            } else {
                AsyncImage(
                    model = e.uri, contentDescription = e.name,
                    modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit
                )
            }
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp).align(Alignment.TopCenter),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "إغلاق", tint = Color.White) }
                Text(e.name, color = Color.White, fontSize = 14.sp, maxLines = 1, modifier = Modifier.weight(1f))
            }
            Row(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onEdit,
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = MaterialTheme.colorScheme.onPrimary)
                ) {
                    Icon(Icons.Default.Edit, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (e.isVideo) "تحرير الفيديو" else "تحرير الصورة")
                }
            }
        }
    }
}

@Composable
private fun VideoPlayerBox(uri: Uri) {
    val ctx = LocalContext.current
    val exo = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(uri) {
        exo.setMediaItem(MediaItem.fromUri(uri))
        exo.prepare()
        exo.playWhenReady = true
        onDispose { exo.release() }
    }
    AndroidView(
        factory = { c -> PlayerView(c).apply { player = exo; useController = true } },
        modifier = Modifier.fillMaxSize()
    )
}

@Suppress("unused")
private fun unusedCheck() = Icons.Default.Check
