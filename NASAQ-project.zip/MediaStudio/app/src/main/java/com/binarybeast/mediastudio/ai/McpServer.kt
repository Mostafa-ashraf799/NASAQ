package com.binarybeast.mediastudio.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.os.Build
import android.os.IBinder
import android.util.Base64
import androidx.core.content.ContextCompat
import com.binarybeast.mediastudio.data.CanvasStore
import com.binarybeast.mediastudio.data.ProjectFactory
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.Executors

/**
 * سيرفر MCP جوّه نسق نفسه (Streamable HTTP / JSON-RPC). أي عميل MCP (Claude Code، Claude Desktop، Cursor ...)
 * يقدر يتوصل ويستخدم أدوات التحرير. مفيش وصول للمعرض: بس مشاريع نسق + الصور اللي العميل بيبعتها.
 */
object McpServer {
    @Volatile private var ss: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()
    @Volatile var projectId: String? = null
    @Volatile var lastClient: String = ""

    val running: Boolean get() = ss?.isClosed == false

    @Synchronized
    fun start(ctx: Context, port: Int) {
        stop()
        val app = ctx.applicationContext
        val s = ServerSocket()
        s.reuseAddress = true
        s.bind(InetSocketAddress(port))
        ss = s
        pool.execute {
            while (!s.isClosed) {
                val c = try { s.accept() } catch (t: Throwable) { break }
                pool.execute { runCatching { serve(app, c) }; runCatching { c.close() } }
            }
        }
    }

    @Synchronized
    fun stop() { runCatching { ss?.close() }; ss = null }

    fun addresses(): List<String> = runCatching {
        NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }.filter { !it.isLoopbackAddress && it.address.size == 4 }.map { it.hostAddress ?: "" }
    }.getOrDefault(emptyList())

    // ------------------------------------------------------------------ HTTP

    private fun readLine(i: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = i.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(b.toChar())
            if (sb.length > 16_384) return sb.toString()
        }
    }

    private fun respond(c: Socket, code: Int, body: String = "", extra: Map<String, String> = emptyMap()) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val reason = when (code) { 200 -> "OK"; 202 -> "Accepted"; 204 -> "No Content"; 401 -> "Unauthorized"; 405 -> "Method Not Allowed"; else -> "Error" }
        val sb = StringBuilder("HTTP/1.1 $code $reason\r\n")
        sb.append("Content-Type: application/json\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n")
        sb.append("Access-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: *\r\nAccess-Control-Allow-Methods: POST, GET, OPTIONS, DELETE\r\nAccess-Control-Expose-Headers: Mcp-Session-Id\r\n")
        extra.forEach { (k, v) -> sb.append("$k: $v\r\n") }
        sb.append("\r\n")
        val o = c.getOutputStream()
        o.write(sb.toString().toByteArray()); o.write(bytes); o.flush()
    }

    private fun serve(ctx: Context, c: Socket) {
        c.soTimeout = 60_000
        val i = BufferedInputStream(c.getInputStream())
        val line = readLine(i) ?: return
        val parts = line.split(" ")
        val method = parts.getOrNull(0) ?: return
        val target = parts.getOrNull(1) ?: "/"
        val headers = HashMap<String, String>()
        while (true) {
            val h = readLine(i) ?: break
            if (h.isEmpty()) break
            val k = h.indexOf(':'); if (k > 0) headers[h.substring(0, k).trim().lowercase()] = h.substring(k + 1).trim()
        }
        if (method == "OPTIONS") { respond(c, 204); return }
        val cfg = AiSettings.load(ctx)
        val tokenQ = Regex("[?&]token=([^&]+)").find(target)?.groupValues?.get(1)
        val given = headers["authorization"]?.removePrefix("Bearer ")?.trim() ?: tokenQ
        if (cfg.serverToken.isBlank() || given != cfg.serverToken) { respond(c, 401, """{"error":"unauthorized"}"""); return }
        if (method == "GET") { respond(c, 405, """{"error":"use POST"}"""); return }
        if (method == "DELETE") { respond(c, 200, "{}"); return }
        if (method != "POST") { respond(c, 405); return }
        val len = headers["content-length"]?.toIntOrNull() ?: 0
        if (len > 40_000_000) { respond(c, 405); return }
        val buf = ByteArray(len)
        var off = 0
        while (off < len) { val n = i.read(buf, off, len - off); if (n < 0) break; off += n }
        val text = String(buf, 0, off, Charsets.UTF_8).trim()
        headers["user-agent"]?.let { lastClient = it.take(60) }
        val out: String? = try {
            if (text.startsWith("[")) {
                val arr = JSONArray(text); val res = JSONArray()
                for (k in 0 until arr.length()) handle(ctx, arr.getJSONObject(k))?.let { res.put(it) }
                if (res.length() == 0) null else res.toString()
            } else handle(ctx, JSONObject(text))?.toString()
        } catch (t: Throwable) {
            JSONObject().put("jsonrpc", "2.0").put("id", JSONObject.NULL).put("error", JSONObject().put("code", -32700).put("message", "parse error: ${t.message}")).toString()
        }
        val extra = HashMap<String, String>()
        if (text.contains("\"initialize\"")) extra["Mcp-Session-Id"] = UUID.randomUUID().toString()
        if (out == null) respond(c, 202, "", extra) else respond(c, 200, out, extra)
    }

    // ------------------------------------------------------------------ JSON-RPC

    private fun ok(id: Any?, result: JSONObject) = JSONObject().put("jsonrpc", "2.0").put("id", id).put("result", result)
    private fun fail(id: Any?, code: Int, msg: String) = JSONObject().put("jsonrpc", "2.0").put("id", id)
        .put("error", JSONObject().put("code", code).put("message", msg))

    private fun handle(ctx: Context, req: JSONObject): JSONObject? {
        val method = req.optString("method")
        if (!req.has("id")) return null          // notification
        val id = req.get("id")
        val params = req.optJSONObject("params") ?: JSONObject()
        return try {
            when (method) {
                "initialize" -> ok(id, JSONObject()
                    .put("protocolVersion", params.optString("protocolVersion", "2025-03-26"))
                    .put("capabilities", JSONObject().put("tools", JSONObject()).put("prompts", JSONObject()).put("resources", JSONObject()))
                    .put("serverInfo", JSONObject().put("name", "NASAQ").put("version", "1.3"))
                    .put("instructions", "NASAQ photo/video/audio/canvas editor on Android. Call get_tool_guide first, then select_project or create_* and edit. No gallery access."))
                "ping" -> ok(id, JSONObject())
                "tools/list" -> ok(id, JSONObject().put("tools", toolList()))
                "tools/call" -> ok(id, callTool(ctx, params.optString("name"), params.optJSONObject("arguments") ?: JSONObject()))
                "prompts/list" -> {
                    val arr = JSONArray()
                    AiPrompts.library.forEachIndexed { ci, (cat, list) -> list.forEachIndexed { pi, (label, _) ->
                        arr.put(JSONObject().put("name", "p${ci}_$pi").put("description", "$cat: $label"))
                    } }
                    ok(id, JSONObject().put("prompts", arr))
                }
                "prompts/get" -> {
                    val n = params.optString("name")
                    val m = Regex("p(\\d+)_(\\d+)").matchEntire(n)
                    val text = m?.let { AiPrompts.library.getOrNull(it.groupValues[1].toInt())?.second?.getOrNull(it.groupValues[2].toInt())?.second }
                        ?: return fail(id, -32602, "unknown prompt")
                    ok(id, JSONObject().put("messages", JSONArray().put(JSONObject().put("role", "user")
                        .put("content", JSONObject().put("type", "text").put("text", text)))))
                }
                "resources/list" -> ok(id, JSONObject().put("resources", JSONArray().put(JSONObject()
                    .put("uri", "nasaq://guide").put("name", "NASAQ tool guide").put("mimeType", "text/markdown"))))
                "resources/read" -> ok(id, JSONObject().put("contents", JSONArray().put(JSONObject()
                    .put("uri", "nasaq://guide").put("mimeType", "text/markdown").put("text", AiPrompts.toolGuide))))
                else -> fail(id, -32601, "method not found: $method")
            }
        } catch (t: Throwable) { fail(id, -32603, t.message ?: "internal error") }
    }

    private fun callTool(ctx: Context, name: String, a: JSONObject): JSONObject {
        val cfg = AiSettings.load(ctx)
        val tools = AiTools(ctx, cfg, projectId)
        val out: ToolOut = try {
            when (name) {
                "get_tool_guide" -> ToolOut(AiPrompts.toolGuide)
                "create_blank_project", "create_image_project", "create_canvas" -> {
                    if (!cfg.allowEdits) ToolOut("ERROR: editing disabled by the user in NASAQ settings") else {
                        val col = runCatching { Color.parseColor(a.optString("color", "#FFFFFF")) }.getOrDefault(Color.WHITE)
                        val w = a.optInt("width", 1080).coerceIn(64, 6000); val h = a.optInt("height", 1080).coerceIn(64, 6000)
                        val nm = a.optString("name", "")
                        when (name) {
                            "create_blank_project" -> {
                                val p = runBlocking { ProjectFactory.createBlankProject(nm, w, h, col) }
                                projectId = p.id; ToolOut("created and selected. id=${p.id}")
                            }
                            "create_canvas" -> {
                                val p = runBlocking { CanvasStore.create(nm, w, h, col, 0) }
                                repeat((a.optInt("pages", 1) - 1).coerceIn(0, 30)) { CanvasStore.addPage(p.id, 9999) }
                                projectId = p.id; ToolOut("canvas created and selected. id=${p.id}")
                            }
                            else -> {
                                val b = a.optString("image_base64").substringAfter("base64,")
                                if (b.isBlank()) ToolOut("ERROR: image_base64 is required") else {
                                    val f = File(ctx.cacheDir, "mcp_${System.currentTimeMillis()}.jpg")
                                    f.writeBytes(Base64.decode(b, Base64.DEFAULT))
                                    val p = runBlocking { ProjectFactory.createImageProject(ctx, nm, android.net.Uri.fromFile(f)) }
                                    projectId = p.id; ToolOut("image project created and selected. id=${p.id}")
                                }
                            }
                        }
                    }
                }
                else -> tools.run(name, a).also { projectId = tools.projectId }
            }
        } catch (t: Throwable) { ToolOut("ERROR: ${t.message}") }
        val content = JSONArray().put(JSONObject().put("type", "text").put("text", out.text))
        out.images.forEach { content.put(JSONObject().put("type", "image").put("data", it).put("mimeType", "image/jpeg")) }
        return JSONObject().put("content", content).put("isError", out.text.startsWith("ERROR"))
    }

    // ------------------------------------------------------------------ tool schemas

    private fun tool(name: String, desc: String, props: Map<String, String> = emptyMap(), req: List<String> = emptyList()): JSONObject {
        val p = JSONObject()
        props.forEach { (k, t) -> p.put(k, JSONObject().put("type", t)) }
        val schema = JSONObject().put("type", "object").put("properties", p)
        if (req.isNotEmpty()) schema.put("required", JSONArray(req))
        return JSONObject().put("name", name).put("description", desc).put("inputSchema", schema)
    }

    private fun nums(vararg k: String) = k.associateWith { "number" }

    private fun toolList(): JSONArray {
        val page = mapOf("page" to "integer")
        val l = JSONArray()
        l.put(tool("get_tool_guide", "Full guide to every NASAQ tool (image, video, audio, canvas) with value ranges. Call this first."))
        l.put(tool("get_project_info", "Describe the selected project (type, size, current edit values, clips/pages)."))
        l.put(tool("list_projects", "List NASAQ projects (not gallery photos): id | name | type."))
        l.put(tool("select_project", "Select the working project by id.", mapOf("id" to "string"), listOf("id")))
        l.put(tool("create_blank_project", "Create a blank image canvas project and select it.", mapOf("name" to "string", "width" to "integer", "height" to "integer", "color" to "string")))
        l.put(tool("create_image_project", "Send an image INTO NASAQ as a new project (base64 JPEG/PNG) and select it.", mapOf("image_base64" to "string", "name" to "string"), listOf("image_base64")))
        l.put(tool("create_canvas", "Create a multi-page Canvas document (exports to images/PDF/Word/video from the app).", mapOf("name" to "string", "width" to "integer", "height" to "integer", "color" to "string", "pages" to "integer")))
        l.put(tool("view_image", "Render and return the current project image (image project, canvas page, or video frame) as an image.", mapOf("max_side" to "integer", "time_ms" to "integer", "clip" to "integer") + page))
        l.put(tool("set_adjust", "Basic adjust: brightness -0.5..0.5, contrast/saturation/warmth -1..1, hue -180..180.", nums("brightness", "contrast", "saturation", "warmth", "hue") + page))
        l.put(tool("set_look", "Apply a preset look (id: vivid,pop,bright,warm,cool,sunset,mint,dream,vintage,fade,matte,cinema,moody,dramatic,sepia,bw,noir,tealorange,golden,cyber,forest,rose,ice,lomo,kodak,hdr,pastel,original).", mapOf("id" to "string", "strength" to "number") + page, listOf("id")))
        l.put(tool("set_effects", "Effects: sharpen/blur/vignette/fade/grain/pixelate 0..1, border 0..0.2, corner 0..0.5, exposure/highlights/shadows/whites/blacks/tint/vibrance/clarity/dehaze -1..1, denoise 0..1.",
            nums("sharpen", "blur", "vignette", "fade", "grain", "pixelate", "border", "corner", "exposure", "highlights", "shadows", "whites", "blacks", "tint", "vibrance", "clarity", "dehaze", "denoise") + page))
        l.put(tool("set_crop", "Crop: aspect (w/h, 0=free), zoom 1..4, cx/cy 0..1, straighten -45..45.", nums("aspect", "zoom", "cx", "cy", "straighten") + page))
        l.put(tool("transform", "Rotate by 90/-90/180 and/or flip.", mapOf("rotate" to "integer", "flipH" to "boolean", "flipV" to "boolean") + page))
        l.put(tool("add_text", "Add a text layer. x,y 0..1; size = fraction of image height; color #RRGGBB.", mapOf("text" to "string", "x" to "number", "y" to "number", "size" to "number", "color" to "string", "bold" to "boolean", "rotation" to "number", "shadow" to "boolean") + page, listOf("text")))
        l.put(tool("clear_texts", "Remove all text layers.", page))
        l.put(tool("reset_edits", "Remove all edits of the current image.", page))
        l.put(tool("set_clip", "Video clip properties: speed 0.25..4, volume 0..2, muted, lookId, lookStrength, fadeInMs, fadeOutMs, zoom, kenBurns 0/1/2, startMs, endMs, brightness/contrast/saturation/warmth.",
            nums("speed", "volume", "lookStrength", "zoom", "brightness", "contrast", "saturation", "warmth") + mapOf("index" to "integer", "muted" to "boolean", "lookId" to "string", "fadeInMs" to "integer", "fadeOutMs" to "integer", "kenBurns" to "integer", "startMs" to "integer", "endMs" to "integer")))
        l.put(tool("add_canvas_page", "Add a blank page to the selected Canvas project.", mapOf("after" to "integer")))
        return l
    }
}

/** خدمة Foreground بتفضّل شغالة عشان سيرفر MCP يفضل متاح والتطبيق في الخلفية. */
class McpService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("mcp", "سيرفر MCP", NotificationManager.IMPORTANCE_LOW))
        val cfg = AiSettings.load(this)
        val n: Notification = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "mcp") else Notification.Builder(this))
            .setContentTitle("نسق • سيرفر MCP شغّال")
            .setContentText("المنفذ ${cfg.serverPort} — اقفله من إعدادات الـ AI")
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setOngoing(true).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(78, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(78, n)
        } catch (e: Throwable) { }
        try { McpServer.start(this, cfg.serverPort) } catch (e: Throwable) { stopSelf() }
        return START_STICKY
    }

    override fun onDestroy() { McpServer.stop(); super.onDestroy() }
}

object McpControl {
    /** يشغّل/يقفل السيرفر حسب الإعدادات. */
    fun apply(ctx: Context, cfg: AiConfig) {
        val app = ctx.applicationContext
        val i = Intent(app, McpService::class.java)
        runCatching {
            if (cfg.serverOn && cfg.serverToken.isNotBlank()) ContextCompat.startForegroundService(app, i)
            else { app.stopService(i); McpServer.stop() }
        }
    }

    fun newToken(): String = UUID.randomUUID().toString().replace("-", "")
}
