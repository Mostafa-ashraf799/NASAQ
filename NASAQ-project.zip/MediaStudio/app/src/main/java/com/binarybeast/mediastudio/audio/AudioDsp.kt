@file:OptIn(UnstableApi::class)

package com.binarybeast.mediastudio.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/** قاعدة معالج PCM 16-bit: بيحوّل كل فريم لـ Float، ويسيب الفرع يعدّله. */
abstract class PcmProcessor : BaseAudioProcessor() {
    protected var rate = 44100
    protected var ch = 2

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        rate = inputAudioFormat.sampleRate
        ch = inputAudioFormat.channelCount.coerceAtLeast(1)
        setup()
        return inputAudioFormat
    }

    protected open fun setup() {}
    protected open fun clear() {}
    abstract fun frame(s: FloatArray)

    override fun onFlush() { clear() }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val n = inputBuffer.remaining()
        if (n == 0) return
        val out = replaceOutputBuffer(n)
        val fb = 2 * ch
        val fr = FloatArray(ch)
        while (inputBuffer.remaining() >= fb) {
            for (c in 0 until ch) fr[c] = inputBuffer.short / 32768f
            frame(fr)
            for (c in 0 until ch) out.putShort((fr[c] * 32767f).roundToInt().coerceIn(-32768, 32767).toShort())
        }
        while (inputBuffer.hasRemaining()) out.put(inputBuffer.get())
        out.flip()
    }
}

/** مرشحات Biquad: kind 0 peak، 1 low-shelf، 2 high-shelf، 3 low-pass، 4 high-pass، 5 notch. */
class BiquadSpec(val kind: Int, val f: Float, val q: Float, val gainDb: Float)

class FilterChainProcessor(private val specs: List<BiquadSpec>) : PcmProcessor() {
    private var b0 = DoubleArray(0); private var b1 = DoubleArray(0); private var b2 = DoubleArray(0)
    private var a1 = DoubleArray(0); private var a2 = DoubleArray(0)
    private var z1 = Array(0) { DoubleArray(0) }
    private var z2 = Array(0) { DoubleArray(0) }

    override fun setup() {
        val n = specs.size
        b0 = DoubleArray(n); b1 = DoubleArray(n); b2 = DoubleArray(n); a1 = DoubleArray(n); a2 = DoubleArray(n)
        for ((i, s) in specs.withIndex()) {
            val f0 = s.f.toDouble().coerceIn(20.0, rate * 0.45)
            val w0 = 2.0 * PI * f0 / rate
            val cw = cos(w0); val sw = sin(w0)
            val q = max(0.1f, s.q).toDouble()
            val alpha = sw / (2.0 * q)
            val a = 10.0.pow(s.gainDb / 40.0)
            var nb0: Double; var nb1: Double; var nb2: Double; var na0: Double; var na1: Double; var na2: Double
            when (s.kind) {
                0 -> {
                    nb0 = 1 + alpha * a; nb1 = -2 * cw; nb2 = 1 - alpha * a
                    na0 = 1 + alpha / a; na1 = -2 * cw; na2 = 1 - alpha / a
                }
                1 -> {
                    val t = 2 * sqrt(a) * alpha
                    nb0 = a * ((a + 1) - (a - 1) * cw + t); nb1 = 2 * a * ((a - 1) - (a + 1) * cw)
                    nb2 = a * ((a + 1) - (a - 1) * cw - t)
                    na0 = (a + 1) + (a - 1) * cw + t; na1 = -2 * ((a - 1) + (a + 1) * cw); na2 = (a + 1) + (a - 1) * cw - t
                }
                2 -> {
                    val t = 2 * sqrt(a) * alpha
                    nb0 = a * ((a + 1) + (a - 1) * cw + t); nb1 = -2 * a * ((a - 1) + (a + 1) * cw)
                    nb2 = a * ((a + 1) + (a - 1) * cw - t)
                    na0 = (a + 1) - (a - 1) * cw + t; na1 = 2 * ((a - 1) - (a + 1) * cw); na2 = (a + 1) - (a - 1) * cw - t
                }
                3 -> {
                    nb0 = (1 - cw) / 2; nb1 = 1 - cw; nb2 = (1 - cw) / 2
                    na0 = 1 + alpha; na1 = -2 * cw; na2 = 1 - alpha
                }
                5 -> {   // notch
                    nb0 = 1.0; nb1 = -2 * cw; nb2 = 1.0
                    na0 = 1 + alpha; na1 = -2 * cw; na2 = 1 - alpha
                }
                else -> {
                    nb0 = (1 + cw) / 2; nb1 = -(1 + cw); nb2 = (1 + cw) / 2
                    na0 = 1 + alpha; na1 = -2 * cw; na2 = 1 - alpha
                }
            }
            b0[i] = nb0 / na0; b1[i] = nb1 / na0; b2[i] = nb2 / na0; a1[i] = na1 / na0; a2[i] = na2 / na0
        }
        z1 = Array(n) { DoubleArray(ch) }
        z2 = Array(n) { DoubleArray(ch) }
    }

    override fun clear() {
        for (r in z1) r.fill(0.0)
        for (r in z2) r.fill(0.0)
    }

    override fun frame(s: FloatArray) {
        for (c in 0 until ch) {
            var x = s[c].toDouble()
            for (i in specs.indices) {
                val y = b0[i] * x + z1[i][c]
                z1[i][c] = b1[i] * x - a1[i] * y + z2[i][c]
                z2[i][c] = b2[i] * x - a2[i] * y
                x = y
            }
            s[c] = x.toFloat().coerceIn(-1.5f, 1.5f)
        }
    }
}

/** بوابة ضوضاء. */
class GateProcessor(private val amount: Float) : PcmProcessor() {
    private var g = 1f
    override fun clear() { g = 1f }
    override fun frame(s: FloatArray) {
        var l = 0f
        for (c in 0 until ch) l = max(l, abs(s[c]))
        val thr = 0.003f + amount * 0.06f
        val target = if (l < thr) 0f else 1f
        g += (target - g) * (if (target > g) 0.01f else 0.0008f)
        for (c in 0 until ch) s[c] *= g
    }
}

/** كومبريسور + ليميتر. */
class DynamicsProcessor(private val comp: Float, private val limiter: Boolean) : PcmProcessor() {
    private var env = 0f
    override fun clear() { env = 0f }
    override fun frame(s: FloatArray) {
        var l = 0f
        for (c in 0 until ch) l = max(l, abs(s[c]))
        env += (l - env) * (if (l > env) 0.02f else 0.0004f)
        var gain = 1f
        if (comp > 0.01f) {
            val thr = 1f - comp * 0.8f
            if (env > thr) gain = (thr + (env - thr) / 4f) / env
            gain *= 1f + comp * 0.6f
        }
        for (c in 0 until ch) {
            var x = s[c] * gain
            if (limiter) {
                val ax = abs(x)
                if (ax > 0.9f) x = (if (x < 0) -1f else 1f) * (0.9f + 0.1f * tanh((ax - 0.9f) / 0.1f))
            }
            s[c] = x
        }
    }
}

/** روبوت (ring modulator) + ترمولو. */
class ModProcessor(private val robot: Float, private val tremolo: Float) : PcmProcessor() {
    private var t = 0L
    override fun clear() { t = 0L }
    override fun frame(s: FloatArray) {
        val sec = t.toDouble() / rate
        var g = 1f
        if (robot > 0.01f) {
            val m = sin(2.0 * PI * 55.0 * sec).toFloat()
            g *= (1f - robot) + robot * m
        }
        if (tremolo > 0.01f) {
            g *= 1f - tremolo * (0.5f + 0.5f * sin(2.0 * PI * 5.5 * sec).toFloat())
        }
        for (c in 0 until ch) s[c] *= g
        t++
    }
}

/** كورس (mode 0) أو فلانجر (mode 1). */
class ChorusProcessor(private val amount: Float, private val mode: Int) : PcmProcessor() {
    private var buf = Array(0) { FloatArray(0) }
    private var pos = 0
    private var t = 0L
    override fun setup() {
        val len = (rate * 0.08).toInt() + 4
        buf = Array(ch) { FloatArray(len) }
        pos = 0
    }
    override fun clear() { for (b in buf) b.fill(0f); pos = 0; t = 0L }
    override fun frame(s: FloatArray) {
        val len = buf[0].size
        val sec = t.toDouble() / rate
        val baseMs = if (mode == 0) 22.0 else 3.0
        val depthMs = if (mode == 0) 6.0 else 2.5
        val lfo = if (mode == 0) 0.8 else 0.3
        for (c in 0 until ch) {
            val ph = sin(2.0 * PI * lfo * sec + c * 0.7)
            val dSamp = (baseMs + depthMs * ph) * rate / 1000.0
            val rp = pos - dSamp
            var i0 = Math.floor(rp).toInt()
            val fr = (rp - i0).toFloat()
            i0 = ((i0 % len) + len) % len
            val i1 = (i0 + 1) % len
            val d = buf[c][i0] * (1 - fr) + buf[c][i1] * fr
            val x = s[c]
            buf[c][pos] = x + (if (mode == 1) d * 0.5f else 0f)
            s[c] = x * (1f - amount * 0.4f) + d * amount * (if (mode == 0) 0.7f else 0.8f)
        }
        pos = (pos + 1) % len
        t++
    }
}

/** ريفيرب Schroeder: 4 combs + 2 allpass. */
class ReverbProcessor(private val amount: Float) : PcmProcessor() {
    private val combBase = intArrayOf(1557, 1617, 1491, 1422)
    private val apBase = intArrayOf(225, 556)
    private var comb = Array(0) { Array(0) { FloatArray(0) } }
    private var combPos = Array(0) { IntArray(0) }
    private var combLp = Array(0) { FloatArray(0) }
    private var ap = Array(0) { Array(0) { FloatArray(0) } }
    private var apPos = Array(0) { IntArray(0) }

    override fun setup() {
        val k = rate / 44100.0
        comb = Array(ch) { c -> Array(4) { FloatArray(((combBase[it] + c * 23) * k).toInt().coerceAtLeast(8)) } }
        combPos = Array(ch) { IntArray(4) }
        combLp = Array(ch) { FloatArray(4) }
        ap = Array(ch) { c -> Array(2) { FloatArray(((apBase[it] + c * 11) * k).toInt().coerceAtLeast(8)) } }
        apPos = Array(ch) { IntArray(2) }
    }

    override fun clear() {
        for (c in comb) for (b in c) b.fill(0f)
        for (c in ap) for (b in c) b.fill(0f)
        for (p in combPos) p.fill(0)
        for (p in apPos) p.fill(0)
        for (p in combLp) p.fill(0f)
    }

    override fun frame(s: FloatArray) {
        val fb = 0.78f + amount * 0.12f
        for (c in 0 until ch) {
            val x = s[c]
            var sum = 0f
            for (i in 0 until 4) {
                val b = comb[c][i]
                val p = combPos[c][i]
                val y = b[p]
                combLp[c][i] = y * 0.7f + combLp[c][i] * 0.3f
                b[p] = x * 0.3f + combLp[c][i] * fb
                combPos[c][i] = (p + 1) % b.size
                sum += y
            }
            var y = sum * 0.25f
            for (i in 0 until 2) {
                val b = ap[c][i]
                val p = apPos[c][i]
                val d = b[p]
                val inp = y + d * 0.5f
                b[p] = inp
                y = d - inp * 0.5f
                apPos[c][i] = (p + 1) % b.size
            }
            s[c] = x * (1f - amount * 0.25f) + y * amount * 0.9f
        }
    }
}

/** مونو / ستيريو واسع / بان. */
class StereoProcessor(private val mode: Int, private val pan: Float) : PcmProcessor() {
    override fun frame(s: FloatArray) {
        if (ch < 2) return
        var l = s[0]; var r = s[1]
        when (mode) {
            1 -> { val m = (l + r) * 0.5f; l = m; r = m }
            2 -> {
                val m = (l + r) * 0.5f; val d = (l - r) * 0.5f * 1.7f
                l = m + d; r = m - d
            }
        }
        if (pan > 0f) l *= 1f - pan else if (pan < 0f) r *= 1f + pan
        s[0] = l; s[1] = r
    }
}

/** يضيف صمت قبل/بعد الصوت. */
class PadAudioProcessor(private val startMs: Long, private val endMs: Long) : BaseAudioProcessor() {
    private var rate = 44100
    private var fb = 4
    private var started = false

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        rate = inputAudioFormat.sampleRate
        fb = 2 * inputAudioFormat.channelCount.coerceAtLeast(1)
        return inputAudioFormat
    }

    override fun onFlush() { started = false }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val n = inputBuffer.remaining()
        if (n == 0) return
        var pad = 0
        if (!started) {
            started = true
            pad = (rate * startMs / 1000L).toInt() * fb
        }
        val out = replaceOutputBuffer(n + pad)
        repeat(pad) { out.put(0.toByte()) }
        out.put(inputBuffer)
        out.flip()
    }

    override fun onQueueEndOfStream() {
        val bytes = (rate * endMs / 1000L).toInt() * fb
        if (bytes > 0) {
            val out = replaceOutputBuffer(bytes)
            repeat(bytes) { out.put(0.toByte()) }
            out.flip()
        }
    }
}

/** فك ترميز مقاطع من ملف صوت إلى PCM 16-bit (لعكس الصوت، وحساب الذروة للتطبيع). */
object AudioPcm {
    class Pcm(val rate: Int, val ch: Int, val data: ShortArray)

    /** يفك ترميز المقاطع [startMs,endMs] بالترتيب. يرجّع null لو فشل. الحد الأقصى ~12 دقيقة. */
    fun decode(ctx: Context, uri: Uri, segs: List<Pair<Long, Long>>): Pcm? {
        var rate = 44100
        var ch = 2
        val chunks = ArrayList<ShortArray>()
        var total = 0L
        for ((s, e) in segs) {
            val ex = MediaExtractor()
            var codec: MediaCodec? = null
            try {
                ex.setDataSource(ctx, uri, null)
                var track = -1
                var fmt: MediaFormat? = null
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; fmt = f; break }
                }
                if (track < 0 || fmt == null) return null
                ex.selectTrack(track)
                ex.seekTo(s * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
                codec.configure(fmt, null, null, 0)
                codec.start()
                val info = MediaCodec.BufferInfo()
                var inDone = false
                var outDone = false
                var guard = 0
                val startUs = s * 1000L
                val endUs = e * 1000L
                while (!outDone && guard < 3_000_000) {
                    guard++
                    if (!inDone) {
                        val i = codec.dequeueInputBuffer(5000)
                        if (i >= 0) {
                            val buf = codec.getInputBuffer(i)!!
                            val n = ex.readSampleData(buf, 0)
                            if (n < 0 || ex.sampleTime > endUs + 500_000L) {
                                codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inDone = true
                            } else {
                                codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                                ex.advance()
                            }
                        }
                    }
                    val o = codec.dequeueOutputBuffer(info, 5000)
                    if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val of = codec.outputFormat
                        rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                    } else if (o >= 0) {
                        val ob = codec.getOutputBuffer(o)
                        if (ob != null && info.size > 0) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                            val arr = ShortArray(sb.remaining())
                            sb.get(arr)
                            // قص بدقة على حدود المقطع
                            val frames = arr.size / ch
                            val t0 = info.presentationTimeUs
                            val dur = frames * 1_000_000L / rate
                            if (t0 + dur > startUs && t0 < endUs) {
                                val from = if (t0 < startUs) ((startUs - t0) * rate / 1_000_000L).toInt() else 0
                                val to = if (t0 + dur > endUs) ((endUs - t0) * rate / 1_000_000L).toInt() else frames
                                if (to > from) {
                                    val part = arr.copyOfRange(from * ch, min(to * ch, arr.size))
                                    chunks.add(part)
                                    total += part.size
                                }
                            }
                        }
                        codec.releaseOutputBuffer(o, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                        if (total > 12L * 60 * 48000 * 2) outDone = true
                    }
                }
            } catch (t: Throwable) {
                return null
            } finally {
                runCatching { codec?.stop() }
                runCatching { codec?.release() }
                runCatching { ex.release() }
            }
        }
        if (chunks.isEmpty()) return null
        val all = ShortArray(total.toInt())
        var p = 0
        for (c in chunks) { System.arraycopy(c, 0, all, p, c.size); p += c.size }
        return Pcm(rate, ch, all)
    }

    fun peak(ctx: Context, uri: Uri, segs: List<Pair<Long, Long>>): Float? {
        val p = decode(ctx, uri, segs) ?: return null
        var m = 0
        for (v in p.data) { val a = abs(v.toInt()); if (a > m) m = a }
        return m / 32768f
    }

    /** يكتب WAV معكوس (أو عادي) من المقاطع. */
    fun renderWav(ctx: Context, uri: Uri, segs: List<Pair<Long, Long>>, reverse: Boolean, out: File): Boolean {
        val pcm = decode(ctx, uri, segs) ?: return false
        val d = pcm.data
        val ch = pcm.ch
        if (reverse) {
            val frames = d.size / ch
            for (i in 0 until frames / 2) {
                val j = frames - 1 - i
                for (c in 0 until ch) {
                    val t = d[i * ch + c]; d[i * ch + c] = d[j * ch + c]; d[j * ch + c] = t
                }
            }
        }
        return try {
            RandomAccessFile(out, "rw").use { f ->
                f.setLength(0)
                val bytes = d.size * 2
                val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
                h.put("RIFF".toByteArray()); h.putInt(36 + bytes); h.put("WAVE".toByteArray())
                h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(ch.toShort())
                h.putInt(pcm.rate); h.putInt(pcm.rate * ch * 2); h.putShort((ch * 2).toShort()); h.putShort(16)
                h.put("data".toByteArray()); h.putInt(bytes)
                f.write(h.array())
                val bb = ByteBuffer.allocate(64 * 1024).order(ByteOrder.LITTLE_ENDIAN)
                var i = 0
                while (i < d.size) {
                    bb.clear()
                    val n = min(d.size - i, bb.capacity() / 2)
                    for (k in 0 until n) bb.putShort(d[i + k])
                    f.write(bb.array(), 0, n * 2)
                    i += n
                }
            }
            true
        } catch (t: Throwable) { false }
    }
}
