@file:OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)

package com.binarybeast.mediastudio.video

import android.app.Application
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateRotation
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke as DrawStroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import com.binarybeast.mediastudio.data.Adjust
import com.binarybeast.mediastudio.data.Look
import com.binarybeast.mediastudio.data.Looks
import com.binarybeast.mediastudio.data.TextLayer
import com.binarybeast.mediastudio.data.VideoClip
import com.binarybeast.mediastudio.data.formatDuration
import com.binarybeast.mediastudio.image.TextRenderer
import com.binarybeast.mediastudio.ui.Accent
import com.binarybeast.mediastudio.ui.Bg
import com.binarybeast.mediastudio.ui.Chip
import com.binarybeast.mediastudio.ui.ColorRow
import com.binarybeast.mediastudio.ui.LabeledSlider
import com.binarybeast.mediastudio.ui.LoadingDialog
import com.binarybeast.mediastudio.ui.SectionLabel
import com.binarybeast.mediastudio.ui.SmallButton
import com.binarybeast.mediastudio.ui.Surface1
import com.binarybeast.mediastudio.ui.Surface2
import com.binarybeast.mediastudio.ui.TextDim
import com.binarybeast.mediastudio.ui.TextInputDialog
import com.binarybeast.mediastudio.ui.ToolTab
import com.binarybeast.mediastudio.ui.isWideLayout
import com.binarybeast.mediastudio.ui.panelMaxHeight
import com.binarybeast.mediastudio.ui.shareUri
import com.binarybeast.mediastudio.ui.toast
import kotlin.math.abs
import com.binarybeast.mediastudio.ui.NIc
import com.binarybeast.mediastudio.ui.NI

private enum class VTool(val label: String) {
    CLIP("المقطع"), SPEED("السرعة"), AUDIO("الصوت"), LOOKS("فلاتر"),
    COLOR("ألوان"), FRAME("الإطار"), MOTION("حركة"), TEXT("نص")
}

private val QuickEmojis = listOf("😀", "😂", "😍", "😎", "🔥", "✨", "❤️", "👍", "🎉", "⭐", "💯", "👀", "🚀", "🎬", "🎵", "⚡")

@Composable
fun VideoEditorScreen(projectId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val vm: VideoEditorViewModel = viewModel(
        key = projectId,
        factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                VideoEditorViewModel(ctx.applicationContext as Application, projectId) as T
        }
    )

    var tool by remember { mutableStateOf(VTool.CLIP) }
    var showExport by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }

    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(30)) { uris ->
        vm.addClips(uris)
    }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.setMusic(uri)
    }

    BackHandler {
        vm.pause()
        vm.saveNow()
        onBack()
    }
    DisposableEffect(Unit) {
        onDispose {
            vm.pause()
            vm.saveNow()
        }
    }
    val view = androidx.compose.ui.platform.LocalView.current
    val exporting = vm.exportState is ExportState.Running
    DisposableEffect(exporting) {
        view.keepScreenOn = exporting
        onDispose { view.keepScreenOn = false }
    }
    LaunchedEffect(vm.message) {
        vm.message?.let { toast(ctx, it); vm.message = null }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        // ---------------- top bar
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.pause(); vm.saveNow(); onBack() }) { NIc(NI.Back, "رجوع") }
            Text(
                vm.project?.name ?: "",
                modifier = Modifier.weight(1f).clickable { showRename = true }.padding(horizontal = 4.dp),
                maxLines = 1, fontSize = 16.sp
            )
            IconButton(onClick = { vm.undo() }, enabled = vm.canUndo) {
                NIc(NI.Undo, "تراجع", tint = if (vm.canUndo) MaterialTheme.colorScheme.onSurface else TextDim.copy(alpha = 0.4f))
            }
            IconButton(onClick = { vm.redo() }, enabled = vm.canRedo) {
                NIc(NI.Redo, "إعادة", tint = if (vm.canRedo) MaterialTheme.colorScheme.onSurface else TextDim.copy(alpha = 0.4f))
            }
            SmallButton("تصدير", onClick = { vm.pause(); showExport = true }, icon = NI.Download)
            Spacer(Modifier.width(6.dp))
        }

        val wide = isWideLayout()
        val previewBox: @Composable () -> Unit = {
            if (vm.loading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    if (vm.failed) Text("تعذر فتح المشروع", color = TextDim) else CircularProgressIndicator(color = Accent)
                }
            } else {
                PreviewArea(vm)
            }
        }
        val strip: @Composable () -> Unit = {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    itemsIndexed(vm.data.clips, key = { _, c -> c.id }) { i, c ->
                        ClipThumb(c, i == vm.selectedIndex) { vm.selectClip(i) }
                    }
                    item {
                        Box(
                            Modifier
                                .size(width = 56.dp, height = 56.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Surface2)
                                .clickable {
                                    pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                                },
                            contentAlignment = Alignment.Center
                        ) { NIc(NI.Add, "إضافة", tint = Accent) }
                    }
                }
            }
        }
        val panel: @Composable () -> Unit = {
            when (tool) {
                VTool.CLIP -> ClipPanel(vm)
                VTool.SPEED -> SpeedPanel(vm)
                VTool.AUDIO -> AudioPanel(vm, onPickAudio = { pickAudio.launch("audio/*") })
                VTool.LOOKS -> LooksPanel(vm)
                VTool.COLOR -> ColorPanel(vm)
                VTool.FRAME -> FramePanel(vm)
                VTool.MOTION -> MotionPanel(vm)
                VTool.TEXT -> TextPanel(vm)
            }
        }
        val tabs: @Composable () -> Unit = {
            LazyRow(
                Modifier.fillMaxWidth().background(Surface1).padding(bottom = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                items(VTool.values().toList()) { t ->
                    ToolTab(
                        icon = when (t) {
                            VTool.CLIP -> NI.ContentCut
                            VTool.SPEED -> NI.Speed
                            VTool.AUDIO -> NI.VolumeUp
                            VTool.LOOKS -> NI.FilterVintage
                            VTool.COLOR -> NI.Tune
                            VTool.FRAME -> NI.Crop
                            VTool.MOTION -> NI.AutoAwesome
                            VTool.TEXT -> NI.TextFields
                        },
                        label = t.label,
                        selected = tool == t,
                        onClick = { tool = t }
                    )
                }
            }
        }

        if (wide) {
            // تابلت / موبايل بالعرض: المعاينة + التايم لاين يسار، الأدوات يمين
            Row(Modifier.weight(1f).fillMaxWidth()) {
                Column(Modifier.weight(1f).fillMaxHeight()) {
                    Box(Modifier.weight(1f).fillMaxWidth()) { previewBox() }
                    TransportRow(vm)
                    strip()
                }
                Column(Modifier.width(400.dp).fillMaxHeight().background(Surface1)) {
                    tabs()
                    Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)) { panel() }
                }
            }
        } else {
            Box(Modifier.weight(1f).fillMaxWidth()) { previewBox() }
            TransportRow(vm)
            strip()
            Box(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 120.dp, max = panelMaxHeight())
                    .background(Surface1)
                    .padding(vertical = 8.dp)
            ) { panel() }
            tabs()
        }
    }

    if (showRename) {
        TextInputDialog(
            title = "اسم المشروع", initial = vm.project?.name ?: "",
            onConfirm = { if (it.isNotBlank()) vm.rename(it); showRename = false },
            onDismiss = { showRename = false }
        )
    }
    if (showExport) {
        ExportSettingsDialog(vm, onDismiss = { showExport = false }, onStart = { q, h, w -> showExport = false; vm.startExport(q, h, w) })
    }
    val uploadToCloud = com.binarybeast.mediastudio.ui.rememberCloudUpload()
    ExportStatusDialogs(vm, onShare = { uri -> shareUri(ctx, uri, "video/mp4") }, onCloud = { uri -> uploadToCloud(listOf(uri)) })
    vm.busyText?.let { LoadingDialog(it) }
}

// ====================================================================== preview

@Composable
private fun PreviewArea(vm: VideoEditorViewModel) {
    val aspect = vm.data.canvasAspect
    val fill = vm.selectedClip?.fill == true
    Box(Modifier.fillMaxSize().padding(8.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .aspectRatio(aspect)
                .clip(RoundedCornerShape(6.dp))
                .background(Color.Black)
        ) {
            AndroidView(
                factory = { c ->
                    PlayerView(c).apply {
                        useController = false
                        player = vm.player
                        setShutterBackgroundColor(android.graphics.Color.BLACK)
                    }
                },
                update = {
                    it.resizeMode = if (fill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
                },
                modifier = Modifier.fillMaxSize()
            )
            Canvas(Modifier.fillMaxSize().pointerInput(Unit) { overlayGestures(vm) }) {
                val pos = vm.positionMs
                val fa = vm.fadeAlpha(pos)
                if (fa > 0.001f) drawRect(Color.Black.copy(alpha = fa))
                drawIntoCanvas { c ->
                    val nc = c.nativeCanvas
                    for (t in vm.data.texts) {
                        if (isVisible(t, pos)) TextRenderer.draw(nc, t, size.width, size.height)
                    }
                }
                val sel = vm.selectedText
                if (sel != null) {
                    vm.data.texts.firstOrNull { it.id == sel }?.let { l ->
                        val (hw, hh) = TextRenderer.halfExtentsFor(l, size.height)
                        val cx = l.x * size.width
                        val cy = l.y * size.height
                        rotate(l.rotation, pivot = Offset(cx, cy)) {
                            drawRect(
                                color = Accent,
                                topLeft = Offset(cx - hw, cy - hh),
                                size = Size(hw * 2, hh * 2),
                                style = DrawStroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 9f)))
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun isVisible(t: TextLayer, posMs: Long): Boolean {
    val end = if (t.endMs < 0) Long.MAX_VALUE else t.endMs
    return posMs in t.startMs..end
}

private suspend fun PointerInputScope.overlayGestures(vm: VideoEditorViewModel) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        val w = size.width.toFloat()
        val h = size.height.toFloat()
        val pos = vm.positionMs
        val candidates = vm.data.texts.filter { isVisible(it, pos) || it.id == vm.selectedText }
        val hit = TextRenderer.hitTest(candidates, down.position.x, down.position.y, w, h)
        if (hit != null) vm.selectedText = hit
        val grabbed = hit != null
        var moved = false
        do {
            val ev = awaitPointerEvent()
            val sel = vm.selectedText
            val multi = ev.changes.count { it.pressed } >= 2
            val zoom = ev.calculateZoom()
            val pan = ev.calculatePan()
            val rot = ev.calculateRotation()
            if (sel != null && (grabbed || multi) && (pan != Offset.Zero || zoom != 1f || rot != 0f)) {
                moved = true
                vm.updateText(sel, true) { l ->
                    l.copy(
                        x = (l.x + pan.x / w).coerceIn(0f, 1f),
                        y = (l.y + pan.y / h).coerceIn(0f, 1f),
                        size = if (multi) (l.size * zoom).coerceIn(0.02f, 0.6f) else l.size,
                        rotation = if (multi) l.rotation + rot else l.rotation,
                    )
                }
                ev.changes.forEach { it.consume() }
            }
        } while (ev.changes.any { it.pressed })
        if (moved) {
            vm.endLive()
        } else if (!grabbed) {
            if (vm.selectedText != null) vm.selectedText = null else vm.togglePlay()
        }
    }
}

@Composable
private fun TransportRow(vm: VideoEditorViewModel) {
    val total = vm.data.totalMs
    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { vm.togglePlay() }) {
            NIc(if (vm.isPlaying) NI.Pause else NI.PlayArrow, "تشغيل", tint = Accent)
        }
        Text("${formatDuration(vm.positionMs)} / ${formatDuration(total)}", fontSize = 12.sp, color = TextDim)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Slider(
                value = vm.positionMs.toFloat().coerceIn(0f, maxOf(1f, total.toFloat())),
                onValueChange = { vm.scrubTo(it.toLong()) },
                onValueChangeFinished = { vm.endScrub() },
                valueRange = 0f..maxOf(1f, total.toFloat()),
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Surface2)
            )
        }
        IconButton(onClick = { vm.captureFrame() }) { NIc(NI.PhotoCamera, "التقاط صورة") }
    }
}

@Composable
private fun ClipThumb(c: VideoClip, selected: Boolean, onClick: () -> Unit) {
    val ctx = LocalContext.current
    Box(
        Modifier
            .size(width = 84.dp, height = 56.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Surface2)
            .border(if (selected) 2.dp else 0.dp, if (selected) Accent else Color.Transparent, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
    ) {
        AsyncImage(
            model = ImageRequest.Builder(ctx).data(Uri.parse(c.uri)).videoFrameMillis(c.startMs).build(),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Text(
            formatDuration(c.effectiveMs),
            fontSize = 10.sp, color = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(3.dp)
                .background(Color(0x99000000), RoundedCornerShape(4.dp))
                .padding(horizontal = 4.dp)
        )
        if (c.isImage) {
            NIc(
                NI.Image, null, tint = Color.White,
                modifier = Modifier.align(Alignment.TopStart).padding(3.dp).size(14.dp)
            )
        } else if (c.speed != 1f) {
            Text(
                "${c.speed}x", fontSize = 10.sp, color = Color.White,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(3.dp)
                    .background(Accent.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp)
            )
        }
    }
}

// ====================================================================== panels

@Composable
private fun ClipPanel(vm: VideoEditorViewModel) {
    val c = vm.selectedClip ?: return
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallButton("تقسيم", { vm.splitAtPlayhead() }, icon = NI.ContentCut)
            SmallButton("نسخ", { vm.duplicateSelected() }, icon = NI.ContentCopy)
            SmallButton("حذف", { vm.deleteSelected() }, danger = true, icon = NI.Delete)
            SmallButton("قبل", { vm.moveSelected(-1) })
            SmallButton("بعد", { vm.moveSelected(1) })
        }
        if (c.isImage) {
            LabeledSlider(
                "المدة", (c.endMs - c.startMs).toFloat(), 500f..30000f,
                { v -> vm.updateSelected(true) { it.copy(endMs = it.startMs + v.toLong()) } }, { vm.endLive() },
                { "%.1f ث".format(it / 1000f) }
            )
        } else {
            SectionLabel("قص المقطع: من ${formatDuration(c.startMs)} إلى ${formatDuration(c.endMs)} (المدة ${formatDuration(c.endMs - c.startMs)})")
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                RangeSlider(
                    value = c.startMs.toFloat()..c.endMs.toFloat(),
                    onValueChange = { r ->
                        val e = maxOf(r.endInclusive.toLong(), r.start.toLong() + 300L).coerceAtMost(c.srcDurationMs)
                        val s = minOf(r.start.toLong(), e - 300L).coerceAtLeast(0L)
                        vm.updateSelected(true) { it.copy(startMs = s, endMs = e) }
                    },
                    onValueChangeFinished = { vm.endLive() },
                    valueRange = 0f..c.srcDurationMs.toFloat(),
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Surface2)
                )
            }
        }
    }
}

@Composable
private fun SpeedPanel(vm: VideoEditorViewModel) {
    val c = vm.selectedClip ?: return
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        if (c.isImage) {
            Text("السرعة متاحة للمقاطع فقط. للصور غيّر المدة من تبويب «المقطع».", color = TextDim, fontSize = 12.sp)
            return@Column
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f)) { s ->
                Chip("${s}x", abs(c.speed - s) < 0.01f, { vm.updateSelected { it.copy(speed = s) } })
            }
        }
        LabeledSlider(
            "السرعة", c.speed, 0.25f..4f,
            { v -> vm.updateSelected(true) { it.copy(speed = v) } }, { vm.endLive() },
            { "%.2fx".format(it) }
        )
        SmallButton("تطبيق على كل المقاطع", {
            val s = c.speed
            vm.updateAllClips { if (it.isImage) it else it.copy(speed = s) }
        })
    }
}

@Composable
private fun AudioPanel(vm: VideoEditorViewModel, onPickAudio: () -> Unit) {
    val c = vm.selectedClip ?: return
    val d = vm.data
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        if (!c.isImage) {
            LabeledSlider(
                "صوت المقطع", c.volume, 0f..2f,
                { v -> vm.updateSelected(true) { it.copy(volume = v) } }, { vm.endLive() },
                { "%.0f%%".format(it * 100) }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("كتم", c.muted, { vm.updateSelected { it.copy(muted = !it.muted) } })
                SmallButton("تطبيق على الكل", {
                    val v = c.volume
                    val m = c.muted
                    vm.updateAllClips { if (it.isImage) it else it.copy(volume = v, muted = m) }
                })
            }
        } else {
            Text("الصور ملهاش صوت.", color = TextDim, fontSize = 12.sp)
        }
        SectionLabel("الموسيقى الخلفية / التعليق الصوتي")
        var showRec by remember { mutableStateOf(false) }
        if (showRec) {
            com.binarybeast.mediastudio.ui.RecordDialog(
                onRecorded = { uri -> showRec = false; vm.setMusic(uri) },
                onDismiss = { showRec = false }
            )
        }
        if (d.musicUri == null) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallButton("إضافة موسيقى", onPickAudio, icon = NI.MusicNote)
                SmallButton("تعليق صوتي", { showRec = true }, icon = NI.Mic)
            }
        } else {
            Text(d.musicName.ifBlank { "موسيقى" }, fontSize = 13.sp, maxLines = 1)
            LabeledSlider(
                "مستوى", d.musicVolume, 0f..2f,
                { v -> vm.setMusicVolume(v, true) }, { vm.endLive() },
                { "%.0f%%".format(it * 100) }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallButton("تغيير", onPickAudio)
                SmallButton("تسجيل بدله", { showRec = true }, icon = NI.Mic)
                SmallButton("إزالة", { vm.removeMusic() }, danger = true, icon = NI.Delete)
            }
        }
    }
}

@Composable
private fun LooksPanel(vm: VideoEditorViewModel) {
    val c = vm.selectedClip ?: return
    Column(Modifier.fillMaxWidth()) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(Looks.all) { look ->
                VLookCard(look, vm.lookThumbs[look.id], c.lookId == look.id) {
                    vm.updateSelected { it.copy(lookId = look.id, lookStrength = 1f) }
                }
            }
        }
        if (c.lookId != "original") {
            Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                LabeledSlider(
                    "الشدة", c.lookStrength, 0f..1f,
                    { v -> vm.updateSelected(true) { it.copy(lookStrength = v) } }, { vm.endLive() },
                    modifier = Modifier.weight(1f)
                )
            }
            Box(Modifier.padding(horizontal = 12.dp)) {
                SmallButton("تطبيق الفلتر على كل المقاطع", {
                    val id = c.lookId
                    val k = c.lookStrength
                    vm.updateAllClips { it.copy(lookId = id, lookStrength = k) }
                })
            }
        }
    }
}

@Composable
private fun VLookCard(look: Look, thumb: android.graphics.Bitmap?, selected: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick)) {
        Box(
            Modifier
                .size(70.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Surface2)
                .border(if (selected) 2.dp else 0.dp, if (selected) Accent else Color.Transparent, RoundedCornerShape(10.dp))
        ) {
            if (thumb != null) Image(thumb.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Text(look.name, fontSize = 11.sp, color = if (selected) Accent else TextDim, modifier = Modifier.padding(top = 4.dp), maxLines = 1)
    }
}

@Composable
private fun ColorPanel(vm: VideoEditorViewModel) {
    val c = vm.selectedClip ?: return
    val a = c.adjust
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallButton("إعادة ضبط", { vm.updateSelected { it.copy(adjust = Adjust()) } })
            SmallButton("تطبيق على الكل", {
                val adj = c.adjust
                vm.updateAllClips { it.copy(adjust = adj) }
            })
        }
        LabeledSlider("السطوع", a.brightness, -0.5f..0.5f, { v -> vm.updateSelected(true) { it.copy(adjust = it.adjust.copy(brightness = v)) } }, { vm.endLive() }, { "%.0f".format(it * 200) })
        LabeledSlider("التباين", a.contrast, -1f..1f, { v -> vm.updateSelected(true) { it.copy(adjust = it.adjust.copy(contrast = v)) } }, { vm.endLive() })
        LabeledSlider("التشبّع", a.saturation, -1f..1f, { v -> vm.updateSelected(true) { it.copy(adjust = it.adjust.copy(saturation = v)) } }, { vm.endLive() })
        LabeledSlider("الدفء", a.warmth, -1f..1f, { v -> vm.updateSelected(true) { it.copy(adjust = it.adjust.copy(warmth = v)) } }, { vm.endLive() })
        LabeledSlider("درجة اللون", a.hue, -180f..180f, { v -> vm.updateSelected(true) { it.copy(adjust = it.adjust.copy(hue = v)) } }, { vm.endLive() }, { "%.0f°".format(it) })
    }
}

private val AspectChoices = listOf(
    "تلقائي" to 0f, "16:9" to 1.7778f, "9:16" to 0.5625f, "1:1" to 1f,
    "4:5" to 0.8f, "4:3" to 1.3333f, "21:9" to 2.3333f,
)

@Composable
private fun FramePanel(vm: VideoEditorViewModel) {
    val c = vm.selectedClip ?: return
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        SectionLabel("نسبة أبعاد الفيديو")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(AspectChoices) { (label, r) ->
                Chip(label, abs(vm.data.aspect - r) < 0.001f, { vm.setAspect(r) })
            }
        }
        SectionLabel("ملاءمة المقطع للإطار")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("احتواء (أشرطة سوداء)", !c.fill, { vm.updateSelected { it.copy(fill = false) } })
            Chip("ملء الإطار (قص)", c.fill, { vm.updateSelected { it.copy(fill = true) } })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            SmallButton("تدوير", { vm.updateSelected { it.copy(rotation = (it.rotation + 90) % 360) } }, icon = NI.RotateRight)
            SmallButton("مرآة", { vm.updateSelected { it.copy(flipH = !it.flipH) } }, icon = NI.Flip)
            SmallButton("ملء الكل", {
                vm.updateAllClips { it.copy(fill = true) }
            })
        }
    }
}

@Composable
private fun TextPanel(vm: VideoEditorViewModel) {
    var showAdd by remember { mutableStateOf(false) }
    val pickOverlay = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.addImageLayer(uri)
    }
    val sel = vm.data.texts.firstOrNull { it.id == vm.selectedText }
    val total = vm.data.totalMs
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallButton("نص جديد", { showAdd = true }, icon = NI.Add)
            if (sel != null) {
                SmallButton("نسخ", { vm.duplicateText(sel.id) }, icon = NI.ContentCopy)
                SmallButton("حذف", { vm.deleteText(sel.id) }, danger = true, icon = NI.Delete)
            }
        }
        SectionLabel("أشكال وصور")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                SmallButton("صورة / لوجو", {
                    pickOverlay.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }, icon = NI.AddPhotoAlternate)
            }
            items(VShapeKinds) { (k, label) -> Chip(label, false, { vm.addShape(k) }) }
        }
        SectionLabel("ستيكرز")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            items(QuickEmojis) { e ->
                Box(
                    Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)).clickable { vm.addText(e, emoji = true) },
                    contentAlignment = Alignment.Center
                ) { Text(e, fontSize = 24.sp) }
            }
        }
        if (sel == null) {
            Text(
                "اضغط على نص داخل الفيديو لتعديله. اسحب بإصبع للتحريك وبإصبعين للتكبير والتدوير.",
                color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
            )
        } else {
            val id = sel.id
            if (sel.shape == 0) OutlinedTextField(
                value = sel.text,
                onValueChange = { nv -> vm.updateText(id, true) { it.copy(text = nv) } },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp).onFocusChanged { if (!it.isFocused) vm.endLive() },
                textStyle = TextStyle(fontSize = 14.sp),
            )
            if (sel.shape != 9) {
                SectionLabel("اللون")
                ColorRow(sel.color, onPick = { c -> vm.updateText(id) { it.copy(color = c) } })
            }
            if (sel.shape != 0) {
                if (sel.shape != 9) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                        Chip("مفرّغ", sel.outline, { vm.updateText(id) { it.copy(outline = !it.outline) } })
                        Chip("ظل", sel.shadow, { vm.updateText(id) { it.copy(shadow = !it.shadow) } })
                    }
                }
                LabeledSlider("العرض/الارتفاع", sel.aspect, 0.2f..6f, { v -> vm.updateText(id, true) { it.copy(aspect = v) } }, { vm.endLive() }, { "%.1f".format(it) })
            }
            if (sel.shape == 0) {
            SectionLabel("الخط")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(TextRenderer.fontNames.indices.toList()) { i ->
                    Chip(TextRenderer.fontNames[i], sel.font == i, { vm.updateText(id) { it.copy(font = i) } })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                Chip("عريض", sel.bold, { vm.updateText(id) { it.copy(bold = !it.bold) } })
                Chip("مائل", sel.italic, { vm.updateText(id) { it.copy(italic = !it.italic) } })
                Chip("ظل", sel.shadow, { vm.updateText(id) { it.copy(shadow = !it.shadow) } })
                Chip("حدود", sel.outline, { vm.updateText(id) { it.copy(outline = !it.outline) } })
                Chip("خلفية", sel.bgColor != 0, {
                    vm.updateText(id) { it.copy(bgColor = if (it.bgColor != 0) 0 else 0xAA000000.toInt()) }
                })
            }
            }
            LabeledSlider("الحجم", sel.size, 0.02f..0.5f, { v -> vm.updateText(id, true) { it.copy(size = v) } }, { vm.endLive() }, { "%.0f".format(it * 100) })
            LabeledSlider("الدوران", sel.rotation, -180f..180f, { v -> vm.updateText(id, true) { it.copy(rotation = v) } }, { vm.endLive() }, { "%.0f°".format(it) })
            LabeledSlider("الشفافية", sel.opacity, 0.1f..1f, { v -> vm.updateText(id, true) { it.copy(opacity = v) } }, { vm.endLive() })
            if (total > 0) {
                val s = sel.startMs.coerceIn(0L, total)
                val e = (if (sel.endMs < 0) total else sel.endMs).coerceIn(s, total)
                SectionLabel("وقت الظهور: ${formatDuration(s)} → ${formatDuration(e)}")
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    RangeSlider(
                        value = s.toFloat()..e.toFloat(),
                        onValueChange = { r ->
                            vm.updateText(id, true) { it.copy(startMs = r.start.toLong(), endMs = r.endInclusive.toLong()) }
                        },
                        onValueChangeFinished = { vm.endLive() },
                        valueRange = 0f..total.toFloat(),
                        colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Surface2)
                    )
                }
            }
        }
    }
    if (showAdd) {
        TextInputDialog(
            title = "أضف نص", hint = "اكتب هنا...", singleLine = false,
            onConfirm = { if (it.isNotBlank()) vm.addText(it); showAdd = false },
            onDismiss = { showAdd = false }
        )
    }
}

private val VShapeKinds = listOf(1 to "مستطيل", 2 to "مدوّر", 3 to "دائرة", 4 to "مثلث", 5 to "نجمة", 6 to "قلب", 7 to "خط", 8 to "سهم")

@Composable
private fun MotionPanel(vm: VideoEditorViewModel) {
    val c = vm.selectedClip ?: return
    var all by remember { mutableStateOf(false) }
    val apply: (Boolean, (VideoClip) -> VideoClip) -> Unit = { live, f ->
        if (all) vm.updateAllClips(f) else vm.updateSelected(live, f)
    }
    val maxFade = (c.effectiveMs / 2).coerceAtLeast(200L).toFloat()
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("تطبيق على كل المقاطع", all, { all = !all })
            if (!c.isImage) SmallButton("تجميد الإطار", { vm.freezeFrame() }, icon = NI.AcUnit)
        }
        SectionLabel("تلاشي (Fade)")
        LabeledSlider("من الأسود", c.fadeInMs.toFloat(), 0f..maxFade,
            { v -> vm.updateSelected(true) { it.copy(fadeInMs = v.toLong()) } }, { vm.endLive() }, { "%.1f ث".format(it / 1000f) })
        LabeledSlider("للأسود", c.fadeOutMs.toFloat(), 0f..maxFade,
            { v -> vm.updateSelected(true) { it.copy(fadeOutMs = v.toLong()) } }, { vm.endLive() }, { "%.1f ث".format(it / 1000f) })
        SectionLabel("حركة الكاميرا (Ken Burns)")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("بدون", c.kenBurns == 0, { apply(false) { it.copy(kenBurns = 0) } })
            Chip("تقريب تدريجي", c.kenBurns == 1, { apply(false) { it.copy(kenBurns = 1) } })
            Chip("تبعيد تدريجي", c.kenBurns == 2, { apply(false) { it.copy(kenBurns = 2) } })
        }
        SectionLabel("تكبير وإزاحة")
        LabeledSlider("التكبير", c.zoom, 1f..4f, { v -> vm.updateSelected(true) { it.copy(zoom = v) } }, { vm.endLive() }, { "%.1fx".format(it) })
        if (c.zoom > 1.01f) {
            LabeledSlider("أفقي", c.panX, -1f..1f, { v -> vm.updateSelected(true) { it.copy(panX = v) } }, { vm.endLive() })
            LabeledSlider("رأسي", c.panY, -1f..1f, { v -> vm.updateSelected(true) { it.copy(panY = v) } }, { vm.endLive() })
        }
    }
}

// ====================================================================== export dialogs

@Composable
private fun ExportSettingsDialog(vm: VideoEditorViewModel, onDismiss: () -> Unit, onStart: (Int, Boolean, Boolean) -> Unit) {
    var wm by remember { mutableStateOf(false) }
    var quality by remember { mutableStateOf(1) }
    var hevc by remember { mutableStateOf(false) }
    val d = vm.data
    val (w, h) = d.outputSize()
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface1,
        title = { Text("تصدير الفيديو") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                SectionLabel("الدقة")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(480, 720, 1080).forEach { r -> Chip("${r}p", d.resolution == r, { vm.setResolution(r) }) }
                }
                SectionLabel("نسبة الأبعاد")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(AspectChoices) { (label, r) -> Chip(label, abs(d.aspect - r) < 0.001f, { vm.setAspect(r) }) }
                }
                SectionLabel("الجودة")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("اقتصادي", "متوازن", "عالي").forEachIndexed { i, label -> Chip(label, quality == i, { quality = i }) }
                }
                SectionLabel("علامة الصانع")
                Chip("إضافة علامة VARQONX", wm, { wm = !wm })
                SectionLabel("الترميز")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("H.264 (متوافق)", !hevc, { hevc = false })
                    Chip("HEVC (حجم أصغر)", hevc, { hevc = true })
                }
                Text(
                    "الناتج: $w×$h • المدة ${formatDuration(d.totalMs)}",
                    color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp)
                )
            }
        },
        confirmButton = { TextButton(onClick = { onStart(quality, hevc, wm) }) { Text("ابدأ التصدير", color = Accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = TextDim) } }
    )
}

@Composable
private fun ExportStatusDialogs(vm: VideoEditorViewModel, onShare: (Uri) -> Unit, onCloud: (Uri) -> Unit) {
    when (val st = vm.exportState) {
        is ExportState.Running -> AlertDialog(
            onDismissRequest = {},
            containerColor = Surface1,
            title = { Text("جاري التصدير...") },
            text = {
                Column {
                    LinearProgressIndicator(progress = { st.progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Accent)
                    Text("${st.progress}%", color = TextDim, modifier = Modifier.padding(top = 8.dp))
                    Text("متقفلش التطبيق لحد ما يخلص.", color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            },
            confirmButton = { TextButton(onClick = { vm.cancelExport() }) { Text("إلغاء", color = TextDim) } }
        )
        is ExportState.Done -> AlertDialog(
            onDismissRequest = { vm.resetExport() },
            containerColor = Surface1,
            title = { Text("تم التصدير") },
            text = {
                Column {
                    Text("اتحفظ الفيديو في المعرض (Movies/NASAQ).", color = TextDim)
                    com.binarybeast.mediastudio.ui.MadeBy(Modifier.padding(top = 10.dp))
                }
            },
            confirmButton = {
                Row {
                    TextButton(onClick = { onCloud(st.uri); vm.resetExport() }) { Text("رفع للسحابة", color = Accent) }
                    TextButton(onClick = { onShare(st.uri); vm.resetExport() }) { Text("مشاركة", color = Accent) }
                }
            },
            dismissButton = { TextButton(onClick = { vm.resetExport() }) { Text("تم", color = TextDim) } }
        )
        is ExportState.Failed -> AlertDialog(
            onDismissRequest = { vm.resetExport() },
            containerColor = Surface1,
            title = { Text("فشل التصدير") },
            text = { Text(st.message, color = TextDim) },
            confirmButton = { TextButton(onClick = { vm.resetExport() }) { Text("حسنًا", color = Accent) } }
        )
        ExportState.Idle -> Unit
    }
}
