package com.binarybeast.mediastudio.image

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** قناع تحديد (0..255) بحجم صورة المصدر. */
class Selection(val w: Int, val h: Int) {
    var m = ByteArray(w * h)

    val isEmpty: Boolean get() = m.all { it.toInt() == 0 }

    fun all() { m.fill(255.toByte()) }

    fun invert() { for (i in m.indices) m[i] = (255 - (m[i].toInt() and 255)).toByte() }

    /** mode: 0 استبدال، 1 إضافة، 2 طرح. */
    fun combine(n: ByteArray, mode: Int) {
        if (n.size != m.size) return
        when (mode) {
            1 -> for (i in m.indices) m[i] = max(m[i].toInt() and 255, n[i].toInt() and 255).toByte()
            2 -> for (i in m.indices) m[i] = max(0, (m[i].toInt() and 255) - (n[i].toInt() and 255)).toByte()
            else -> m = n
        }
    }

    fun feather(r: Int) {
        if (r <= 0) return
        var src = m
        repeat(2) {
            val tmp = ByteArray(src.size)
            for (y in 0 until h) {
                var sum = 0; var cnt = 0
                val row = y * w
                for (k in 0..min(r, w - 1)) { sum += src[row + k].toInt() and 255; cnt++ }
                for (x in 0 until w) {
                    tmp[row + x] = (sum / cnt).toByte()
                    val add = x + r + 1; val rem = x - r
                    if (add < w) { sum += src[row + add].toInt() and 255; cnt++ }
                    if (rem >= 0) { sum -= src[row + rem].toInt() and 255; cnt-- }
                }
            }
            val out = ByteArray(src.size)
            for (x in 0 until w) {
                var sum = 0; var cnt = 0
                for (k in 0..min(r, h - 1)) { sum += tmp[k * w + x].toInt() and 255; cnt++ }
                for (y in 0 until h) {
                    out[y * w + x] = (sum / cnt).toByte()
                    val add = y + r + 1; val rem = y - r
                    if (add < h) { sum += tmp[add * w + x].toInt() and 255; cnt++ }
                    if (rem >= 0) { sum -= tmp[rem * w + x].toInt() and 255; cnt-- }
                }
            }
            src = out
        }
        m = src
    }

    companion object {
        private fun fromPath(w: Int, h: Int, draw: (Canvas, Paint) -> Unit): ByteArray {
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
            val c = Canvas(bmp)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = 0xFF000000.toInt()
            draw(c, p)
            val px = IntArray(w * h)
            bmp.getPixels(px, 0, w, 0, 0, w, h)
            bmp.recycle()
            val out = ByteArray(w * h)
            for (i in px.indices) out[i] = (px[i] ushr 24).toByte()
            return out
        }

        fun rect(w: Int, h: Int, x0: Float, y0: Float, x1: Float, y1: Float) = fromPath(w, h) { c, p ->
            c.drawRect(RectF(min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1)), p)
        }

        fun ellipse(w: Int, h: Int, x0: Float, y0: Float, x1: Float, y1: Float) = fromPath(w, h) { c, p ->
            c.drawOval(RectF(min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1)), p)
        }

        fun polygon(w: Int, h: Int, pts: List<Pair<Float, Float>>): ByteArray {
            if (pts.size < 3) return ByteArray(w * h)
            return fromPath(w, h) { c, p ->
                val path = Path()
                path.moveTo(pts[0].first, pts[0].second)
                for (i in 1 until pts.size) path.lineTo(pts[i].first, pts[i].second)
                path.close()
                c.drawPath(path, p)
            }
        }

        private fun dist(c1: Int, c2: Int): Int {
            val dr = ((c1 shr 16) and 255) - ((c2 shr 16) and 255)
            val dg = ((c1 shr 8) and 255) - ((c2 shr 8) and 255)
            val db = (c1 and 255) - (c2 and 255)
            return (abs(dr) + abs(dg) + abs(db)) / 3
        }

        /** العصا السحرية. contiguous=true: منطقة متصلة، false: كل البكسلات المشابهة. */
        fun wand(b: Bitmap, sx: Int, sy: Int, tol: Float, contiguous: Boolean): ByteArray {
            val w = b.width; val h = b.height
            val out = ByteArray(w * h)
            if (sx !in 0 until w || sy !in 0 until h) return out
            val px = IntArray(w * h)
            b.getPixels(px, 0, w, 0, 0, w, h)
            val seed = px[sy * w + sx]
            val t = (tol * 120f).toInt() + 4
            if (!contiguous) {
                for (i in px.indices) if (dist(px[i], seed) <= t) out[i] = 255.toByte()
                return out
            }
            val q = IntArray(w * h)
            var head = 0; var tail = 0
            q[tail++] = sy * w + sx; out[sy * w + sx] = 255.toByte()
            while (head < tail) {
                val i = q[head++]
                val x = i % w; val y = i / w
                if (x > 0 && out[i - 1].toInt() == 0 && dist(px[i - 1], seed) <= t) { out[i - 1] = 255.toByte(); q[tail++] = i - 1 }
                if (x < w - 1 && out[i + 1].toInt() == 0 && dist(px[i + 1], seed) <= t) { out[i + 1] = 255.toByte(); q[tail++] = i + 1 }
                if (y > 0 && out[i - w].toInt() == 0 && dist(px[i - w], seed) <= t) { out[i - w] = 255.toByte(); q[tail++] = i - w }
                if (y < h - 1 && out[i + w].toInt() == 0 && dist(px[i + w], seed) <= t) { out[i + w] = 255.toByte(); q[tail++] = i + w }
            }
            return out
        }
    }
}
