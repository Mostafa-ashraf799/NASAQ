package com.binarybeast.mediastudio.video

import android.content.Context
import android.net.Uri
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.SingleColorLut
import java.io.File

/** LUT ثلاثي الأبعاد بصيغة .cube (Input/Creative LUT) عن طريق Media3 SingleColorLut. */
@UnstableApi
object Lut {
    private val cache = HashMap<String, SingleColorLut?>()

    fun effect(path: String?): SingleColorLut? {
        if (path.isNullOrBlank()) return null
        synchronized(cache) {
            if (cache.containsKey(path)) return cache[path]
            val e = try { parse(File(path))?.let { SingleColorLut.createFromCube(it) } } catch (t: Throwable) { null }
            cache[path] = e
            return e
        }
    }

    /** cube[r][g][b] = ARGB. ترتيب ملف .cube: الأحمر بيتغيّر الأسرع ثم الأخضر ثم الأزرق. */
    fun parse(f: File): Array<Array<IntArray>>? {
        var n = 0
        var vals = ArrayList<Float>()
        f.bufferedReader().useLines { lines ->
            for (raw in lines) {
                val l = raw.trim()
                if (l.isEmpty() || l.startsWith("#")) continue
                if (l.startsWith("LUT_3D_SIZE")) { n = l.split(Regex("\\s+")).getOrNull(1)?.toIntOrNull() ?: 0; vals = ArrayList(n * n * n * 3); continue }
                val first = l[0]
                if (first.isLetter()) continue      // TITLE / DOMAIN_MIN / ...
                val p = l.split(Regex("\\s+"))
                if (p.size >= 3) { p[0].toFloatOrNull()?.let { r -> vals.add(r); vals.add(p[1].toFloat()); vals.add(p[2].toFloat()) } }
            }
        }
        if (n < 2 || n > 128 || vals.size < n * n * n * 3) return null
        val cube = Array(n) { Array(n) { IntArray(n) } }
        var i = 0
        for (b in 0 until n) for (g in 0 until n) for (r in 0 until n) {
            val rr = (vals[i++].coerceIn(0f, 1f) * 255f + 0.5f).toInt()
            val gg = (vals[i++].coerceIn(0f, 1f) * 255f + 0.5f).toInt()
            val bb = (vals[i++].coerceIn(0f, 1f) * 255f + 0.5f).toInt()
            cube[r][g][b] = (255 shl 24) or (rr shl 16) or (gg shl 8) or bb
        }
        return cube
    }

    /** ينسخ ملف الـ LUT لمخزن التطبيق ويتأكد إنه صالح. */
    fun import(ctx: Context, uri: Uri): String? {
        val dir = File(ctx.filesDir, "luts").apply { mkdirs() }
        val f = File(dir, "lut_${System.currentTimeMillis()}.cube")
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { ins -> f.outputStream().use { ins.copyTo(it) } } ?: return null
            if (parse(f) == null) { f.delete(); null } else f.absolutePath
        } catch (t: Throwable) { f.delete(); null }
    }
}
