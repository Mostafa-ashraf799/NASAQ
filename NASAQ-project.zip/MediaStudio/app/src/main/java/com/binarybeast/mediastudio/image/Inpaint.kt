package com.binarybeast.mediastudio.image

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

/** حذف عنصر ذكي: بيملأ المنطقة المحدّدة من البكسلات المحيطة (طبقة بطبقة من الحافة للجوه) + حبيبات تحاكي الملمس. */
object Inpaint {

    fun fill(b: Bitmap, mask: ByteArray, grow: Int = 3) {
        val w = b.width
        val h = b.height
        if (mask.size != w * h) return
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        var unk = BooleanArray(w * h) { (mask[it].toInt() and 255) > 100 }
        // توسيع المنطقة شوية عشان نشيل الحواف المتبقية
        repeat(grow) {
            val n = unk.copyOf()
            for (y in 0 until h) for (x in 0 until w) {
                if (!unk[y * w + x]) continue
                if (x > 0) n[y * w + x - 1] = true
                if (x < w - 1) n[y * w + x + 1] = true
                if (y > 0) n[(y - 1) * w + x] = true
                if (y < h - 1) n[(y + 1) * w + x] = true
            }
            unk = n
        }
        var pending = ArrayList<Int>()
        for (i in unk.indices) if (unk[i]) pending.add(i)
        if (pending.isEmpty()) return
        val filled = BooleanArray(w * h)
        val r = 4
        var guard = 0
        while (pending.isNotEmpty() && guard++ < 600) {
            val idx = ArrayList<Int>()
            val col = ArrayList<Int>()
            val still = ArrayList<Int>()
            for (i in pending) {
                val x = i % w; val y = i / w
                val hasKnown = (x > 0 && !unk[i - 1]) || (x < w - 1 && !unk[i + 1]) ||
                    (y > 0 && !unk[i - w]) || (y < h - 1 && !unk[i + w])
                if (!hasKnown) { still.add(i); continue }
                var sr = 0f; var sg = 0f; var sb = 0f; var sw = 0f
                for (dy in -r..r) {
                    val yy = y + dy
                    if (yy < 0 || yy >= h) continue
                    for (dx in -r..r) {
                        val xx = x + dx
                        if (xx < 0 || xx >= w) continue
                        val j = yy * w + xx
                        if (unk[j]) continue
                        val wt = 1f / (1f + dx * dx + dy * dy)
                        val c = px[j]
                        sr += ((c shr 16) and 255) * wt; sg += ((c shr 8) and 255) * wt; sb += (c and 255) * wt
                        sw += wt
                    }
                }
                if (sw <= 0f) { still.add(i); continue }
                idx.add(i)
                col.add((0xFF shl 24) or ((sr / sw).toInt() shl 16) or ((sg / sw).toInt() shl 8) or (sb / sw).toInt())
            }
            if (idx.isEmpty()) break
            for (k in idx.indices) { px[idx[k]] = col[k]; unk[idx[k]] = false; filled[idx[k]] = true }
            pending = still
        }
        // حبيبات خفيفة عشان المنطقة المملوءة ما تبانش ملساء بزيادة
        val rnd = java.util.Random(7L)
        for (i in filled.indices) if (filled[i]) {
            val n = ((rnd.nextFloat() - 0.5f) * 10f).toInt()
            val c = px[i]
            val rr = min(255, max(0, ((c shr 16) and 255) + n))
            val gg = min(255, max(0, ((c shr 8) and 255) + n))
            val bb = min(255, max(0, (c and 255) + n))
            px[i] = (c and -16777216) or (rr shl 16) or (gg shl 8) or bb
        }
        b.setPixels(px, 0, w, 0, 0, w, h)
    }
}
