package com.binarybeast.mediastudio.ui

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.binarybeast.mediastudio.Graph
import com.binarybeast.mediastudio.R
import com.binarybeast.mediastudio.data.Project
import com.binarybeast.mediastudio.data.ProjectFactory
import com.binarybeast.mediastudio.data.ProjectType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed interface NewProjectRequest {
    val name: String

    data class Pick(override val name: String, val type: ProjectType) : NewProjectRequest
    data class PickAudio(override val name: String) : NewProjectRequest
    data class PickCollage(override val name: String) : NewProjectRequest
    data class Record(override val name: String) : NewProjectRequest
    data class Blank(override val name: String, val w: Int, val h: Int, val color: Int) : NewProjectRequest
}

private enum class WFilter(val label: String) { ALL("الكل"), IMAGE("صور"), VIDEO("فيديو"), AUDIO("صوت") }

@Composable
fun WorkspaceScreen(onOpen: (Project) -> Unit, onNew: (NewProjectRequest) -> Unit) {
    val ctx = LocalContext.current
    var projects by remember { mutableStateOf<List<Project>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var reloadKey by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(WFilter.ALL) }
    var sortByName by remember { mutableStateOf(false) }
    var showNew by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<Project?>(null) }
    var deleting by remember { mutableStateOf<Project?>(null) }

    // إعادة تحميل المشاريع كل ما نرجع للصفحة (بعد الخروج من المحرر مثلاً)
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) reloadKey++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    LaunchedEffect(reloadKey) {
        projects = withContext(Dispatchers.IO) { Graph.repo.list() }
        loaded = true
    }

    val shown = remember(projects, query, filter, sortByName) {
        projects
            .filter {
                (filter == WFilter.ALL || (filter == WFilter.IMAGE && it.type == ProjectType.IMAGE) ||
                    (filter == WFilter.VIDEO && it.type == ProjectType.VIDEO) ||
                    (filter == WFilter.AUDIO && it.type == ProjectType.AUDIO)) &&
                    (query.isBlank() || it.name.contains(query.trim(), ignoreCase = true))
            }
            .let { l -> if (sortByName) l.sortedBy { it.name.lowercase() } else l.sortedByDescending { it.updatedAt } }
            .sortedByDescending { it.pinned }
    }

    Box(Modifier.fillMaxSize().background(Bg).statusBarsPadding(), contentAlignment = Alignment.TopCenter) {
    Column(Modifier.widthIn(max = 1100.dp).fillMaxSize()) {
        // ---------------- brand header
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painterResource(R.drawable.nasaq_mark), null,
                modifier = Modifier.size(52.dp).clip(CircleShape).clickable { showAbout = true }, contentScale = ContentScale.Fit
            )
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                Text("نسق", fontSize = 26.sp, color = MaterialTheme.colorScheme.onBackground)
                Text("NASAQ  •  استوديو الصور والفيديو والصوت", fontSize = 11.sp, color = TextDim, letterSpacing = 1.2.sp)
                Text(com.binarybeast.mediastudio.data.Brand.MADE_BY, fontSize = 10.sp, color = Accent)
            }
            Text("${projects.size} مشروع", fontSize = 12.sp, color = TextDim)
        }

        LazyVerticalGrid(
            columns = GridCells.Adaptive(165.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // زر مشروع جديد
            item(span = { GridItemSpan(maxLineSpan) }) { NewProjectCard { showNew = true } }

            // بحث وفلترة
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column {
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("ابحث في مشاريعك...", color = TextDim) },
                        leadingIcon = { Icon(Icons.Default.Search, null, tint = TextDim) },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Accent, unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                            focusedContainerColor = Surface1, unfocusedContainerColor = Surface1
                        )
                    )
                    LazyRow(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(WFilter.values().toList()) { f -> Chip(f.label, filter == f, { filter = f }) }
                        item { Chip(if (sortByName) "ترتيب: الاسم" else "ترتيب: الأحدث", false, { sortByName = !sortByName }) }
                    }
                }
            }

            if (loaded && shown.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) { EmptyState(hasAny = projects.isNotEmpty()) }
            }

            items(shown, key = { it.id }) { p ->
                ProjectCard(
                    p,
                    onOpen = { onOpen(p) },
                    onRename = { renaming = p },
                    onDuplicate = {
                        Graph.repo.duplicate(p.id)
                        reloadKey++
                    },
                    onPin = {
                        Graph.repo.setPinned(p.id, !p.pinned)
                        reloadKey++
                    },
                    onDelete = { deleting = p }
                )
            }

        }
    }
    }

    if (showAbout) AboutDialog(onDismiss = { showAbout = false })
    if (showNew) {
        NewProjectDialog(
            onDismiss = { showNew = false },
            onCreate = { showNew = false; onNew(it) }
        )
    }
    renaming?.let { p ->
        TextInputDialog(
            title = "إعادة تسمية", initial = p.name,
            onConfirm = {
                if (it.isNotBlank()) {
                    Graph.repo.rename(p.id, it)
                    reloadKey++
                }
                renaming = null
            },
            onDismiss = { renaming = null }
        )
    }
    deleting?.let { p ->
        ConfirmDialog(
            title = "حذف المشروع", text = "هيتحذف «${p.name}» نهائيًا من التطبيق (الملفات الأصلية في معرضك مش هتتأثر).",
            confirm = "حذف", danger = true,
            onConfirm = {
                Graph.repo.delete(p.id)
                deleting = null
                reloadKey++
            },
            onDismiss = { deleting = null }
        )
    }
    @Suppress("UNUSED_VARIABLE") val unusedCtx = ctx
}

@Composable
private fun NewProjectCard(onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF1A1C2C), Color(0xFF241F45), Color(0xFF14151F))))
            .border(1.dp, Brush.linearGradient(listOf(Silver.copy(alpha = 0.55f), Accent.copy(alpha = 0.35f))), RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(Accent),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Add, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(28.dp)) }
            Column(Modifier.padding(start = 14.dp)) {
                Text("مشروع جديد", fontSize = 18.sp)
                Text("صورة، فيديو، أو لوحة فارغة", fontSize = 12.sp, color = TextDim)
            }
        }
    }
}

@Composable
private fun EmptyState(hasAny: Boolean) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 36.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painterResource(R.drawable.nasaq_mark), null, Modifier.size(96.dp).alpha(0.55f))
        Text(
            if (hasAny) "مفيش نتايج مطابقة" else "لسه مفيش مشاريع",
            fontSize = 16.sp, modifier = Modifier.padding(top = 12.dp)
        )
        Text(
            if (hasAny) "جرّب كلمة بحث تانية أو غيّر الفلتر." else "اضغط «مشروع جديد» وابدأ أول شغلة ليك.",
            fontSize = 12.sp, color = TextDim, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun ProjectCard(p: Project, onOpen: () -> Unit, onRename: () -> Unit, onDuplicate: () -> Unit, onPin: () -> Unit, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    val thumb = remember(p.id, p.updatedAt) { Graph.repo.thumbFile(p.id) }
    Column(
        Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Surface1)
            .clickable(onClick = onOpen)
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1.15f).background(Surface2)) {
            if (thumb.exists()) {
                AsyncImage(
                    model = ImageRequest.Builder(ctx).data(thumb)
                        .memoryCacheKey("${p.id}_${p.updatedAt}").diskCacheKey("${p.id}_${p.updatedAt}").build(),
                    contentDescription = p.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                )
            } else {
                Icon(
                    typeIcon(p.type), null,
                    tint = TextDim, modifier = Modifier.align(Alignment.Center).size(36.dp)
                )
            }
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xAA000000))
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(typeIcon(p.type), null, tint = Silver, modifier = Modifier.size(14.dp))
                    if (p.pinned) Icon(Icons.Default.PushPin, null, tint = Accent, modifier = Modifier.padding(start = 4.dp).size(14.dp))
                }
            }
            Box(Modifier.align(Alignment.TopEnd)) {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Default.MoreVert, "خيارات", tint = Color.White)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("فتح") }, leadingIcon = { Icon(Icons.Default.Edit, null) },
                        onClick = { menu = false; onOpen() }
                    )
                    DropdownMenuItem(
                        text = { Text("إعادة تسمية") }, leadingIcon = { Icon(Icons.Default.Edit, null) },
                        onClick = { menu = false; onRename() }
                    )
                    DropdownMenuItem(
                        text = { Text(if (p.pinned) "إلغاء التثبيت" else "تثبيت في الأعلى") }, leadingIcon = { Icon(Icons.Default.PushPin, null) },
                        onClick = { menu = false; onPin() }
                    )
                    DropdownMenuItem(
                        text = { Text("نسخ المشروع") }, leadingIcon = { Icon(Icons.Default.ContentCopy, null) },
                        onClick = { menu = false; onDuplicate() }
                    )
                    DropdownMenuItem(
                        text = { Text("حذف", color = Danger) }, leadingIcon = { Icon(Icons.Default.Delete, null, tint = Danger) },
                        onClick = { menu = false; onDelete() }
                    )
                }
            }
        }
        Column(Modifier.padding(10.dp)) {
            Text(p.name, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(p.summary, fontSize = 11.sp, color = TextDim, maxLines = 1)
            Text(formatDate(p.updatedAt), fontSize = 10.sp, color = TextDim.copy(alpha = 0.7f), maxLines = 1)
        }
    }
}

// ====================================================================== new project dialog

private val BlankSizes = listOf(
    Triple("1:1 • 1080×1080", 1080, 1080),
    Triple("ستوري • 1080×1920", 1080, 1920),
    Triple("أفقي • 1920×1080", 1920, 1080),
    Triple("4:5 • 1080×1350", 1080, 1350),
    Triple("A4 • 2480×3508", 2480, 3508),
)

private enum class Kind(val label: String) { IMAGE("صورة"), VIDEO("فيديو"), AUDIO("صوت"), COLLAGE("كولاج"), RECORD("تسجيل صوت"), BLANK("لوحة فارغة") }

private fun typeIcon(t: ProjectType) = when (t) {
    ProjectType.VIDEO -> Icons.Default.Movie
    ProjectType.AUDIO -> Icons.Default.MusicNote
    else -> Icons.Default.Image
}

@Composable
private fun NewProjectDialog(onDismiss: () -> Unit, onCreate: (NewProjectRequest) -> Unit) {
    var name by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(Kind.IMAGE) }
    var size by remember { mutableStateOf(0) }
    var color by remember { mutableStateOf(0xFFFFFFFF.toInt()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface1,
        title = { Text("مشروع جديد") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("اسم المشروع (اختياري)", color = TextDim) }
                )
                SectionLabel("النوع")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Kind.values().forEach { k -> Chip(k.label, kind == k, { kind = k }) }
                }
                Text(
                    when (kind) {
                        Kind.IMAGE -> "هتختار صورة من المعرض وتفتح في محرر الصور."
                        Kind.VIDEO -> "هتختار مقاطع وصور من المعرض وترتبها في تايم لاين."
                        Kind.AUDIO -> "اختار ملف صوت (أو فيديو لاستخراج صوته) من جهازك أو من السحابة."
                        Kind.COLLAGE -> "اختار من 2 لـ 9 صور ورتبها في تخطيط جاهز."
                        Kind.RECORD -> "سجّل صوتك بالمايك وعدّله مباشرة."
                        Kind.BLANK -> "ابدأ من لوحة فاضية وارسم واكتب عليها."
                    },
                    color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
                )
                if (kind == Kind.BLANK) {
                    SectionLabel("المقاس")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(BlankSizes.indices.toList()) { i -> Chip(BlankSizes[i].first, size == i, { size = i }) }
                    }
                    SectionLabel("لون الخلفية")
                    ColorRow(color, onPick = { color = it })
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val n = name.trim()
                onCreate(
                    when (kind) {
                        Kind.IMAGE -> NewProjectRequest.Pick(n, ProjectType.IMAGE)
                        Kind.VIDEO -> NewProjectRequest.Pick(n, ProjectType.VIDEO)
                        Kind.AUDIO -> NewProjectRequest.PickAudio(n)
                        Kind.COLLAGE -> NewProjectRequest.PickCollage(n)
                        Kind.RECORD -> NewProjectRequest.Record(n)
                        Kind.BLANK -> NewProjectRequest.Blank(n, BlankSizes[size].second, BlankSizes[size].third, color)
                    }
                )
            }) { Text(if (kind == Kind.BLANK) "إنشاء" else if (kind == Kind.RECORD) "ابدأ التسجيل" else "التالي: اختر الميديا", color = Accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = TextDim) } }
    )
}

@Suppress("unused")
private fun unusedFactory() = ProjectFactory.defaultName("")
