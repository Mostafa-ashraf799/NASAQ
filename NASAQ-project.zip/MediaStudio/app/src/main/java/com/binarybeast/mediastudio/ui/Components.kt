package com.binarybeast.mediastudio.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val PaletteColors: List<Int> = listOf(
    0xFFFFFFFF, 0xFF000000, 0xFFFF4D4D, 0xFFFF8A3D, 0xFFFFD43B, 0xFF51CF66,
    0xFF2EE6C5, 0xFF339AF0, 0xFF8B7CFF, 0xFFE64980, 0xFFB197FC, 0xFF868E96,
).map { it.toInt() }

/** سلايدر مع عنوان وقيمة. onFinished بيتنادى لما المستخدم يرفع إصبعه. */
@Composable
fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    onFinished: () -> Unit = {},
    display: (Float) -> String = { "%.0f".format(it * 100) },
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, fontSize = 12.sp, color = TextDim, modifier = Modifier.width(64.dp), maxLines = 1)
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            onValueChangeFinished = onFinished,
            valueRange = range,
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(
                thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Surface2
            )
        )
        Text(display(value), fontSize = 12.sp, color = TextDim, modifier = Modifier.width(44.dp), textAlign = TextAlign.End, maxLines = 1)
    }
}

@Composable
fun ColorRow(selected: Int?, onPick: (Int) -> Unit, modifier: Modifier = Modifier, colors: List<Int> = PaletteColors) {
    LazyRow(modifier = modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(colors) { c ->
            val sel = selected == c
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(Color(c))
                    .border(if (sel) 3.dp else 1.dp, if (sel) Accent else Color(0x55FFFFFF), CircleShape)
                    .clickable { onPick(c) }
            ) {
                if (sel) {
                    Icon(
                        Icons.Default.Check, null,
                        tint = if (c == 0xFFFFFFFF.toInt()) Color.Black else Color.White,
                        modifier = Modifier.align(Alignment.Center).size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Accent else Surface2)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun ToolTab(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = if (selected) Accent else TextDim, modifier = Modifier.size(24.dp))
        Text(label, fontSize = 11.sp, color = if (selected) Accent else TextDim, maxLines = 1)
    }
}

@Composable
fun SmallButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, danger: Boolean = false, icon: ImageVector? = null) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Surface2)
            .border(BorderStroke(1.dp, if (danger) Danger.copy(alpha = 0.6f) else MaterialTheme.colorScheme.outline), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (icon != null) Icon(icon, null, tint = if (danger) Danger else MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(16.dp))
        Text(text, fontSize = 13.sp, color = if (danger) Danger else MaterialTheme.colorScheme.onSurface, maxLines = 1)
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(text, fontSize = 12.sp, color = TextDim, modifier = modifier.padding(vertical = 4.dp))
}

@Composable
fun LoadingDialog(text: String) {
    AlertDialog(
        onDismissRequest = {},
        confirmButton = {},
        containerColor = Surface1,
        text = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                CircularProgressIndicator(modifier = Modifier.size(28.dp), color = Accent, strokeWidth = 3.dp)
                Text(text)
            }
        }
    )
}

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit, danger: Boolean = false) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface1,
        title = { Text(title) },
        text = { Text(text, color = TextDim) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirm, color = if (danger) Danger else Accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = TextDim) } }
    )
}

fun formatDate(ts: Long): String =
    SimpleDateFormat("d MMM yyyy • HH:mm", Locale("ar")).format(Date(ts))

@Suppress("unused")
private fun unusedDp(d: Dp) = d
