package com.binarybeast.mediastudio.image

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

/**
 * إدارة ألوان للطباعة (تقريبية، مش ICC حقيقي): محاكاة CMYK، تحذير خارج النطاق، فصل القنوات، Lab/تدرج رمادي.
 * وضع العرض: 0 عادي، 1 تحذير القص، 2 خارج نطاق الطباعة، 3 Soft Proof (محاكاة ورق/حبر)،
 * 4..7 قنوات C/M/Y/K، 8 قناة L (Lab).
 */
object ColorMgmt {
    val viewNames = listOf("عادي", "تحذير القص", "خارج نطاق الطباعة", "Soft Proof", "C سيان", "M ماجنتا", "Y أصفر", "K أسود", "Lab: L")

    private const val TAC = 3.0f   // أقصى مجموع حبر 300%

    private fun cmyk(r: Int, g: Int, b: Int, out: FloatArray) {
        val rf = r / 255f; val gf = g / 255f; val bf = b / 255f
        val k = 1f - max(rf, max(gf, bf))
        if (k >= 0.999f) { out[0] = 0f; out[1] = 0f; out[2] = 0f; out[3] = 1f; return }
        val d = 1f - k
        out[0] = (1f - rf - k) / d; out[1] = (1f - gf - k) / d; out[2] = (1f - bf - k) / d; out[3] = k
    }

    /** محاكاة طباعة: حد الحبر الكلي + ضغط التشبّع + ورق مش أبيض تمامًا. ترجع RGB. */
    private fun proof(r: Int, g: Int, b: Int): Int {
        val v = FloatArray(4); cmyk(r, g, b, v)
        val total = v[0] + v[1] + v[2] + v[3]
        if (total > TAC) { val s = TAC / total; for (i in 0 until 4) v[i] *= s }
        // رجوع لـ RGB مع ضغط التشبّع (نطاق الحبر أضيق من الشاشة) وورق بدرجة 96%
        var rr = (1f - v[0]) * (1f - v[3]); var gg = (1f - v[1]) * (1f - v[3]); var bb = (1f - v[2]) * (1f - v[3])
        val gray = (rr + gg + bb) / 3f
        val sat = 0.88f
        rr = gray + (rr - gray) * sat; gg = gray + (gg - gray) * sat; bb = gray + (bb - gray) * sat
        val paperR = 0.98f; val paperG = 0.97f; val paperB = 0.94f
        val ink = 0.06f
        fun f(x: Float, p: Float) = ((ink + (p - ink) * x).coerceIn(0f, 1f) * 255f + 0.5f).toInt()
        return (f(rr, paperR) shl 16) or (f(gg, paperG) shl 8) or f(bb, paperB)
    }

    private fun gamutDelta(r: Int, g: Int, b: Int): Int {
        val p = proof(r, g, b)
        val dr = kotlin.math.abs(((p shr 16) and 255) - r)
        val dg = kotlin.math.abs(((p shr 8) and 255) - g)
        val db = kotlin.math.abs((p and 255) - b)
        return max(dr, max(dg, db))
    }

    private fun lightness(r: Int, g: Int, b: Int): Int {
        fun lin(c: Int): Float { val x = c / 255f; return if (x <= 0.04045f) x / 12.92f else Math.pow(((x + 0.055f) / 1.055f).toDouble(), 2.4).toFloat() }
        val y = 0.2126f * lin(r) + 0.7152f * lin(g) + 0.0722f * lin(b)
        val l = if (y > 0.008856f) 116f * Math.cbrt(y.toDouble()).toFloat() - 16f else 903.3f * y
        return (l * 2.55f).toInt().coerceIn(0, 255)
    }

    /** يبني صورة العرض لوضع معيّن (الأصل ما بيتغيّرش). */
    fun view(src: Bitmap, mode: Int): Bitmap {
        if (mode == 1) return ImageAnalysis.clipOverlay(src)
        val w = src.width; val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val v = FloatArray(4)
        for (i in px.indices) {
            val c = px[i]
            val a = c and -16777216
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            px[i] = when (mode) {
                2 -> if (gamutDelta(r, g, b) > 28) a or 0xFF00FF else (a or (((r + g + b) / 3 / 2 + 100) * 0x010101))
                3 -> a or proof(r, g, b)
                4, 5, 6, 7 -> {
                    cmyk(r, g, b, v)
                    val ink = v[mode - 4]
                    val gv = ((1f - ink) * 255f).toInt().coerceIn(0, 255)
                    a or (gv * 0x010101)
                }
                8 -> a or (lightness(r, g, b) * 0x010101)
                else -> c
            }
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    /** تطبيق محاكاة الطباعة على الصورة نفسها (ألوان آمنة للطباعة). */
    fun applySafeForPrint(b: Bitmap) {
        val w = b.width; val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            px[i] = (c and -16777216) or proof((c shr 16) and 255, (c shr 8) and 255, c and 255)
        }
        b.setPixels(px, 0, w, 0, 0, w, h)
    }

    /** يضيف هامش نزف (Bleed) بانعكاس الحواف + علامات القص. bleedPx بالبكسل. */
    fun addBleedAndMarks(src: Bitmap, bleedPx: Int): Bitmap {
        val bl = bleedPx.coerceAtLeast(1)
        val markLen = max(24, bl * 2); val gap = max(6, bl / 2)
        val margin = bl + gap + markLen
        val w = src.width + margin * 2; val h = src.height + margin * 2
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(out)
        c.drawColor(android.graphics.Color.WHITE)
        val p = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)
        // الصورة في المنتصف
        val x0 = margin; val y0 = margin
        c.drawBitmap(src, x0.toFloat(), y0.toFloat(), p)
        // نزف: أشرطة معكوسة حوالين الصورة
        fun strip(sx: Int, sy: Int, sw: Int, sh: Int, dx: Int, dy: Int, fx: Float, fy: Float) {
            if (sw <= 0 || sh <= 0) return
            val part = Bitmap.createBitmap(src, sx, sy, sw, sh)
            val m = android.graphics.Matrix()
            m.postScale(fx, fy, sw / 2f, sh / 2f)
            m.postTranslate(dx.toFloat(), dy.toFloat())
            c.drawBitmap(part, m, p)
            part.recycle()
        }
        val bw = min(bl, src.width); val bh = min(bl, src.height)
        strip(0, 0, bw, src.height, x0 - bw, y0, -1f, 1f)
        strip(src.width - bw, 0, bw, src.height, x0 + src.width, y0, -1f, 1f)
        strip(0, 0, src.width, bh, x0, y0 - bh, 1f, -1f)
        strip(0, src.height - bh, src.width, bh, x0, y0 + src.height, 1f, -1f)
        // علامات القص عند حدود القص (trim) — خارج منطقة النزف
        val mk = android.graphics.Paint().apply { color = android.graphics.Color.BLACK; strokeWidth = max(1f, bl / 14f) }
        val l = x0.toFloat(); val r = (x0 + src.width).toFloat(); val t = y0.toFloat(); val b = (y0 + src.height).toFloat()
        val o = (bl + gap).toFloat(); val e = o + markLen
        for (x in listOf(l, r)) { c.drawLine(x, t - o, x, t - e, mk); c.drawLine(x, b + o, x, b + e, mk) }
        for (y in listOf(t, b)) { c.drawLine(l - o, y, l - e, y, mk); c.drawLine(r + o, y, r + e, y, mk) }
        return out
    }
}
