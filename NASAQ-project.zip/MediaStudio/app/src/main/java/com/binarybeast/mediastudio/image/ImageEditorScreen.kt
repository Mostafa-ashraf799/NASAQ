package com.binarybeast.mediastudio.image

import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.FilterVintage
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.FlipToBack
import androidx.compose.material.icons.filled.FlipToFront
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Undo
import android.app.Application
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateRotation
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke as DrawStroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.binarybeast.mediastudio.data.Adjust
import com.binarybeast.mediastudio.data.ExportFormat
import com.binarybeast.mediastudio.data.Look
import com.binarybeast.mediastudio.data.Looks
import com.binarybeast.mediastudio.data.Stroke
import com.binarybeast.mediastudio.data.TextLayer
import com.binarybeast.mediastudio.ui.Accent
import com.binarybeast.mediastudio.ui.Bg
import com.binarybeast.mediastudio.ui.Chip
import com.binarybeast.mediastudio.ui.ColorRow
import com.binarybeast.mediastudio.ui.LabeledSlider
import com.binarybeast.mediastudio.ui.LoadingDialog
import com.binarybeast.mediastudio.ui.SectionLabel
import com.binarybeast.mediastudio.ui.SmallButton
import com.binarybeast.mediastudio.ui.Surface1
import com.binarybeast.mediastudio.ui.Surface2
import com.binarybeast.mediastudio.ui.TextDim
import com.binarybeast.mediastudio.ui.TextInputDialog
import com.binarybeast.mediastudio.ui.ToolTab
import com.binarybeast.mediastudio.ui.isWideLayout
import com.binarybeast.mediastudio.ui.panelMaxHeight
import com.binarybeast.mediastudio.ui.shareUri
import com.binarybeast.mediastudio.ui.toast
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

private enum class Tool(val label: String) {
    ADJUST("تعديل"), LOOKS("فلاتر"), CROP("قص وتدوير"), TEXT("نص"),
    STICKER("ستيكر"), DRAW("رسم"), EFFECTS("تأثيرات")
}

private val Emojis = listOf(
    "😀", "😂", "🤣", "😍", "🥰", "😎", "🤩", "😜", "🤔", "😭", "😡", "🥳",
    "👍", "👎", "👏", "🙏", "💪", "🔥", "✨", "💯", "❤️", "🧡", "💛", "💚",
    "💙", "💜", "🖤", "⭐", "🌟", "🎉", "🎈", "🎁", "🏆", "👑", "💎", "🌈",
    "☀️", "🌙", "⚡", "❄️", "🌸", "🌹", "🍀", "🎵", "🎬", "📸", "✅", "❌",
    "⚠️", "➡️", "📍", "🚀", "🎮", "🍕", "☕", "🐱", "🐶", "🦋", "👀", "💬",
)

@Composable
fun ImageEditorScreen(projectId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val vm: ImageEditorViewModel = viewModel(
        key = projectId,
        factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                ImageEditorViewModel(ctx.applicationContext as Application, projectId) as T
        }
    )

    var tool by remember { mutableStateOf(Tool.ADJUST) }
    var showExport by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var brushColor by remember { mutableStateOf(0xFFFF4D4D.toInt()) }
    var brushSize by remember { mutableStateOf(0.012f) }
    var brushAlpha by remember { mutableStateOf(1f) }

    BackHandler {
        vm.saveNow()
        onBack()
    }
    DisposableEffect(Unit) { onDispose { vm.saveNow() } }
    LaunchedEffect(vm.message) {
        vm.message?.let { toast(ctx, it); vm.message = null }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        // ---------------- top bar
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.saveNow(); onBack() }) { Icon(Icons.Default.ArrowBack, "رجوع") }
            Text(
                vm.project?.name ?: "",
                modifier = Modifier.weight(1f).clickable { showRename = true }.padding(horizontal = 4.dp),
                maxLines = 1, fontSize = 16.sp
            )
            IconButton(onClick = { vm.undo() }, enabled = vm.canUndo) {
                Icon(Icons.Default.Undo, "تراجع", tint = if (vm.canUndo) MaterialTheme.colorScheme.onSurface else TextDim.copy(alpha = 0.4f))
            }
            IconButton(onClick = { vm.redo() }, enabled = vm.canRedo) {
                Icon(Icons.Default.Redo, "إعادة", tint = if (vm.canRedo) MaterialTheme.colorScheme.onSurface else TextDim.copy(alpha = 0.4f))
            }
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .pointerInput(Unit) {
                        detectTapGestures(onPress = {
                            vm.showOriginal = true
                            tryAwaitRelease()
                            vm.showOriginal = false
                        })
                    },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Compare, "مقارنة (اضغط مطولاً)") }
            SmallButton("حفظ", onClick = { showExport = true }, icon = Icons.Default.Save)
            Spacer(Modifier.width(6.dp))
        }

        val wide = isWideLayout()
        val panel: @Composable () -> Unit = {
            when (tool) {
                Tool.ADJUST -> AdjustPanel(vm)
                Tool.LOOKS -> LooksPanel(vm)
                Tool.CROP -> CropPanel(vm)
                Tool.TEXT -> TextPanel(vm)
                Tool.STICKER -> StickerPanel(vm)
                Tool.DRAW -> DrawPanel(
                    vm, brushColor, brushSize, brushAlpha,
                    onColor = { brushColor = it }, onSize = { brushSize = it }, onAlpha = { brushAlpha = it }
                )
                Tool.EFFECTS -> EffectsPanel(vm)
            }
        }
        val tabs: @Composable () -> Unit = {
            LazyRow(
                Modifier.fillMaxWidth().background(Surface1).padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                items(Tool.values().toList()) { t ->
                    ToolTab(
                        icon = when (t) {
                            Tool.ADJUST -> Icons.Default.Tune
                            Tool.LOOKS -> Icons.Default.FilterVintage
                            Tool.CROP -> Icons.Default.Crop
                            Tool.TEXT -> Icons.Default.TextFields
                            Tool.STICKER -> Icons.Default.EmojiEmotions
                            Tool.DRAW -> Icons.Default.Brush
                            Tool.EFFECTS -> Icons.Default.AutoAwesome
                        },
                        label = t.label,
                        selected = tool == t,
                        onClick = {
                            tool = t
                            if (t != Tool.TEXT && t != Tool.STICKER) vm.selectedLayer = null
                        }
                    )
                }
            }
        }

        if (wide) {
            // تابلت / موبايل بالعرض: المعاينة يسار واللوحة يمين
            Row(Modifier.weight(1f).fillMaxWidth()) {
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    EditCanvas(vm, tool, brushColor, brushSize, brushAlpha)
                }
                Column(Modifier.width(390.dp).fillMaxHeight().background(Surface1)) {
                    tabs()
                    Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)) { panel() }
                }
            }
        } else {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                EditCanvas(vm, tool, brushColor, brushSize, brushAlpha)
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 130.dp, max = panelMaxHeight())
                    .background(Surface1)
                    .padding(vertical = 8.dp)
            ) { panel() }
            tabs()
        }
    }

    if (showRename) {
        TextInputDialog(
            title = "اسم المشروع", initial = vm.project?.name ?: "",
            onConfirm = { if (it.isNotBlank()) vm.rename(it); showRename = false },
            onDismiss = { showRename = false }
        )
    }
    val uploadToCloud = com.binarybeast.mediastudio.ui.rememberCloudUpload()
    if (showExport) {
        ExportDialog(
            onDismiss = { showExport = false },
            onExport = { fmt, quality, scale, mode, wm ->
                showExport = false
                vm.export(fmt, quality, scale, wm) { uri ->
                    if (uri != null) {
                        toast(ctx, "تم الحفظ في المعرض (Pictures/NASAQ)")
                        if (mode == 1) shareUri(ctx, uri, fmt.mime)
                        if (mode == 2) uploadToCloud(listOf(uri))
                    }
                }
            }
        )
    }
    if (vm.exporting) LoadingDialog("جاري التصدير بأعلى جودة...")
    vm.processing?.let { LoadingDialog(it) }
    CutoutDialog(vm)
}

// ====================================================================== canvas

@Composable
private fun EditCanvas(vm: ImageEditorViewModel, tool: Tool, brushColor: Int, brushSize: Float, brushAlpha: Float) {
    val bmp = vm.preview
    if (vm.loading || bmp == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (vm.failed) Text("تعذر فتح المشروع", color = TextDim) else CircularProgressIndicator(color = Accent)
        }
        return
    }
    val orig = vm.original
    val showOrig = vm.showOriginal && orig != null
    val shown = if (showOrig) orig!! else bmp
    val img = remember(shown) { shown.asImageBitmap() }
    val ratio = bmp.width.toFloat() / bmp.height
    val live = remember { mutableStateListOf<Float>() }

    val gestures = when (tool) {
        Tool.DRAW -> Modifier.pointerInput(tool, brushColor, brushSize, brushAlpha) {
            detectDragGestures(
                onDragStart = { o ->
                    live.clear()
                    live.add(o.x / size.width); live.add(o.y / size.height)
                },
                onDrag = { change, _ ->
                    change.consume()
                    live.add((change.position.x / size.width).coerceIn(0f, 1f))
                    live.add((change.position.y / size.height).coerceIn(0f, 1f))
                },
                onDragEnd = {
                    if (live.size >= 4) vm.addStroke(Stroke(brushColor, brushSize, brushAlpha, live.toList()))
                    live.clear()
                },
                onDragCancel = { live.clear() }
            )
        }
        Tool.TEXT, Tool.STICKER -> Modifier.pointerInput(tool) { layerGestures(vm) }
        else -> Modifier
    }

    Box(Modifier.fillMaxSize().padding(10.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .aspectRatio(if (showOrig) orig!!.width.toFloat() / orig.height else ratio)
                .clip(RoundedCornerShape(4.dp))
                .then(gestures)
        ) {
            Image(
                bitmap = img, contentDescription = null,
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds
            )
            if (!showOrig) {
                Canvas(Modifier.fillMaxSize()) {
                    drawIntoCanvas { c ->
                        val nc = c.nativeCanvas
                        ImageProcessor.drawOverlays(nc, size.width, size.height, vm.edit.strokes, vm.edit.texts)
                        if (live.size >= 4) {
                            ImageProcessor.drawStroke(
                                nc, Stroke(brushColor, brushSize, brushAlpha, live.toList()), size.width, size.height
                            )
                        }
                    }
                    val sel = vm.selectedLayer
                    if (sel != null && (tool == Tool.TEXT || tool == Tool.STICKER)) {
                        vm.edit.texts.firstOrNull { it.id == sel }?.let { l ->
                            val (hw, hh) = TextRenderer.halfExtentsFor(l, size.height)
                            val cx = l.x * size.width
                            val cy = l.y * size.height
                            rotate(l.rotation, pivot = Offset(cx, cy)) {
                                drawRect(
                                    color = Accent,
                                    topLeft = Offset(cx - hw, cy - hh),
                                    size = Size(hw * 2, hh * 2),
                                    style = DrawStroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 9f)))
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun hitTest(texts: List<TextLayer>, p: Offset, w: Float, h: Float): Long? {
    for (l in texts.asReversed()) {
        val (hw, hh) = TextRenderer.halfExtentsFor(l, h)
        val dx = p.x - l.x * w
        val dy = p.y - l.y * h
        val rad = Math.toRadians(-l.rotation.toDouble())
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()
        val lx = dx * c - dy * s
        val ly = dx * s + dy * c
        val pad = 24f
        if (abs(lx) <= hw + pad && abs(ly) <= hh + pad) return l.id
    }
    return null
}

/** سحب بإصبع واحد على الطبقة لتحريكها، وإصبعين للتكبير والتدوير. */
private suspend fun PointerInputScope.layerGestures(vm: ImageEditorViewModel) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        val w = size.width.toFloat()
        val h = size.height.toFloat()
        val hit = hitTest(vm.edit.texts, down.position, w, h)
        if (hit != null) vm.selectedLayer = hit
        val grabbed = hit != null
        var moved = false
        do {
            val ev = awaitPointerEvent()
            val sel = vm.selectedLayer
            val multi = ev.changes.count { it.pressed } >= 2
            val zoom = ev.calculateZoom()
            val pan = ev.calculatePan()
            val rot = ev.calculateRotation()
            if (sel != null && (grabbed || multi) && (pan != Offset.Zero || zoom != 1f || rot != 0f)) {
                moved = true
                vm.updateLayer(sel, true) { l ->
                    l.copy(
                        x = (l.x + pan.x / w).coerceIn(0f, 1f),
                        y = (l.y + pan.y / h).coerceIn(0f, 1f),
                        size = if (multi) (l.size * zoom).coerceIn(0.02f, 0.6f) else l.size,
                        rotation = if (multi) l.rotation + rot else l.rotation,
                    )
                }
                ev.changes.forEach { it.consume() }
            }
        } while (ev.changes.any { it.pressed })
        if (moved) vm.endLive() else if (!grabbed) vm.selectedLayer = null
    }
}

// ====================================================================== panels

@Composable
private fun AdjustPanel(vm: ImageEditorViewModel) {
    val a = vm.edit.adjust
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallButton("تحسين تلقائي", { vm.autoEnhance() }, icon = Icons.Default.AutoFixHigh)
            SmallButton("إعادة ضبط", { vm.commit { it.copy(adjust = Adjust(), fade = 0f) } })
        }
        LabeledSlider("السطوع", a.brightness, -0.5f..0.5f, { v -> vm.live { it.copy(adjust = it.adjust.copy(brightness = v)) } }, vm::endLive, { "%.0f".format(it * 200) })
        LabeledSlider("التباين", a.contrast, -1f..1f, { v -> vm.live { it.copy(adjust = it.adjust.copy(contrast = v)) } }, vm::endLive)
        LabeledSlider("التشبّع", a.saturation, -1f..1f, { v -> vm.live { it.copy(adjust = it.adjust.copy(saturation = v)) } }, vm::endLive)
        LabeledSlider("الدفء", a.warmth, -1f..1f, { v -> vm.live { it.copy(adjust = it.adjust.copy(warmth = v)) } }, vm::endLive)
        LabeledSlider("درجة اللون", a.hue, -180f..180f, { v -> vm.live { it.copy(adjust = it.adjust.copy(hue = v)) } }, vm::endLive, { "%.0f°".format(it) })
    }
}

@Composable
private fun LooksPanel(vm: ImageEditorViewModel) {
    Column(Modifier.fillMaxWidth()) {
        LazyRow(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(Looks.all) { look ->
                LookCard(look, vm.lookThumbs[look.id], vm.edit.lookId == look.id) {
                    vm.commit { it.copy(lookId = look.id, lookStrength = 1f) }
                }
            }
        }
        if (vm.edit.lookId != "original") {
            LabeledSlider(
                "الشدة", vm.edit.lookStrength, 0f..1f,
                { v -> vm.live { it.copy(lookStrength = v) } }, vm::endLive,
                modifier = Modifier.padding(horizontal = 12.dp)
            )
        }
    }
}

@Composable
private fun LookCard(look: Look, thumb: android.graphics.Bitmap?, selected: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick)) {
        Box(
            Modifier
                .size(74.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Surface2)
                .border(if (selected) 2.dp else 0.dp, if (selected) Accent else Color.Transparent, RoundedCornerShape(10.dp))
        ) {
            if (thumb != null) {
                Image(thumb.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
        }
        Text(look.name, fontSize = 11.sp, color = if (selected) Accent else TextDim, modifier = Modifier.padding(top = 4.dp), maxLines = 1)
    }
}

private val CropRatios = listOf(
    "الأصلي" to 0f, "1:1" to 1f, "4:5" to 0.8f, "3:4" to 0.75f, "9:16" to 0.5625f,
    "4:3" to 1.3333f, "3:2" to 1.5f, "16:9" to 1.7778f,
)

@Composable
private fun CropPanel(vm: ImageEditorViewModel) {
    val e = vm.edit
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(CropRatios) { (label, r) ->
                Chip(label, abs(e.cropAspect - r) < 0.001f, onClick = {
                    vm.commit { it.copy(cropAspect = r, cropZoom = 1f, cropCx = 0.5f, cropCy = 0.5f) }
                })
            }
        }
        LabeledSlider("التكبير", e.cropZoom, 1f..4f, { v -> vm.live { it.copy(cropZoom = v) } }, vm::endLive, { "%.1fx".format(it) })
        LabeledSlider("أفقي", e.cropCx, 0f..1f, { v -> vm.live { it.copy(cropCx = v) } }, vm::endLive)
        LabeledSlider("رأسي", e.cropCy, 0f..1f, { v -> vm.live { it.copy(cropCy = v) } }, vm::endLive)
        LabeledSlider("تسوية", e.straighten, -45f..45f, { v -> vm.live { it.copy(straighten = v) } }, vm::endLive, { "%.0f°".format(it) })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp)) {
            SmallButton("تدوير", { vm.commit { it.copy(rotation = (it.rotation + 90) % 360) } }, icon = Icons.Default.RotateRight)
            SmallButton("قلب أفقي", { vm.commit { it.copy(flipH = !it.flipH) } }, icon = Icons.Default.Flip)
            SmallButton("قلب رأسي", { vm.commit { it.copy(flipV = !it.flipV) } }, icon = Icons.Default.Flip)
        }
    }
}

@Composable
private fun TextPanel(vm: ImageEditorViewModel) {
    var showAdd by remember { mutableStateOf(false) }
    val sel = vm.edit.texts.firstOrNull { it.id == vm.selectedLayer }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallButton("نص جديد", { showAdd = true }, icon = Icons.Default.Add)
            if (sel != null) {
                SmallButton("نسخ", { vm.duplicateLayer(sel.id) }, icon = Icons.Default.ContentCopy)
                SmallButton("حذف", { vm.deleteLayer(sel.id) }, danger = true, icon = Icons.Default.Delete)
            }
        }
        if (sel == null) {
            Text(
                "اضغط على نص في الصورة لتعديله، أو أضف نص جديد.\nاسحب بإصبع للتحريك وبإصبعين للتكبير والتدوير.",
                color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp)
            )
        } else {
            LayerControls(vm, sel, allowTextEdit = sel.shape == 0)
        }
    }
    if (showAdd) {
        TextInputDialog(
            title = "أضف نص", hint = "اكتب هنا...", singleLine = false,
            onConfirm = { if (it.isNotBlank()) vm.addText(it); showAdd = false },
            onDismiss = { showAdd = false }
        )
    }
}

@Composable
private fun LayerControls(vm: ImageEditorViewModel, l: TextLayer, allowTextEdit: Boolean) {
    val id = l.id
    if (allowTextEdit) {
        OutlinedTextField(
            value = l.text,
            onValueChange = { nv -> vm.updateLayer(id, true) { it.copy(text = nv) } },
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp).onFocusChanged { if (!it.isFocused) vm.endLive() },
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 14.sp),
        )
    }
    SectionLabel("اللون")
    ColorRow(l.color, onPick = { c -> vm.updateLayer(id, false) { it.copy(color = c) } })
    if (l.shape == 0) {
        SectionLabel("الخط")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(TextRenderer.fontNames.indices.toList()) { i ->
                Chip(TextRenderer.fontNames[i], l.font == i, { vm.updateLayer(id, false) { it.copy(font = i) } })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp)) {
            Chip("عريض", l.bold, { vm.updateLayer(id, false) { it.copy(bold = !it.bold) } })
            Chip("مائل", l.italic, { vm.updateLayer(id, false) { it.copy(italic = !it.italic) } })
            Chip("ظل", l.shadow, { vm.updateLayer(id, false) { it.copy(shadow = !it.shadow) } })
            Chip("حدود", l.outline, { vm.updateLayer(id, false) { it.copy(outline = !it.outline) } })
            Chip("خلفية", l.bgColor != 0, {
                vm.updateLayer(id, false) { it.copy(bgColor = if (it.bgColor != 0) 0 else 0xAA000000.toInt()) }
            })
        }
        if (l.bgColor != 0) {
            SectionLabel("لون الخلفية")
            ColorRow(
                l.bgColor,
                onPick = { c -> vm.updateLayer(id, false) { it.copy(bgColor = (c and 0x00FFFFFF) or 0xCC000000.toInt()) } }
            )
        }
    } else if (l.shape != 9) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp)) {
            Chip("مفرّغ", l.outline, { vm.updateLayer(id, false) { it.copy(outline = !it.outline) } })
            Chip("ظل", l.shadow, { vm.updateLayer(id, false) { it.copy(shadow = !it.shadow) } })
        }
    }
    if (l.shape != 0) {
        LabeledSlider("العرض/الارتفاع", l.aspect, 0.2f..4f, { v -> vm.updateLayer(id, true) { it.copy(aspect = v) } }, vm::endLive, { "%.1f".format(it) })
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp)) {
        SmallButton("لقدّام", { vm.moveLayer(id, true) }, icon = Icons.Default.FlipToFront)
        SmallButton("لورا", { vm.moveLayer(id, false) }, icon = Icons.Default.FlipToBack)
    }
    LabeledSlider("الحجم", l.size, 0.02f..(if (l.shape == 9) 1.5f else 0.5f), { v -> vm.updateLayer(id, true) { it.copy(size = v) } }, vm::endLive, { "%.0f".format(it * 100) })
    LabeledSlider("الدوران", l.rotation, -180f..180f, { v -> vm.updateLayer(id, true) { it.copy(rotation = v) } }, vm::endLive, { "%.0f°".format(it) })
    LabeledSlider("الشفافية", l.opacity, 0.1f..1f, { v -> vm.updateLayer(id, true) { it.copy(opacity = v) } }, vm::endLive)
}

private val ShapeKinds = listOf(1 to "مستطيل", 2 to "مدوّر", 3 to "دائرة", 4 to "مثلث", 5 to "نجمة", 6 to "قلب", 7 to "خط", 8 to "سهم")

@Composable
private fun StickerPanel(vm: ImageEditorViewModel) {
    val sel = vm.edit.texts.firstOrNull { it.id == vm.selectedLayer }
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) vm.addImageLayer(uri) }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 6.dp)) {
            item {
                SmallButton("صورة / لوجو", {
                    picker.launch(androidx.activity.result.PickVisualMediaRequest(
                        androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly))
                }, icon = Icons.Default.AddPhotoAlternate)
            }
            items(ShapeKinds) { (k, label) -> Chip(label, false, { vm.addShape(k) }) }
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(44.dp),
            modifier = Modifier.fillMaxWidth().height(if (sel != null) 90.dp else 130.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            gridItems(Emojis) { e ->
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)).clickable { vm.addEmoji(e) },
                    contentAlignment = Alignment.Center
                ) { Text(e, fontSize = 26.sp, textAlign = TextAlign.Center) }
            }
        }
        if (sel != null) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp)) {
                SmallButton("نسخ", { vm.duplicateLayer(sel.id) }, icon = Icons.Default.ContentCopy)
                SmallButton("حذف", { vm.deleteLayer(sel.id) }, danger = true, icon = Icons.Default.Delete)
            }
            if (sel.shape != 0) LayerControls(vm, sel, allowTextEdit = false)
            else LabeledSlider("الحجم", sel.size, 0.04f..0.6f, { v -> vm.updateLayer(sel.id, true) { it.copy(size = v) } }, vm::endLive, { "%.0f".format(it * 100) })
        }
    }
}

@Composable
private fun DrawPanel(
    vm: ImageEditorViewModel,
    color: Int, size: Float, alpha: Float,
    onColor: (Int) -> Unit, onSize: (Float) -> Unit, onAlpha: (Float) -> Unit,
) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        Text("ارسم بإصبعك مباشرة على الصورة", color = TextDim, fontSize = 12.sp)
        ColorRow(color, onPick = onColor, modifier = Modifier.padding(vertical = 8.dp))
        LabeledSlider("الحجم", size, 0.003f..0.08f, onSize, display = { "%.0f".format(it * 1000) })
        LabeledSlider("الشفافية", alpha, 0.1f..1f, onAlpha)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp)) {
            SmallButton("تراجع عن خط", { if (vm.edit.strokes.isNotEmpty()) vm.undoStroke() }, icon = Icons.Default.Undo)
            SmallButton("مسح الرسم", { vm.clearStrokes() }, danger = true, icon = Icons.Default.Delete)
        }
    }
}

@Composable
private fun EffectsPanel(vm: ImageEditorViewModel) {
    val e = vm.edit
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        SectionLabel("الخلفية")
        if (vm.isBlank) {
            ColorRow(vm.backgroundColor, onPick = { c -> vm.setBackground(c) })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp)) {
                Chip("شفافة (PNG)", vm.backgroundColor == 0, { vm.setBackground(0) })
                if (vm.canRestoreBackground) SmallButton("استعادة الأصل", { vm.restoreBackground() })
            }
        } else {
            SmallButton("إزالة الخلفية وضبطها", { vm.removeBackground() }, icon = Icons.Default.AutoFixHigh)
            Text("بيفتح شاشة ضبط: وضع شخص ذكي، أو حسب لون الخلفية لأي جسم، مع فرشاة محو/استعادة وتحكم في الحواف.", color = TextDim, fontSize = 11.sp)
        }
        SectionLabel("تأثيرات")
        LabeledSlider("الحدّة", e.sharpen, 0f..1f, { v -> vm.live { it.copy(sharpen = v) } }, vm::endLive)
        LabeledSlider("بلور", e.blur, 0f..1f, { v -> vm.live { it.copy(blur = v) } }, vm::endLive)
        LabeledSlider("فينيت", e.vignette, 0f..1f, { v -> vm.live { it.copy(vignette = v) } }, vm::endLive)
        LabeledSlider("باهت", e.fade, 0f..1f, { v -> vm.live { it.copy(fade = v) } }, vm::endLive)
        LabeledSlider("حبيبات", e.grain, 0f..1f, { v -> vm.live { it.copy(grain = v) } }, vm::endLive)
        LabeledSlider("بكسلة", e.pixelate, 0f..1f, { v -> vm.live { it.copy(pixelate = v) } }, vm::endLive)
        LabeledSlider("زوايا مدوّرة", e.corner, 0f..0.5f, { v -> vm.live { it.copy(corner = v) } }, vm::endLive, { "%.0f".format(it / 0.5f * 100) })
        LabeledSlider("إطار", e.border, 0f..0.12f, { v -> vm.live { it.copy(border = v) } }, vm::endLive, { "%.0f".format(it / 0.12f * 100) })
        if (e.border > 0.001f) {
            ColorRow(e.borderColor, onPick = { c -> vm.commit { it.copy(borderColor = c) } }, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

// ====================================================================== export

@Composable
private fun ExportDialog(onDismiss: () -> Unit, onExport: (ExportFormat, Int, Int, Int, Boolean) -> Unit) {
    var wm by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf(0) }
    var fmt by remember { mutableStateOf(ExportFormat.JPG) }
    var quality by remember { mutableStateOf(92f) }
    var scale by remember { mutableStateOf(100) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface1,
        title = { Text("تصدير الصورة") },
        text = {
            Column {
                SectionLabel("الصيغة")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ExportFormat.values().forEach { f -> Chip(f.label, fmt == f, { fmt = f }) }
                }
                if (fmt != ExportFormat.PNG) {
                    LabeledSlider("الجودة", quality, 50f..100f, { quality = it }, display = { "%.0f%%".format(it) })
                }
                SectionLabel("الوجهة")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("حفظ في المعرض", mode == 0, { mode = 0 })
                    Chip("مشاركة", mode == 1, { mode = 1 })
                    Chip("رفع للسحابة", mode == 2, { mode = 2 })
                }
                SectionLabel("علامة الصانع")
                Chip("إضافة علامة VARQONX", wm, { wm = !wm })
                SectionLabel("الحجم")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(100 to "كامل", 75 to "75%", 50 to "50%", 25 to "25%").forEach { (v, label) ->
                        Chip(label, scale == v, { scale = v })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onExport(fmt, quality.toInt(), scale, mode, wm) }) { Text("تصدير", color = Accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = TextDim) } }
    )
}
