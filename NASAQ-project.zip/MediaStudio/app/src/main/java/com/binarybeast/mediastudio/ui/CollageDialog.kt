package com.binarybeast.mediastudio.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binarybeast.mediastudio.data.Collage
import com.binarybeast.mediastudio.data.CollageLayout

/** اختيار تخطيط الكولاج والنسبة والمسافات ولون الخلفية. */
@Composable
fun CollageDialog(
    count: Int,
    onCreate: (layout: CollageLayout, ratio: Float, gap: Float, bg: Int) -> Unit,
    onDismiss: () -> Unit,
) {
    val layouts = remember(count) { Collage.options(count) }
    var li by remember { mutableStateOf(0) }
    var ri by remember { mutableStateOf(0) }
    var gap by remember { mutableStateOf(0.02f) }
    var bg by remember { mutableStateOf(0xFFFFFFFF.toInt()) }
    val ratio = Collage.ratios[ri].second

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface1,
        title = { Text("كولاج $count صور") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                SectionLabel("التخطيط")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    itemsIndexed(layouts) { i, l ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Canvas(
                                Modifier
                                    .size(64.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Surface2)
                                    .border(2.dp, if (i == li) Accent else Surface2, RoundedCornerShape(8.dp))
                                    .clickable { li = i }
                                    .padding(4.dp)
                            ) {
                                val pad = 2f
                                for (c in l.cells) {
                                    drawRect(
                                        color = if (i == li) Accent else TextDim,
                                        topLeft = Offset(c.x * size.width + pad, c.y * size.height + pad),
                                        size = Size((c.w * size.width - 2 * pad).coerceAtLeast(1f), (c.h * size.height - 2 * pad).coerceAtLeast(1f))
                                    )
                                }
                            }
                            Text(l.label, fontSize = 10.sp, color = TextDim)
                        }
                    }
                }
                SectionLabel("النسبة")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Collage.ratios.forEachIndexed { i, (label, _) -> Chip(label, ri == i, { ri = i }) }
                }
                LabeledSlider("المسافات", gap, 0f..0.06f, { gap = it }, display = { "%.0f".format(it / 0.06f * 100) })
                SectionLabel("لون الخلفية")
                ColorRow(bg, onPick = { bg = it })
                Text("بعد الإنشاء تقدر تحرّك وتكبّر كل صورة، وتضيف نصوص وفلاتر.", color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp).fillMaxWidth())
            }
        },
        confirmButton = { TextButton(onClick = { onCreate(layouts[li], ratio, gap, bg) }) { Text("إنشاء", color = Accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = TextDim) } }
    )
}
