package com.binarybeast.mediastudio.image

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** أدوات ML Kit: استخراج النص (OCR لاتيني/أرقام) وتصنيف محتوى الصورة. */
object ScanTools {

    suspend fun ocr(bmp: Bitmap): String? = suspendCancellableCoroutine { cont ->
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        cont.invokeOnCancellation { runCatching { rec.close() } }
        rec.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { r -> runCatching { rec.close() }; if (cont.isActive) cont.resume(r.text) }
            .addOnFailureListener { runCatching { rec.close() }; if (cont.isActive) cont.resume(null) }
    }

    /** أهم العناوين اللي ML Kit اكتشفها في الصورة (إنجليزي). */
    suspend fun labels(bmp: Bitmap): List<String>? = suspendCancellableCoroutine { cont ->
        val lab = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
        cont.invokeOnCancellation { runCatching { lab.close() } }
        lab.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { r ->
                runCatching { lab.close() }
                if (cont.isActive) cont.resume(r.sortedByDescending { it.confidence }.map { it.text })
            }
            .addOnFailureListener { runCatching { lab.close() }; if (cont.isActive) cont.resume(null) }
    }

    /** يختار فلتر مناسب من محتوى الصورة. */
    fun suggestLook(labels: List<String>): String {
        val l = labels.map { it.lowercase() }
        fun has(vararg k: String) = l.any { t -> k.any { t.contains(it) } }
        return when {
            has("sunset", "sunrise", "sky", "cloud", "horizon") -> "golden"
            has("plant", "tree", "forest", "grass", "leaf", "garden", "nature") -> "forest"
            has("food", "dish", "cuisine", "meal", "fruit", "dessert", "coffee") -> "kodak"
            has("snow", "ice", "winter", "glacier") -> "ice"
            has("night", "neon", "city", "skyscraper", "street") -> "cyber"
            has("flower", "petal", "bouquet") -> "rose"
            has("person", "face", "smile", "selfie", "portrait", "skin") -> "pastel"
            else -> "hdr"
        }
    }
}
