package com.binarybeast.mediastudio.video

import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import com.binarybeast.mediastudio.data.VideoClip
import com.binarybeast.mediastudio.data.formatDuration
import com.binarybeast.mediastudio.ui.Accent
import com.binarybeast.mediastudio.ui.Surface1
import com.binarybeast.mediastudio.ui.Surface2
import com.binarybeast.mediastudio.ui.TextDim
import com.binarybeast.mediastudio.ui.isWideLayout
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

private val MarkerColor = Color(0xFFFFB020)
private val TextTrackColor = Color(0xFF7C5CFF)
private val AudioTrackColor = Color(0xFF1FB58F)
private val Playhead = Color(0xFFFF4D4D)

/**
 * تايم لاين بأسلوب Premiere Pro: مسطرة زمنية + مسارات V1 / A1 / T1 + مؤشر تشغيل،
 * مع تكبير/تصغير، Snap، علامات Markers، قص الحواف بالسحب، وإعادة ترتيب بالضغط المطوّل.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PremiereTimeline(
    vm: VideoEditorViewModel,
    onSelectTool: (Int) -> Unit,   // 0 مقطع، 1 صوت، 2 نص
    onAddMedia: () -> Unit,
    onPickAudio: () -> Unit,
    modifier: Modifier = Modifier,
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        val wide = isWideLayout()
        val data = vm.data
        val total = data.totalMs
        val density = LocalDensity.current
        var dpPerSec by remember { mutableStateOf(70f) }
        var snapOn by remember { mutableStateOf(true) }
        val scroll = rememberScrollState()

        val vH = if (wide) 58.dp else 48.dp
        val aH = if (wide) 30.dp else 26.dp
        val rulerH = 24.dp
        val labelW = if (wide) 64.dp else 52.dp
        val laneH = if (wide) 26.dp else 22.dp

        // مسارات النصوص (lanes) عشان الطبقات المتداخلة ما تتغطاش
        val lanes = remember(data.texts, total) { assignLanes(vm) }
        val laneCount = (lanes.values.maxOrNull() ?: 0) + 1
        val tH = laneH * laneCount.coerceAtMost(4) + 4.dp

        fun msToDp(ms: Long): Dp = (ms / 1000f * dpPerSec).dp
        fun dpToMs(dp: Float): Long = (dp / dpPerSec * 1000f).toLong()
        fun pxToMs(px: Float): Long = dpToMs(px / density.density)

        fun snapPoints(): List<Long> {
            val pts = ArrayList<Long>()
            pts.add(0L)
            var acc = 0L
            data.clips.forEach { acc += it.effectiveMs; pts.add(acc) }
            pts.addAll(data.markers)
            data.texts.forEach { pts.add(it.startMs); if (it.endMs >= 0) pts.add(it.endMs) }
            return pts
        }
        fun snap(ms: Long): Long {
            if (!snapOn) return ms
            val th = dpToMs(9f)
            val near = snapPoints().minByOrNull { abs(it - ms) } ?: return ms
            return if (abs(near - ms) <= th) near else ms
        }

        Column(modifier.fillMaxWidth().background(Surface1)) {
            // ------------------------------------------------ شريط الأدوات
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TlBtn(Icons.Default.ContentCut, "قسّم") { vm.splitAtPlayhead() }
                TlBtn(Icons.Default.ContentCopy, "نسخ") { vm.duplicateSelected() }
                TlBtn(Icons.Default.Delete, "حذف") { vm.deleteSelected() }
                TlBtn(Icons.Default.Bookmark, "علامة", MarkerColor) { vm.toggleMarker() }
                TlBtn(Icons.Default.Bookmark, "◀ علامة", Color.White) { vm.seekMarker(-1) }
                TlBtn(Icons.Default.Bookmark, "علامة ▶", Color.White) { vm.seekMarker(1) }
                TlBtn(Icons.Default.Link, if (snapOn) "Snap ✓" else "Snap", if (snapOn) Accent else TextDim) { snapOn = !snapOn }
                TlBtn(Icons.Default.ZoomOut, "تصغير") { dpPerSec = (dpPerSec / 1.5f).coerceAtLeast(6f) }
                TlBtn(Icons.Default.ZoomIn, "تكبير") { dpPerSec = (dpPerSec * 1.5f).coerceAtMost(600f) }
                Text(
                    "${formatDuration(vm.positionMs)} / ${formatDuration(total)}",
                    fontSize = 11.sp, color = TextDim, modifier = Modifier.padding(horizontal = 6.dp)
                )
            }

            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val viewportW = maxWidth - labelW
                val contentW = msToDp(total) + viewportW * 0.5f + 70.dp

                // ملاءمة الشاشة
                fun fit() { if (total > 0) dpPerSec = ((viewportW.value - 90f) / (total / 1000f)).coerceIn(6f, 600f) }

                // متابعة المؤشر أثناء التشغيل
                LaunchedEffect(vm.positionMs, vm.isPlaying, dpPerSec) {
                    if (vm.isPlaying) {
                        val x = with(density) { msToDp(vm.positionMs).toPx() }
                        val vw = with(density) { viewportW.toPx() }
                        if (x < scroll.value || x > scroll.value + vw * 0.85f) scroll.scrollTo(max(0f, x - vw * 0.3f).toInt())
                    }
                }

                Row(Modifier.fillMaxWidth()) {
                    // ---------------- عمود العناوين (ثابت)
                    Column(Modifier.width(labelW).background(Surface1)) {
                        Box(Modifier.height(rulerH).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Text("fit", fontSize = 10.sp, color = Accent, modifier = Modifier.clickable { fit() }.padding(4.dp))
                        }
                        val muted = vm.selectedClip?.muted == true
                        TrackHead("V1", if (muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp, vH, if (muted) "مكتوم" else "كتم") {
                            vm.updateSelected { it.copy(muted = !it.muted) }
                        }
                        TrackHead("A1", Icons.Default.MusicNote, aH, "موسيقى") { onPickAudio() }
                        TrackHead("T1", Icons.Default.TextFields, tH.coerceAtLeast(aH), "نص") { onSelectTool(2) }
                    }

                    // ---------------- المحتوى القابل للتمرير
                    Box(
                        Modifier
                            .weight(1f)
                            .horizontalScroll(scroll)
                            .pointerInput(Unit) {
                                // قرص بإصبعين للتكبير والتصغير
                                awaitEachGesture {
                                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                                    do {
                                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                                        if (ev.changes.size >= 2) {
                                            val z = ev.calculateZoom()
                                            if (z != 1f) {
                                                dpPerSec = (dpPerSec * z).coerceIn(6f, 600f)
                                                ev.changes.forEach { it.consume() }
                                            }
                                        }
                                    } while (ev.changes.any { it.pressed })
                                }
                            }
                    ) {
                        Box(Modifier.width(contentW)) {
                            Column {
                                // ------------ المسطرة
                                Ruler(
                                    Modifier.height(rulerH).width(contentW)
                                        .pointerInput(dpPerSec, snapOn, data) {
                                            detectTapGestures { o -> vm.scrubTo(snap(pxToMs(o.x))); vm.endScrub() }
                                        }
                                        .pointerInput(dpPerSec, snapOn, data) {
                                            detectDragGestures(
                                                onDragStart = { o -> vm.scrubTo(snap(pxToMs(o.x))) },
                                                onDrag = { c, _ -> c.consume(); vm.scrubTo(snap(pxToMs(c.position.x))) },
                                                onDragEnd = { vm.endScrub() }, onDragCancel = { vm.endScrub() }
                                            )
                                        },
                                    dpPerSec = dpPerSec, totalMs = total, markers = data.markers
                                )

                                // ------------ V1
                                Row(
                                    Modifier.height(vH).width(contentW)
                                        .pointerInput(dpPerSec, snapOn) {
                                            detectTapGestures { o -> vm.scrubTo(snap(pxToMs(o.x))); vm.endScrub() }
                                        },
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    data.clips.forEachIndexed { i, c ->
                                        ClipBlock(vm, c, i, vH, dpPerSec, pxToMs = { pxToMs(it) }) { onSelectTool(0) }
                                    }
                                    Box(
                                        Modifier.padding(start = 6.dp).size(vH - 8.dp).clip(RoundedCornerShape(6.dp))
                                            .background(Color.White).clickable { onAddMedia() },
                                        contentAlignment = Alignment.Center
                                    ) { Icon(Icons.Default.Add, "إضافة", tint = Color.Black) }
                                }

                                // ------------ A1
                                Box(
                                    Modifier.height(aH).width(contentW).padding(vertical = 2.dp)
                                        .pointerInput(dpPerSec) { detectTapGestures { o -> vm.scrubTo(pxToMs(o.x)); vm.endScrub() } }
                                ) {
                                    if (data.musicUri != null) {
                                        val w = msToDp(min(total, max(data.musicDurationMs, 1L)))
                                        Box(
                                            Modifier.width(w).fillMaxHeight().clip(RoundedCornerShape(5.dp))
                                                .background(AudioTrackColor.copy(alpha = 0.55f))
                                                .border(1.dp, AudioTrackColor, RoundedCornerShape(5.dp))
                                                .clickable { onSelectTool(1) },
                                            contentAlignment = Alignment.CenterStart
                                        ) {
                                            Text("♪ " + data.musicName, fontSize = 10.sp, color = Color.White, maxLines = 1,
                                                modifier = Modifier.padding(horizontal = 6.dp))
                                        }
                                    } else {
                                        Row(
                                            Modifier.fillMaxSize().clip(RoundedCornerShape(5.dp)).background(Surface2).clickable { onPickAudio() }
                                                .padding(horizontal = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) { Text("+ إضافة صوت", fontSize = 10.sp, color = TextDim) }
                                    }
                                }

                                // ------------ T1 (عدة lanes)
                                Box(Modifier.height(tH.coerceAtLeast(aH)).width(contentW).padding(vertical = 2.dp)
                                    .pointerInput(dpPerSec) { detectTapGestures { o -> vm.scrubTo(pxToMs(o.x)); vm.endScrub() } }) {
                                    if (data.texts.isEmpty()) {
                                        Row(
                                            Modifier.fillMaxSize().clip(RoundedCornerShape(5.dp)).background(Surface2).clickable { onSelectTool(2) }
                                                .padding(horizontal = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) { Text("+ إضافة نص", fontSize = 10.sp, color = TextDim) }
                                    }
                                    data.texts.forEach { t ->
                                        val lane = (lanes[t.id] ?: 0).coerceAtMost(3)
                                        TextBlock(vm, t, total, lane, laneH, dpPerSec, { pxToMs(it) }, snap = { snap(it) }) { onSelectTool(2) }
                                    }
                                }
                            }

                            // ------------ مؤشر التشغيل
                            val phX = msToDp(vm.positionMs)
                            Box(Modifier.offset(x = phX - 1.dp).width(2.dp).fillMaxHeight().background(Playhead))
                            Box(
                                Modifier.offset(x = phX - 6.dp).size(12.dp, 10.dp)
                                    .clip(RoundedCornerShape(bottomStart = 6.dp, bottomEnd = 6.dp)).background(Playhead)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ أجزاء

@Composable
private fun TlBtn(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, tint: Color = Color.White, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(8.dp)).background(Surface2).clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(16.dp))
        Text(label, fontSize = 10.sp, color = tint, maxLines = 1)
    }
}

@Composable
private fun TrackHead(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, h: Dp, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.height(h).fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(label, fontSize = 10.sp, color = Accent)
        Icon(icon, sub, tint = TextDim, modifier = Modifier.size(15.dp))
    }
}

@Composable
private fun Ruler(modifier: Modifier, dpPerSec: Float, totalMs: Long, markers: List<Long>) {
    val steps = floatArrayOf(0.5f, 1f, 2f, 5f, 10f, 15f, 30f, 60f, 120f, 300f)
    val step = steps.firstOrNull { it * dpPerSec >= 56f } ?: 300f
    Canvas(modifier.background(Color(0xFF15151C))) {
        val d = density
        val paint = android.graphics.Paint().apply {
            color = 0xFFB0B0C0.toInt(); textSize = 10f * d; isAntiAlias = true
        }
        val end = (totalMs / 1000f) + (size.width / d / dpPerSec) + 1f
        var t = 0f
        while (t <= end) {
            val x = t * dpPerSec * d
            drawLine(Color(0xFF8A8A9A), Offset(x, size.height * 0.55f), Offset(x, size.height), 1.5f)
            drawIntoCanvas { it.nativeCanvas.drawText(formatDuration((t * 1000).toLong()), x + 3f * d, size.height * 0.5f, paint) }
            // ticks فرعية
            val sub = step / 5f
            for (k in 1..4) {
                val sx = (t + sub * k) * dpPerSec * d
                drawLine(Color(0xFF55555F), Offset(sx, size.height * 0.78f), Offset(sx, size.height), 1f)
            }
            t += step
        }
        // نهاية المشروع
        val ex = totalMs / 1000f * dpPerSec * d
        drawLine(Color(0x66FFFFFF), Offset(ex, 0f), Offset(ex, size.height), 1f)
        markers.forEach { m ->
            val mx = m / 1000f * dpPerSec * d
            drawRect(MarkerColor, Offset(mx - 4f * d, 0f), androidx.compose.ui.geometry.Size(8f * d, 7f * d))
            drawLine(MarkerColor, Offset(mx, 0f), Offset(mx, size.height), 1.5f)
        }
    }
}

@Composable
private fun ClipBlock(
    vm: VideoEditorViewModel, c: VideoClip, index: Int, h: Dp, dpPerSec: Float,
    pxToMs: (Float) -> Long, onSelected: () -> Unit
) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val selected = vm.selectedIndex == index && vm.selectedText == null
    val w = (c.effectiveMs / 1000f * dpPerSec).dp.coerceAtLeast(14.dp)
    val shape = RoundedCornerShape(5.dp)
    var acc by remember { mutableStateOf(0f) }

    Box(
        Modifier
            .padding(end = 1.dp)
            .width(w).height(h - 4.dp)
            .clip(shape)
            .background(Surface2)
            .border(if (selected) 2.dp else 0.dp, if (selected) Accent else Color.Transparent, shape)
            .pointerInput(index) {
                detectTapGestures { vm.selectClip(index); onSelected() }
            }
            .pointerInput(index) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { vm.selectClip(index); acc = 0f },
                    onDrag = { ch, d ->
                        ch.consume()
                        acc += d.x
                        val thr = with(density) { w.toPx() } * 0.55f
                        if (acc > thr) { vm.moveSelected(1); acc = 0f }
                        else if (acc < -thr) { vm.moveSelected(-1); acc = 0f }
                    },
                    onDragEnd = { acc = 0f }, onDragCancel = { acc = 0f }
                )
            }
    ) {
        // شرائح مصغّرة
        val tileDp = (h.value * 1.7f)
        val n = ceil(w.value / tileDp).toInt().coerceIn(1, 18)
        Row(Modifier.fillMaxSize()) {
            for (k in 0 until n) {
                val frame = c.startMs + ((c.endMs - c.startMs) * k / n)
                AsyncImage(
                    model = ImageRequest.Builder(ctx).data(Uri.parse(c.uri)).videoFrameMillis(frame).build(),
                    contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
        }
        // معلومات
        Text(
            (if (c.speed != 1f) "${c.speed}x  " else "") + (if (c.muted) "🔇 " else "") + formatDuration(c.effectiveMs),
            fontSize = 9.sp, color = Color.White,
            modifier = Modifier.align(Alignment.BottomStart).padding(3.dp)
                .background(Color(0x99000000), RoundedCornerShape(3.dp)).padding(horizontal = 3.dp)
        )
        if (selected) {
            // مقابض القص
            TrimHandle(Modifier.align(Alignment.CenterStart), { vm.endLive() }) { dxPx ->
                val ms = (pxToMs(dxPx) * c.speed).toLong()
                vm.updateClip(index, live = true) {
                    val ns = (it.startMs + ms).coerceIn(0L, it.endMs - 300L)
                    if (it.isImage) it else it.copy(startMs = ns)
                }
            }
            TrimHandle(Modifier.align(Alignment.CenterEnd), { vm.endLive() }) { dxPx ->
                val ms = (pxToMs(dxPx) * c.speed).toLong()
                vm.updateClip(index, live = true) {
                    val maxEnd = if (it.isImage) it.srcDurationMs else it.srcDurationMs
                    val ne = (it.endMs + ms).coerceIn(it.startMs + 300L, maxOf(maxEnd, it.startMs + 300L))
                    it.copy(endMs = ne)
                }
            }
        }
    }
}

@Composable
private fun TrimHandle(modifier: Modifier, onEnd: () -> Unit, onDrag: (Float) -> Unit) {
    Box(
        modifier.width(14.dp).fillMaxHeight()
            .background(Accent.copy(alpha = 0.9f))
            .pointerInput(Unit) {
                // نستخدم onDragEnd لإنهاء الإيماءة؛ vm.endLive بيتنادى من الخارج عبر LiveEnd
                detectDragGestures(
                    onDrag = { ch, d -> ch.consume(); onDrag(d.x) },
                    onDragEnd = onEnd, onDragCancel = onEnd
                )
            },
        contentAlignment = Alignment.Center
    ) { Box(Modifier.width(2.dp).height(14.dp).background(Color.Black.copy(alpha = 0.6f))) }
}

@Composable
private fun TextBlock(
    vm: VideoEditorViewModel, t: com.binarybeast.mediastudio.data.TextLayer, total: Long, lane: Int, laneH: Dp,
    dpPerSec: Float, pxToMs: (Float) -> Long, snap: (Long) -> Long, onSelected: () -> Unit
) {
    val density = LocalDensity.current
    val end = if (t.endMs < 0) total else min(t.endMs, total)
    val start = t.startMs.coerceIn(0L, total)
    val w = ((end - start).coerceAtLeast(200L) / 1000f * dpPerSec).dp
    val x = (start / 1000f * dpPerSec).dp
    val selected = vm.selectedText == t.id
    val shape = RoundedCornerShape(5.dp)
    Box(
        Modifier.offset(x = x, y = laneH * lane).width(w).height(laneH - 2.dp).clip(shape)
            .background(TextTrackColor.copy(alpha = if (selected) 0.95f else 0.6f))
            .border(if (selected) 2.dp else 1.dp, if (selected) Color.White else TextTrackColor, shape)
            .pointerInput(t.id) { detectTapGestures { vm.selectedText = t.id; onSelected() } }
            .pointerInput(t.id) {
                // سحب الجسم = تحريك زمن ظهور النص
                detectDragGestures(
                    onDragStart = { vm.selectedText = t.id },
                    onDrag = { ch, d ->
                        ch.consume()
                        val dms = pxToMs(d.x)
                        vm.updateText(t.id, live = true) { l ->
                            val e = if (l.endMs < 0) total else l.endMs
                            val len = e - l.startMs
                            val ns = (l.startMs + dms).coerceIn(0L, max(0L, total - len))
                            l.copy(startMs = ns, endMs = ns + len)
                        }
                    },
                    onDragEnd = { vm.endLive() }, onDragCancel = { vm.endLive() }
                )
            },
        contentAlignment = Alignment.CenterStart
    ) {
        Text(
            if (t.shape == 9) "🖼" else t.text.replace("\n", " ").ifEmpty { "نص" },
            fontSize = 10.sp, color = Color.White, maxLines = 1, modifier = Modifier.padding(horizontal = 8.dp)
        )
        if (selected) {
            TrimHandle(Modifier.align(Alignment.CenterEnd).width(10.dp), { vm.endLive() }) { dxPx ->
                val dms = pxToMs(dxPx)
                vm.updateText(t.id, live = true) { l ->
                    val e = if (l.endMs < 0) total else l.endMs
                    l.copy(endMs = (e + dms).coerceIn(l.startMs + 200L, total))
                }
            }
            TrimHandle(Modifier.align(Alignment.CenterStart).width(10.dp), { vm.endLive() }) { dxPx ->
                val dms = pxToMs(dxPx)
                vm.updateText(t.id, live = true) { l ->
                    val e = if (l.endMs < 0) total else l.endMs
                    l.copy(startMs = (l.startMs + dms).coerceIn(0L, e - 200L))
                }
            }
        }
    }
}

private fun assignLanes(vm: VideoEditorViewModel): Map<Long, Int> {
    val total = vm.data.totalMs
    val ends = ArrayList<Long>()
    val out = HashMap<Long, Int>()
    vm.data.texts.sortedBy { it.startMs }.forEach { t ->
        val e = if (t.endMs < 0) total else t.endMs
        var lane = ends.indexOfFirst { it <= t.startMs }
        if (lane < 0) { ends.add(e); lane = ends.lastIndex } else ends[lane] = e
        out[t.id] = lane
    }
    return out
}
