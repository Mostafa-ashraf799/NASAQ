package com.binarybeast.mediastudio.data

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.util.UUID

/** تخزين المشاريع داخل filesDir/projects/<id>/ (project.json + thumb.jpg + media/). */
class ProjectRepository(private val ctx: Context) {

    private val root = File(ctx.filesDir, "projects").apply { mkdirs() }

    fun newId(): String = UUID.randomUUID().toString()

    fun dir(id: String): File = File(root, id).apply { mkdirs() }

    fun thumbFile(id: String): File = File(dir(id), "thumb.jpg")

    fun list(): List<Project> {
        val dirs = root.listFiles() ?: return emptyList()
        return dirs.mapNotNull { d ->
            val f = File(d, "project.json")
            if (!f.exists()) null else runCatching { ProjectJson.decode(f.readText()) }.getOrNull()
        }.sortedByDescending { it.updatedAt }
    }

    fun load(id: String): Project? {
        val f = File(dir(id), "project.json")
        if (!f.exists()) return null
        return runCatching { ProjectJson.decode(f.readText()) }.getOrNull()
    }

    @Synchronized
    fun save(p: Project) {
        val d = dir(p.id)
        val tmp = File(d, "project.json.tmp")
        tmp.writeText(ProjectJson.encode(p))
        val dst = File(d, "project.json")
        if (!tmp.renameTo(dst)) {
            dst.writeText(tmp.readText())
            tmp.delete()
        }
    }

    fun delete(id: String) {
        File(root, id).deleteRecursively()
    }

    fun rename(id: String, name: String) {
        load(id)?.let { save(it.copy(name = name, updatedAt = System.currentTimeMillis())) }
    }

    fun setPinned(id: String, pinned: Boolean) {
        load(id)?.let { save(it.copy(pinned = pinned)) }
    }

    fun duplicate(id: String): Project? {
        val src = load(id) ?: return null
        val newId = newId()
        File(root, id).copyRecursively(File(root, newId), overwrite = true)
        // المسارات داخل الـ JSON بتشاور على فولدر المشروع القديم، نعدّلها للجديد.
        val json = File(root, "$newId/project.json").readText().replace("/projects/$id/", "/projects/$newId/")
        val copy = ProjectJson.decode(json).copy(
            id = newId, name = src.name + " (نسخة)",
            createdAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis()
        )
        save(copy)
        return copy
    }

    fun saveThumb(id: String, bmp: Bitmap) {
        runCatching {
            val maxSide = 480
            val scale = maxSide.toFloat() / maxOf(bmp.width, bmp.height)
            val t = if (scale < 1f)
                Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt().coerceAtLeast(1), (bmp.height * scale).toInt().coerceAtLeast(1), true)
            else bmp
            thumbFile(id).outputStream().use { t.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        }
    }

    /**
     * ميديا جاية من منتقي النظام (Photo Picker) أو من ملفات خارجية: نسخها لمجلد المشروع
     * عشان يفضل الوصول ليها بعد إعادة تشغيل التطبيق. ميديا المعرض العادية بتفضل زي ما هي.
     */
    fun importIfNeeded(projectId: String, uri: Uri, forceCopy: Boolean = false): Uri {
        val s = uri.toString()
        val needCopy = forceCopy || s.contains("picker") || (uri.scheme != "content" && uri.scheme != "file") ||
            (uri.scheme == "content" && uri.authority != "media")
        if (!needCopy || uri.scheme == "file") return uri
        val mediaDir = File(dir(projectId), "media").apply { mkdirs() }
        val ext = guessExt(uri)
        val out = File(mediaDir, "m_${System.currentTimeMillis()}_${(0..9999).random()}$ext")
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            out.outputStream().use { input.copyTo(it) }
        } ?: return uri
        return Uri.fromFile(out)
    }

    fun displayName(uri: Uri): String {
        if (uri.scheme == "file") return File(uri.path ?: "").name
        return runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull() ?: "ملف"
    }

    private fun guessExt(uri: Uri): String {
        val mime = ctx.contentResolver.getType(uri) ?: return ".bin"
        return when {
            mime.contains("jpeg") -> ".jpg"
            mime.contains("png") -> ".png"
            mime.contains("webp") -> ".webp"
            mime.contains("heic") || mime.contains("heif") -> ".heic"
            mime.contains("mp4") -> ".mp4"
            mime.contains("quicktime") -> ".mov"
            mime.contains("webm") -> ".webm"
            mime.contains("mpeg") && mime.startsWith("audio") -> ".mp3"
            mime.contains("mp4") || mime.contains("m4a") || mime.contains("aac") -> ".m4a"
            mime.contains("wav") -> ".wav"
            mime.contains("ogg") -> ".ogg"
            mime.startsWith("video/") -> ".mp4"
            mime.startsWith("image/") -> ".jpg"
            else -> ".bin"
        }
    }
}
