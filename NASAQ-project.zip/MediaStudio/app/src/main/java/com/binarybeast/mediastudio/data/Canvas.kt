package com.binarybeast.mediastudio.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.binarybeast.mediastudio.Graph
import com.binarybeast.mediastudio.image.BitmapLoader
import com.binarybeast.mediastudio.image.ImageCache
import com.binarybeast.mediastudio.image.ImageProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.max

/** إدارة مستندات الكانفس: صفحات = مشاريع صور تابعة (parentId). */
object CanvasStore {

    val sizes = listOf(
        Triple("1:1 • 1080×1080", 1080, 1080),
        Triple("ستوري • 1080×1920", 1080, 1920),
        Triple("عرض تقديمي • 1920×1080", 1920, 1080),
        Triple("بوست 4:5 • 1080×1350", 1080, 1350),
        Triple("A4 طولي • 2480×3508", 2480, 3508),
        Triple("A4 عرضي • 3508×2480", 3508, 2480),
        Triple("غلاف يوتيوب • 1280×720", 1280, 720),
        Triple("غلاف فيسبوك • 1640×924", 1640, 924),
    )

    val templates = listOf("فاضي", "عنوان", "اقتباس", "دعوة")

    private fun templateLayers(t: Int): List<TextLayer> = when (t) {
        1 -> listOf(
            TextLayer(id = ProjectFactory.nextId(), text = "العنوان هنا", y = 0.42f, size = 0.09f, color = 0xFF111111.toInt(), shadow = false),
            TextLayer(id = ProjectFactory.nextId(), text = "عنوان فرعي أو وصف قصير", y = 0.55f, size = 0.04f, color = 0xFF555555.toInt(), bold = false, shadow = false),
        )
        2 -> listOf(
            TextLayer(id = ProjectFactory.nextId(), text = "\"اكتب اقتباسك هنا\"", y = 0.45f, size = 0.06f, color = 0xFF222222.toInt(), italic = true, shadow = false),
            TextLayer(id = ProjectFactory.nextId(), text = "— الاسم", y = 0.62f, size = 0.035f, color = 0xFF777777.toInt(), bold = false, shadow = false),
        )
        3 -> listOf(
            TextLayer(id = ProjectFactory.nextId(), text = "دعوة", y = 0.28f, size = 0.07f, color = 0xFF5B3DF5.toInt(), shadow = false),
            TextLayer(id = ProjectFactory.nextId(), text = "يسعدنا حضورك", y = 0.42f, size = 0.05f, color = 0xFF222222.toInt(), shadow = false),
            TextLayer(id = ProjectFactory.nextId(), text = "التاريخ • المكان • الوقت", y = 0.56f, size = 0.032f, color = 0xFF666666.toInt(), bold = false, shadow = false),
        )
        else -> emptyList()
    }

    private fun newPage(parentId: String, name: String, w: Int, h: Int, bg: Int, layers: List<TextLayer>): Project {
        val repo = Graph.repo
        val id = repo.newId()
        val now = System.currentTimeMillis()
        val p = Project(
            id = id, name = name, type = ProjectType.IMAGE, createdAt = now, updatedAt = now,
            image = ImageData(sourceUri = null, blankW = w, blankH = h, blankColor = bg, edit = ImageEdit(texts = layers)),
            parentId = parentId
        )
        repo.save(p)
        runCatching {
            val k = 240f / max(w, h)
            val t = Bitmap.createBitmap((w * k).toInt().coerceAtLeast(1), (h * k).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            t.eraseColor(bg)
            repo.saveThumb(id, t)
        }
        return p
    }

    suspend fun create(name: String, w: Int, h: Int, bg: Int, template: Int): Project = withContext(Dispatchers.IO) {
        val repo = Graph.repo
        val id = repo.newId()
        val page = newPage(id, "صفحة 1", w, h, bg, templateLayers(template))
        val now = System.currentTimeMillis()
        val p = Project(
            id = id, name = name.ifBlank { ProjectFactory.defaultName("كانفس") }, type = ProjectType.CANVAS,
            createdAt = now, updatedAt = now, canvas = CanvasData(listOf(page.id), w, h, bg)
        )
        repo.save(p)
        repo.thumbFile(page.id).takeIf { it.exists() }?.copyTo(repo.thumbFile(id), overwrite = true)
        p
    }

    private fun touch(p: Project, c: CanvasData): Project {
        val np = p.copy(canvas = c, updatedAt = System.currentTimeMillis())
        Graph.repo.save(np)
        return np
    }

    fun pages(canvasId: String): List<Project> {
        val c = Graph.repo.load(canvasId)?.canvas ?: return emptyList()
        return c.pages.mapNotNull { Graph.repo.load(it) }
    }

    /** يضيف صفحة فاضية (أو نسخة من صفحة) بعد الفهرس. */
    fun addPage(canvasId: String, afterIndex: Int, duplicateOf: String? = null): Project? {
        val repo = Graph.repo
        val p = repo.load(canvasId) ?: return null
        val c = p.canvas ?: return null
        val page = if (duplicateOf != null) repo.duplicate(duplicateOf)?.copy(parentId = canvasId)?.also { repo.save(it) }
        else newPage(canvasId, "صفحة ${c.pages.size + 1}", c.w, c.h, c.bg, emptyList())
        page ?: return null
        val list = c.pages.toMutableList()
        list.add((afterIndex + 1).coerceIn(0, list.size), page.id)
        return touch(p, c.copy(pages = list))
    }

    fun deletePage(canvasId: String, pageId: String): Project? {
        val repo = Graph.repo
        val p = repo.load(canvasId) ?: return null
        val c = p.canvas ?: return null
        if (c.pages.size <= 1) return p
        repo.delete(pageId)
        return touch(p, c.copy(pages = c.pages.filter { it != pageId }))
    }

    fun movePage(canvasId: String, from: Int, to: Int): Project? {
        val p = Graph.repo.load(canvasId) ?: return null
        val c = p.canvas ?: return null
        if (from !in c.pages.indices || to !in c.pages.indices) return p
        val l = c.pages.toMutableList()
        l.add(to, l.removeAt(from))
        return touch(p, c.copy(pages = l))
    }

    /** يغيّر مقاس/خلفية كل الصفحات. */
    fun restyle(canvasId: String, w: Int?, h: Int?, bg: Int?): Project? {
        val repo = Graph.repo
        val p = repo.load(canvasId) ?: return null
        val c = p.canvas ?: return null
        val nc = c.copy(w = w ?: c.w, h = h ?: c.h, bg = bg ?: c.bg)
        c.pages.forEach { id ->
            repo.load(id)?.let { pg ->
                val im = pg.image ?: return@let
                repo.save(pg.copy(image = im.copy(blankW = nc.w, blankH = nc.h, blankColor = nc.bg), updatedAt = System.currentTimeMillis()))
                if (im.sourceUri == null) runCatching {
                    // مصغّر الصفحة هيتحدّث لما تتفتح، بس نمسح القديم عشان ما يبانش بمقاس غلط
                    repo.thumbFile(id).delete()
                }
            }
        }
        return touch(p, nc)
    }
}

/** تصدير الكانفس: صور، PDF، Word، فيديو متتابع. */
object CanvasExport {

    enum class Fmt(val label: String) { PNG("صور PNG"), JPG("صور JPG"), PDF("ملف PDF"), DOCX("ملف Word"), VIDEO("فيديو متتابع") }

    class Result(val message: String, val shareUri: Uri? = null, val mime: String = "", val video: Project? = null)

    /** يرسم صفحة كاملة بجودتها (مع العلامة المائية لو مطلوبة). */
    suspend fun renderPage(ctx: Context, page: Project, watermark: Boolean, flattenWhite: Boolean): Bitmap? = withContext(Dispatchers.Default) {
        val d = page.image ?: return@withContext null
        val full = if (d.sourceUri == null) BitmapLoader.blank(d.blankW, d.blankH, d.blankColor)
        else BitmapLoader.load(ctx, Uri.parse(d.retouchUri ?: d.sourceUri), 4096) ?: return@withContext null
        var e = d.edit
        if (watermark) e = e.copy(texts = e.texts + Brand.watermarkLayers(ctx, full.width.toFloat() / full.height))
        ImageCache.preload(ctx, e.texts)
        var out = ImageProcessor.renderFull(full, e)
        if (flattenWhite) {
            val flat = Bitmap.createBitmap(out.width, out.height, Bitmap.Config.ARGB_8888)
            val c = Canvas(flat); c.drawColor(android.graphics.Color.WHITE); c.drawBitmap(out, 0f, 0f, null)
            out = flat
        }
        out
    }

    private fun saveToDownloads(ctx: Context, file: File, name: String, mime: String): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return runCatching {
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/NASAQ")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val cr = ctx.contentResolver
            val uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return false
            cr.openOutputStream(uri)?.use { os -> file.inputStream().use { it.copyTo(os) } }
            v.clear(); v.put(MediaStore.MediaColumns.IS_PENDING, 0)
            cr.update(uri, v, null, null)
            true
        }.getOrDefault(false)
    }

    private fun writePdf(doc: PdfDocument, b: Bitmap, index: Int) {
        val k = 842f / max(b.width, b.height)
        val pw = (b.width * k).toInt().coerceAtLeast(1); val ph = (b.height * k).toInt().coerceAtLeast(1)
        val page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, index).create())
        page.canvas.drawBitmap(b, null, RectF(0f, 0f, pw.toFloat(), ph.toFloat()), Paint(Paint.FILTER_BITMAP_FLAG))
        doc.finishPage(page)
    }

    private fun docxXml(n: Int, aspect: Float): Triple<String, String, String> {
        val long = 16838
        val pgW = if (aspect >= 1f) long else (long * aspect).toInt()
        val pgH = if (aspect >= 1f) (long / aspect).toInt() else long
        val cx = (pgW * 635L * 0.995).toLong(); val cy = (pgH * 635L * 0.995).toLong()
        val body = StringBuilder()
        val rels = StringBuilder("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
        for (i in 1..n) {
            rels.append("""<Relationship Id="rId$i" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/page$i.jpeg"/>""")
            body.append("""<w:p><w:pPr>${if (i > 1) "<w:pageBreakBefore/>" else ""}<w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="$cx" cy="$cy"/><wp:docPr id="$i" name="Page $i"/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="0" name="page$i.jpeg"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="rId$i"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="$cx" cy="$cy"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>""")
        }
        rels.append("</Relationships>")
        val doc = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><w:body>$body<w:sectPr><w:pgSz w:w="$pgW" w:h="$pgH"/><w:pgMar w:top="0" w:right="0" w:bottom="0" w:left="0" w:header="0" w:footer="0" w:gutter="0"/></w:sectPr></w:body></w:document>"""
        return Triple(doc, rels.toString(), "")
    }

    suspend fun export(
        ctx: Context, canvas: Project, fmt: Fmt, watermark: Boolean,
        secondsPerPage: Float, kenBurns: Boolean, onProgress: (Int, Int) -> Unit
    ): Result = withContext(Dispatchers.IO) {
        val pages = CanvasStore.pages(canvas.id)
        if (pages.isEmpty()) return@withContext Result("مفيش صفحات للتصدير")
        val n = pages.size
        val stamp = System.currentTimeMillis()
        val base = canvas.name.replace(Regex("[^\\p{L}\\p{N}_-]+"), "_").ifBlank { "canvas" }
        try {
            when (fmt) {
                Fmt.PNG, Fmt.JPG -> {
                    var last: Uri? = null
                    for ((i, p) in pages.withIndex()) {
                        onProgress(i + 1, n)
                        val bmp = renderPage(ctx, p, watermark, fmt == Fmt.JPG) ?: continue
                        last = MediaRepository.saveImage(ctx, bmp, if (fmt == Fmt.PNG) ExportFormat.PNG else ExportFormat.JPG, 94)
                        bmp.recycle()
                    }
                    Result("اتحفظت $n صفحة كصور في المعرض (Pictures/NASAQ)", last, if (fmt == Fmt.PNG) "image/png" else "image/jpeg")
                }
                Fmt.PDF -> {
                    val f = File(ctx.cacheDir, "${base}_$stamp.pdf")
                    val doc = PdfDocument()
                    try {
                        for ((i, p) in pages.withIndex()) {
                            onProgress(i + 1, n)
                            val bmp = renderPage(ctx, p, watermark, true) ?: continue
                            writePdf(doc, bmp, i + 1)
                            bmp.recycle()
                        }
                        f.outputStream().use { doc.writeTo(it) }
                    } finally { doc.close() }
                    val saved = saveToDownloads(ctx, f, f.name, "application/pdf")
                    Result(if (saved) "اتحفظ PDF في التنزيلات (Download/NASAQ)" else "تم إنشاء PDF — شاركه أو احفظه من زرار المشاركة", shareOf(ctx, f), "application/pdf")
                }
                Fmt.DOCX -> {
                    val f = File(ctx.cacheDir, "${base}_$stamp.docx")
                    var aspect = 1f
                    ZipOutputStream(f.outputStream().buffered()).use { z ->
                        z.putNextEntry(ZipEntry("[Content_Types].xml"))
                        z.write("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="jpeg" ContentType="image/jpeg"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>""".toByteArray())
                        z.closeEntry()
                        z.putNextEntry(ZipEntry("_rels/.rels"))
                        z.write("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>""".toByteArray())
                        z.closeEntry()
                        var count = 0
                        for ((i, p) in pages.withIndex()) {
                            onProgress(i + 1, n)
                            val bmp = renderPage(ctx, p, watermark, true) ?: continue
                            count++
                            if (count == 1) aspect = bmp.width.toFloat() / bmp.height
                            z.putNextEntry(ZipEntry("word/media/page$count.jpeg"))
                            bmp.compress(Bitmap.CompressFormat.JPEG, 92, z)
                            z.closeEntry()
                            bmp.recycle()
                        }
                        val (doc, rels, _) = docxXml(count, aspect)
                        z.putNextEntry(ZipEntry("word/document.xml")); z.write(doc.toByteArray()); z.closeEntry()
                        z.putNextEntry(ZipEntry("word/_rels/document.xml.rels")); z.write(rels.toByteArray()); z.closeEntry()
                    }
                    val mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    val saved = saveToDownloads(ctx, f, f.name, mime)
                    Result(if (saved) "اتحفظ ملف Word في التنزيلات (Download/NASAQ)" else "تم إنشاء ملف Word — شاركه أو احفظه من زرار المشاركة", shareOf(ctx, f), mime)
                }
                Fmt.VIDEO -> {
                    // بنرسم كل صفحة صورة، وننشئ مشروع فيديو (مقطع لكل صفحة) يتفتح في محرر الفيديو للموسيقى والتصدير
                    val repo = Graph.repo
                    val vid = repo.newId()
                    val clips = ArrayList<VideoClip>()
                    for ((i, p) in pages.withIndex()) {
                        onProgress(i + 1, n)
                        val bmp = renderPage(ctx, p, false, true) ?: continue
                        val f = File(repo.dir(vid), "page_${i + 1}.png")
                        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                        clips.add(
                            VideoClip(
                                id = ProjectFactory.nextId(), uri = Uri.fromFile(f).toString(), isImage = true,
                                srcDurationMs = 30_000L, startMs = 0L, endMs = (secondsPerPage * 1000).toLong(),
                                width = bmp.width, height = bmp.height, fill = false, kenBurns = if (kenBurns) 1 else 0
                            )
                        )
                        if (i == 0) repo.saveThumb(vid, bmp)
                        bmp.recycle()
                    }
                    if (clips.isEmpty()) return@withContext Result("تعذّر تجهيز الصفحات")
                    val c = canvas.canvas
                    val aspect = if (c != null) c.w.toFloat() / c.h else 0f
                    val now = System.currentTimeMillis()
                    val vp = Project(
                        id = vid, name = canvas.name + " (فيديو)", type = ProjectType.VIDEO, createdAt = now, updatedAt = now,
                        video = VideoData(clips = clips, aspect = aspect, resolution = if (minOf(c?.w ?: 1080, c?.h ?: 1080) >= 1080) 1080 else 720)
                    )
                    repo.save(vp)
                    Result("اتجهّز مشروع فيديو من ${clips.size} صفحة — هيتفتح في محرر الفيديو", video = vp)
                }
            }
        } catch (t: Throwable) {
            Result("فشل التصدير: ${t.message ?: "خطأ غير معروف"}")
        }
    }

    private fun shareOf(ctx: Context, f: File): Uri =
        androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
}
