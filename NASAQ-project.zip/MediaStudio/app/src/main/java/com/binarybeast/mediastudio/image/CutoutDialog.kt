package com.binarybeast.mediastudio.image

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.binarybeast.mediastudio.ui.Accent
import com.binarybeast.mediastudio.ui.Bg
import com.binarybeast.mediastudio.ui.Chip
import com.binarybeast.mediastudio.ui.ColorRow
import com.binarybeast.mediastudio.ui.LabeledSlider
import com.binarybeast.mediastudio.ui.SectionLabel
import com.binarybeast.mediastudio.ui.SmallButton
import com.binarybeast.mediastudio.ui.TextDim
import kotlin.math.min

@Composable
fun CutoutDialog(vm: ImageEditorViewModel) {
    if (!vm.cutoutOpen) return
    Dialog(
        onDismissRequest = { vm.cancelCutout() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.cancelCutout() }) { Icon(Icons.Default.Close, "إلغاء") }
                Text("ضبط إزالة الخلفية", fontSize = 16.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { vm.applyCutout() }) { Text("تطبيق", color = Accent, fontSize = 16.sp) }
            }
            Preview(vm, Modifier.weight(1f).fillMaxWidth())
            Column(
                Modifier.fillMaxWidth().heightIn(max = 270.dp).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("شخص (ذكي)", vm.cMode == 0, { vm.cMode = 0; vm.requestCutout() })
                    Chip("حسب لون الخلفية", vm.cMode == 1, { vm.cMode = 1; vm.requestCutout() })
                    Chip(if (vm.cBrushOn) "الفرشاة: شغالة" else "فرشاة يدوية", vm.cBrushOn, { vm.cBrushOn = !vm.cBrushOn })
                }
                if (vm.cMode == 1) {
                    LabeledSlider("حساسية لون الخلفية", vm.cTol, 0f..1f, { vm.cTol = it; vm.requestCutout() })
                    Text("بتشيل اللون المتجانس اللي حوالين الجسم. زوّد الحساسية لو فضل جزء من الخلفية.", color = TextDim, fontSize = 11.sp)
                }
                LabeledSlider("قوة القص", vm.cThreshold, 0.1f..0.9f, { vm.cThreshold = it; vm.requestCutout() })
                LabeledSlider("نعومة الحافة", vm.cSoft, 0.02f..0.4f, { vm.cSoft = it; vm.requestCutout() })
                LabeledSlider("توسيع / تقليص", vm.cGrow.toFloat(), -8f..8f, { vm.cGrow = it.toInt(); vm.requestCutout() }, {}, { "%+d".format(it.toInt()) })
                LabeledSlider("تنعيم", vm.cFeather.toFloat(), 0f..8f, { vm.cFeather = it.toInt(); vm.requestCutout() }, {}, { "%d".format(it.toInt()) })
                if (vm.cBrushOn) {
                    SectionLabel("الفرشاة")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Chip("محو", !vm.cRestore, { vm.cRestore = false })
                        Chip("استعادة", vm.cRestore, { vm.cRestore = true })
                        SmallButton("مسح تعديلاتي", { vm.cutoutClearBrush() })
                    }
                    LabeledSlider("حجم الفرشاة", vm.cBrushSize, 0.01f..0.15f, { vm.cBrushSize = it })
                }
                LabeledSlider("تمويه الخلفية بدل حذفها (بورتريه)", vm.cBlurBg, 0f..1f, { vm.cBlurBg = it })
                SectionLabel("لون الخلفية")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("شفافة", vm.cutoutBg == 0, { vm.cutoutBg = 0 })
                }
                ColorRow(vm.cutoutBg, onPick = { vm.cutoutBg = it }, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}

@Composable
private fun Preview(vm: ImageEditorViewModel, modifier: Modifier) {
    val bmp = vm.cutoutPreview
    var box by remember { mutableStateOf(IntSize.Zero) }
    val size = vm.cutoutSize()
    Canvas(
        modifier
            .onSizeChanged { box = it }
            .pointerInput(vm.cBrushOn, size, box) {
                if (!vm.cBrushOn || size == null || box.width == 0) return@pointerInput
                val sc = min(box.width.toFloat() / size.first, box.height.toFloat() / size.second)
                val ox = (box.width - size.first * sc) / 2f
                val oy = (box.height - size.second * sc) / 2f
                fun paint(p: Offset) = vm.cutoutBrush((p.x - ox) / sc, (p.y - oy) / sc)
                detectDragGestures(onDragStart = { paint(it) }, onDrag = { c, _ -> paint(c.position) })
            }
    ) {
        val tile = 16.dp.toPx()
        var y = 0f; var r = 0
        while (y < this.size.height) {
            var x = 0f; var c = r % 2
            while (x < this.size.width) {
                drawRect(if (c % 2 == 0) Color(0xFF2A2D3A) else Color(0xFF1B1E2A), Offset(x, y), androidx.compose.ui.geometry.Size(tile, tile))
                x += tile; c++
            }
            y += tile; r++
        }
        if (bmp != null) {
            val sc = min(this.size.width / bmp.width, this.size.height / bmp.height)
            val dw = (bmp.width * sc).toInt(); val dh = (bmp.height * sc).toInt()
            val off = IntOffset(((this.size.width - dw) / 2).toInt(), ((this.size.height - dh) / 2).toInt())
            if (vm.cutoutBg != 0) drawRect(Color(vm.cutoutBg), Offset(off.x.toFloat(), off.y.toFloat()), androidx.compose.ui.geometry.Size(dw.toFloat(), dh.toFloat()))
            drawImage(bmp.asImageBitmap(), dstOffset = off, dstSize = IntSize(dw, dh))
        }
    }
}
