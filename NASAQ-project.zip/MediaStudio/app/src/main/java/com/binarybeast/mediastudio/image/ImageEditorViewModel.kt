package com.binarybeast.mediastudio.image

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.binarybeast.mediastudio.Graph
import com.binarybeast.mediastudio.data.Adjust
import com.binarybeast.mediastudio.data.ExportFormat
import com.binarybeast.mediastudio.data.ImageData
import com.binarybeast.mediastudio.data.ImageEdit
import com.binarybeast.mediastudio.data.Looks
import com.binarybeast.mediastudio.data.MediaRepository
import com.binarybeast.mediastudio.data.Project
import com.binarybeast.mediastudio.data.ProjectFactory
import com.binarybeast.mediastudio.data.Stroke
import com.binarybeast.mediastudio.data.TextLayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ImageEditorViewModel(app: Application, private val projectId: String) : AndroidViewModel(app) {

    private val repo = Graph.repo

    var project by mutableStateOf<Project?>(null)
        private set
    var edit by mutableStateOf(ImageEdit())
        private set
    var preview by mutableStateOf<Bitmap?>(null)
        private set
    var original by mutableStateOf<Bitmap?>(null)
        private set
    var loading by mutableStateOf(true)
        private set
    var failed by mutableStateOf(false)
        private set
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set
    var selectedLayer by mutableStateOf<Long?>(null)
    var showOriginal by mutableStateOf(false)
    var exporting by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)

    /** رسالة تحميل أثناء عمليات طويلة (إزالة الخلفية...). */
    var processing by mutableStateOf<String?>(null)
        private set
    val isBlank: Boolean get() = data?.sourceUri == null
    val backgroundColor: Int get() = data?.blankColor ?: 0
    var canRestoreBackground by mutableStateOf(false)
        private set
    private var bgBackup: Pair<ImageData, ImageEdit>? = null

    /** مصغّرات الفلاتر (id -> Bitmap). */
    val lookThumbs = mutableStateMapOf<String, Bitmap>()

    private var source: Bitmap? = null
    private var data: ImageData? = null
    private val undoStack = ArrayDeque<ImageEdit>()
    private val redoStack = ArrayDeque<ImageEdit>()
    private var gestureBase: ImageEdit? = null
    private var renderJob: Job? = null
    private var saveJob: Job? = null

    init {
        viewModelScope.launch(Dispatchers.IO) {
            val p = repo.load(projectId)
            val d = p?.image
            if (p == null || d == null) {
                withContext(Dispatchers.Main) { failed = true; loading = false }
                return@launch
            }
            val src = if (d.sourceUri != null) BitmapLoader.load(getApplication(), Uri.parse(d.sourceUri), 1600)
            else {
                val k = minOf(1f, 1600f / maxOf(d.blankW, d.blankH))
                BitmapLoader.blank((d.blankW * k).toInt(), (d.blankH * k).toInt(), d.blankColor)
            }
            if (src == null) {
                withContext(Dispatchers.Main) { failed = true; loading = false }
                return@launch
            }
            ImageCache.preload(getApplication(), d.edit.texts)
            source = src
            data = d
            // مصغّرات الفلاتر على نسخة صغيرة
            val small = scaleDown(src, 120)
            val thumbs = Looks.all.associate { look ->
                look.id to ImageProcessor.render(small, ImageEdit(lookId = look.id))
            }
            withContext(Dispatchers.Main) {
                project = p
                edit = d.edit
                original = src
                lookThumbs.putAll(thumbs)
                loading = false
                scheduleRender(immediate = true)
            }
        }
    }

    private fun scaleDown(b: Bitmap, maxSide: Int): Bitmap {
        val big = maxOf(b.width, b.height)
        if (big <= maxSide) return b
        val k = maxSide.toFloat() / big
        return Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true)
    }

    // ---------------------------------------------------------------- edit state

    private fun baseKey(e: ImageEdit) = e.copy(texts = emptyList(), strokes = emptyList())

    private fun setEdit(e: ImageEdit) {
        val need = baseKey(e) != baseKey(edit)
        edit = e
        if (need) scheduleRender()
        scheduleSave()
    }

    private fun refreshFlags() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    /** تعديل لحظي واحد يدخل في سجل التراجع. */
    fun commit(f: (ImageEdit) -> ImageEdit) {
        undoStack.addLast(edit)
        if (undoStack.size > 80) undoStack.removeFirst()
        redoStack.clear()
        setEdit(f(edit))
        refreshFlags()
    }

    /** تعديل مستمر (سحب سلايدر/إيماءة): بيتسجل في السجل مرة واحدة عند endLive. */
    fun live(f: (ImageEdit) -> ImageEdit) {
        if (gestureBase == null) gestureBase = edit
        setEdit(f(edit))
    }

    fun endLive() {
        val base = gestureBase
        gestureBase = null
        if (base != null && base != edit) {
            undoStack.addLast(base)
            if (undoStack.size > 80) undoStack.removeFirst()
            redoStack.clear()
        }
        refreshFlags()
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.addLast(edit)
        setEdit(undoStack.removeLast())
        refreshFlags()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.addLast(edit)
        setEdit(redoStack.removeLast())
        refreshFlags()
    }

    fun resetAll() = commit { ImageEdit() }

    fun autoEnhance() = commit {
        it.copy(adjust = Adjust(brightness = 0.04f, contrast = 0.18f, saturation = 0.22f, warmth = 0.05f), sharpen = 0.25f)
    }

    // ---------------------------------------------------------------- layers

    private var layerSeed = System.nanoTime()

    fun addText(text: String, size: Float = 0.08f) {
        val id = ++layerSeed
        commit { it.copy(texts = it.texts + TextLayer(id = id, text = text, size = size)) }
        selectedLayer = id
    }

    fun addEmoji(emoji: String) {
        val id = ++layerSeed
        commit { it.copy(texts = it.texts + TextLayer(id = id, text = emoji, size = 0.16f, shadow = false, bold = false)) }
        selectedLayer = id
    }

    /** يضيف شكل (مستطيل/دائرة/نجمة/قلب/سهم...) كطبقة قابلة للتحريك. */
    fun addShape(kind: Int) {
        val id = ++layerSeed
        val layer = TextLayer(
            id = id, text = "", shape = kind,
            size = if (kind == 7 || kind == 8) 0.06f else 0.2f,
            aspect = when (kind) { 7, 8 -> 6f; 1, 2 -> 1.4f; else -> 1f },
            color = 0xFFA99DFF.toInt(), shadow = false, bold = false,
        )
        commit { it.copy(texts = it.texts + layer) }
        selectedLayer = id
    }

    /** يضيف صورة/لوجو كطبقة فوق الصورة. */
    fun addImageLayer(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val local = runCatching { repo.importIfNeeded(projectId, uri, forceCopy = true) }.getOrNull()
            val bmp = local?.let { ImageCache.load(getApplication(), it.toString()) }
            if (local == null || bmp == null) {
                withContext(Dispatchers.Main) { message = "تعذّر فتح الصورة" }
                return@launch
            }
            val aspect = bmp.width.toFloat() / bmp.height
            val id = ++layerSeed
            val layer = TextLayer(
                id = id, text = "", shape = 9, imageUri = local.toString(), aspect = aspect,
                size = (0.3f / maxOf(1f, aspect)), shadow = false, bold = false,
            )
            withContext(Dispatchers.Main) {
                commit { it.copy(texts = it.texts + layer) }
                selectedLayer = id
            }
        }
    }

    fun moveLayer(id: Long, toFront: Boolean) {
        val l = edit.texts.firstOrNull { it.id == id } ?: return
        commit { e ->
            val rest = e.texts.filter { it.id != id }
            e.copy(texts = if (toFront) rest + l else listOf(l) + rest)
        }
    }

    fun duplicateLayer(id: Long) {
        val l = edit.texts.firstOrNull { it.id == id } ?: return
        val nid = ++layerSeed
        commit { it.copy(texts = it.texts + l.copy(id = nid, x = (l.x + 0.05f).coerceAtMost(0.95f), y = (l.y + 0.05f).coerceAtMost(0.95f))) }
        selectedLayer = nid
    }

    fun deleteLayer(id: Long) {
        commit { it.copy(texts = it.texts.filter { t -> t.id != id }) }
        if (selectedLayer == id) selectedLayer = null
    }

    fun updateLayer(id: Long, transient: Boolean, f: (TextLayer) -> TextLayer) {
        val change: (ImageEdit) -> ImageEdit = { e -> e.copy(texts = e.texts.map { if (it.id == id) f(it) else it }) }
        if (transient) live(change) else commit(change)
    }

    fun addStroke(s: Stroke) = commit { it.copy(strokes = it.strokes + s) }

    fun undoStroke() = commit { it.copy(strokes = it.strokes.dropLast(1)) }

    fun clearStrokes() = commit { it.copy(strokes = emptyList()) }

    // ---------------------------------------------------------------- background

    /** تغيير لون خلفية اللوحة (للمشاريع الفاضية/الكولاج/بعد إزالة الخلفية). 0 = شفاف. */
    fun setBackground(color: Int) {
        val d = data ?: return
        if (d.sourceUri != null) return
        data = d.copy(blankColor = color)
        val b = BitmapLoader.blank(d.blankW, d.blankH, color)
        source = b
        original = b
        scheduleRender(immediate = true)
        scheduleSave()
    }

    /** إزالة الخلفية تلقائيًا: يعزل الشخص، ويحوّل المشروع للوحة شفافة عليها الشخص كطبقة. */
    fun removeBackground() {
        val d = data ?: return
        val src = source ?: return
        if (d.sourceUri == null || processing != null) return
        processing = "جاري عزل الشخص عن الخلفية..."
        val e = edit
        viewModelScope.launch(Dispatchers.Default) {
            val cut: Bitmap? = try {
                val base = ImageProcessor.render(src, e.copy(texts = emptyList(), strokes = emptyList()))
                BackgroundRemover.cutout(base)
            } catch (t: Throwable) {
                null
            }
            val file = cut?.let {
                runCatching {
                    val f = java.io.File(repo.dir(projectId), "cutout_${System.currentTimeMillis()}.png")
                    f.outputStream().use { os -> it.compress(Bitmap.CompressFormat.PNG, 100, os) }
                    f
                }.getOrNull()
            }
            withContext(Dispatchers.Main) {
                processing = null
                if (cut == null || file == null) {
                    message = "تعذّر إزالة الخلفية (جرّب صورة فيها شخص واضح)"
                    return@withContext
                }
                val uri = Uri.fromFile(file).toString()
                ImageCache.load(getApplication(), uri)
                val id = ++layerSeed
                val layer = TextLayer(
                    id = id, text = "", x = 0.5f, y = 0.5f, size = 1f, aspect = cut.width.toFloat() / cut.height,
                    shape = 9, imageUri = uri, shadow = false, bold = false
                )
                bgBackup = Pair(d, e)
                canRestoreBackground = true
                val nd = ImageData(sourceUri = null, blankW = cut.width, blankH = cut.height, blankColor = 0)
                data = nd
                val b = BitmapLoader.blank(cut.width, cut.height, 0)
                source = b
                original = b
                undoStack.clear(); redoStack.clear()
                edit = ImageEdit(texts = listOf(layer) + e.texts, strokes = e.strokes)
                refreshFlags()
                scheduleRender(immediate = true)
                scheduleSave()
                message = "تمت إزالة الخلفية. غيّر لون الخلفية أو خليها شفافة وصدّر PNG"
            }
        }
    }

    /** يرجّع الصورة الأصلية قبل إزالة الخلفية (في نفس الجلسة). */
    fun restoreBackground() {
        val (d, e) = bgBackup ?: return
        bgBackup = null
        canRestoreBackground = false
        data = d
        val src = if (d.sourceUri != null) BitmapLoader.load(getApplication(), Uri.parse(d.sourceUri), 1600) else null
        if (src != null) {
            source = src
            original = src
        }
        undoStack.clear(); redoStack.clear()
        edit = e
        refreshFlags()
        scheduleRender(immediate = true)
        scheduleSave()
    }

    // ---------------------------------------------------------------- render

    private fun scheduleRender(immediate: Boolean = false) {
        val src = source ?: return
        val e = edit
        renderJob?.cancel()
        renderJob = viewModelScope.launch(Dispatchers.Default) {
            if (!immediate) delay(24)
            val bmp = ImageProcessor.render(src, e)
            ensureActive()
            withContext(Dispatchers.Main) { preview = bmp }
        }
    }

    // ---------------------------------------------------------------- persistence

    private fun snapshot(): Project? {
        val p = project ?: return null
        val d = data ?: return null
        val updated = p.copy(image = d.copy(edit = edit), updatedAt = System.currentTimeMillis())
        project = updated
        return updated
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(900)
            val u = snapshot() ?: return@launch
            withContext(Dispatchers.IO) { repo.save(u) }
        }
    }

    /** حفظ متزامن (بيتنادى عند الخروج، وقت ما الـ scope ممكن يكون اتلغى). */
    fun saveNow() {
        val u = snapshot() ?: return
        repo.save(u)
        val thumb = preview ?: return
        val e = u.image!!.edit
        kotlin.concurrent.thread {
            runCatching {
                val t = thumb.copy(Bitmap.Config.ARGB_8888, true)
                ImageProcessor.drawOverlays(Canvas(t), t.width.toFloat(), t.height.toFloat(), e.strokes, e.texts)
                repo.saveThumb(u.id, t)
            }
        }
    }

    fun rename(name: String) {
        val p = project ?: return
        project = p.copy(name = name)
        saveNow()
    }

    override fun onCleared() {
        saveNow()
        super.onCleared()
    }

    // ---------------------------------------------------------------- export

    /** تصدير بجودة كاملة وحفظ في المعرض. onDone بيتنادى على الـ Main بالـ Uri أو null لو فشل. */
    fun export(fmt: ExportFormat, quality: Int, scalePercent: Int, watermark: Boolean, onDone: (Uri?) -> Unit) {
        val d = data ?: return
        val e = if (watermark) edit.copy(texts = edit.texts + com.binarybeast.mediastudio.data.Brand.watermark()) else edit
        exporting = true
        viewModelScope.launch(Dispatchers.Default) {
            val result: Uri? = try {
                ImageCache.preload(getApplication(), e.texts)
                var full: Bitmap? = if (d.sourceUri != null) {
                    BitmapLoader.load(getApplication(), Uri.parse(d.sourceUri), 4096)
                        ?: BitmapLoader.load(getApplication(), Uri.parse(d.sourceUri), 2048)
                } else BitmapLoader.blank(d.blankW, d.blankH, d.blankColor)
                if (full == null) throw IllegalStateException("تعذر تحميل الصورة")
                var out = ImageProcessor.renderFull(full, e)
                full = null
                if (d.sourceUri == null && android.graphics.Color.alpha(d.blankColor) == 0 && fmt != ExportFormat.PNG) {
                    // JPG/WEBP مش بيدعموا الشفافية: نحط خلفية بيضا بدل الأسود
                    val flat = Bitmap.createBitmap(out.width, out.height, Bitmap.Config.ARGB_8888)
                    val c = Canvas(flat)
                    c.drawColor(android.graphics.Color.WHITE)
                    c.drawBitmap(out, 0f, 0f, null)
                    out = flat
                }
                if (scalePercent < 100) {
                    val k = scalePercent / 100f
                    out = Bitmap.createScaledBitmap(out, (out.width * k).toInt().coerceAtLeast(1), (out.height * k).toInt().coerceAtLeast(1), true)
                }
                MediaRepository.saveImage(getApplication(), out, fmt, quality)
            } catch (t: Throwable) {
                null
            }
            withContext(Dispatchers.Main) {
                exporting = false
                if (result == null) message = "فشل التصدير"
                onDone(result)
            }
        }
    }

    @Suppress("unused")
    private fun unusedFactoryRef() = ProjectFactory.defaultName("")
}
