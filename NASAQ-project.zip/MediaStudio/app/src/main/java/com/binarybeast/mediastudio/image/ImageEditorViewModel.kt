package com.binarybeast.mediastudio.image

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.binarybeast.mediastudio.Graph
import com.binarybeast.mediastudio.data.Adjust
import com.binarybeast.mediastudio.data.ExportFormat
import com.binarybeast.mediastudio.data.ImageData
import com.binarybeast.mediastudio.data.ImageEdit
import com.binarybeast.mediastudio.data.Looks
import com.binarybeast.mediastudio.data.MediaRepository
import com.binarybeast.mediastudio.data.Project
import com.binarybeast.mediastudio.data.ProjectFactory
import com.binarybeast.mediastudio.data.Stroke
import com.binarybeast.mediastudio.data.TextLayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ImageEditorViewModel(app: Application, private val projectId: String) : AndroidViewModel(app) {

    private val repo = Graph.repo

    var project by mutableStateOf<Project?>(null)
        private set
    var edit by mutableStateOf(ImageEdit())
        private set
    var preview by mutableStateOf<Bitmap?>(null)
        private set
    var original by mutableStateOf<Bitmap?>(null)
        private set
    var loading by mutableStateOf(true)
        private set
    var failed by mutableStateOf(false)
        private set
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set
    var selectedLayer by mutableStateOf<Long?>(null)
    var showOriginal by mutableStateOf(false)
    var exporting by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)

    /** رسالة تحميل أثناء عمليات طويلة (إزالة الخلفية...). */
    var processing by mutableStateOf<String?>(null)
        private set
    val isBlank: Boolean get() = data?.sourceUri == null
    val backgroundColor: Int get() = data?.blankColor ?: 0
    var canRestoreBackground by mutableStateOf(false)
        private set
    private var bgBackup: Pair<ImageData, ImageEdit>? = null

    /** مصغّرات الفلاتر (id -> Bitmap). */
    val lookThumbs = mutableStateMapOf<String, Bitmap>()

    private var source: Bitmap? = null
    private var data: ImageData? = null
    private val undoStack = ArrayDeque<ImageEdit>()
    private val redoStack = ArrayDeque<ImageEdit>()
    private var gestureBase: ImageEdit? = null
    private var renderJob: Job? = null
    private var saveJob: Job? = null

    init {
        viewModelScope.launch(Dispatchers.IO) {
            val p = repo.load(projectId)
            val d = p?.image
            if (p == null || d == null) {
                withContext(Dispatchers.Main) { failed = true; loading = false }
                return@launch
            }
            val src = if (d.sourceUri != null) BitmapLoader.load(getApplication(), Uri.parse(d.retouchUri ?: d.sourceUri), 1280)
            else {
                val k = minOf(1f, 1280f / maxOf(d.blankW, d.blankH))
                BitmapLoader.blank((d.blankW * k).toInt(), (d.blankH * k).toInt(), d.blankColor)
            }
            if (src == null) {
                withContext(Dispatchers.Main) { failed = true; loading = false }
                return@launch
            }
            ImageCache.preload(getApplication(), d.edit.texts)
            source = src
            data = d
            // مصغّرات الفلاتر على نسخة صغيرة
            val small = scaleDown(src, 120)
            val thumbs = Looks.all.associate { look ->
                look.id to ImageProcessor.render(small, ImageEdit(lookId = look.id))
            }
            withContext(Dispatchers.Main) {
                project = p
                edit = d.edit
                original = src
                lookThumbs.putAll(thumbs)
                loading = false
                scheduleRender(immediate = true)
            }
        }
    }

    private fun scaleDown(b: Bitmap, maxSide: Int): Bitmap {
        val big = maxOf(b.width, b.height)
        if (big <= maxSide) return b
        val k = maxSide.toFloat() / big
        return Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true)
    }

    // ---------------------------------------------------------------- edit state

    private fun baseKey(e: ImageEdit) = e.copy(texts = emptyList(), strokes = emptyList())

    private fun applyEdit(e: ImageEdit) {
        val need = baseKey(e) != baseKey(edit)
        edit = e
        if (need) scheduleRender()
        scheduleSave()
    }

    private fun refreshFlags() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    /** تعديل لحظي واحد يدخل في سجل التراجع. */
    fun commit(f: (ImageEdit) -> ImageEdit) {
        undoStack.addLast(edit)
        if (undoStack.size > 80) undoStack.removeFirst()
        redoStack.clear()
        applyEdit(f(edit))
        refreshFlags()
    }

    /** تعديل مستمر (سحب سلايدر/إيماءة): بيتسجل في السجل مرة واحدة عند endLive. */
    fun live(f: (ImageEdit) -> ImageEdit) {
        if (gestureBase == null) gestureBase = edit
        applyEdit(f(edit))
    }

    fun endLive() {
        val base = gestureBase
        gestureBase = null
        if (base != null && base != edit) {
            undoStack.addLast(base)
            if (undoStack.size > 80) undoStack.removeFirst()
            redoStack.clear()
        }
        refreshFlags()
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.addLast(edit)
        applyEdit(undoStack.removeLast())
        refreshFlags()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.addLast(edit)
        applyEdit(redoStack.removeLast())
        refreshFlags()
    }

    fun resetAll() = commit { ImageEdit() }

    // ---------------------------------------------------------------- layers

    private var layerSeed = System.nanoTime()

    fun addText(text: String, size: Float = 0.08f) {
        val id = ++layerSeed
        commit { it.copy(texts = it.texts + TextLayer(id = id, text = text, size = size)) }
        selectedLayer = id
    }

    fun addEmoji(emoji: String) {
        val id = ++layerSeed
        commit { it.copy(texts = it.texts + TextLayer(id = id, text = emoji, size = 0.16f, shadow = false, bold = false)) }
        selectedLayer = id
    }

    /** يضيف شكل (مستطيل/دائرة/نجمة/قلب/سهم...) كطبقة قابلة للتحريك. */
    fun addShape(kind: Int) {
        val id = ++layerSeed
        val layer = TextLayer(
            id = id, text = "", shape = kind,
            size = if (kind == 7 || kind == 8) 0.06f else 0.2f,
            aspect = when (kind) { 7, 8 -> 6f; 1, 2 -> 1.4f; else -> 1f },
            color = 0xFFA99DFF.toInt(), shadow = false, bold = false,
        )
        commit { it.copy(texts = it.texts + layer) }
        selectedLayer = id
    }

    /** طبقة لون أو تدرّج بتغطي الصورة كلها (زي Fill/Gradient Layer). */
    fun addFillLayer(gradient: Boolean) {
        val id = ++layerSeed
        val layer = TextLayer(
            id = id, text = "", shape = if (gradient) 11 else 10, size = 1f,
            color = 0xFF3A6BFF.toInt(), color2 = 0xFFFF7A59.toInt(),
            opacity = if (gradient) 0.55f else 0.35f, blend = if (gradient) 3 else 1,
            shadow = false, bold = false, rotation = 0f,
        )
        commit { it.copy(texts = it.texts + layer) }
        selectedLayer = id
    }

    /** يضيف صورة/لوجو كطبقة فوق الصورة. */
    fun addImageLayer(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val local = runCatching { repo.importIfNeeded(projectId, uri, forceCopy = true) }.getOrNull()
            val bmp = local?.let { ImageCache.load(getApplication(), it.toString()) }
            if (local == null || bmp == null) {
                withContext(Dispatchers.Main) { message = "تعذّر فتح الصورة" }
                return@launch
            }
            val aspect = bmp.width.toFloat() / bmp.height
            val id = ++layerSeed
            val layer = TextLayer(
                id = id, text = "", shape = 9, imageUri = local.toString(), aspect = aspect,
                size = (0.3f / maxOf(1f, aspect)), shadow = false, bold = false,
            )
            withContext(Dispatchers.Main) {
                commit { it.copy(texts = it.texts + layer) }
                selectedLayer = id
            }
        }
    }

    fun moveLayer(id: Long, toFront: Boolean) {
        val l = edit.texts.firstOrNull { it.id == id } ?: return
        commit { e ->
            val rest = e.texts.filter { it.id != id }
            e.copy(texts = if (toFront) rest + l else listOf(l) + rest)
        }
    }

    fun duplicateLayer(id: Long) {
        val l = edit.texts.firstOrNull { it.id == id } ?: return
        val nid = ++layerSeed
        commit { it.copy(texts = it.texts + l.copy(id = nid, x = (l.x + 0.05f).coerceAtMost(0.95f), y = (l.y + 0.05f).coerceAtMost(0.95f))) }
        selectedLayer = nid
    }

    fun deleteLayer(id: Long) {
        commit { it.copy(texts = it.texts.filter { t -> t.id != id }) }
        if (selectedLayer == id) selectedLayer = null
    }

    fun updateLayer(id: Long, transient: Boolean, f: (TextLayer) -> TextLayer) {
        val change: (ImageEdit) -> ImageEdit = { e -> e.copy(texts = e.texts.map { if (it.id == id) f(it) else it }) }
        if (transient) live(change) else commit(change)
    }

    // ---------------------------------------------------------------- أداة القلم (مسارات Bezier)
    var penMode by mutableStateOf(false)
    val penPts = androidx.compose.runtime.mutableStateListOf<Float>()

    fun penAdd(nx: Float, ny: Float) { penPts.add(nx.coerceIn(0f, 1f)); penPts.add(ny.coerceIn(0f, 1f)) }
    fun penUndo() { if (penPts.size >= 2) { penPts.removeAt(penPts.size - 1); penPts.removeAt(penPts.size - 1) } }
    fun penClear() = penPts.clear()

    /** يحوّل نقاط الارتكاز لمنحنى ناعم (Catmull-Rom) ويرسمه كخط. */
    fun penFinish(color: Int, width: Float, alpha: Float, close: Boolean) {
        val n = penPts.size / 2
        if (n < 2) { message = "حط نقطتين على الأقل"; return }
        val a = ArrayList<Pair<Float, Float>>()
        for (i in 0 until n) a.add(penPts[i * 2] to penPts[i * 2 + 1])
        if (close && n > 2) a.add(a[0])
        val out = ArrayList<Float>()
        for (i in 0 until a.size - 1) {
            val p0 = if (i == 0) (if (close && n > 2) a[a.size - 2] else a[0]) else a[i - 1]
            val p1 = a[i]; val p2 = a[i + 1]
            val p3 = if (i + 2 < a.size) a[i + 2] else if (close && n > 2) a[1] else a[a.size - 1]
            for (s in 0 until 12) {
                val t = s / 12f; val t2 = t * t; val t3 = t2 * t
                fun cr(a0: Float, b0: Float, c0: Float, d0: Float) =
                    0.5f * ((2 * b0) + (-a0 + c0) * t + (2 * a0 - 5 * b0 + 4 * c0 - d0) * t2 + (-a0 + 3 * b0 - 3 * c0 + d0) * t3)
                out.add(cr(p0.first, p1.first, p2.first, p3.first)); out.add(cr(p0.second, p1.second, p2.second, p3.second))
            }
        }
        out.add(a.last().first); out.add(a.last().second)
        commit { it.copy(strokes = it.strokes + Stroke(color, width, alpha, out)) }
        penPts.clear()
    }

    fun addStroke(s: Stroke) = commit { it.copy(strokes = it.strokes + s) }

    fun undoStroke() = commit { it.copy(strokes = it.strokes.dropLast(1)) }

    fun clearStrokes() = commit { it.copy(strokes = emptyList()) }

    // ---------------------------------------------------------------- background

    /** تغيير لون خلفية اللوحة (للمشاريع الفاضية/الكولاج/بعد إزالة الخلفية). 0 = شفاف. */
    fun setBackground(color: Int) {
        val d = data ?: return
        if (d.sourceUri != null) return
        data = d.copy(blankColor = color)
        val b = BitmapLoader.blank(d.blankW, d.blankH, color)
        source = b
        original = b
        scheduleRender(immediate = true)
        scheduleSave()
    }

    // ---- محرر قص الخلفية (قابل للضبط)
    var cutoutOpen by mutableStateOf(false)
        private set
    var cutoutPreview by mutableStateOf<Bitmap?>(null)
        private set
    var cMode by mutableStateOf(0)
    var cThreshold by mutableStateOf(0.5f)
    var cSoft by mutableStateOf(0.15f)
    var cGrow by mutableStateOf(0)
    var cFeather by mutableStateOf(1)
    var cTol by mutableStateOf(0.35f)
    var cBrushOn by mutableStateOf(false)
    var cRestore by mutableStateOf(false)
    var cBrushSize by mutableStateOf(0.05f)
    var cutoutBg by mutableStateOf(0)
    /** 0 = إزالة تامة، >0 = إبقاء الخلفية مموّهة بدل حذفها. */
    var cBlurBg by mutableStateOf(0f)
    private var cutout: Cutout? = null
    private var cutD: ImageData? = null
    private var cutE: ImageEdit? = null
    private val cutReq = Channel<Unit>(Channel.CONFLATED)
    private var cutWorker: Job? = null

    /** يفتح محرر قص الخلفية: يجهّز الصورة ويحسب القناع. */
    fun removeBackground() {
        val d = data ?: return
        if (d.sourceUri == null || processing != null) return
        processing = "جاري تحليل الصورة..."
        val e = edit
        viewModelScope.launch(Dispatchers.Default) {
            var session: Cutout? = null
            var person = false
            try {
                val big = BitmapLoader.load(getApplication(), Uri.parse(d.retouchUri ?: d.sourceUri), 1600) ?: source
                if (big != null) {
                    val base = ImageProcessor.render(big, e.copy(texts = emptyList(), strokes = emptyList()))
                    session = Cutout(base)
                    person = session.loadPerson()
                }
            } catch (t: Throwable) { session = null }
            withContext(Dispatchers.Main) {
                processing = null
                if (session == null) { message = "تعذّر تجهيز الصورة"; return@withContext }
                cutout = session; cutD = d; cutE = e
                cMode = if (person) 0 else 1
                cThreshold = 0.5f; cSoft = 0.15f; cGrow = 0; cFeather = 1; cTol = 0.35f
                cBrushOn = false; cRestore = false; cutoutBg = 0; cBlurBg = 0f
                if (!person) message = "مفيش شخص واضح، اتفعّل وضع (لون الخلفية). ممكن تظبطه يدويًا."
                cutoutOpen = true
                startCutoutWorker()
                requestCutout()
            }
        }
    }

    private fun startCutoutWorker() {
        cutWorker?.cancel()
        cutWorker = viewModelScope.launch(Dispatchers.Default) {
            for (r in cutReq) {
                val c = cutout ?: continue
                val bmp = try {
                    c.compose(cMode, cThreshold, cSoft, cGrow, cFeather, cTol)
                } catch (t: Throwable) { null }
                if (bmp != null) withContext(Dispatchers.Main) { cutoutPreview = bmp }
            }
        }
    }

    fun requestCutout() { cutReq.trySend(Unit) }

    /** نقطة فرشاة بإحداثيات الصورة. */
    fun cutoutBrush(x: Float, y: Float) {
        val c = cutout ?: return
        c.brush(x, y, cBrushSize * minOf(c.w, c.h), cRestore)
        requestCutout()
    }

    fun cutoutClearBrush() { cutout?.clearManual(); requestCutout() }

    fun cutoutSize(): Pair<Int, Int>? = cutout?.let { it.w to it.h }

    fun cancelCutout() {
        cutWorker?.cancel(); cutWorker = null
        cutoutOpen = false; cutoutPreview = null; cutout = null
    }

    /** تثبيت القص: يحوّل المشروع للوحة شفافة عليها الجسم كطبقة. */
    fun applyCutout() {
        val c = cutout ?: return
        val d = cutD ?: return
        val e = cutE ?: return
        processing = "جاري تطبيق القص..."
        viewModelScope.launch(Dispatchers.Default) {
            val cut = try { c.compose(cMode, cThreshold, cSoft, cGrow, cFeather, cTol) } catch (t: Throwable) { null }
            val file = cut?.let {
                runCatching {
                    val f = java.io.File(repo.dir(projectId), "cutout_${System.currentTimeMillis()}.png")
                    f.outputStream().use { os -> it.compress(Bitmap.CompressFormat.PNG, 100, os) }
                    f
                }.getOrNull()
            }
            val blurFile = if (cut != null && cBlurBg > 0.01f) runCatching {
                val k = (4 + cBlurBg * 28).toInt()
                var t = Bitmap.createScaledBitmap(c.base, maxOf(8, c.base.width / k), maxOf(8, c.base.height / k), true)
                t = Bitmap.createScaledBitmap(t, maxOf(4, t.width / 2), maxOf(4, t.height / 2), true)
                val up = Bitmap.createScaledBitmap(t, c.base.width, c.base.height, true)
                val f = java.io.File(repo.dir(projectId), "blurbg_${System.currentTimeMillis()}.png")
                f.outputStream().use { os -> up.compress(Bitmap.CompressFormat.PNG, 95, os) }
                f
            }.getOrNull() else null
            withContext(Dispatchers.Main) {
                processing = null
                if (cut == null || file == null) { message = "تعذّر تطبيق القص"; return@withContext }
                cancelCutout()
                val uri = Uri.fromFile(file).toString()
                ImageCache.load(getApplication(), uri)
                val id = ++layerSeed
                val layer = TextLayer(
                    id = id, text = "", x = 0.5f, y = 0.5f, size = 1f, aspect = cut.width.toFloat() / cut.height,
                    shape = 9, imageUri = uri, shadow = false, bold = false
                )
                bgBackup = Pair(d, e)
                canRestoreBackground = true
                data = ImageData(sourceUri = null, blankW = cut.width, blankH = cut.height, blankColor = cutoutBg)
                val b = BitmapLoader.blank(cut.width, cut.height, cutoutBg)
                source = b
                original = b
                undoStack.clear(); redoStack.clear()
                val bgLayer = blurFile?.let { bf ->
                    val bu = Uri.fromFile(bf).toString()
                    ImageCache.load(getApplication(), bu)
                    TextLayer(
                        id = ++layerSeed, text = "", x = 0.5f, y = 0.5f, size = 1f, aspect = cut.width.toFloat() / cut.height,
                        shape = 9, imageUri = bu, shadow = false, bold = false
                    )
                }
                edit = ImageEdit(texts = listOfNotNull(bgLayer, layer) + e.texts, strokes = e.strokes)
                refreshFlags()
                scheduleRender(immediate = true)
                scheduleSave()
                message = "تمت إزالة الخلفية. غيّر لون الخلفية أو خليها شفافة وصدّر PNG"
            }
        }
    }

    /** يرجّع الصورة الأصلية قبل إزالة الخلفية (في نفس الجلسة). */
    fun restoreBackground() {
        val (d, e) = bgBackup ?: return
        bgBackup = null
        canRestoreBackground = false
        data = d
        val src = if (d.sourceUri != null) BitmapLoader.load(getApplication(), Uri.parse(d.retouchUri ?: d.sourceUri), 1280) else null
        if (src != null) {
            source = src
            original = src
        }
        undoStack.clear(); redoStack.clear()
        edit = e
        refreshFlags()
        scheduleRender(immediate = true)
        scheduleSave()
    }

    // ---------------------------------------------------------------- render

    private val renderReq = Channel<Unit>(Channel.CONFLATED)
    private var renderWorker: Job? = null

    /** عامل رسم واحد: الطلبات المتلاحقة بتتدمج وبياخد آخر حالة بس، فمفيش تكدس. */
    private fun scheduleRender(immediate: Boolean = false) {
        if (renderWorker == null) {
            renderWorker = viewModelScope.launch(Dispatchers.Default) {
                for (r in renderReq) {
                    val src = source ?: continue
                    val e0 = edit
                    val e = if (retouchActive) e0.copy(
                        rotation = 0, flipH = false, flipV = false, cropAspect = 0f, cropZoom = 1f,
                        cropCx = 0.5f, cropCy = 0.5f, straighten = 0f, corner = 0f, border = 0f,
                        perspH = 0f, perspV = 0f, expand = 0f
                    ) else e0
                    var bmp = try { ImageProcessor.render(src, e) } catch (t: OutOfMemoryError) {
                        System.gc()
                        try {
                            val s = Bitmap.createScaledBitmap(src, src.width / 2, src.height / 2, true)
                            ImageProcessor.render(s, e)
                        } catch (t2: Throwable) { null }
                    } catch (t: Throwable) { null }
                    if (bmp != null) withContext(Dispatchers.Main) { preview = bmp }
                }
            }
        }
        renderReq.trySend(Unit)
    }

    // ---------------------------------------------------------------- retouch (أدوات بكسلية)

    /** true أثناء فتح تبويب الريتوش: المعاينة بتتعرض من غير قص/تدوير عشان الإحداثيات تطابق المصدر. */
    var retouchActive by mutableStateOf(false)
        private set
    var rtTool by mutableStateOf(0)
    var rtSize by mutableStateOf(0.05f)
    var rtStrength by mutableStateOf(0.5f)
    var rtHard by mutableStateOf(0.5f)
    var rtTol by mutableStateOf(0.3f)
    var rtColor by mutableStateOf(0xFFFFFFFF.toInt())
    var rtColor2 by mutableStateOf(0x00000000)
    var rtCanUndo by mutableStateOf(false)
        private set
    var rtCloneSet by mutableStateOf(false)
        private set
    private var rtSrc: Pair<Float, Float>? = null
    private var rtOff: Pair<Float, Float>? = null
    private var rtLast: Pair<Float, Float>? = null
    private var rtGradStart: Pair<Float, Float>? = null
    private val rtUndo = ArrayDeque<Bitmap>()
    private var rtSaveJob: Job? = null

    fun setRetouchActive(on: Boolean) {
        if (retouchActive == on) return
        retouchActive = on
        if (!on) selClear()
        scheduleRender(immediate = true)
    }

    val canRetouch: Boolean get() = data?.sourceUri != null

    private fun rtBitmap(): Bitmap? {
        val s = source ?: return null
        if (!s.isMutable) {
            val m = s.copy(Bitmap.Config.ARGB_8888, true) ?: return null
            source = m
            return m
        }
        return s
    }

    private fun rtPush() {
        val b = source ?: return
        rtUndo.addLast(b.copy(Bitmap.Config.ARGB_8888, true))
        while (rtUndo.size > 6) rtUndo.removeFirst().recycle()
        rtCanUndo = true
    }

    /** يقصّ آخر ضربة على التحديد: برّه التحديد بيرجع للبكسلات القديمة. */
    private fun rtClip() {
        val s = sel ?: return
        if (!selActive) return
        val b = source ?: return
        val prev = rtUndo.lastOrNull() ?: return
        if (s.w != b.width || s.h != b.height || prev.width != b.width || prev.height != b.height) return
        val w = b.width; val h = b.height
        val cur = IntArray(w * h); val old = IntArray(w * h)
        b.getPixels(cur, 0, w, 0, 0, w, h)
        prev.getPixels(old, 0, w, 0, 0, w, h)
        for (i in cur.indices) {
            val m = s.m[i].toInt() and 255
            if (m == 255 || cur[i] == old[i]) continue
            if (m == 0) { cur[i] = old[i]; continue }
            val t = m / 255f
            fun ch(sh: Int) = (((old[i] shr sh) and 255) * (1 - t) + ((cur[i] shr sh) and 255) * t).toInt()
            cur[i] = (ch(24) shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
        }
        b.setPixels(cur, 0, w, 0, 0, w, h)
    }

    private fun rtDone() {
        scheduleRender(immediate = true)
        rtSaveJob?.cancel()
        rtSaveJob = viewModelScope.launch {
            delay(900)
            val b = source ?: return@launch
            val d = data ?: return@launch
            val f = withContext(Dispatchers.IO) {
                runCatching {
                    val file = java.io.File(repo.dir(projectId), "retouch.png")
                    file.outputStream().use { os -> b.compress(Bitmap.CompressFormat.PNG, 100, os) }
                    file
                }.getOrNull()
            }
            if (f != null) {
                data = d.copy(retouchUri = Uri.fromFile(f).toString())
                scheduleSave()
            }
        }
    }

    fun rtUndoLast() {
        val prev = rtUndo.removeLastOrNull() ?: return
        source = prev
        rtCanUndo = rtUndo.isNotEmpty()
        rtDone()
    }

    /** يرجّع الصورة الأصلية ويلغي كل تعديلات الريتوش. */
    fun rtReset() {
        val d = data ?: return
        val u = d.sourceUri ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val src = BitmapLoader.load(getApplication(), Uri.parse(u), 1280) ?: return@launch
            withContext(Dispatchers.Main) {
                rtUndo.clear(); rtCanUndo = false
                source = src
                original = src
                data = d.copy(retouchUri = null)
                scheduleRender(immediate = true)
                scheduleSave()
            }
        }
    }

    private fun px(nx: Float, ny: Float): Pair<Float, Float>? {
        val b = source ?: return null
        return nx.coerceIn(0f, 1f) * (b.width - 1) to ny.coerceIn(0f, 1f) * (b.height - 1)
    }

    private fun radius(): Float {
        val b = source ?: return 10f
        return (rtSize * minOf(b.width, b.height)).coerceAtLeast(3f)
    }

    fun rtLongPress(nx: Float, ny: Float) {
        if (rtTool != 1 && rtTool != 2) return
        rtSrc = px(nx, ny)
        rtCloneSet = rtSrc != null
        message = "اتحددت نقطة النسخ. اسحب في المكان اللي عايز تنسخ عليه"
    }

    private val rtTapTools = setOf(3, 13, 15, 16, 17)

    fun rtStart(nx: Float, ny: Float) {
        if (rtTool in selTools) { if (rtTool != 21) selDragStart(nx, ny); return }
        if (rtTool in rtTapTools) return
        val p = px(nx, ny) ?: return
        if (rtTool == 14) { rtGradStart = p; rtLast = p; return }
        if (rtTool == 1 || rtTool == 2) {
            val s = rtSrc
            if (s == null) { message = "اضغط مطوّلًا على نقطة النسخ الأول"; rtLast = null; return }
            rtOff = (s.first - p.first) to (s.second - p.second)
        }
        rtBitmap() ?: return
        rtPush()
        rtLast = p
        dab(p, p)
    }

    fun rtMove(nx: Float, ny: Float) {
        if (rtTool in selTools) { if (rtTool != 21) selDragMove(nx, ny); return }
        val p = px(nx, ny) ?: return
        val last = rtLast ?: return
        if (rtTool == 14) { rtLast = p; return }
        val step = (radius() * 0.25f).coerceAtLeast(1.5f)
        val dist = kotlin.math.hypot(p.first - last.first, p.second - last.second)
        if (dist < step) return
        val n = (dist / step).toInt()
        var prev = last
        for (i in 1..n) {
            val t = i.toFloat() / n
            val q = (last.first + (p.first - last.first) * t) to (last.second + (p.second - last.second) * t)
            dab(q, prev)
            prev = q
        }
        rtLast = p
        scheduleRender()
    }

    fun rtEnd() {
        if (rtTool in selTools) { if (rtTool != 21) selDragEnd(); return }
        if (rtTool == 14) {
            val a = rtGradStart
            val z = rtLast
            if (a != null && z != null && rtBitmap() != null) {
                rtPush()
                Retouch.gradient(source!!, a.first, a.second, z.first, z.second, rtColor, rtColor2)
                rtClip(); rtDone()
            }
            rtGradStart = null
            rtLast = null
            return
        }
        if (rtLast != null) { rtClip(); rtDone() }
        rtLast = null
    }

    private fun dab(p: Pair<Float, Float>, prev: Pair<Float, Float>) {
        val b = source ?: return
        val r = radius()
        val (x, y) = p
        val k = rtStrength
        val h = rtHard
        when (rtTool) {
            0 -> Retouch.erase(b, x, y, r, h, k)
            1, 2 -> rtOff?.let { Retouch.clone(b, x, y, r, h, k, it.first, it.second, rtTool == 2) }
            4 -> Retouch.blur(b, x, y, r, h, k)
            5 -> Retouch.sharpen(b, x, y, r, h, k)
            6 -> Retouch.smudge(b, x, y, r, h, k, x - prev.first, y - prev.second)
            7 -> Retouch.exposure(b, x, y, r, h, k, true)
            8 -> Retouch.exposure(b, x, y, r, h, k, false)
            9 -> Retouch.sponge(b, x, y, r, h, k, true)
            10 -> Retouch.sponge(b, x, y, r, h, k, false)
            11 -> Retouch.colorReplace(b, x, y, r, h, k, rtColor)
            12 -> Retouch.liquify(b, x, y, r, h, k, (x - prev.first) * 1.2f, (y - prev.second) * 1.2f)
        }
    }

    fun rtTap(nx: Float, ny: Float) {
        if (rtTool == 21) { selWand(nx, ny, wandContiguous); return }
        if (rtTool in selTools) return
        if (rtTool !in rtTapTools) {
            if (rtTool != 14) { rtStart(nx, ny); rtEnd() }
            return
        }
        val p = px(nx, ny) ?: return
        val b = rtBitmap() ?: return
        when (rtTool) {
            3 -> { rtPush(); Retouch.spotHeal(b, p.first, p.second, radius()); rtClip(); rtDone() }
            13 -> { rtPush(); Retouch.redEye(b, p.first, p.second, radius()); rtClip(); rtDone() }
            15 -> { rtPush(); Retouch.flood(b, p.first.toInt(), p.second.toInt(), rtTol, rtColor); rtClip(); rtDone() }
            16 -> { rtPush(); Retouch.flood(b, p.first.toInt(), p.second.toInt(), rtTol, 0); rtClip(); rtDone() }
            17 -> { rtColor = Retouch.pick(b, p.first.toInt(), p.second.toInt()) or (0xFF shl 24); message = "اتاخد اللون" }
        }
    }

    // ---------------------------------------------------------------- تحسين تلقائي + ألوان الصورة + شبكة

    var showGrid by mutableStateOf(false)
    var palette by mutableStateOf<List<Int>>(emptyList())

    /** تحسين تلقائي: يمدّ المستويات من الهيستوجرام ويظبط الجاما والحيوية. */
    fun autoEnhance() {
        val b = source ?: return
        viewModelScope.launch(Dispatchers.Default) {
            val w = b.width; val h = b.height
            val px = IntArray(w * h)
            b.getPixels(px, 0, w, 0, 0, w, h)
            val hist = IntArray(256)
            var n = 0
            var sum = 0.0
            var i = 0
            while (i < px.size) {
                val c = px[i]
                val l = (0.299 * ((c shr 16) and 255) + 0.587 * ((c shr 8) and 255) + 0.114 * (c and 255)).toInt().coerceIn(0, 255)
                hist[l]++; n++; sum += l
                i += 3
            }
            if (n == 0) return@launch
            fun pct(p: Float): Int {
                var acc = 0
                val t = (n * p).toInt()
                for (k in 0..255) { acc += hist[k]; if (acc >= t) return k }
                return 255
            }
            val black = (pct(0.01f) / 255f).coerceAtMost(0.25f)
            val white = (pct(0.99f) / 255f).coerceAtLeast(0.75f)
            val mean = ((sum / n) / 255.0).toFloat()
            val st = ((mean - black) / (white - black)).coerceIn(0.05f, 0.95f)
            val gamma = (Math.log(st.toDouble()) / Math.log(0.46)).toFloat().coerceIn(0.7f, 1.5f)
            withContext(Dispatchers.Main) {
                commit { it.copy(fx = it.fx.copy(lvBlack = black, lvWhite = white, lvGamma = gamma, vibrance = maxOf(it.fx.vibrance, 0.15f))) }
                message = "اتحسّنت الصورة تلقائيًا"
            }
        }
    }

    /** يستخرج أهم 6 ألوان من الصورة. */
    fun extractPalette() {
        val b = source ?: return
        viewModelScope.launch(Dispatchers.Default) {
            val s = Bitmap.createScaledBitmap(b, 64, 64, true)
            val px = IntArray(64 * 64)
            s.getPixels(px, 0, 64, 0, 0, 64, 64)
            if (s !== b) s.recycle()
            val cnt = HashMap<Int, Int>()
            for (c in px) {
                val k = (((c shr 16) and 255) / 40 shl 16) or (((c shr 8) and 255) / 40 shl 8) or ((c and 255) / 40)
                cnt[k] = (cnt[k] ?: 0) + 1
            }
            val res = ArrayList<Int>()
            for ((k, _) in cnt.entries.sortedByDescending { it.value }) {
                val r = ((k shr 16) and 255) * 40 + 20; val g = ((k shr 8) and 255) * 40 + 20; val bl = (k and 255) * 40 + 20
                val col = (0xFF shl 24) or (r.coerceAtMost(255) shl 16) or (g.coerceAtMost(255) shl 8) or bl.coerceAtMost(255)
                val far = res.all { o ->
                    kotlin.math.abs(((o shr 16) and 255) - r) + kotlin.math.abs(((o shr 8) and 255) - g) + kotlin.math.abs((o and 255) - bl) > 90
                }
                if (far) res.add(col)
                if (res.size >= 6) break
            }
            withContext(Dispatchers.Main) { palette = res }
        }
    }

    // ---------------------------------------------------------------- أدوات ذكية (حذف عنصر / تجميل وجه)

    /** يحذف العنصر المحدّد ويعيد بناء الخلفية خلفه. */
    fun selInpaint() {
        val s = sel ?: run { message = "حدّد العنصر اللي عايز تحذفه الأول (لاسو أو فرشاة تحديد)"; return }
        val b = rtBitmap() ?: return
        if (s.w != b.width || s.h != b.height) { selClear(); return }
        rtPush()
        processing = "جاري حذف العنصر..."
        val mask = s.m.copyOf()
        viewModelScope.launch(Dispatchers.Default) {
            // OpenCV (Telea) لو متاحة، وإلا الخوارزمية الداخلية
            val ok = try { CvTools.inpaint(b, mask) } catch (t: Throwable) { false }
            if (!ok) { try { Inpaint.fill(b, mask) } catch (t: Throwable) { } }
            withContext(Dispatchers.Main) {
                processing = null
                selClear()
                rtDone()
                message = "اتحذف العنصر"
            }
        }
    }

    /** أدوات OpenCV على الصورة: 0 إزالة ضوضاء، 1 تفاصيل HDR، 2 كرتون، 3 رسم رصاص، 4 تنعيم ذكي. */
    fun cvTool(kind: Int, strength: Float = 0.5f) {
        val b = rtBitmap() ?: return
        rtPush()
        processing = "جاري المعالجة..."
        viewModelScope.launch {
            val ok = withContext(Dispatchers.Default) { try { CvTools.apply(b, kind, strength) } catch (t: Throwable) { false } }
            processing = null
            if (!ok) { message = "تعذّر تشغيل مكتبة المعالجة"; rtUndoLast(); return@launch }
            rtDone()
        }
    }

    /** مؤثرات GPU (GPUImage) على الصورة. */
    fun gpuTool(kind: Int) {
        val b = rtBitmap() ?: return
        rtPush()
        processing = "جاري المعالجة..."
        viewModelScope.launch {
            val ok = withContext(Dispatchers.Default) { GpuFx.apply(getApplication(), b, kind) }
            processing = null
            if (!ok) { message = "تعذّر تطبيق المؤثر"; rtUndoLast(); return@launch }
            rtDone()
        }
    }

    /** استخراج النص من الصورة (لاتيني/أرقام) كطبقة نص. */
    fun ocrToLayer() {
        val b = source ?: return
        processing = "جاري قراءة النص..."
        viewModelScope.launch {
            val t = withContext(Dispatchers.Default) { ScanTools.ocr(b.copy(Bitmap.Config.ARGB_8888, false)) }
            processing = null
            if (t.isNullOrBlank()) { message = "مفيش نص واضح اتلقى (بيدعم الإنجليزي والأرقام)"; return@launch }
            addText(t.trim(), 0.045f)
            message = "اتضاف النص المستخرج"
        }
    }

    /** يحلّل محتوى الصورة ويقترح فلتر مناسب. */
    fun autoLook() {
        val b = source ?: return
        processing = "جاري تحليل الصورة..."
        viewModelScope.launch {
            val labs = withContext(Dispatchers.Default) { ScanTools.labels(b.copy(Bitmap.Config.ARGB_8888, false)) }
            processing = null
            if (labs == null) { message = "تعذّر تحليل الصورة"; return@launch }
            val id = ScanTools.suggestLook(labs)
            commit { it.copy(lookId = id, lookStrength = 0.85f) }
            message = "اكتشفت: ${labs.take(3).joinToString("، ")} ← طبّقت فلتر مناسب"
        }
    }

    fun addQrLayer(text: String) {
        val f = QrTool.makeFile(getApplication(), text)
        if (f == null) { message = "تعذّر عمل الـ QR"; return }
        addImageLayer(Uri.fromFile(f))
    }

    /** ترجمة نصوص الطبقات (كلها أو طبقة واحدة). */
    fun translateTexts(target: String, onlyId: Long? = null) {
        val layers = edit.texts.filter { it.shape == 0 && it.text.isNotBlank() && (onlyId == null || it.id == onlyId) }
        if (layers.isEmpty()) { message = "مفيش نصوص للترجمة"; return }
        processing = "جاري الترجمة..."
        viewModelScope.launch {
            val res = TextTranslate.translate(layers.map { it.text }, target)
            processing = null
            if (res == null) { message = "فشلت الترجمة (محتاج إنترنت أول مرة لتحميل اللغة)"; return@launch }
            val map = layers.map { it.id }.zip(res).toMap()
            commit { e -> e.copy(texts = e.texts.map { t -> map[t.id]?.let { t.copy(text = it) } ?: t }) }
        }
    }

    /** تحديد الشخص تلقائيًا (بنموذج الـ Selfie Segmentation). */
    fun selSubject() {
        val b = source ?: return
        processing = "جاري تحديد الشخص..."
        viewModelScope.launch {
            val m = withContext(Dispatchers.Default) { BackgroundRemover.mask(b.copy(Bitmap.Config.ARGB_8888, false)) }
            if (m == null) { processing = null; message = "تعذّر تحديد الشخص"; return@launch }
            val (conf, mw, mh) = m
            val w = b.width; val h = b.height
            val out = withContext(Dispatchers.Default) {
                val o = ByteArray(w * h)
                for (y in 0 until h) {
                    val my = (y.toLong() * mh / h).toInt().coerceIn(0, mh - 1)
                    for (x in 0 until w) {
                        val mx = (x.toLong() * mw / w).toInt().coerceIn(0, mw - 1)
                        val t = ((conf[my * mw + mx] - 0.35f) / 0.3f).coerceIn(0f, 1f)
                        o[y * w + x] = (t * t * (3f - 2f * t) * 255f).toInt().toByte()
                    }
                }
                o
            }
            processing = null
            selMode = 0
            applySel(out)
            if (!selActive) message = "مفيش شخص اتلقى في الصورة"
        }
    }

    /** قص ذكي: يركّز القص على أكبر وجه. */
    fun smartCropFace() {
        val b = source ?: return
        val e = edit
        if (e.rotation != 0 || e.flipH || e.flipV) { message = "الغي التدوير والقلب الأول"; return }
        processing = "جاري اكتشاف الوجه..."
        viewModelScope.launch {
            val faces = withContext(Dispatchers.Default) { FaceTools.detect(b.copy(Bitmap.Config.ARGB_8888, false)) }
            processing = null
            val f = faces?.maxByOrNull { it.width() * it.height() }
            if (f == null) { message = "مفيش وجه اتلقى"; return@launch }
            val cx = (f.centerX().toFloat() / b.width).coerceIn(0f, 1f)
            val cy = (f.centerY().toFloat() / b.height).coerceIn(0f, 1f)
            val zoom = (1f / (f.height().toFloat() / b.height * 3.2f)).coerceIn(1f, 4f)
            commit { it.copy(cropAspect = if (it.cropAspect == 0f) 1f else it.cropAspect, cropZoom = zoom, cropCx = cx, cropCy = cy) }
            message = "اتقص على الوجه"
        }
    }

    /** يكتشف الوجوه وينعّم البشرة. */
    fun beautifyFaces(strength: Float) {
        val b = rtBitmap() ?: return
        processing = "جاري اكتشاف الوجوه..."
        viewModelScope.launch {
            val faces = withContext(Dispatchers.Default) { FaceTools.detect(b.copy(Bitmap.Config.ARGB_8888, false)) }
            if (faces == null) { processing = null; message = "تعذّر اكتشاف الوجوه"; return@launch }
            if (faces.isEmpty()) { processing = null; message = "مفيش وجوه اتلقت في الصورة"; return@launch }
            rtPush()
            withContext(Dispatchers.Default) { FaceTools.smooth(b, faces, strength, strength) }
            processing = null
            rtDone()
            message = "اتجمّل ${faces.size} وجه"
        }
    }

    // ---------------------------------------------------------------- التحديد (Selection)
    private var sel: Selection? = null
    var selActive by mutableStateOf(false)
    var selMode by mutableStateOf(0)          // 0 جديد، 1 إضافة، 2 طرح
    var selFeather by mutableStateOf(0.0f)
    var selOverlay by mutableStateOf<android.graphics.Bitmap?>(null)
    private val selTools = setOf(18, 19, 20, 21)
    val rtIsSelTool: Boolean get() = rtTool in selTools
    private var selPts = ArrayList<Pair<Float, Float>>()
    var selDrag by mutableStateOf<List<Float>>(emptyList())   // نقاط معيارية للرسم الحي

    private fun refreshSelOverlay() {
        val s = sel
        if (s == null || !selActive) { selOverlay = null; return }
        // تغميق خارج التحديد بنسخة مصغّرة عشان الأداء
        val sc = if (maxOf(s.w, s.h) > 640) 640f / maxOf(s.w, s.h) else 1f
        val ow = (s.w * sc).toInt().coerceAtLeast(1); val oh = (s.h * sc).toInt().coerceAtLeast(1)
        val px = IntArray(ow * oh)
        for (y in 0 until oh) for (x in 0 until ow) {
            val m = s.m[(y / sc).toInt().coerceAtMost(s.h - 1) * s.w + (x / sc).toInt().coerceAtMost(s.w - 1)].toInt() and 255
            px[y * ow + x] = ((150 * (255 - m) / 255) shl 24) or 0x101830
        }
        selOverlay = Bitmap.createBitmap(px, ow, oh, Bitmap.Config.ARGB_8888)
    }

    private fun applySel(mask: ByteArray) {
        val b = source ?: return
        var s = sel
        if (s == null || s.w != b.width || s.h != b.height) { s = Selection(b.width, b.height); sel = s }
        val m = if (selMode == 0 || s.isEmpty) 0 else selMode
        if (m != 0 && s.isEmpty) s.m = mask else s.combine(mask, if (selMode == 0) 0 else m)
        if (s.isEmpty) { selActive = false; sel = null } else { selActive = true }
        refreshSelOverlay()
    }

    fun selClear() { sel = null; selActive = false; selOverlay = null; selDrag = emptyList() }

    fun selInvert() {
        val b = source ?: return
        var s = sel
        if (s == null) { s = Selection(b.width, b.height); s.all(); sel = s } else s.invert()
        if (s.isEmpty) { selClear(); return }
        selActive = true; refreshSelOverlay()
    }

    fun selAll() {
        val b = source ?: return
        val s = Selection(b.width, b.height); s.all(); sel = s; selActive = true; refreshSelOverlay()
    }

    fun selDoFeather(r: Int) {
        val s = sel ?: return
        viewModelScope.launch(Dispatchers.Default) {
            s.feather(r)
            withContext(Dispatchers.Main) { refreshSelOverlay() }
        }
    }

    fun selDragStart(nx: Float, ny: Float) {
        selPts.clear(); px(nx, ny)?.let { selPts.add(it) }
        selDrag = listOf(nx.coerceIn(0f, 1f), ny.coerceIn(0f, 1f), nx.coerceIn(0f, 1f), ny.coerceIn(0f, 1f))
    }

    fun selDragMove(nx: Float, ny: Float) {
        val p = px(nx, ny) ?: return
        if (rtTool == 20) {
            selPts.add(p)
            selDrag = selDrag + listOf(nx.coerceIn(0f, 1f), ny.coerceIn(0f, 1f))
        } else if (selDrag.size >= 2) {
            selDrag = listOf(selDrag[0], selDrag[1], nx.coerceIn(0f, 1f), ny.coerceIn(0f, 1f))
            if (selPts.size > 1) selPts.removeAt(1)
            selPts.add(p)
        }
    }

    fun selDragEnd() {
        val b = source
        val pts = selPts.toList()
        selPts.clear(); selDrag = emptyList()
        if (b == null || pts.size < 2) return
        val w = b.width; val h = b.height
        viewModelScope.launch(Dispatchers.Default) {
            val mask = when (rtTool) {
                18 -> Selection.rect(w, h, pts.first().first, pts.first().second, pts.last().first, pts.last().second)
                19 -> Selection.ellipse(w, h, pts.first().first, pts.first().second, pts.last().first, pts.last().second)
                else -> Selection.polygon(w, h, pts)
            }
            withContext(Dispatchers.Main) { applySel(mask) }
        }
    }

    fun selWand(nx: Float, ny: Float, contiguous: Boolean) {
        val b = source ?: return
        val p = px(nx, ny) ?: return
        val tol = rtTol
        viewModelScope.launch(Dispatchers.Default) {
            val mask = Selection.wand(b, p.first.toInt(), p.second.toInt(), tol, contiguous)
            withContext(Dispatchers.Main) { applySel(mask) }
        }
    }

    var wandContiguous by mutableStateOf(true)

    /** يطبّق ممحاة/تعبئة داخل التحديد. mode: 0 حذف، 1 تعبئة بلون الريتوش. */
    fun selFillOrDelete(mode: Int) {
        val s = sel ?: run { message = "حدّد منطقة الأول"; return }
        val b = rtBitmap() ?: return
        if (s.w != b.width || s.h != b.height) { selClear(); return }
        rtPush()
        val w = b.width; val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        val fill = rtColor or (0xFF shl 24)
        for (i in px.indices) {
            val m = s.m[i].toInt() and 255
            if (m == 0) continue
            val a = m / 255f
            if (mode == 0) {
                val oa = ((px[i] ushr 24) * (1f - a)).toInt()
                px[i] = (oa shl 24) or (px[i] and 0xFFFFFF)
            } else {
                val r = (((px[i] shr 16) and 255) * (1 - a) + ((fill shr 16) and 255) * a).toInt()
                val g = (((px[i] shr 8) and 255) * (1 - a) + ((fill shr 8) and 255) * a).toInt()
                val bl = ((px[i] and 255) * (1 - a) + (fill and 255) * a).toInt()
                val al = maxOf(px[i] ushr 24, (255 * a).toInt())
                px[i] = (al shl 24) or (r shl 16) or (g shl 8) or bl
            }
        }
        b.setPixels(px, 0, w, 0, 0, w, h)
        rtDone()
    }

    /** ينسخ المنطقة المحدّدة لطبقة صورة جديدة. */
    fun selToLayer() {
        val s = sel ?: run { message = "حدّد منطقة الأول"; return }
        val b = source ?: return
        if (s.w != b.width || s.h != b.height) return
        viewModelScope.launch(Dispatchers.IO) {
            var x0 = s.w; var y0 = s.h; var x1 = -1; var y1 = -1
            for (y in 0 until s.h) for (x in 0 until s.w) if ((s.m[y * s.w + x].toInt() and 255) > 8) {
                if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y
            }
            if (x1 < x0 || y1 < y0) return@launch
            val bw = x1 - x0 + 1; val bh = y1 - y0 + 1
            val px = IntArray(bw * bh)
            val src = IntArray(s.w * s.h)
            b.getPixels(src, 0, s.w, 0, 0, s.w, s.h)
            for (y in 0 until bh) for (x in 0 until bw) {
                val i = (y + y0) * s.w + (x + x0)
                val m = s.m[i].toInt() and 255
                val c = src[i]
                px[y * bw + x] = (((c ushr 24) * m / 255) shl 24) or (c and 0xFFFFFF)
            }
            val out = Bitmap.createBitmap(px, bw, bh, Bitmap.Config.ARGB_8888)
            val id = ++layerSeed
            val file = java.io.File(repo.dir(projectId), "sel_$id.png")
            val ok = runCatching { file.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) } }.isSuccess
            if (!ok) { withContext(Dispatchers.Main) { message = "تعذّر النسخ" }; return@launch }
            val uri = Uri.fromFile(file)
            ImageCache.load(getApplication(), uri.toString())
            val layer = TextLayer(
                id = id, text = "", shape = 9, imageUri = uri.toString(), aspect = bw.toFloat() / bh,
                x = (x0 + bw / 2f) / s.w, y = (y0 + bh / 2f) / s.h,
                size = bh.toFloat() / s.h, shadow = false, bold = false,
            )
            withContext(Dispatchers.Main) { commit { it.copy(texts = it.texts + layer) }; selectedLayer = id; message = "اتنسخت لطبقة جديدة (روح لتبويب الستيكر)" }
        }
    }

    /** قصّ الصورة على حدود التحديد (Crop to selection) — بيحوّل التحديد لطبقة وبيمسح الباقي. */
    fun selKeepOnly() {
        val s = sel ?: return
        s.invert()
        selFillOrDelete(0)
        s.invert()
    }

    // ---------------------------------------------------------------- persistence

    private fun snapshot(): Project? {
        val p = project ?: return null
        val d = data ?: return null
        val updated = p.copy(image = d.copy(edit = edit), updatedAt = System.currentTimeMillis())
        project = updated
        return updated
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(900)
            val u = snapshot() ?: return@launch
            withContext(Dispatchers.IO) { repo.save(u) }
        }
    }

    /** حفظ متزامن (بيتنادى عند الخروج، وقت ما الـ scope ممكن يكون اتلغى). */
    fun saveNow() {
        val u = snapshot() ?: return
        repo.save(u)
        val thumb = preview ?: return
        val e = u.image!!.edit
        kotlin.concurrent.thread {
            runCatching {
                val t = thumb.copy(Bitmap.Config.ARGB_8888, true)
                ImageProcessor.drawOverlays(Canvas(t), t.width.toFloat(), t.height.toFloat(), e.strokes, e.texts)
                repo.saveThumb(u.id, t)
            }
        }
    }

    fun rename(name: String) {
        val p = project ?: return
        project = p.copy(name = name)
        saveNow()
    }

    override fun onCleared() {
        saveNow()
        super.onCleared()
    }

    // ---------------------------------------------------------------- export

    /** تصدير بجودة كاملة وحفظ في المعرض. onDone بيتنادى على الـ Main بالـ Uri أو null لو فشل. */
    fun export(fmt: ExportFormat, quality: Int, scalePercent: Int, watermark: Boolean, onDone: (Uri?) -> Unit) {
        val d = data ?: return
        val e0 = edit
        exporting = true
        viewModelScope.launch(Dispatchers.Default) {
            val result: Uri? = try {
                var full: Bitmap? = if (d.sourceUri != null) {
                    BitmapLoader.load(getApplication(), Uri.parse(d.retouchUri ?: d.sourceUri), 4096)
                        ?: BitmapLoader.load(getApplication(), Uri.parse(d.retouchUri ?: d.sourceUri), 2048)
                } else BitmapLoader.blank(d.blankW, d.blankH, d.blankColor)
                if (full == null) throw IllegalStateException("تعذر تحميل الصورة")
                val e = if (watermark)
                    e0.copy(texts = e0.texts + com.binarybeast.mediastudio.data.Brand.watermarkLayers(getApplication(), full.width.toFloat() / full.height))
                else e0
                ImageCache.preload(getApplication(), e.texts)
                var out = ImageProcessor.renderFull(full, e)
                full = null
                if (d.sourceUri == null && android.graphics.Color.alpha(d.blankColor) == 0 && fmt != ExportFormat.PNG) {
                    // JPG/WEBP مش بيدعموا الشفافية: نحط خلفية بيضا بدل الأسود
                    val flat = Bitmap.createBitmap(out.width, out.height, Bitmap.Config.ARGB_8888)
                    val c = Canvas(flat)
                    c.drawColor(android.graphics.Color.WHITE)
                    c.drawBitmap(out, 0f, 0f, null)
                    out = flat
                }
                if (scalePercent > 100) {
                    val k = scalePercent / 100f
                    if (out.width.toLong() * k * out.height * k <= 36_000_000L) out = ImageProcessor.upscale(out, k)
                    MediaRepository.saveImage(getApplication(), out, fmt, quality)
                } else if (scalePercent < 0) {
                    // كل المقاسات: كامل + 50% + 25% (بيرجّع الكامل للمشاركة/السحابة)
                    val first = MediaRepository.saveImage(getApplication(), out, fmt, quality)
                    for (k in listOf(0.5f, 0.25f)) {
                        val s = Bitmap.createScaledBitmap(out, (out.width * k).toInt().coerceAtLeast(1), (out.height * k).toInt().coerceAtLeast(1), true)
                        MediaRepository.saveImage(getApplication(), s, fmt, quality)
                        if (s !== out) s.recycle()
                    }
                    first
                } else {
                    if (scalePercent < 100) {
                        val k = scalePercent / 100f
                        out = Bitmap.createScaledBitmap(out, (out.width * k).toInt().coerceAtLeast(1), (out.height * k).toInt().coerceAtLeast(1), true)
                    }
                    MediaRepository.saveImage(getApplication(), out, fmt, quality)
                }
            } catch (t: Throwable) {
                null
            }
            withContext(Dispatchers.Main) {
                exporting = false
                if (result == null) message = "فشل التصدير"
                onDone(result)
            }
        }
    }

    @Suppress("unused")
    private fun unusedFactoryRef() = ProjectFactory.defaultName("")
}
