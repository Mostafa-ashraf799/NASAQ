package com.binarybeast.mediastudio.ui

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.DocumentsContract
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import androidx.compose.runtime.mutableStateListOf
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** عمليات نقل الملفات من/إلى السحابة في الخلفية. الحالة تظهر داخل التطبيق + إشعار (خدمة أمامية). */
object Transfers {
    data class Item(
        val id: Long,
        val name: String,
        val upload: Boolean,
        /** -1 = غير محدد. */
        val progress: Int = -1,
        /** 0 شغال، 1 خلص، 2 فشل. */
        val state: Int = 0,
        val uri: Uri? = null,
        val kind: CloudOpenKind? = null,
    )

    val items = mutableStateListOf<Item>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var seed = System.nanoTime()

    val activeCount: Int get() = items.count { it.state == 0 }

    private suspend fun update(id: Long, f: (Item) -> Item) = withContext(Dispatchers.Main) {
        val i = items.indexOfFirst { it.id == id }
        if (i >= 0) items[i] = f(items[i])
        if (activeCount == 0) stopService()
    }

    private lateinit var appCtx: Context

    private fun ensureService(ctx: Context) {
        appCtx = ctx.applicationContext
        runCatching { ContextCompat.startForegroundService(appCtx, Intent(appCtx, TransferService::class.java)) }
    }

    private fun stopService() {
        if (::appCtx.isInitialized) runCatching { appCtx.stopService(Intent(appCtx, TransferService::class.java)) }
    }

    fun clearFinished() { items.removeAll { it.state != 0 } }

    private suspend fun add(it: Item) = withContext(Dispatchers.Main) { items.add(0, it) }

    fun kindOf(mime: String?, name: String): CloudOpenKind? {
        var m = mime ?: ""
        if (!(m.startsWith("image/") || m.startsWith("video/") || m.startsWith("audio/"))) {
            m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: m
        }
        return when {
            m.startsWith("image/") -> CloudOpenKind.IMAGE
            m.startsWith("video/") -> CloudOpenKind.VIDEO
            m.startsWith("audio/") -> CloudOpenKind.AUDIO
            else -> null
        }
    }

    fun download(ctx: Context, url: String, ua: String?, mime: String?, disposition: String?) {
        ensureService(ctx)
        val id = ++seed
        val name0 = android.webkit.URLUtil.guessFileName(url, disposition, mime)
        val cookie = CookieManager.getInstance().getCookie(url)
        scope.launch {
            add(Item(id, name0, false))
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.instanceFollowRedirects = true
                conn.connectTimeout = 20000
                conn.readTimeout = 60000
                if (cookie != null) conn.setRequestProperty("Cookie", cookie)
                if (ua != null) conn.setRequestProperty("User-Agent", ua)
                val total = conn.contentLengthLong
                val dir = File(appCtx.filesDir, "cloud").apply { mkdirs() }
                var f = File(dir, name0)
                var n = 1
                while (f.exists()) f = File(dir, "${n++}_$name0")
                var done = 0L
                var last = -1
                conn.inputStream.use { ins ->
                    f.outputStream().use { os ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val r = ins.read(buf)
                            if (r < 0) break
                            os.write(buf, 0, r)
                            done += r
                            if (total > 0) {
                                val p = (done * 100 / total).toInt()
                                if (p != last) { last = p; update(id) { it.copy(progress = p) } }
                            }
                        }
                    }
                }
                conn.disconnect()
                val type = conn.contentType ?: mime
                update(id) { it.copy(state = 1, progress = 100, name = f.name, uri = Uri.fromFile(f), kind = kindOf(mime ?: type, f.name)) }
            } catch (e: Throwable) {
                update(id) { it.copy(state = 2) }
            }
        }
    }

    fun upload(ctx: Context, tree: Uri, files: List<Uri>) {
        ensureService(ctx)
        val cr = appCtx.contentResolver
        for (src in files) {
            val id = ++seed
            val name = CloudUploader.displayName(appCtx, src)
            scope.launch {
                add(Item(id, name, true))
                try {
                    val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
                    val mime = cr.getType(src) ?: "application/octet-stream"
                    val dst = DocumentsContract.createDocument(cr, parent, mime, name) ?: error("create failed")
                    val total = runCatching { cr.openAssetFileDescriptor(src, "r")?.use { it.length } }.getOrNull() ?: -1L
                    var done = 0L
                    var last = -1
                    cr.openInputStream(src)!!.use { ins ->
                        cr.openOutputStream(dst)!!.use { os ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val r = ins.read(buf)
                                if (r < 0) break
                                os.write(buf, 0, r)
                                done += r
                                if (total > 0) {
                                    val p = (done * 100 / total).toInt()
                                    if (p != last) { last = p; update(id) { it.copy(progress = p) } }
                                }
                            }
                        }
                    }
                    update(id) { it.copy(state = 1, progress = 100) }
                } catch (e: Throwable) {
                    update(id) { it.copy(state = 2) }
                }
            }
        }
    }
}

class TransferService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("transfers", "نقل الملفات", NotificationManager.IMPORTANCE_LOW))
        }
        val n: Notification = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "transfers") else Notification.Builder(this))
            .setContentTitle("نسق")
            .setContentText("جاري نقل الملفات من/إلى السحابة...")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(77, n)
        } catch (e: Throwable) { stopSelf() }
        return START_NOT_STICKY
    }
}
