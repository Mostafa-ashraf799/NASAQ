package com.binarybeast.mediastudio.data

import org.json.JSONArray
import org.json.JSONObject

/** تحويل المشاريع من/إلى JSON باستخدام org.json المدمجة في أندرويد (بدون مكتبات إضافية). */
object ProjectJson {

    fun encode(p: Project): String = JSONObject().apply {
        put("id", p.id)
        put("name", p.name)
        put("type", p.type.name)
        put("createdAt", p.createdAt)
        put("updatedAt", p.updatedAt)
        put("pinned", p.pinned)
        p.image?.let { put("image", imageData(it)) }
        p.video?.let { put("video", videoData(it)) }
        p.audio?.let { put("audio", audioData(it)) }
    }.toString()

    fun decode(s: String): Project {
        val o = JSONObject(s)
        return Project(
            id = o.getString("id"),
            name = o.optString("name", "مشروع"),
            type = ProjectType.valueOf(o.getString("type")),
            createdAt = o.optLong("createdAt"),
            updatedAt = o.optLong("updatedAt"),
            pinned = o.optBoolean("pinned", false),
            image = o.optJSONObject("image")?.let { readImageData(it) },
            video = o.optJSONObject("video")?.let { readVideoData(it) },
            audio = o.optJSONObject("audio")?.let { readAudioData(it) },
        )
    }

    // ---------- writers ----------

    private fun adjust(a: Adjust) = JSONObject()
        .put("b", a.brightness.toDouble()).put("c", a.contrast.toDouble())
        .put("s", a.saturation.toDouble()).put("w", a.warmth.toDouble()).put("h", a.hue.toDouble())

    private fun text(t: TextLayer) = JSONObject()
        .put("id", t.id).put("text", t.text).put("x", t.x.toDouble()).put("y", t.y.toDouble())
        .put("size", t.size.toDouble()).put("rot", t.rotation.toDouble()).put("color", t.color)
        .put("bg", t.bgColor).put("bold", t.bold).put("italic", t.italic).put("font", t.font)
        .put("shadow", t.shadow).put("outline", t.outline).put("opacity", t.opacity.toDouble())
        .put("start", t.startMs).put("end", t.endMs)
        .put("shape", t.shape).put("aspect", t.aspect.toDouble())
        .put("imageUri", t.imageUri ?: JSONObject.NULL)

    private fun stroke(s: Stroke): JSONObject {
        val pts = JSONArray()
        s.pts.forEach { pts.put(it.toDouble()) }
        return JSONObject().put("color", s.color).put("w", s.width.toDouble())
            .put("a", s.alpha.toDouble()).put("pts", pts)
    }

    private fun imageEdit(e: ImageEdit): JSONObject {
        val texts = JSONArray(); e.texts.forEach { texts.put(text(it)) }
        val strokes = JSONArray(); e.strokes.forEach { strokes.put(stroke(it)) }
        return JSONObject()
            .put("adjust", adjust(e.adjust)).put("look", e.lookId).put("lookStrength", e.lookStrength.toDouble())
            .put("sharpen", e.sharpen.toDouble()).put("blur", e.blur.toDouble())
            .put("vignette", e.vignette.toDouble()).put("fade", e.fade.toDouble())
            .put("border", e.border.toDouble()).put("borderColor", e.borderColor)
            .put("rotation", e.rotation).put("flipH", e.flipH).put("flipV", e.flipV)
            .put("cropAspect", e.cropAspect.toDouble()).put("cropZoom", e.cropZoom.toDouble())
            .put("cropCx", e.cropCx.toDouble()).put("cropCy", e.cropCy.toDouble())
            .put("straighten", e.straighten.toDouble()).put("grain", e.grain.toDouble())
            .put("pixelate", e.pixelate.toDouble()).put("corner", e.corner.toDouble())
            .put("fx", imageFx(e.fx))
            .put("texts", texts).put("strokes", strokes)
    }

    private fun imageFx(f: ImageFx) = JSONObject()
        .put("exposure", f.exposure.toDouble()).put("highlights", f.highlights.toDouble())
        .put("shadows", f.shadows.toDouble()).put("whites", f.whites.toDouble())
        .put("blacks", f.blacks.toDouble()).put("tint", f.tint.toDouble())
        .put("vibrance", f.vibrance.toDouble()).put("clarity", f.clarity.toDouble())
        .put("dehaze", f.dehaze.toDouble()).put("chroma", f.chroma.toDouble())
        .put("denoise", f.denoise.toDouble()).put("focus", f.focus.toDouble())
        .put("focusMode", f.focusMode).put("focusX", f.focusX.toDouble()).put("focusY", f.focusY.toDouble())
        .put("filter", f.filter).put("filterAmount", f.filterAmount.toDouble())
        .put("vignetteColor", f.vignetteColor).put("leak", f.leak.toDouble())
        .put("leakStyle", f.leakStyle).put("dust", f.dust.toDouble())

    private fun readImageFx(o: JSONObject?): ImageFx {
        if (o == null) return ImageFx()
        return ImageFx(
            exposure = o.optDouble("exposure", 0.0).toFloat(), highlights = o.optDouble("highlights", 0.0).toFloat(),
            shadows = o.optDouble("shadows", 0.0).toFloat(), whites = o.optDouble("whites", 0.0).toFloat(),
            blacks = o.optDouble("blacks", 0.0).toFloat(), tint = o.optDouble("tint", 0.0).toFloat(),
            vibrance = o.optDouble("vibrance", 0.0).toFloat(), clarity = o.optDouble("clarity", 0.0).toFloat(),
            dehaze = o.optDouble("dehaze", 0.0).toFloat(), chroma = o.optDouble("chroma", 0.0).toFloat(),
            denoise = o.optDouble("denoise", 0.0).toFloat(), focus = o.optDouble("focus", 0.0).toFloat(),
            focusMode = o.optInt("focusMode", 0), focusX = o.optDouble("focusX", 0.5).toFloat(),
            focusY = o.optDouble("focusY", 0.5).toFloat(),
            filter = o.optInt("filter", 0), filterAmount = o.optDouble("filterAmount", 1.0).toFloat(),
            vignetteColor = o.optInt("vignetteColor", 0xFF000000.toInt()),
            leak = o.optDouble("leak", 0.0).toFloat(), leakStyle = o.optInt("leakStyle", 0),
            dust = o.optDouble("dust", 0.0).toFloat(),
        )
    }

    private fun imageData(d: ImageData) = JSONObject()
        .put("source", d.sourceUri ?: JSONObject.NULL)
        .put("blankW", d.blankW).put("blankH", d.blankH).put("blankColor", d.blankColor)
        .put("edit", imageEdit(d.edit))
        .put("retouch", d.retouchUri ?: JSONObject.NULL)

    private fun clip(c: VideoClip) = JSONObject()
        .put("id", c.id).put("uri", c.uri).put("isImage", c.isImage).put("src", c.srcDurationMs)
        .put("start", c.startMs).put("end", c.endMs).put("w", c.width).put("h", c.height)
        .put("speed", c.speed.toDouble()).put("volume", c.volume.toDouble()).put("muted", c.muted)
        .put("rotation", c.rotation).put("flipH", c.flipH).put("fill", c.fill)
        .put("look", c.lookId).put("lookStrength", c.lookStrength.toDouble()).put("adjust", adjust(c.adjust))
        .put("fadeIn", c.fadeInMs).put("fadeOut", c.fadeOutMs).put("zoom", c.zoom.toDouble())
        .put("panX", c.panX.toDouble()).put("panY", c.panY.toDouble()).put("kb", c.kenBurns)
        .put("vfx", c.vfx).put("flipV", c.flipV).put("tint", c.tint.toDouble())

    private fun audioData(a: AudioData) = JSONObject()
        .put("uri", a.uri).put("name", a.name).put("src", a.srcDurationMs)
        .put("start", a.startMs).put("end", a.endMs)
        .put("speed", a.speed.toDouble()).put("pitch", a.pitch.toDouble()).put("volume", a.volume.toDouble())
        .put("fadeIn", a.fadeInMs).put("fadeOut", a.fadeOutMs).put("echo", a.echo.toDouble())
        .put("normalize", a.normalize).put("normGain", a.normGain.toDouble())
        .put("eq", JSONArray().also { arr -> a.eq.forEach { arr.put(it.toDouble()) } })
        .put("bass", a.bass.toDouble()).put("treble", a.treble.toDouble()).put("voiceFilter", a.voiceFilter)
        .put("robot", a.robot.toDouble()).put("reverb", a.reverb.toDouble())
        .put("chorus", a.chorus.toDouble()).put("chorusMode", a.chorusMode).put("tremolo", a.tremolo.toDouble())
        .put("lowPass", a.lowPassHz.toDouble()).put("highPass", a.highPassHz.toDouble())
        .put("gate", a.gate.toDouble()).put("comp", a.comp.toDouble()).put("limiter", a.limiter)
        .put("channelMode", a.channelMode).put("pan", a.pan.toDouble()).put("reverse", a.reverse)
        .put("loops", a.loops).put("padStart", a.padStartMs).put("padEnd", a.padEndMs).put("fadeCurve", a.fadeCurve)
        .put("cuts", JSONArray().also { arr -> a.cuts.forEach { arr.put(JSONArray().put(it.first).put(it.second)) } })
        .put("bitrate", a.bitrateKbps)

    private fun readAudioData(o: JSONObject) = AudioData(
        uri = o.getString("uri"), name = o.optString("name"), srcDurationMs = o.optLong("src"),
        startMs = o.optLong("start"), endMs = o.optLong("end"),
        speed = o.optDouble("speed", 1.0).toFloat(), pitch = o.optDouble("pitch", 1.0).toFloat(),
        volume = o.optDouble("volume", 1.0).toFloat(),
        fadeInMs = o.optLong("fadeIn"), fadeOutMs = o.optLong("fadeOut"),
        echo = o.optDouble("echo", 0.0).toFloat(),
        normalize = o.optBoolean("normalize"), normGain = o.optDouble("normGain", 1.0).toFloat(),
        eq = o.optJSONArray("eq")?.let { arr -> List(5) { i -> arr.optDouble(i, 0.0).toFloat() } } ?: List(5) { 0f },
        bass = o.optDouble("bass", 0.0).toFloat(), treble = o.optDouble("treble", 0.0).toFloat(),
        voiceFilter = o.optInt("voiceFilter"),
        robot = o.optDouble("robot", 0.0).toFloat(), reverb = o.optDouble("reverb", 0.0).toFloat(),
        chorus = o.optDouble("chorus", 0.0).toFloat(), chorusMode = o.optInt("chorusMode"),
        tremolo = o.optDouble("tremolo", 0.0).toFloat(),
        lowPassHz = o.optDouble("lowPass", 20000.0).toFloat(), highPassHz = o.optDouble("highPass", 20.0).toFloat(),
        gate = o.optDouble("gate", 0.0).toFloat(), comp = o.optDouble("comp", 0.0).toFloat(),
        limiter = o.optBoolean("limiter"), channelMode = o.optInt("channelMode"),
        pan = o.optDouble("pan", 0.0).toFloat(), reverse = o.optBoolean("reverse"),
        loops = o.optInt("loops", 1).coerceAtLeast(1), padStartMs = o.optLong("padStart"), padEndMs = o.optLong("padEnd"),
        fadeCurve = o.optInt("fadeCurve"),
        cuts = o.optJSONArray("cuts")?.let { arr ->
            (0 until arr.length()).mapNotNull { i -> arr.optJSONArray(i)?.let { it.optLong(0) to it.optLong(1) } }
        } ?: emptyList(),
        bitrateKbps = o.optInt("bitrate", 128),
    )

    private fun videoData(v: VideoData): JSONObject {
        val clips = JSONArray(); v.clips.forEach { clips.put(clip(it)) }
        val texts = JSONArray(); v.texts.forEach { texts.put(text(it)) }
        return JSONObject()
            .put("clips", clips).put("texts", texts)
            .put("musicUri", v.musicUri ?: JSONObject.NULL).put("musicName", v.musicName)
            .put("musicDuration", v.musicDurationMs).put("musicVolume", v.musicVolume.toDouble())
            .put("aspect", v.aspect.toDouble()).put("resolution", v.resolution)
    }

    // ---------- readers ----------

    private fun readAdjust(o: JSONObject?): Adjust {
        if (o == null) return Adjust()
        return Adjust(
            o.optDouble("b", 0.0).toFloat(), o.optDouble("c", 0.0).toFloat(),
            o.optDouble("s", 0.0).toFloat(), o.optDouble("w", 0.0).toFloat(), o.optDouble("h", 0.0).toFloat()
        )
    }

    private fun readText(o: JSONObject) = TextLayer(
        id = o.optLong("id"), text = o.optString("text"),
        x = o.optDouble("x", 0.5).toFloat(), y = o.optDouble("y", 0.5).toFloat(),
        size = o.optDouble("size", 0.07).toFloat(), rotation = o.optDouble("rot", 0.0).toFloat(),
        color = o.optInt("color", 0xFFFFFFFF.toInt()), bgColor = o.optInt("bg", 0),
        bold = o.optBoolean("bold", true), italic = o.optBoolean("italic", false),
        font = o.optInt("font", 0), shadow = o.optBoolean("shadow", true),
        outline = o.optBoolean("outline", false), opacity = o.optDouble("opacity", 1.0).toFloat(),
        startMs = o.optLong("start", 0L), endMs = o.optLong("end", -1L),
        shape = o.optInt("shape", 0), aspect = o.optDouble("aspect", 1.0).toFloat(),
        imageUri = if (o.isNull("imageUri")) null else o.optString("imageUri"),
    )

    private fun readStroke(o: JSONObject): Stroke {
        val arr = o.optJSONArray("pts") ?: JSONArray()
        val pts = ArrayList<Float>(arr.length())
        for (i in 0 until arr.length()) pts.add(arr.optDouble(i).toFloat())
        return Stroke(o.optInt("color"), o.optDouble("w", 0.01).toFloat(), o.optDouble("a", 1.0).toFloat(), pts)
    }

    private fun readImageEdit(o: JSONObject): ImageEdit {
        val texts = ArrayList<TextLayer>()
        o.optJSONArray("texts")?.let { a -> for (i in 0 until a.length()) texts.add(readText(a.getJSONObject(i))) }
        val strokes = ArrayList<Stroke>()
        o.optJSONArray("strokes")?.let { a -> for (i in 0 until a.length()) strokes.add(readStroke(a.getJSONObject(i))) }
        return ImageEdit(
            adjust = readAdjust(o.optJSONObject("adjust")),
            lookId = o.optString("look", "original"),
            lookStrength = o.optDouble("lookStrength", 1.0).toFloat(),
            sharpen = o.optDouble("sharpen", 0.0).toFloat(), blur = o.optDouble("blur", 0.0).toFloat(),
            vignette = o.optDouble("vignette", 0.0).toFloat(), fade = o.optDouble("fade", 0.0).toFloat(),
            border = o.optDouble("border", 0.0).toFloat(),
            borderColor = o.optInt("borderColor", 0xFFFFFFFF.toInt()),
            rotation = o.optInt("rotation", 0), flipH = o.optBoolean("flipH"), flipV = o.optBoolean("flipV"),
            cropAspect = o.optDouble("cropAspect", 0.0).toFloat(),
            cropZoom = o.optDouble("cropZoom", 1.0).toFloat(),
            cropCx = o.optDouble("cropCx", 0.5).toFloat(), cropCy = o.optDouble("cropCy", 0.5).toFloat(),
            straighten = o.optDouble("straighten", 0.0).toFloat(), grain = o.optDouble("grain", 0.0).toFloat(),
            pixelate = o.optDouble("pixelate", 0.0).toFloat(), corner = o.optDouble("corner", 0.0).toFloat(),
            fx = readImageFx(o.optJSONObject("fx")),
            texts = texts, strokes = strokes,
        )
    }

    private fun readImageData(o: JSONObject) = ImageData(
        sourceUri = if (o.isNull("source")) null else o.optString("source"),
        blankW = o.optInt("blankW", 1080), blankH = o.optInt("blankH", 1080),
        blankColor = o.optInt("blankColor", 0xFFFFFFFF.toInt()),
        edit = o.optJSONObject("edit")?.let { readImageEdit(it) } ?: ImageEdit(),
        retouchUri = if (!o.has("retouch") || o.isNull("retouch")) null else o.optString("retouch"),
    )

    private fun readClip(o: JSONObject) = VideoClip(
        id = o.optLong("id"), uri = o.getString("uri"), isImage = o.optBoolean("isImage"),
        srcDurationMs = o.optLong("src"), startMs = o.optLong("start"), endMs = o.optLong("end"),
        width = o.optInt("w"), height = o.optInt("h"),
        speed = o.optDouble("speed", 1.0).toFloat(), volume = o.optDouble("volume", 1.0).toFloat(),
        muted = o.optBoolean("muted"), rotation = o.optInt("rotation"), flipH = o.optBoolean("flipH"),
        fill = o.optBoolean("fill"), lookId = o.optString("look", "original"),
        lookStrength = o.optDouble("lookStrength", 1.0).toFloat(),
        adjust = readAdjust(o.optJSONObject("adjust")),
        fadeInMs = o.optLong("fadeIn"), fadeOutMs = o.optLong("fadeOut"),
        zoom = o.optDouble("zoom", 1.0).toFloat(), panX = o.optDouble("panX", 0.0).toFloat(),
        panY = o.optDouble("panY", 0.0).toFloat(), kenBurns = o.optInt("kb", 0),
        vfx = o.optInt("vfx", 0), flipV = o.optBoolean("flipV"), tint = o.optDouble("tint", 0.0).toFloat(),
    )

    private fun readVideoData(o: JSONObject): VideoData {
        val clips = ArrayList<VideoClip>()
        o.optJSONArray("clips")?.let { a -> for (i in 0 until a.length()) clips.add(readClip(a.getJSONObject(i))) }
        val texts = ArrayList<TextLayer>()
        o.optJSONArray("texts")?.let { a -> for (i in 0 until a.length()) texts.add(readText(a.getJSONObject(i))) }
        return VideoData(
            clips = clips, texts = texts,
            musicUri = if (o.isNull("musicUri")) null else o.optString("musicUri"),
            musicName = o.optString("musicName"), musicDurationMs = o.optLong("musicDuration"),
            musicVolume = o.optDouble("musicVolume", 1.0).toFloat(),
            aspect = o.optDouble("aspect", 0.0).toFloat(), resolution = o.optInt("resolution", 720),
        )
    }
}
