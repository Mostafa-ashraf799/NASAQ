package com.binarybeast.mediastudio.data

import org.json.JSONArray
import org.json.JSONObject

/** تحويل المشاريع من/إلى JSON باستخدام org.json المدمجة في أندرويد (بدون مكتبات إضافية). */
object ProjectJson {

    fun encode(p: Project): String = JSONObject().apply {
        put("id", p.id)
        put("name", p.name)
        put("type", p.type.name)
        put("createdAt", p.createdAt)
        put("updatedAt", p.updatedAt)
        put("pinned", p.pinned)
        p.image?.let { put("image", imageData(it)) }
        p.video?.let { put("video", videoData(it)) }
        p.audio?.let { put("audio", audioData(it)) }
    }.toString()

    fun decode(s: String): Project {
        val o = JSONObject(s)
        return Project(
            id = o.getString("id"),
            name = o.optString("name", "مشروع"),
            type = ProjectType.valueOf(o.getString("type")),
            createdAt = o.optLong("createdAt"),
            updatedAt = o.optLong("updatedAt"),
            pinned = o.optBoolean("pinned", false),
            image = o.optJSONObject("image")?.let { readImageData(it) },
            video = o.optJSONObject("video")?.let { readVideoData(it) },
            audio = o.optJSONObject("audio")?.let { readAudioData(it) },
        )
    }

    // ---------- writers ----------

    private fun adjust(a: Adjust) = JSONObject()
        .put("b", a.brightness.toDouble()).put("c", a.contrast.toDouble())
        .put("s", a.saturation.toDouble()).put("w", a.warmth.toDouble()).put("h", a.hue.toDouble())

    private fun text(t: TextLayer) = JSONObject()
        .put("id", t.id).put("text", t.text).put("x", t.x.toDouble()).put("y", t.y.toDouble())
        .put("size", t.size.toDouble()).put("rot", t.rotation.toDouble()).put("color", t.color)
        .put("bg", t.bgColor).put("bold", t.bold).put("italic", t.italic).put("font", t.font)
        .put("shadow", t.shadow).put("outline", t.outline).put("opacity", t.opacity.toDouble())
        .put("start", t.startMs).put("end", t.endMs)
        .put("shape", t.shape).put("aspect", t.aspect.toDouble())
        .put("imageUri", t.imageUri ?: JSONObject.NULL)

    private fun stroke(s: Stroke): JSONObject {
        val pts = JSONArray()
        s.pts.forEach { pts.put(it.toDouble()) }
        return JSONObject().put("color", s.color).put("w", s.width.toDouble())
            .put("a", s.alpha.toDouble()).put("pts", pts)
    }

    private fun imageEdit(e: ImageEdit): JSONObject {
        val texts = JSONArray(); e.texts.forEach { texts.put(text(it)) }
        val strokes = JSONArray(); e.strokes.forEach { strokes.put(stroke(it)) }
        return JSONObject()
            .put("adjust", adjust(e.adjust)).put("look", e.lookId).put("lookStrength", e.lookStrength.toDouble())
            .put("sharpen", e.sharpen.toDouble()).put("blur", e.blur.toDouble())
            .put("vignette", e.vignette.toDouble()).put("fade", e.fade.toDouble())
            .put("border", e.border.toDouble()).put("borderColor", e.borderColor)
            .put("rotation", e.rotation).put("flipH", e.flipH).put("flipV", e.flipV)
            .put("cropAspect", e.cropAspect.toDouble()).put("cropZoom", e.cropZoom.toDouble())
            .put("cropCx", e.cropCx.toDouble()).put("cropCy", e.cropCy.toDouble())
            .put("straighten", e.straighten.toDouble()).put("grain", e.grain.toDouble())
            .put("pixelate", e.pixelate.toDouble()).put("corner", e.corner.toDouble())
            .put("texts", texts).put("strokes", strokes)
    }

    private fun imageData(d: ImageData) = JSONObject()
        .put("source", d.sourceUri ?: JSONObject.NULL)
        .put("blankW", d.blankW).put("blankH", d.blankH).put("blankColor", d.blankColor)
        .put("edit", imageEdit(d.edit))

    private fun clip(c: VideoClip) = JSONObject()
        .put("id", c.id).put("uri", c.uri).put("isImage", c.isImage).put("src", c.srcDurationMs)
        .put("start", c.startMs).put("end", c.endMs).put("w", c.width).put("h", c.height)
        .put("speed", c.speed.toDouble()).put("volume", c.volume.toDouble()).put("muted", c.muted)
        .put("rotation", c.rotation).put("flipH", c.flipH).put("fill", c.fill)
        .put("look", c.lookId).put("lookStrength", c.lookStrength.toDouble()).put("adjust", adjust(c.adjust))
        .put("fadeIn", c.fadeInMs).put("fadeOut", c.fadeOutMs).put("zoom", c.zoom.toDouble())
        .put("panX", c.panX.toDouble()).put("panY", c.panY.toDouble()).put("kb", c.kenBurns)

    private fun audioData(a: AudioData) = JSONObject()
        .put("uri", a.uri).put("name", a.name).put("src", a.srcDurationMs)
        .put("start", a.startMs).put("end", a.endMs)
        .put("speed", a.speed.toDouble()).put("pitch", a.pitch.toDouble()).put("volume", a.volume.toDouble())
        .put("fadeIn", a.fadeInMs).put("fadeOut", a.fadeOutMs).put("echo", a.echo.toDouble())

    private fun readAudioData(o: JSONObject) = AudioData(
        uri = o.getString("uri"), name = o.optString("name"), srcDurationMs = o.optLong("src"),
        startMs = o.optLong("start"), endMs = o.optLong("end"),
        speed = o.optDouble("speed", 1.0).toFloat(), pitch = o.optDouble("pitch", 1.0).toFloat(),
        volume = o.optDouble("volume", 1.0).toFloat(),
        fadeInMs = o.optLong("fadeIn"), fadeOutMs = o.optLong("fadeOut"),
        echo = o.optDouble("echo", 0.0).toFloat(),
    )

    private fun videoData(v: VideoData): JSONObject {
        val clips = JSONArray(); v.clips.forEach { clips.put(clip(it)) }
        val texts = JSONArray(); v.texts.forEach { texts.put(text(it)) }
        return JSONObject()
            .put("clips", clips).put("texts", texts)
            .put("musicUri", v.musicUri ?: JSONObject.NULL).put("musicName", v.musicName)
            .put("musicDuration", v.musicDurationMs).put("musicVolume", v.musicVolume.toDouble())
            .put("aspect", v.aspect.toDouble()).put("resolution", v.resolution)
    }

    // ---------- readers ----------

    private fun readAdjust(o: JSONObject?): Adjust {
        if (o == null) return Adjust()
        return Adjust(
            o.optDouble("b", 0.0).toFloat(), o.optDouble("c", 0.0).toFloat(),
            o.optDouble("s", 0.0).toFloat(), o.optDouble("w", 0.0).toFloat(), o.optDouble("h", 0.0).toFloat()
        )
    }

    private fun readText(o: JSONObject) = TextLayer(
        id = o.optLong("id"), text = o.optString("text"),
        x = o.optDouble("x", 0.5).toFloat(), y = o.optDouble("y", 0.5).toFloat(),
        size = o.optDouble("size", 0.07).toFloat(), rotation = o.optDouble("rot", 0.0).toFloat(),
        color = o.optInt("color", 0xFFFFFFFF.toInt()), bgColor = o.optInt("bg", 0),
        bold = o.optBoolean("bold", true), italic = o.optBoolean("italic", false),
        font = o.optInt("font", 0), shadow = o.optBoolean("shadow", true),
        outline = o.optBoolean("outline", false), opacity = o.optDouble("opacity", 1.0).toFloat(),
        startMs = o.optLong("start", 0L), endMs = o.optLong("end", -1L),
        shape = o.optInt("shape", 0), aspect = o.optDouble("aspect", 1.0).toFloat(),
        imageUri = if (o.isNull("imageUri")) null else o.optString("imageUri"),
    )

    private fun readStroke(o: JSONObject): Stroke {
        val arr = o.optJSONArray("pts") ?: JSONArray()
        val pts = ArrayList<Float>(arr.length())
        for (i in 0 until arr.length()) pts.add(arr.optDouble(i).toFloat())
        return Stroke(o.optInt("color"), o.optDouble("w", 0.01).toFloat(), o.optDouble("a", 1.0).toFloat(), pts)
    }

    private fun readImageEdit(o: JSONObject): ImageEdit {
        val texts = ArrayList<TextLayer>()
        o.optJSONArray("texts")?.let { a -> for (i in 0 until a.length()) texts.add(readText(a.getJSONObject(i))) }
        val strokes = ArrayList<Stroke>()
        o.optJSONArray("strokes")?.let { a -> for (i in 0 until a.length()) strokes.add(readStroke(a.getJSONObject(i))) }
        return ImageEdit(
            adjust = readAdjust(o.optJSONObject("adjust")),
            lookId = o.optString("look", "original"),
            lookStrength = o.optDouble("lookStrength", 1.0).toFloat(),
            sharpen = o.optDouble("sharpen", 0.0).toFloat(), blur = o.optDouble("blur", 0.0).toFloat(),
            vignette = o.optDouble("vignette", 0.0).toFloat(), fade = o.optDouble("fade", 0.0).toFloat(),
            border = o.optDouble("border", 0.0).toFloat(),
            borderColor = o.optInt("borderColor", 0xFFFFFFFF.toInt()),
            rotation = o.optInt("rotation", 0), flipH = o.optBoolean("flipH"), flipV = o.optBoolean("flipV"),
            cropAspect = o.optDouble("cropAspect", 0.0).toFloat(),
            cropZoom = o.optDouble("cropZoom", 1.0).toFloat(),
            cropCx = o.optDouble("cropCx", 0.5).toFloat(), cropCy = o.optDouble("cropCy", 0.5).toFloat(),
            straighten = o.optDouble("straighten", 0.0).toFloat(), grain = o.optDouble("grain", 0.0).toFloat(),
            pixelate = o.optDouble("pixelate", 0.0).toFloat(), corner = o.optDouble("corner", 0.0).toFloat(),
            texts = texts, strokes = strokes,
        )
    }

    private fun readImageData(o: JSONObject) = ImageData(
        sourceUri = if (o.isNull("source")) null else o.optString("source"),
        blankW = o.optInt("blankW", 1080), blankH = o.optInt("blankH", 1080),
        blankColor = o.optInt("blankColor", 0xFFFFFFFF.toInt()),
        edit = o.optJSONObject("edit")?.let { readImageEdit(it) } ?: ImageEdit(),
    )

    private fun readClip(o: JSONObject) = VideoClip(
        id = o.optLong("id"), uri = o.getString("uri"), isImage = o.optBoolean("isImage"),
        srcDurationMs = o.optLong("src"), startMs = o.optLong("start"), endMs = o.optLong("end"),
        width = o.optInt("w"), height = o.optInt("h"),
        speed = o.optDouble("speed", 1.0).toFloat(), volume = o.optDouble("volume", 1.0).toFloat(),
        muted = o.optBoolean("muted"), rotation = o.optInt("rotation"), flipH = o.optBoolean("flipH"),
        fill = o.optBoolean("fill"), lookId = o.optString("look", "original"),
        lookStrength = o.optDouble("lookStrength", 1.0).toFloat(),
        adjust = readAdjust(o.optJSONObject("adjust")),
        fadeInMs = o.optLong("fadeIn"), fadeOutMs = o.optLong("fadeOut"),
        zoom = o.optDouble("zoom", 1.0).toFloat(), panX = o.optDouble("panX", 0.0).toFloat(),
        panY = o.optDouble("panY", 0.0).toFloat(), kenBurns = o.optInt("kb", 0),
    )

    private fun readVideoData(o: JSONObject): VideoData {
        val clips = ArrayList<VideoClip>()
        o.optJSONArray("clips")?.let { a -> for (i in 0 until a.length()) clips.add(readClip(a.getJSONObject(i))) }
        val texts = ArrayList<TextLayer>()
        o.optJSONArray("texts")?.let { a -> for (i in 0 until a.length()) texts.add(readText(a.getJSONObject(i))) }
        return VideoData(
            clips = clips, texts = texts,
            musicUri = if (o.isNull("musicUri")) null else o.optString("musicUri"),
            musicName = o.optString("musicName"), musicDurationMs = o.optLong("musicDuration"),
            musicVolume = o.optDouble("musicVolume", 1.0).toFloat(),
            aspect = o.optDouble("aspect", 0.0).toFloat(), resolution = o.optInt("resolution", 720),
        )
    }
}
