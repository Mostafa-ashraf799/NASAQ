@file:OptIn(UnstableApi::class)

package com.binarybeast.mediastudio.video

import android.graphics.Bitmap
import android.net.Uri
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import com.binarybeast.mediastudio.data.VideoClip
import com.binarybeast.mediastudio.data.VideoData
import com.binarybeast.mediastudio.image.ImageCache
import com.binarybeast.mediastudio.image.TextRenderer
import com.google.common.collect.ImmutableList

/** بناء Composition الخاصة بـ Media3 Transformer من بيانات المشروع. */
object VideoExporter {

    fun buildComposition(d: VideoData): Composition {
        val (outW, outH) = d.outputSize()
        val items = d.clips.map { buildItem(it, outW, outH) }
        val sequences = ArrayList<EditedMediaItemSequence>()
        sequences.add(EditedMediaItemSequence(items))
        musicSequence(d)?.let { sequences.add(it) }

        val builder = Composition.Builder(sequences)
        val overlays = buildOverlays(d, outW, outH).toMutableList()
        buildFadeOverlay(d, outW, outH)?.let { overlays.add(it) }
        if (overlays.isNotEmpty()) {
            builder.setEffects(
                Effects(
                    emptyList(),
                    listOf<Effect>(OverlayEffect(ImmutableList.copyOf(overlays)))
                )
            )
        }
        forceAudioTrack(builder)
        return builder.build()
    }

    private fun buildItem(c: VideoClip, outW: Int, outH: Int): EditedMediaItem {
        val mi = MediaItem.Builder().setUri(Uri.parse(c.uri))
        val trimmed = c.startMs > 0L || c.endMs < c.srcDurationMs
        if (c.isImage) {
            mi.setImageDurationMs(c.endMs - c.startMs)
        } else if (trimmed) {
            mi.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.startMs)
                    .setEndPositionMs(c.endMs)
                    .build()
            )
        }

        val video = ArrayList<Effect>()
        video.addAll(VideoEffects.geometry(c))
        video.addAll(VideoEffects.motion(c))
        video.addAll(VideoEffects.color(c))
        video.add(
            Presentation.createForWidthAndHeight(
                outW, outH,
                if (c.fill) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT
            )
        )
        if (!c.isImage && c.speed != 1f) video.add(SpeedChangeEffect(c.speed))

        val b = EditedMediaItem.Builder(mi.build())
            .setEffects(Effects(VideoEffects.audio(c), video))
        if (c.isImage) {
            b.setDurationUs((c.endMs - c.startMs) * 1000L)
            b.setFrameRate(30)
        }
        return b.build()
    }

    private fun musicSequence(d: VideoData): EditedMediaItemSequence? {
        val uri = d.musicUri ?: return null
        val total = d.totalMs
        val end = if (d.musicDurationMs > 0) minOf(total, d.musicDurationMs) else total
        val mi = MediaItem.Builder().setUri(Uri.parse(uri))
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder().setStartPositionMs(0).setEndPositionMs(end).build()
            ).build()
        val audio = if (d.musicVolume != 1f) listOf(GainAudioProcessor(d.musicVolume)) else emptyList()
        val item = EditedMediaItem.Builder(mi)
            .setRemoveVideo(true)
            .setEffects(Effects(audio, emptyList()))
            .build()
        return EditedMediaItemSequence(listOf(item))
    }

    private fun buildOverlays(d: VideoData, outW: Int, outH: Int): List<TextureOverlay> {
        val total = d.totalMs
        val out = ArrayList<TextureOverlay>()
        for (l in d.texts) {
            if (l.shape == 0 && l.text.isEmpty()) continue
            if (l.shape == 9 && (l.imageUri == null || ImageCache.get(l.imageUri) == null)) continue
            val bmp = TextRenderer.toBitmap(l, outH.toFloat())
            val startUs = l.startMs.coerceAtLeast(0L) * 1000L
            val endUs = (if (l.endMs < 0) total else minOf(l.endMs, total)) * 1000L
            val on = OverlaySettings.Builder()
                .setBackgroundFrameAnchor(l.x * 2f - 1f, 1f - l.y * 2f)
                .build()
            val off = OverlaySettings.Builder()
                .setBackgroundFrameAnchor(l.x * 2f - 1f, 1f - l.y * 2f)
                .setAlphaScale(0f)
                .build()
            out.add(TimedBitmapOverlay(bmp, on, off, startUs, endUs))
        }
        @Suppress("UNUSED_VARIABLE") val unused = outW
        return out
    }

    /** طبقة سودا بالحجم الكامل شفافيتها بتتغير مع الزمن لعمل تلاشي (Fade) في بداية/نهاية المقاطع. */
    private fun buildFadeOverlay(d: VideoData, outW: Int, outH: Int): TextureOverlay? {
        if (d.clips.none { it.fadeInMs > 0 || it.fadeOutMs > 0 }) return null
        val segs = ArrayList<FadeSeg>()
        var t = 0L
        for (c in d.clips) {
            val dur = c.effectiveMs
            segs.add(FadeSeg(t * 1000L, (t + dur) * 1000L, minOf(c.fadeInMs, dur) * 1000L, minOf(c.fadeOutMs, dur) * 1000L))
            t += dur
        }
        val bmp = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(android.graphics.Color.BLACK)
        return FadeOverlay(bmp, segs)
    }

    /**
     * لو في صور وفيديوهات مع بعض لازم مسار صوت إجباري عشان الصور (اللي من غير صوت) تتدمج.
     * الدالة دي تجريبية في Media3 1.4 فبننادي عليها بالـ reflection عشان لو اتغير اسمها ما يتكسرش البناء.
     */
    private fun forceAudioTrack(b: Composition.Builder) {
        runCatching {
            Composition.Builder::class.java
                .getMethod("experimentalSetForceAudioTrack", java.lang.Boolean.TYPE)
                .invoke(b, true)
        }
    }
}

/** Overlay نقطي (Bitmap) بيظهر بين زمنين على التايم لاين النهائي. */
private class TimedBitmapOverlay(
    private val bmp: Bitmap,
    private val on: OverlaySettings,
    private val off: OverlaySettings,
    private val startUs: Long,
    private val endUs: Long,
) : BitmapOverlay() {

    override fun getBitmap(presentationTimeUs: Long): Bitmap = bmp

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings =
        if (presentationTimeUs in startUs..endUs) on else off
}

class FadeSeg(val startUs: Long, val endUs: Long, val inUs: Long, val outUs: Long)

private class FadeOverlay(private val bmp: Bitmap, private val segs: List<FadeSeg>) : BitmapOverlay() {
    override fun getBitmap(presentationTimeUs: Long): Bitmap = bmp

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val a = FadeMath.alpha(segs, presentationTimeUs)
        return OverlaySettings.Builder().setAlphaScale(a).build()
    }
}

object FadeMath {
    fun alpha(segs: List<FadeSeg>, tUs: Long): Float {
        for (s in segs) {
            if (tUs < s.startUs || tUs > s.endUs) continue
            val local = tUs - s.startUs
            val dur = s.endUs - s.startUs
            var a = 0f
            if (s.inUs > 0 && local < s.inUs) a = maxOf(a, 1f - local.toFloat() / s.inUs)
            if (s.outUs > 0 && local > dur - s.outUs) a = maxOf(a, (local - (dur - s.outUs)).toFloat() / s.outUs)
            return a.coerceIn(0f, 1f)
        }
        return 0f
    }
}
