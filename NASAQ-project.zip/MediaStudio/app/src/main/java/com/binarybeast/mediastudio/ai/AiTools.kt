package com.binarybeast.mediastudio.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Base64
import com.binarybeast.mediastudio.Graph
import com.binarybeast.mediastudio.data.CanvasStore
import com.binarybeast.mediastudio.data.ImageEdit
import com.binarybeast.mediastudio.data.Looks
import com.binarybeast.mediastudio.data.Project
import com.binarybeast.mediastudio.data.ProjectFactory
import com.binarybeast.mediastudio.data.ProjectType
import com.binarybeast.mediastudio.data.TextLayer
import com.binarybeast.mediastudio.image.BitmapLoader
import com.binarybeast.mediastudio.image.ImageCache
import com.binarybeast.mediastudio.image.ImageProcessor
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.math.max

class ToolOut(val text: String, val images: List<String> = emptyList())

/** تنفيذ أدوات التحرير محليًا على المشروع المختار فقط (مفيش وصول للمعرض). */
class AiTools(private val ctx: Context, private val cfg: AiConfig, var projectId: String?) {

    private fun JSONObject.f(k: String): Float? = if (has(k) && !isNull(k)) optDouble(k).toFloat() else null
    private fun JSONObject.i(k: String): Int? = if (has(k) && !isNull(k)) optInt(k) else null
    private fun JSONObject.b(k: String): Boolean? = if (has(k) && !isNull(k)) optBoolean(k) else null
    private fun Float.c(lo: Float, hi: Float) = coerceIn(lo, hi)

    private fun err(m: String) = ToolOut("ERROR: $m")

    fun info(): String {
        val p = projectId?.let { Graph.repo.load(it) } ?: return "No project selected."
        return describe(p)
    }

    fun describe(p: Project): String {
        val sb = StringBuilder("id=${p.id}, name=\"${p.name}\", type=${p.type}\n")
        when (p.type) {
            ProjectType.IMAGE -> p.image?.let { d ->
                val e = d.edit
                sb.append("size=${if (d.sourceUri == null) "${d.blankW}x${d.blankH} blank canvas" else "photo"}\n")
                sb.append("adjust=${e.adjust} look=${e.lookId}(${e.lookStrength}) sharpen=${e.sharpen} blur=${e.blur} vignette=${e.vignette} fade=${e.fade} grain=${e.grain}\n")
                sb.append("crop aspect=${e.cropAspect} zoom=${e.cropZoom} rotation=${e.rotation} texts=${e.texts.size}\n")
            }
            ProjectType.VIDEO -> p.video?.let { v ->
                sb.append("aspect=${v.aspect} resolution=${v.resolution} total=${v.totalMs}ms clips=${v.clips.size}\n")
                v.clips.forEachIndexed { i, c ->
                    sb.append("  [$i] ${if (c.isImage) "photo" else "video"} ${c.startMs}-${c.endMs}ms speed=${c.speed} vol=${c.volume} look=${c.lookId}\n")
                }
            }
            ProjectType.CANVAS -> {
                val pages = CanvasStore.pages(p.id)
                sb.append("canvas ${p.canvas?.w}x${p.canvas?.h}, pages=${pages.size}\n")
            }
            ProjectType.AUDIO -> sb.append("audio project (use advice only; audio tools are UI-only)\n")
        }
        return sb.toString().trim()
    }

    private fun resolveImageProject(page: Int?): Project? {
        val p = projectId?.let { Graph.repo.load(it) } ?: return null
        return when (p.type) {
            ProjectType.IMAGE -> p
            ProjectType.CANVAS -> {
                val pages = CanvasStore.pages(p.id)
                pages.getOrNull(((page ?: 1) - 1).coerceIn(0, max(0, pages.lastIndex)))
            }
            else -> null
        }
    }

    private fun editImage(args: JSONObject, f: (ImageEdit) -> ImageEdit): ToolOut {
        if (!cfg.allowEdits) return err("editing disabled by the user")
        val p = resolveImageProject(args.i("page")) ?: return err("no image project selected (select an image or canvas project)")
        val d = p.image ?: return err("not an image project")
        Graph.repo.save(p.copy(image = d.copy(edit = f(d.edit)), updatedAt = System.currentTimeMillis()))
        return ToolOut("ok")
    }

    private fun toB64(bmp: Bitmap): String {
        val bo = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, bo)
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
    }

    fun currentB64(maxSide: Int = 1024): String? = renderCurrent(maxSide)?.let { toB64(it) }

    /** صورة المشروع الحالية (للإرسال للـ AI). */
    fun renderCurrent(maxSide: Int, page: Int? = null, timeMs: Long = 0L, clip: Int = 0): Bitmap? {
        val p0 = projectId?.let { Graph.repo.load(it) } ?: return null
        if (p0.type == ProjectType.VIDEO) {
            val c = p0.video?.clips?.getOrNull(clip) ?: return null
            if (c.isImage) return BitmapLoader.load(ctx, Uri.parse(c.uri), maxSide)
            val r = MediaMetadataRetriever()
            return try {
                r.setDataSource(ctx, Uri.parse(c.uri))
                val raw = r.getFrameAtTime((c.startMs + timeMs) * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                raw?.let { b -> val k = maxSide.toFloat() / max(b.width, b.height); if (k < 1f) Bitmap.createScaledBitmap(b, (b.width * k).toInt(), (b.height * k).toInt(), true) else b }
            } catch (t: Throwable) { null } finally { runCatching { r.release() } }
        }
        val p = resolveImageProject(page) ?: return null
        val d = p.image ?: return null
        val src = if (d.sourceUri == null) {
            val k = maxSide.toFloat() / max(d.blankW, d.blankH)
            BitmapLoader.blank((d.blankW * minOf(k, 1f)).toInt().coerceAtLeast(1), (d.blankH * minOf(k, 1f)).toInt().coerceAtLeast(1), d.blankColor)
        } else BitmapLoader.load(ctx, Uri.parse(d.retouchUri ?: d.sourceUri), maxSide) ?: return null
        ImageCache.preload(ctx, d.edit.texts)
        return ImageProcessor.renderFull(src, d.edit)
    }

    fun run(name: String, a: JSONObject): ToolOut = try {
        when (name) {
            "get_project_info" -> ToolOut(info())
            "list_projects" -> ToolOut(Graph.repo.list().filter { it.parentId == null }.take(40)
                .joinToString("\n") { "${it.id} | ${it.name} | ${it.type}" }.ifBlank { "(none)" })
            "select_project" -> {
                val id = a.optString("id")
                if (Graph.repo.load(id) == null) err("project not found") else { projectId = id; ToolOut("selected\n" + info()) }
            }
            "view_image" -> {
                if (!cfg.sendImages) err("sending images to the AI is disabled by the user")
                else {
                    val side = (a.i("max_side") ?: 1024).coerceIn(256, 1568)
                    val bmp = renderCurrent(side, a.i("page"), (a.f("time_ms") ?: 0f).toLong(), a.i("clip") ?: 0)
                    if (bmp == null) err("could not render the project") else ToolOut("image attached (${bmp.width}x${bmp.height})", listOf(toB64(bmp)))
                }
            }
            "set_adjust" -> editImage(a) { e ->
                val o = e.adjust
                e.copy(adjust = o.copy(
                    brightness = a.f("brightness")?.c(-0.5f, 0.5f) ?: o.brightness, contrast = a.f("contrast")?.c(-1f, 1f) ?: o.contrast,
                    saturation = a.f("saturation")?.c(-1f, 1f) ?: o.saturation, warmth = a.f("warmth")?.c(-1f, 1f) ?: o.warmth,
                    hue = a.f("hue")?.c(-180f, 180f) ?: o.hue
                ))
            }
            "set_look" -> {
                val id = a.optString("id", "original")
                if (Looks.all.none { it.id == id }) err("unknown look id") else editImage(a) { it.copy(lookId = id, lookStrength = a.f("strength")?.c(0f, 1f) ?: 1f) }
            }
            "set_effects" -> editImage(a) { e ->
                val x = e.fx
                e.copy(
                    sharpen = a.f("sharpen")?.c(0f, 1f) ?: e.sharpen, blur = a.f("blur")?.c(0f, 1f) ?: e.blur,
                    vignette = a.f("vignette")?.c(0f, 1f) ?: e.vignette, fade = a.f("fade")?.c(0f, 1f) ?: e.fade,
                    grain = a.f("grain")?.c(0f, 1f) ?: e.grain, pixelate = a.f("pixelate")?.c(0f, 1f) ?: e.pixelate,
                    border = a.f("border")?.c(0f, 0.2f) ?: e.border, corner = a.f("corner")?.c(0f, 0.5f) ?: e.corner,
                    fx = x.copy(
                        exposure = a.f("exposure")?.c(-1f, 1f) ?: x.exposure, highlights = a.f("highlights")?.c(-1f, 1f) ?: x.highlights,
                        shadows = a.f("shadows")?.c(-1f, 1f) ?: x.shadows, whites = a.f("whites")?.c(-1f, 1f) ?: x.whites,
                        blacks = a.f("blacks")?.c(-1f, 1f) ?: x.blacks, tint = a.f("tint")?.c(-1f, 1f) ?: x.tint,
                        vibrance = a.f("vibrance")?.c(-1f, 1f) ?: x.vibrance, clarity = a.f("clarity")?.c(-1f, 1f) ?: x.clarity,
                        dehaze = a.f("dehaze")?.c(-1f, 1f) ?: x.dehaze, denoise = a.f("denoise")?.c(0f, 1f) ?: x.denoise
                    )
                )
            }
            "set_crop" -> editImage(a) { e ->
                e.copy(
                    cropAspect = a.f("aspect")?.c(0f, 6f) ?: e.cropAspect, cropZoom = a.f("zoom")?.c(1f, 4f) ?: e.cropZoom,
                    cropCx = a.f("cx")?.c(0f, 1f) ?: e.cropCx, cropCy = a.f("cy")?.c(0f, 1f) ?: e.cropCy,
                    straighten = a.f("straighten")?.c(-45f, 45f) ?: e.straighten
                )
            }
            "transform" -> editImage(a) { e ->
                var r = e.rotation
                a.i("rotate")?.let { r = ((r + it) % 360 + 360) % 360 }
                e.copy(rotation = r, flipH = if (a.b("flipH") == true) !e.flipH else e.flipH, flipV = if (a.b("flipV") == true) !e.flipV else e.flipV)
            }
            "add_text" -> {
                val col = runCatching { Color.parseColor(a.optString("color", "#FFFFFF")) }.getOrDefault(Color.WHITE)
                val t = a.optString("text").take(300)
                if (t.isBlank()) err("text is empty") else editImage(a) { e ->
                    e.copy(texts = e.texts + TextLayer(
                        id = ProjectFactory.nextId(), text = t, x = a.f("x")?.c(0f, 1f) ?: 0.5f, y = a.f("y")?.c(0f, 1f) ?: 0.5f,
                        size = a.f("size")?.c(0.02f, 0.4f) ?: 0.07f, rotation = a.f("rotation") ?: 0f, color = col,
                        bold = a.b("bold") ?: true, shadow = a.b("shadow") ?: true
                    ))
                }
            }
            "clear_texts" -> editImage(a) { it.copy(texts = emptyList()) }
            "reset_edits" -> editImage(a) { ImageEdit() }
            "set_clip" -> {
                if (!cfg.allowEdits) err("editing disabled by the user")
                else {
                    val p = projectId?.let { Graph.repo.load(it) }
                    val v = p?.video
                    val idx = a.i("index") ?: 0
                    if (p == null || v == null || p.type != ProjectType.VIDEO) err("select a video project first")
                    else if (idx !in v.clips.indices) err("clip index out of range")
                    else {
                        val c = v.clips[idx]
                        val adj = c.adjust
                        val lookOk = a.optString("lookId").let { it.isBlank() || Looks.all.any { l -> l.id == it } }
                        if (!lookOk) err("unknown look id") else {
                            val nc = c.copy(
                                speed = a.f("speed")?.c(0.25f, 4f) ?: c.speed, volume = a.f("volume")?.c(0f, 2f) ?: c.volume,
                                muted = a.b("muted") ?: c.muted, lookId = a.optString("lookId").ifBlank { c.lookId },
                                lookStrength = a.f("lookStrength")?.c(0f, 1f) ?: c.lookStrength,
                                fadeInMs = (a.i("fadeInMs") ?: c.fadeInMs.toInt()).toLong().coerceIn(0, 5000),
                                fadeOutMs = (a.i("fadeOutMs") ?: c.fadeOutMs.toInt()).toLong().coerceIn(0, 5000),
                                zoom = a.f("zoom")?.c(1f, 4f) ?: c.zoom, kenBurns = (a.i("kenBurns") ?: c.kenBurns).coerceIn(0, 2),
                                startMs = (a.i("startMs") ?: c.startMs.toInt()).toLong().coerceIn(0, c.srcDurationMs),
                                endMs = (a.i("endMs") ?: c.endMs.toInt()).toLong().coerceIn(0, c.srcDurationMs),
                                adjust = adj.copy(
                                    brightness = a.f("brightness")?.c(-0.5f, 0.5f) ?: adj.brightness, contrast = a.f("contrast")?.c(-1f, 1f) ?: adj.contrast,
                                    saturation = a.f("saturation")?.c(-1f, 1f) ?: adj.saturation, warmth = a.f("warmth")?.c(-1f, 1f) ?: adj.warmth
                                )
                            )
                            if (nc.endMs - nc.startMs < 200) err("clip would be too short")
                            else {
                                val list = v.clips.toMutableList(); list[idx] = nc
                                Graph.repo.save(p.copy(video = v.copy(clips = list), updatedAt = System.currentTimeMillis()))
                                ToolOut("ok")
                            }
                        }
                    }
                }
            }
            "add_canvas_page" -> {
                if (!cfg.allowEdits) err("editing disabled by the user")
                else {
                    val id = projectId
                    val p = id?.let { Graph.repo.load(it) }
                    if (p?.type != ProjectType.CANVAS) err("select a canvas project first")
                    else { CanvasStore.addPage(p.id, (a.i("after") ?: p.canvas!!.pages.size) - 1); ToolOut("ok, pages=${CanvasStore.pages(p.id).size}") }
                }
            }
            else -> err("unknown tool '$name'")
        }
    } catch (t: Throwable) {
        err(t.message ?: t.javaClass.simpleName)
    }
}
