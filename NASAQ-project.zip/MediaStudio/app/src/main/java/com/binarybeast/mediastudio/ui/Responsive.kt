package com.binarybeast.mediastudio.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp

/** تابلت أو موبايل بالعرض: المحرر يتقسم لمعاينة + لوحة أدوات جنب بعض. */
@Composable
fun isWideLayout(): Boolean {
    val c = LocalConfiguration.current
    return (c.screenWidthDp >= 720 && c.screenWidthDp > c.screenHeightDp * 1.1f) || c.screenWidthDp >= 900
}

/** أقصى ارتفاع للوحة الأدوات في الوضع الرأسي (بيكبر على الشاشات الطويلة). */
@Composable
fun panelMaxHeight(): Dp {
    val c = LocalConfiguration.current
    return (c.screenHeightDp * 0.3f).dp.coerceIn(200.dp, 340.dp)
}

/** عدد خلايا الشبكة حسب عرض الشاشة. */
@Composable
fun gridCellDp(compact: Dp, large: Dp): Dp {
    val c = LocalConfiguration.current
    return if (c.screenWidthDp >= 600) large else compact
}
