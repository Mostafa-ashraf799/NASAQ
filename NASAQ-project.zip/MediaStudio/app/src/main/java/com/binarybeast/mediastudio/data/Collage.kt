package com.binarybeast.mediastudio.data

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.binarybeast.mediastudio.Graph
import com.binarybeast.mediastudio.image.BitmapLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.ceil
import kotlin.math.sqrt

/** خلية في الكولاج بإحداثيات طبيعية 0..1 على اللوحة. */
data class CollageCell(val x: Float, val y: Float, val w: Float, val h: Float)

data class CollageLayout(val label: String, val cells: List<CollageCell>)

object Collage {

    private fun rows(counts: List<Int>): List<CollageCell> {
        val r = counts.size
        val out = ArrayList<CollageCell>()
        counts.forEachIndexed { ri, c ->
            for (i in 0 until c) out.add(CollageCell(i / c.toFloat(), ri / r.toFloat(), 1f / c, 1f / r))
        }
        return out
    }

    private fun cols(counts: List<Int>): List<CollageCell> =
        rows(counts).map { CollageCell(it.y, it.x, it.h, it.w) }

    private fun balanced(n: Int): List<Int> {
        val r = ceil(sqrt(n.toFloat())).toInt().coerceAtLeast(1)
        return List(r) { i -> n / r + if (i < n % r) 1 else 0 }.filter { it > 0 }
    }

    private fun bigLeft(n: Int): List<CollageCell> {
        val others = n - 1
        val list = ArrayList<CollageCell>()
        list.add(CollageCell(0f, 0f, 0.6f, 1f))
        for (i in 0 until others) list.add(CollageCell(0.6f, i / others.toFloat(), 0.4f, 1f / others))
        return list
    }

    private fun bigTop(n: Int): List<CollageCell> {
        val others = n - 1
        val list = ArrayList<CollageCell>()
        list.add(CollageCell(0f, 0f, 1f, 0.6f))
        for (i in 0 until others) list.add(CollageCell(i / others.toFloat(), 0.6f, 1f / others, 0.4f))
        return list
    }

    /** تخطيطات مناسبة لعدد الصور n. */
    fun options(n: Int): List<CollageLayout> {
        val list = ArrayList<CollageLayout>()
        if (n <= 1) return listOf(CollageLayout("صورة", listOf(CollageCell(0f, 0f, 1f, 1f))))
        list.add(CollageLayout("شبكة", rows(balanced(n))))
        list.add(CollageLayout("أعمدة", cols(balanced(n))))
        if (n <= 4) {
            list.add(CollageLayout("صف", rows(listOf(n))))
            list.add(CollageLayout("عمود", rows(List(n) { 1 })))
        }
        if (n >= 3) {
            list.add(CollageLayout("كبيرة يمين", bigLeft(n)))
            list.add(CollageLayout("كبيرة فوق", bigTop(n)))
        }
        return list
    }

    val ratios = listOf("1:1" to 1f, "4:5" to 0.8f, "9:16" to 0.5625f, "16:9" to 1.7778f)

    private fun centerCrop(b: Bitmap, targetAspect: Float): Bitmap {
        val a = b.width.toFloat() / b.height
        val (cw, ch) = if (a > targetAspect) Pair((b.height * targetAspect).toInt(), b.height)
        else Pair(b.width, (b.width / targetAspect).toInt())
        val x = (b.width - cw) / 2
        val y = (b.height - ch) / 2
        val cropped = Bitmap.createBitmap(b, x.coerceAtLeast(0), y.coerceAtLeast(0), cw.coerceAtLeast(1), ch.coerceAtLeast(1))
        val big = maxOf(cropped.width, cropped.height)
        if (big <= 1200) return cropped
        val k = 1200f / big
        return Bitmap.createScaledBitmap(cropped, (cropped.width * k).toInt().coerceAtLeast(1), (cropped.height * k).toInt().coerceAtLeast(1), true)
    }

    /** ينشئ مشروع صورة على لوحة فاضية، وكل خلية صورة مقصوصة كطبقة قابلة للتحريك. */
    suspend fun createProject(
        ctx: Context, name: String, uris: List<Uri>, layout: CollageLayout,
        ratio: Float, gap: Float, bg: Int,
    ): Project? = withContext(Dispatchers.IO) {
        val repo = Graph.repo
        val id = repo.newId()
        val w = 1080
        val h = (1080 / ratio).toInt().coerceAtLeast(1)
        val gx = gap
        val gy = gap * w / h
        val layers = ArrayList<TextLayer>()
        uris.take(layout.cells.size).forEachIndexed { i, u ->
            val c = layout.cells[i]
            val x = c.x + gx / 2
            val y = c.y + gy / 2
            val cw = c.w - gx
            val ch = c.h - gy
            if (cw <= 0f || ch <= 0f) return@forEachIndexed
            val bmp = BitmapLoader.load(ctx, u, 1600) ?: return@forEachIndexed
            val aspect = (cw * w) / (ch * h)
            val cropped = centerCrop(bmp, aspect)
            val f = File(repo.dir(id), "collage_$i.jpg")
            f.outputStream().use { cropped.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            layers.add(
                TextLayer(
                    id = ProjectFactory.nextId(), text = "", x = x + cw / 2, y = y + ch / 2,
                    size = ch, aspect = aspect, shape = 9, imageUri = Uri.fromFile(f).toString(),
                    shadow = false, bold = false
                )
            )
        }
        if (layers.isEmpty()) { repo.delete(id); return@withContext null }
        val now = System.currentTimeMillis()
        val p = Project(
            id = id, name = name.ifBlank { ProjectFactory.defaultName("كولاج") }, type = ProjectType.IMAGE,
            createdAt = now, updatedAt = now,
            image = ImageData(sourceUri = null, blankW = w, blankH = h, blankColor = bg, edit = ImageEdit(texts = layers))
        )
        repo.save(p)
        p
    }
}
