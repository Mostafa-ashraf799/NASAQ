@file:OptIn(UnstableApi::class)

package com.binarybeast.mediastudio.video

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.binarybeast.mediastudio.Graph
import com.binarybeast.mediastudio.data.ExportFormat
import com.binarybeast.mediastudio.data.ImageEdit
import com.binarybeast.mediastudio.data.Keyframe
import com.binarybeast.mediastudio.data.Looks
import com.binarybeast.mediastudio.data.MediaRepository
import com.binarybeast.mediastudio.data.Project
import com.binarybeast.mediastudio.data.ProjectFactory
import com.binarybeast.mediastudio.data.TextLayer
import com.binarybeast.mediastudio.data.VideoClip
import com.binarybeast.mediastudio.data.VideoData
import com.binarybeast.mediastudio.image.BitmapLoader
import com.binarybeast.mediastudio.image.ImageCache
import com.binarybeast.mediastudio.image.ImageProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val progress: Int) : ExportState
    data class Done(val file: File, val savedUri: Uri? = null) : ExportState
    data class Failed(val message: String) : ExportState
}

class VideoEditorViewModel(app: Application, private val projectId: String) : AndroidViewModel(app) {

    private val repo = Graph.repo
    private val appCtx: Application = app

    val player: ExoPlayer = ExoPlayer.Builder(app).build()
    private val music: ExoPlayer = ExoPlayer.Builder(app).build()

    var project by mutableStateOf<Project?>(null)
        private set
    var data by mutableStateOf(VideoData())
        private set
    var loading by mutableStateOf(true)
        private set
    var failed by mutableStateOf(false)
        private set
    var selectedIndex by mutableStateOf(0)
        private set
    var selectedText by mutableStateOf<Long?>(null)
    var isPlaying by mutableStateOf(false)
        private set
    var positionMs by mutableStateOf(0L)
        private set
    var busyText by mutableStateOf<String?>(null)
        private set
    var message by mutableStateOf<String?>(null)
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set
    var exportState by mutableStateOf<ExportState>(ExportState.Idle)
        private set

    /** مصغّرات الفلاتر من لقطة من أول مقطع. */
    val lookThumbs = mutableStateMapOf<String, Bitmap>()

    private val undoStack = ArrayDeque<VideoData>()
    private val redoStack = ArrayDeque<VideoData>()
    private var gestureBase: VideoData? = null
    private var pendingRebuild = false
    private var lastSig: List<List<Any>> = emptyList()
    private var scrubbing = false
    private var saveJob: Job? = null
    private var thumbKey: String = ""
    private var transformer: Transformer? = null
    private var exportFile: File? = null

    val selectedClip: VideoClip? get() = data.clips.getOrNull(selectedIndex)

    // ---------------------------------------------------------------- player wiring

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(playing: Boolean) {
            this@VideoEditorViewModel.isPlaying = playing
            syncMusic()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val i = curClipIndex()
            if (i in data.clips.indices) {
                applyFx(i)
                selectedIndex = i
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED) {
                player.pause()
                if (data.clips.isNotEmpty()) {
                    playerSeek(0, 0L)
                    applyFx(0)
                    selectedIndex = 0
                    positionMs = 0L
                }
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            message = "تعذّر تشغيل المعاينة لهذا المقطع"
        }
    }

    init {
        player.addListener(playerListener)
        viewModelScope.launch {
            val p = withContext(Dispatchers.IO) { repo.load(projectId) }
            val v = p?.video
            if (p == null || v == null) {
                failed = true
                loading = false
                return@launch
            }
            project = p
            data = v
            loading = false
            withContext(Dispatchers.IO) { ImageCache.preload(appCtx, v.texts) }
            rebuildPlayer(0, 0L)
            loadMusic()
            buildLookThumbs()
        }
        viewModelScope.launch {
            while (true) {
                delay(60)
                tick()
            }
        }
    }

    private fun tick() {
        if (scrubbing || loading) return
        val clips = data.clips
        if (clips.isEmpty()) return
        val i = curClipIndex()
        if (i !in clips.indices) return
        val c = clips[i]
        val local = curLocalMs().coerceAtLeast(0L)
        positionMs = data.clipStartMs(i) + (local / c.speed).toLong()
        // عبور حدود مقطع جوه نفس عنصر التشغيل (قطع متتالية من نفس الملف): نحدّث التحديد/التأثيرات من غير ما نوقف التشغيل
        if (i != lastTickClip) {
            lastTickClip = i
            if (player.isPlaying) selectedIndex = i
            applyFx(i)
        }
    }

    private fun toMediaItem(c: VideoClip): MediaItem {
        val b = MediaItem.Builder().setUri(Uri.parse(c.uri)).setMediaId(c.id.toString())
        if (c.isImage) {
            b.setImageDurationMs(c.endMs - c.startMs)
        } else {
            b.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.startMs)
                    .setEndPositionMs(c.endMs)
                    .build()
            )
        }
        return b.build()
    }

    private fun sig(d: VideoData): List<List<Any>> =
        d.clips.map { listOf<Any>(it.id, it.uri, it.startMs, it.endMs, it.isImage) } +
            listOf<List<Any>>(buildGroups(d.clips).map { it.first * 1000 + it.last })

    // ---------------- تجميع القطع المتتالية من نفس الملف في عنصر تشغيل واحد (بيخلّي القص سلس من غير تقطيع)
    private var groups: List<IntRange> = emptyList()
    private var lastTickClip = -1

    private fun canMerge(a: VideoClip, b: VideoClip): Boolean =
        !a.isImage && !b.isImage && a.uri == b.uri && a.endMs == b.startMs && fxKey(a) == fxKey(b)

    private fun buildGroups(clips: List<VideoClip>): List<IntRange> {
        if (clips.isEmpty()) return emptyList()
        val out = ArrayList<IntRange>()
        var s0 = 0
        for (i in 1 until clips.size) {
            if (!canMerge(clips[i - 1], clips[i])) { out.add(s0 until i); s0 = i }
        }
        out.add(s0 until clips.size)
        return out
    }

    private fun itemOf(clipIdx: Int): Int = groups.indexOfFirst { clipIdx in it }.let { if (it < 0) 0 else it }

    /** رقم المقطع (في الخط الزمني) اللي المشغّل واقف عليه دلوقتي. */
    private fun curClipIndex(): Int {
        val clips = data.clips
        if (clips.isEmpty()) return 0
        val g = groups.getOrNull(player.currentMediaItemIndex) ?: return player.currentMediaItemIndex.coerceIn(0, clips.lastIndex)
        val first = clips.getOrNull(g.first) ?: return 0
        val src = first.startMs + player.currentPosition.coerceAtLeast(0L)
        for (i in g) {
            val c = clips.getOrNull(i) ?: break
            if (src < c.endMs || i == g.last) return i
        }
        return g.last.coerceIn(0, clips.lastIndex)
    }

    /** الموضع داخل المقطع الحالي (بالمصدر). */
    private fun curLocalMs(): Long {
        val clips = data.clips
        val i = curClipIndex()
        val g = groups.getOrNull(player.currentMediaItemIndex) ?: return player.currentPosition
        val first = clips.getOrNull(g.first) ?: return player.currentPosition
        val c = clips.getOrNull(i) ?: return player.currentPosition
        return first.startMs + player.currentPosition - c.startMs
    }

    private fun playerSeek(clipIdx: Int, localMs: Long) {
        val clips = data.clips
        val c = clips.getOrNull(clipIdx) ?: return
        val gi = itemOf(clipIdx)
        val g = groups.getOrNull(gi) ?: return
        val first = clips[g.first]
        player.seekTo(gi, (c.startMs - first.startMs) + localMs.coerceAtLeast(0L))
    }

    private fun groupItem(clips: List<VideoClip>, g: IntRange): MediaItem {
        val first = clips[g.first]
        if (first.isImage || g.first == g.last) return toMediaItem(first)
        val last = clips[g.last]
        return MediaItem.Builder().setUri(Uri.parse(first.uri)).setMediaId(first.id.toString())
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(first.startMs).setEndPositionMs(last.endMs).build()
            ).build()
    }

    private fun rebuildPlayer(index: Int, posMs: Long) {
        val clips = data.clips
        lastSig = sig(data)
        if (clips.isEmpty()) {
            groups = emptyList()
            player.clearMediaItems()
            return
        }
        groups = buildGroups(clips)
        val idx = index.coerceIn(0, clips.lastIndex)
        val items = groups.map { groupItem(clips, it) }
        val old = ArrayList<String>()
        for (k in 0 until player.mediaItemCount) {
            val m = player.getMediaItemAt(k)
            old.add(m.mediaId + "|" + m.localConfiguration?.uri + "|" + m.clippingConfiguration.startPositionMs + "|" + m.clippingConfiguration.endPositionMs)
        }
        val neu = items.map { it.mediaId + "|" + it.localConfiguration?.uri + "|" + it.clippingConfiguration.startPositionMs + "|" + it.clippingConfiguration.endPositionMs }
        val gi = itemOf(idx)
        val localPos = (clips[idx].startMs - clips[groups[gi].first].startMs) + posMs.coerceAtLeast(0L)
        if (old.isEmpty() || player.playbackState == Player.STATE_IDLE) {
            player.setMediaItems(items, gi, localPos)
            player.prepare()
        } else {
            // تحديث جزئي: بنغيّر بس العناصر اللي اتغيّرت (القص من غير حذف = مفيش أي تغيير في المشغّل)
            var pre = 0
            while (pre < old.size && pre < neu.size && old[pre] == neu[pre]) pre++
            var suf = 0
            while (suf < old.size - pre && suf < neu.size - pre && old[old.size - 1 - suf] == neu[neu.size - 1 - suf]) suf++
            val oldEnd = old.size - suf
            val newEnd = neu.size - suf
            if (oldEnd > pre || newEnd > pre) {
                player.replaceMediaItems(pre, oldEnd, items.subList(pre, newEnd))
            }
            if (player.currentMediaItemIndex != gi || (gi in pre until newEnd)) player.seekTo(gi, localPos)
        }
        lastFxKey = null
        applyFx(idx)
    }

    private fun rebuildKeep() {
        rebuildPlayer(curClipIndex(), curLocalMs())
    }

    private var fxJob: kotlinx.coroutines.Job? = null
    private fun scheduleFx() {
        // Throttle (مش debounce): التأثير بيتطبّق كل ~70ms أثناء السحب نفسه، مش بعد ما تسيب إيدك
        if (fxJob?.isActive == true) return
        fxJob = viewModelScope.launch {
            kotlinx.coroutines.delay(70)
            applyFx(curClipIndex())
        }
    }

    private var lastFxKey: Any? = null

    /** إظهار مناطق الأمان (Action/Title safe) فوق المعاينة. */
    var safeMargins by mutableStateOf(false)
    /** تعطيل التأثيرات مؤقتًا للمقارنة (من غير ما نمسح الإعدادات). */
    var fxBypass by mutableStateOf(false)
        private set

    fun toggleBypass() {
        fxBypass = !fxBypass
        lastFxKey = null
        applyFx(curClipIndex())
    }

    private fun fxKey(c: VideoClip): Any {
        val k: Any = if (c.kfs.isEmpty() && c.kenBurns == 0)
            c.copy(id = 0L, uri = "", startMs = 0L, endMs = 0L, srcDurationMs = 0L)
        else c
        return listOf(k, fxBypass)
    }

    // ---------------- Timecode / EDL
    private val tcFps = 30

    /** HH:MM:SS:FF (30 إطار/ث). */
    fun timecode(ms: Long): String {
        val t = ms.coerceAtLeast(0L)
        val totalSec = t / 1000
        val ff = ((t % 1000) * tcFps / 1000).toInt()
        return "%02d:%02d:%02d:%02d".format(totalSec / 3600, (totalSec / 60) % 60, totalSec % 60, ff)
    }

    /** يقبل HH:MM:SS:FF أو MM:SS أو SS. */
    fun gotoTimecode(text: String) {
        val parts = text.trim().split(':', '.', ';').map { it.trim().toLongOrNull() ?: run { message = "صيغة غير صحيحة، مثال: 00:01:30:10"; return } }
        val ms = when (parts.size) {
            1 -> parts[0] * 1000
            2 -> parts[0] * 60000 + parts[1] * 1000
            3 -> parts[0] * 3600000 + parts[1] * 60000 + parts[2] * 1000
            4 -> parts[0] * 3600000 + parts[1] * 60000 + parts[2] * 1000 + parts[3] * 1000 / tcFps
            else -> { message = "صيغة غير صحيحة"; return }
        }
        scrubbing = false
        seekTimeline(ms.coerceIn(0L, data.totalMs))
    }

    /** يصدّر الخط الزمني بصيغة EDL (CMX3600) للتبادل مع برامج المونتاج. */
    fun exportEdl(): File? {
        if (data.clips.isEmpty()) { message = "مفيش مقاطع"; return null }
        fun tc(ms: Long): String {
            val fr = ms * tcFps / 1000
            val f = fr % tcFps; val sec = fr / tcFps
            return "%02d:%02d:%02d:%02d".format(sec / 3600, (sec / 60) % 60, sec % 60, f)
        }
        val sb = StringBuilder("TITLE: ${project?.name ?: "NASAQ"}\nFCM: NON-DROP FRAME\n\n")
        var rec = 0L
        data.clips.forEachIndexed { i, c ->
            val dur = c.effectiveMs
            val name = (Uri.parse(c.uri).lastPathSegment ?: "clip").takeLast(30)
            sb.append("%03d  AX       V     C        %s %s %s %s\n".format(i + 1, tc(c.startMs), tc(c.endMs), tc(rec), tc(rec + dur)))
            sb.append("* FROM CLIP NAME: $name\n")
            if (c.speed != 1f) sb.append("* SPEED: ${c.speed}x\n")
            sb.append("\n")
            rec += dur
        }
        val f = File(appCtx.cacheDir, "nasaq_timeline.edl")
        return runCatching { f.writeText(sb.toString()); f }.getOrNull()
    }

    /** يطبّق تأثيرات المقطع. لو التأثيرات ما اتغيرتش (زي قطعتين من نفس المقطع) مبنعيدش بناء الـ pipeline عشان الانتقال يبقى سلس. */
    private fun applyFx(i: Int) {
        val c = data.clips.getOrNull(i) ?: return
        player.setPlaybackSpeed((if (c.isImage) 1f else c.speed) * (if (jklRate > 0f) jklRate else 1f))
        player.volume = if (c.muted) 0f else c.volume.coerceIn(0f, 1f)
        val key = fxKey(c)
        if (key == lastFxKey) return
        lastFxKey = key
        player.setVideoEffects(if (fxBypass) emptyList() else VideoEffects.preview(c))
        // وهو واقف: لازم نعيد رسم الفريم الحالي عشان التعديل يظهر لحظيًا
        if (!player.isPlaying && player.playbackState != Player.STATE_IDLE) {
            player.seekTo(player.currentMediaItemIndex, player.currentPosition)
        }
    }

    // ---------------------------------------------------------------- music

    private fun loadMusic() {
        val u = data.musicUri
        if (u == null) {
            music.stop()
            music.clearMediaItems()
            return
        }
        music.setMediaItem(MediaItem.fromUri(Uri.parse(u)))
        music.prepare()
        music.volume = data.musicVolume.coerceIn(0f, 1f)
        syncMusic()
    }

    private fun syncMusic() {
        if (data.musicUri == null) return
        music.volume = data.musicVolume.coerceIn(0f, 1f)
        if (player.isPlaying) {
            val md = data.musicDurationMs
            music.seekTo(if (md > 0) positionMs.coerceAtMost(md - 1) else positionMs)
            music.play()
        } else {
            music.pause()
        }
    }

    // ---------------------------------------------------------------- transport

    fun togglePlay() {
        if (data.clips.isEmpty()) return
        resetJkl()
        if (player.isPlaying) player.pause() else player.play()
    }

    fun pause() {
        resetJkl()
        player.pause()
    }

    // ---------------- J-K-L
    var jklRate by mutableStateOf(0f)
        private set
    private var jklJob: Job? = null

    private fun resetJkl() {
        if (jklRate == 0f && jklJob == null) return
        jklJob?.cancel(); jklJob = null
        if (jklRate < 0f) player.setSeekParameters(androidx.media3.exoplayer.SeekParameters.EXACT)
        jklRate = 0f
        val c = data.clips.getOrNull(curClipIndex())
        player.setPlaybackSpeed(if (c == null || c.isImage) 1f else c.speed)
    }

    /** J = رجوع (يتضاعف)، K = إيقاف، L = تقديم (يتضاعف). */
    fun jkl(key: Char) {
        if (data.clips.isEmpty()) return
        when (key) {
            'K' -> { resetJkl(); player.pause() }
            'L' -> {
                jklJob?.cancel(); jklJob = null
                if (jklRate < 0f) player.setSeekParameters(androidx.media3.exoplayer.SeekParameters.EXACT)
                jklRate = if (jklRate < 1f) 1f else (jklRate * 2f).coerceAtMost(8f)
                val c = data.clips.getOrNull(curClipIndex())
                player.setPlaybackSpeed((if (c == null || c.isImage) 1f else c.speed) * jklRate)
                player.play()
            }
            'J' -> {
                player.pause()
                jklRate = if (jklRate > -1f) -1f else (jklRate * 2f).coerceAtLeast(-8f)
                player.setSeekParameters(androidx.media3.exoplayer.SeekParameters.CLOSEST_SYNC)
                jklJob?.cancel()
                jklJob = viewModelScope.launch {
                    while (true) {
                        delay(80)
                        val step = (80f * -jklRate).toLong()
                        val t = (positionMs - step).coerceAtLeast(0L)
                        seekTimeline(t)
                        if (t <= 0L) { resetJkl(); break }
                    }
                }
            }
        }
    }

    // ---------------- LUT / معلومات الكاميرا / مطابقة اللقطات / تجميع المشروع
    fun importLut(uri: Uri) {
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) { Lut.import(appCtx, uri) }
            if (path == null) { message = "ملف LUT غير صالح (لازم .cube ثلاثي الأبعاد)"; return@launch }
            updateSelected { it.copy(lutUri = path) }
            message = "اتطبّق الـ LUT على المقطع"
        }
    }

    fun clearLut() { updateSelected { it.copy(lutUri = null) } }

    suspend fun cameraInfo(): List<Pair<String, String>> {
        val c = selectedClip ?: return emptyList()
        return withContext(Dispatchers.IO) {
            val out = ArrayList<Pair<String, String>>()
            val r = android.media.MediaMetadataRetriever()
            try {
                r.setDataSource(appCtx, Uri.parse(c.uri))
                fun k(label: String, key: Int, fmt: (String) -> String = { it }) {
                    r.extractMetadata(key)?.takeIf { it.isNotBlank() }?.let { out.add(label to fmt(it)) }
                }
                k("الصيغة", android.media.MediaMetadataRetriever.METADATA_KEY_MIMETYPE)
                val w = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                val h = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                if (w != null && h != null) out.add("الدقة" to "$w × $h")
                k("الدوران", android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION) { "$it°" }
                k("معدل الإطارات", android.media.MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE) { "$it fps" }
                k("المدة", android.media.MediaMetadataRetriever.METADATA_KEY_DURATION) { formatDurationMs(it.toLongOrNull() ?: 0L) }
                k("معدل البت", android.media.MediaMetadataRetriever.METADATA_KEY_BITRATE) { "%.1f Mbps".format((it.toLongOrNull() ?: 0L) / 1_000_000.0) }
                k("تاريخ التصوير", android.media.MediaMetadataRetriever.METADATA_KEY_DATE)
                k("الموقع", android.media.MediaMetadataRetriever.METADATA_KEY_LOCATION)
                k("صوت", android.media.MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) { if (it == "yes") "موجود" else it }
                k("عدد المسارات", android.media.MediaMetadataRetriever.METADATA_KEY_NUM_TRACKS)
                k("الشركة", android.media.MediaMetadataRetriever.METADATA_KEY_MANUFACTURER)
            } catch (t: Throwable) {
                out.add("خطأ" to "تعذّر قراءة بيانات الملف")
            } finally { runCatching { r.release() } }
            out
        }
    }

    private fun formatDurationMs(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60)
    }

    /** مطابقة التعريض والحرارة بين اللقطات: كل المقاطع بتتظبط على المقطع المحدد. */
    fun matchShots() {
        val refIdx = selectedIndex
        val clips = data.clips
        if (clips.size < 2) { message = "محتاج مقطعين على الأقل"; return }
        processingMsg("جاري تحليل اللقطات...")
        viewModelScope.launch {
            val stats: List<FloatArray?> = withContext(Dispatchers.IO) {
                clips.map { c ->
                    if (c.isImage) null else runCatching {
                        val r = android.media.MediaMetadataRetriever()
                        r.setDataSource(appCtx, Uri.parse(c.uri))
                        val bmp = r.getFrameAtTime((c.startMs + (c.endMs - c.startMs) / 2) * 1000L, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        r.release()
                        bmp?.let { b ->
                            val s = Bitmap.createScaledBitmap(b, 48, 48, true)
                            val px = IntArray(48 * 48); s.getPixels(px, 0, 48, 0, 0, 48, 48)
                            var rr = 0f; var gg = 0f; var bb = 0f; var sat = 0f
                            for (p in px) {
                                val r1 = ((p shr 16) and 255) / 255f; val g1 = ((p shr 8) and 255) / 255f; val b1 = (p and 255) / 255f
                                rr += r1; gg += g1; bb += b1
                                sat += maxOf(r1, g1, b1) - minOf(r1, g1, b1)
                            }
                            val n = px.size.toFloat()
                            floatArrayOf(rr / n, gg / n, bb / n, sat / n)
                        }
                    }.getOrNull()
                }
            }
            clearProcessing()
            val ref = stats.getOrNull(refIdx)
            if (ref == null) { message = "اختار مقطع فيديو كمرجع"; return@launch }
            mutate { d ->
                d.copy(clips = d.clips.mapIndexed { i, c ->
                    val st = stats.getOrNull(i)
                    if (i == refIdx || st == null) c else {
                        val lumRef = 0.299f * ref[0] + 0.587f * ref[1] + 0.114f * ref[2]
                        val lum = 0.299f * st[0] + 0.587f * st[1] + 0.114f * st[2]
                        val warmRef = ref[0] - ref[2]; val warm = st[0] - st[2]
                        c.copy(adjust = c.adjust.copy(
                            brightness = (c.adjust.brightness + (lumRef - lum) * 0.8f).coerceIn(-0.4f, 0.4f),
                            warmth = (c.adjust.warmth + (warmRef - warm) * 2.5f).coerceIn(-0.5f, 0.5f),
                            saturation = (c.adjust.saturation + (ref[3] - st[3]) * 2f).coerceIn(-0.5f, 0.5f),
                        ))
                    }
                })
            }
            message = "اتطابقت اللقطات على المقطع المحدد"
        }
    }

    private fun processingMsg(m: String) { message = m }
    private fun clearProcessing() {}

    /** يجمّع الوسائط المستخدمة + EDL في ملف ZIP منظّم للتسليم. */
    suspend fun consolidate(): File? = withContext(Dispatchers.IO) {
        try {
            val zip = File(appCtx.cacheDir, "nasaq_consolidated.zip")
            java.util.zip.ZipOutputStream(zip.outputStream().buffered()).use { z ->
                val uris = LinkedHashSet<String>()
                data.clips.forEach { uris.add(it.uri) }
                data.musicUri?.let { uris.add(it) }
                uris.forEachIndexed { i, u ->
                    val name = (Uri.parse(u).lastPathSegment ?: "media").substringAfterLast('/')
                    z.putNextEntry(java.util.zip.ZipEntry("media/%02d_%s".format(i + 1, name)))
                    appCtx.contentResolver.openInputStream(Uri.parse(u))?.use { it.copyTo(z) }
                    z.closeEntry()
                }
                exportEdl()?.let { e ->
                    z.putNextEntry(java.util.zip.ZipEntry("timeline.edl")); z.write(e.readBytes()); z.closeEntry()
                }
                exportSrt()?.let { e ->
                    z.putNextEntry(java.util.zip.ZipEntry("captions.srt")); z.write(e.readBytes()); z.closeEntry()
                }
            }
            zip
        } catch (t: Throwable) { null }
    }

    private var resumeAfterScrub = false
    val isScrubbing: Boolean get() = scrubbing

    fun scrubTo(t: Long) {
        if (!scrubbing) {
            player.setSeekParameters(androidx.media3.exoplayer.SeekParameters.CLOSEST_SYNC)
            // لو الفيديو شغّال: بنوقفه أثناء السحب (عشان السحب مايتعاركش مع التشغيل) ونكمّل بعد الإفلات
            resumeAfterScrub = player.isPlaying && jklRate == 0f
            if (resumeAfterScrub) player.pause()
        }
        scrubbing = true
        seekTimeline(t)
    }

    fun endScrub() {
        scrubbing = false
        player.setSeekParameters(androidx.media3.exoplayer.SeekParameters.EXACT)
        if (data.clips.isNotEmpty()) player.seekTo(player.currentMediaItemIndex, player.currentPosition)
        if (resumeAfterScrub) { resumeAfterScrub = false; player.play() }
    }

    fun seekTimeline(t: Long) {
        val clips = data.clips
        if (clips.isEmpty()) return
        var acc = 0L
        for ((i, c) in clips.withIndex()) {
            if (t < acc + c.effectiveMs || i == clips.lastIndex) {
                val local = ((t - acc) * c.speed).toLong().coerceIn(0L, (c.endMs - c.startMs).coerceAtLeast(0L))
                playerSeek(i, local)
                applyFx(i)
                selectedIndex = i
                positionMs = t
                if (data.musicUri != null && player.isPlaying) syncMusic()
                return
            }
            acc += c.effectiveMs
        }
    }

    fun selectClip(i: Int) {
        if (i !in data.clips.indices) return
        selectedIndex = i
        selectedText = null
        playerSeek(i, 0L)
        applyFx(i)
        positionMs = data.clipStartMs(i)
    }

    // ---------------------------------------------------------------- mutation core

    private fun refreshFlags() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    private fun pushUndo(d: VideoData) {
        undoStack.addLast(d)
        if (undoStack.size > 60) undoStack.removeFirst()
        redoStack.clear()
    }

    private fun mutate(live: Boolean = false, f: (VideoData) -> VideoData) {
        val old = data
        val new = f(old)
        if (new == old) return
        if (!live) pushUndo(old) else if (gestureBase == null) gestureBase = old
        data = new
        afterChange(old, new, live)
        refreshFlags()
    }

    private fun afterChange(old: VideoData, new: VideoData, live: Boolean) {
        if (sig(new) != lastSig) {
            if (live) { pendingRebuild = true; scheduleFx() } else rebuildKeep()
        } else {
            if (live) scheduleFx() else applyFx(curClipIndex())
        }
        if (new.musicUri != old.musicUri) loadMusic() else music.volume = new.musicVolume.coerceIn(0f, 1f)
        selectedIndex = selectedIndex.coerceIn(0, maxOf(0, new.clips.lastIndex))
        scheduleSave()
    }

    fun endLive() {
        val base = gestureBase
        gestureBase = null
        if (base != null && base != data) pushUndo(base)
        if (pendingRebuild) {
            pendingRebuild = false
            rebuildKeep()
        } else if (fxJob?.isActive == true) {
            fxJob?.cancel()
            applyFx(curClipIndex())
        }
        refreshFlags()
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val old = data
        redoStack.addLast(old)
        restore(undoStack.removeLast(), old)
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val old = data
        undoStack.addLast(old)
        restore(redoStack.removeLast(), old)
    }

    private fun restore(v: VideoData, old: VideoData) {
        val idx = curClipIndex()
        data = v
        selectedIndex = selectedIndex.coerceIn(0, maxOf(0, v.clips.lastIndex))
        rebuildPlayer(idx, 0L)
        if (v.musicUri != old.musicUri) loadMusic()
        refreshFlags()
        scheduleSave()
    }

    // ---------------------------------------------------------------- clip operations

    fun updateClip(index: Int, live: Boolean = false, f: (VideoClip) -> VideoClip) {
        mutate(live) { d -> d.copy(clips = d.clips.mapIndexed { i, c -> if (i == index) f(c) else c }) }
    }

    fun updateSelected(live: Boolean = false, f: (VideoClip) -> VideoClip) = updateClip(selectedIndex, live, f)

    fun updateAllClips(f: (VideoClip) -> VideoClip) {
        mutate { d -> d.copy(clips = d.clips.map(f)) }
    }

    fun splitAtPlayhead() {
        val i = curClipIndex()
        val c = data.clips.getOrNull(i) ?: return
        val cut = c.startMs + curLocalMs()
        if (cut - c.startMs < 300 || c.endMs - cut < 300) {
            message = "حرّك المؤشر لمكان أبعد عن حافة المقطع"
            return
        }
        val a = c.copy(endMs = cut)
        val b = c.copy(id = ProjectFactory.nextId(), startMs = cut)
        mutate { d ->
            val list = d.clips.toMutableList()
            list[i] = a
            list.add(i + 1, b)
            d.copy(clips = list)
        }
        selectClip(i + 1)
    }

    fun duplicateSelected() {
        val i = selectedIndex
        val c = data.clips.getOrNull(i) ?: return
        mutate { d ->
            val list = d.clips.toMutableList()
            list.add(i + 1, c.copy(id = ProjectFactory.nextId()))
            d.copy(clips = list)
        }
        selectClip(i + 1)
    }

    fun reverseOrder() {
        if (data.clips.size < 2) return
        mutate { d -> d.copy(clips = d.clips.reversed()) }
        selectClip(0)
    }

    fun loopSelected(times: Int) {
        val i = selectedIndex
        val c = data.clips.getOrNull(i) ?: return
        if (times < 2) return
        mutate { d ->
            val list = d.clips.toMutableList()
            for (k in 1 until times) list.add(i + k, c.copy(id = ProjectFactory.nextId()))
            d.copy(clips = list)
        }
    }

    fun deleteSelected() {
        val i = selectedIndex
        if (data.clips.size <= 1) {
            message = "لازم يفضل مقطع واحد على الأقل"
            return
        }
        mutate { d -> d.copy(clips = d.clips.filterIndexed { idx, _ -> idx != i }) }
        selectClip((i - 1).coerceAtLeast(0).coerceAtMost(data.clips.lastIndex))
    }

    fun moveSelected(delta: Int) {
        val i = selectedIndex
        val j = i + delta
        if (j !in data.clips.indices) return
        mutate { d ->
            val list = d.clips.toMutableList()
            val t = list[i]
            list[i] = list[j]
            list[j] = t
            d.copy(clips = list)
        }
        selectClip(j)
    }

    fun addClips(uris: List<Uri>) {
        if (uris.isEmpty()) return
        busyText = "جاري استيراد الملفات..."
        viewModelScope.launch {
            val clips = withContext(Dispatchers.IO) {
                uris.mapNotNull { u -> runCatching { ProjectFactory.makeClip(appCtx, projectId, u) }.getOrNull() }
            }
            busyText = null
            if (clips.isEmpty()) {
                message = "تعذّر قراءة الملفات المختارة"
                return@launch
            }
            mutate { d -> d.copy(clips = d.clips + clips) }
            selectClip(data.clips.size - clips.size)
            if (lookThumbs.isEmpty()) buildLookThumbs()
        }
    }

    // ---------------------------------------------------------------- Keyframes
    var kfSel by mutableStateOf(-1)

    fun addKeyframe() {
        val c = selectedClip ?: return
        if (c.isImage && c.effectiveMs < 100) return
        val start = data.clipStartMs(selectedIndex)
        val t = ((positionMs - start).toFloat() / c.effectiveMs).coerceIn(0f, 1f)
        val cur = VideoEffects.kfAt(c, t)
        updateSelected { cl ->
            cl.copy(kfs = (cl.kfs.filter { kotlin.math.abs(it.t - t) > 0.01f } + Keyframe(t, cur.zoom, cur.x, cur.y)).sortedBy { it.t })
        }
        kfSel = (selectedClip?.kfs ?: emptyList()).indexOfFirst { kotlin.math.abs(it.t - t) <= 0.01f }
    }

    fun updateKf(i: Int, live: Boolean, f: (Keyframe) -> Keyframe) {
        updateSelected(live) { cl -> cl.copy(kfs = cl.kfs.mapIndexed { j, k -> if (j == i) f(k) else k }) }
    }

    fun deleteKf(i: Int) {
        updateSelected { cl -> cl.copy(kfs = cl.kfs.filterIndexed { j, _ -> j != i }) }
        kfSel = -1
    }

    fun clearKfs() { updateSelected { it.copy(kfs = emptyList()) }; kfSel = -1 }

    // ---------------------------------------------------------------- اكتشاف المشاهد والصمت

    private fun replaceSelectedWithRanges(ranges: List<Pair<Long, Long>>, speeds: List<Float>? = null) {
        val i = selectedIndex
        val c = data.clips.getOrNull(i) ?: return
        val pieces = ranges.mapIndexed { n, (s, e) ->
            c.copy(
                id = if (n == 0) c.id else ProjectFactory.nextId(), startMs = s, endMs = e, kfs = emptyList(),
                speed = speeds?.getOrNull(n) ?: c.speed
            )
        }
        mutate { d ->
            val list = d.clips.toMutableList()
            list.removeAt(i)
            list.addAll(i, pieces)
            d.copy(clips = list)
        }
        selectedIndex = i
    }

    private fun histOf(b: Bitmap): FloatArray {
        val s = Bitmap.createScaledBitmap(b, 32, 32, true)
        val h = FloatArray(24)
        val px = IntArray(32 * 32)
        s.getPixels(px, 0, 32, 0, 0, 32, 32)
        for (c in px) {
            h[((c shr 16) and 255) / 32]++
            h[8 + ((c shr 8) and 255) / 32]++
            h[16 + (c and 255) / 32]++
        }
        for (i in h.indices) h[i] /= 1024f
        if (s !== b) s.recycle()
        return h
    }

    /** يقسّم المقطع المحدّد تلقائيًا عند تغيّر المشهد. */
    fun detectScenes() {
        val c = selectedClip ?: return
        if (c.isImage) { message = "المقطع ده صورة"; return }
        busyText = "جاري اكتشاف المشاهد..."
        viewModelScope.launch {
            val cuts = withContext(Dispatchers.IO) {
                val out = ArrayList<Long>()
                val mmr = android.media.MediaMetadataRetriever()
                try {
                    mmr.setDataSource(appCtx, Uri.parse(c.uri))
                    val len = c.endMs - c.startMs
                    val step = maxOf(400L, len / 300L)
                    var prev: FloatArray? = null
                    var last = c.startMs
                    var t = c.startMs
                    while (t < c.endMs) {
                        val fr = mmr.getFrameAtTime(t * 1000L, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        if (fr != null) {
                            val h = histOf(fr)
                            fr.recycle()
                            val p0 = prev
                            if (p0 != null) {
                                var d = 0f
                                for (k in 0 until 24) d += kotlin.math.abs(h[k] - p0[k])
                                if (d / 3f > 0.45f && t - last >= 1000L && c.endMs - t >= 1000L) { out.add(t); last = t }
                            }
                            prev = h
                        }
                        t += step
                    }
                } catch (_: Throwable) {
                } finally { runCatching { mmr.release() } }
                out
            }
            busyText = null
            if (cuts.isEmpty()) { message = "مفيش تغيير مشاهد واضح في المقطع"; return@launch }
            val b = listOf(c.startMs) + cuts + listOf(c.endMs)
            replaceSelectedWithRanges(b.zipWithNext())
            message = "اتقسّم لـ ${cuts.size + 1} مشاهد"
        }
    }

    /** تقسيم المقطع لأجزاء متساوية. */
    fun splitEqual(n: Int) {
        val c = selectedClip ?: return
        if (c.isImage || n < 2) return
        val len = c.endMs - c.startMs
        if (len / n < 300L) { message = "المقطع قصير على التقسيم ده"; return }
        replaceSelectedWithRanges((0 until n).map { c.startMs + len * it / n to c.startMs + len * (it + 1) / n })
        message = "اتقسّم لـ $n أجزاء"
    }

    private fun localSrcMs(c: VideoClip): Long =
        c.startMs + ((positionMs - data.clipStartMs(selectedIndex)) * c.speed).toLong()

    fun trimStartHere() {
        val c = selectedClip ?: return
        if (c.isImage) return
        val ns = localSrcMs(c)
        if (ns <= c.startMs + 50L || ns >= c.endMs - 300L) { message = "حرّك المؤشر جوه المقطع"; return }
        updateSelected { it.copy(startMs = ns) }
    }

    fun trimEndHere() {
        val c = selectedClip ?: return
        if (c.isImage) return
        val ne = localSrcMs(c)
        if (ne <= c.startMs + 300L || ne >= c.endMs - 50L) { message = "حرّك المؤشر جوه المقطع"; return }
        updateSelected { it.copy(endMs = ne) }
    }

    /** منحنيات سرعة جاهزة: 0 بطيء في النص، 1 سريع في النص، 2 بطيء ثم سريع. */
    fun speedRamp(kind: Int) {
        val c = selectedClip ?: return
        if (c.isImage) return
        val len = c.endMs - c.startMs
        if (len < 900L) { message = "المقطع قصير"; return }
        val a = c.startMs + len / 3; val b = c.startMs + 2 * len / 3
        val speeds = when (kind) { 0 -> listOf(1f, 0.35f, 1f); 1 -> listOf(1f, 3f, 1f); else -> listOf(0.4f, 1f, 2.5f) }
        replaceSelectedWithRanges(listOf(c.startMs to a, a to b, b to c.endMs), speeds)
        message = "اتطبّق منحنى السرعة"
    }

    fun seekMarker(dir: Int) {
        val m = data.markers.sorted()
        val p = positionMs
        val t = if (dir > 0) m.firstOrNull { it > p + 50L } else m.lastOrNull { it < p - 50L }
        if (t == null) { message = "مفيش علامة كده"; return }
        scrubTo(t); endScrub()
    }

    /** يمسح الصمت من المقطع المحدّد ويقسّمه لأجزاء (Jump-cut). */
    fun removeSilence(thresholdDb: Float) {
        val c = selectedClip ?: return
        if (c.isImage) { message = "المقطع ده صورة"; return }
        busyText = "جاري تحليل الصوت..."
        viewModelScope.launch {
            val sil = withContext(Dispatchers.IO) {
                val pcm = com.binarybeast.mediastudio.audio.AudioPcm.decode(appCtx, Uri.parse(c.uri), listOf(c.startMs to c.endMs))
                pcm?.let { com.binarybeast.mediastudio.audio.SilenceDetector.find(it, thresholdDb, 500L) }
            }
            busyText = null
            if (sil == null) { message = "تعذّر تحليل الصوت (المقطع ممكن يكون من غير صوت)"; return@launch }
            if (sil.isEmpty()) { message = "مفيش صمت واضح. جرّب حساسية أعلى"; return@launch }
            val pad = 120L
            val keep = ArrayList<Pair<Long, Long>>()
            var cur = 0L
            val len = c.endMs - c.startMs
            for ((s, e) in sil) {
                val ks = cur; val ke = (s + pad).coerceAtMost(len)
                if (ke - ks > 250L) keep.add(ks to ke)
                cur = (e - pad).coerceAtLeast(0L)
            }
            if (len - cur > 250L) keep.add(cur to len)
            if (keep.isEmpty()) { message = "الصوت كله صمت تقريبًا"; return@launch }
            replaceSelectedWithRanges(keep.map { (s, e) -> (c.startMs + s) to (c.startMs + e) })
            message = "اتشال الصمت: ${keep.size} جزء"
        }
    }

    // ---------------------------------------------------------------- ترجمة SRT

    private fun srtTime(ms: Long): String {
        val t = ms.coerceAtLeast(0L)
        return "%02d:%02d:%02d,%03d".format(t / 3600000, t / 60000 % 60, t / 1000 % 60, t % 1000)
    }

    fun exportSrt(): File? {
        val items = data.texts.filter { it.shape == 0 && it.text.isNotBlank() }.sortedBy { it.startMs }
        if (items.isEmpty()) { message = "مفيش نصوص تتصدّر كترجمة"; return null }
        val sb = StringBuilder()
        items.forEachIndexed { i, t ->
            val end = if (t.endMs < 0) data.totalMs else t.endMs
            sb.append(i + 1).append('\n').append(srtTime(t.startMs)).append(" --> ").append(srtTime(end)).append('\n')
                .append(t.text).append("\n\n")
        }
        val f = File(appCtx.cacheDir, "nasaq_captions.srt")
        return runCatching { f.writeText(sb.toString()); f }.getOrNull()
    }

    private fun parseSrtTime(s: String): Long? {
        val m = Regex("(\\d+):(\\d+):(\\d+)[,.](\\d+)").find(s.trim()) ?: return null
        val (h, mi, se, ms) = m.destructured
        return h.toLong() * 3600000 + mi.toLong() * 60000 + se.toLong() * 1000 + ms.padEnd(3, '0').take(3).toLong()
    }

    fun importSrt(uri: Uri) {
        viewModelScope.launch {
            val txt = withContext(Dispatchers.IO) {
                runCatching { appCtx.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.readText() }.getOrNull()
            }
            if (txt.isNullOrBlank()) { message = "تعذّر قراءة ملف الترجمة"; return@launch }
            val layers = ArrayList<TextLayer>()
            for (block in txt.replace("\r", "").split(Regex("\n\\s*\n"))) {
                val lines = block.lines().filter { it.isNotBlank() }
                val ti = lines.indexOfFirst { it.contains("-->") }
                if (ti < 0) continue
                val parts = lines[ti].split("-->")
                val s = parseSrtTime(parts[0]) ?: continue
                val e = parseSrtTime(parts.getOrElse(1) { "" }) ?: continue
                val text = lines.drop(ti + 1).joinToString("\n").replace(Regex("<[^>]+>"), "").trim()
                if (text.isEmpty()) continue
                layers.add(TextLayer(
                    id = ProjectFactory.nextId(), text = text, y = 0.86f, size = 0.05f,
                    bgColor = 0x99000000.toInt(), startMs = s, endMs = e
                ))
            }
            if (layers.isEmpty()) { message = "مفيش ترجمة صالحة في الملف"; return@launch }
            mutate { it.copy(texts = it.texts + layers) }
            message = "اتضافت ${layers.size} جملة"
        }
    }

    /** يحدّد ضربات الموسيقى ويحطها علامات على التايم لاين. */
    fun detectBeats() {
        val uri = data.musicUri ?: run { message = "ضيف موسيقى الأول"; return }
        busyText = "جاري تحليل الإيقاع..."
        viewModelScope.launch {
            val beats = withContext(Dispatchers.IO) {
                val pcm = com.binarybeast.mediastudio.audio.AudioPcm.decode(appCtx, Uri.parse(uri), listOf(0L to minOf(data.musicDurationMs.coerceAtLeast(1000L), 300_000L)))
                pcm?.let { com.binarybeast.mediastudio.audio.BeatDetector.find(it) }
            }
            busyText = null
            if (beats == null) { message = "تعذّر تحليل الموسيقى"; return@launch }
            val total = data.totalMs
            val ms = beats.filter { it < total }
            if (ms.isEmpty()) { message = "مفيش إيقاع واضح"; return@launch }
            mutate { d -> d.copy(markers = (d.markers + ms).distinct().sorted()) }
            message = "اتحطّت ${ms.size} علامة على الإيقاع"
        }
    }

    fun clearMarkers() = mutate { it.copy(markers = emptyList()) }

    fun addQrLayer(text: String) {
        val f = com.binarybeast.mediastudio.image.QrTool.makeFile(appCtx, text)
        if (f == null) { message = "تعذّر عمل الـ QR"; return }
        addImageLayer(Uri.fromFile(f))
    }

    /** ترجمة كل النصوص (الترجمات/العناوين) للغة معيّنة. */
    fun translateTexts(target: String) {
        val layers = data.texts.filter { it.shape == 0 && it.text.isNotBlank() }
        if (layers.isEmpty()) { message = "مفيش نصوص للترجمة"; return }
        busyText = "جاري الترجمة..."
        viewModelScope.launch {
            val res = com.binarybeast.mediastudio.image.TextTranslate.translate(layers.map { it.text }, target)
            busyText = null
            if (res == null) { message = "فشلت الترجمة (محتاج إنترنت أول مرة لتحميل اللغة)"; return@launch }
            val map = layers.map { it.id }.zip(res).toMap()
            mutate { d -> d.copy(texts = d.texts.map { t -> map[t.id]?.let { t.copy(text = it) } ?: t }) }
            message = "اتترجمت ${layers.size} نص"
        }
    }

    /** مدة كل الصور (سلايد شو). */
    fun setImageDurations(ms: Long) {
        mutate { d ->
            d.copy(clips = d.clips.map { c ->
                if (c.isImage) c.copy(endMs = (c.startMs + ms).coerceAtMost(maxOf(c.srcDurationMs, c.startMs + 500L))) else c
            })
        }
    }

    fun toggleMarker() {
        val p = positionMs
        mutate { d ->
            val near = d.markers.firstOrNull { kotlin.math.abs(it - p) < 200L }
            d.copy(markers = if (near != null) d.markers - near else (d.markers + p).sorted())
        }
    }

    fun setAspect(a: Float) = mutate { it.copy(aspect = a) }

    fun setResolution(r: Int) = mutate { it.copy(resolution = r) }

    // ---------------------------------------------------------------- music

    fun setMusic(uri: Uri) {
        busyText = "جاري إضافة الموسيقى..."
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val name = repo.displayName(uri)
                    val local = repo.importIfNeeded(projectId, uri, forceCopy = true)
                    Triple(local, name, MediaRepository.probeAudioDuration(appCtx, local))
                }.getOrNull()
            }
            busyText = null
            if (r == null) {
                message = "تعذّر قراءة ملف الصوت"
                return@launch
            }
            mutate { it.copy(musicUri = r.first.toString(), musicName = r.second, musicDurationMs = r.third) }
        }
    }

    fun removeMusic() = mutate { it.copy(musicUri = null, musicName = "", musicDurationMs = 0L) }

    fun setMusicVolume(v: Float, live: Boolean) = mutate(live) { it.copy(musicVolume = v) }

    // ---------------------------------------------------------------- text overlays

    fun addText(text: String, emoji: Boolean = false) {
        val id = ProjectFactory.nextId()
        val total = data.totalMs
        val start = positionMs.coerceIn(0L, maxOf(0L, total - 500L))
        val end = minOf(total, start + 3000L)
        val t = TextLayer(
            id = id, text = text, size = if (emoji) 0.16f else 0.07f,
            shadow = !emoji, bold = !emoji, startMs = start, endMs = end
        )
        mutate { it.copy(texts = it.texts + t) }
        selectedText = id
    }

    fun updateText(id: Long, live: Boolean = false, f: (TextLayer) -> TextLayer) {
        mutate(live) { d -> d.copy(texts = d.texts.map { if (it.id == id) f(it) else it }) }
    }

    fun deleteText(id: Long) {
        mutate { d -> d.copy(texts = d.texts.filter { it.id != id }) }
        if (selectedText == id) selectedText = null
    }

    /** شكل (مستطيل/دائرة/نجمة...) فوق الفيديو. */
    fun addShape(kind: Int) {
        val id = ProjectFactory.nextId()
        val total = data.totalMs
        val start = positionMs.coerceIn(0L, maxOf(0L, total - 500L))
        val end = minOf(total, start + 3000L)
        val t = TextLayer(
            id = id, text = "", shape = kind, size = if (kind == 7 || kind == 8) 0.04f else 0.2f,
            aspect = if (kind == 7 || kind == 8) 5f else 1f, shadow = false, bold = false,
            startMs = start, endMs = end
        )
        mutate { it.copy(texts = it.texts + t) }
        selectedText = id
    }

    /** صورة/لوجو فوق الفيديو. */
    fun addImageLayer(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val local = runCatching { repo.importIfNeeded(projectId, uri, forceCopy = true) }.getOrNull()
            val bmp = local?.let { ImageCache.load(appCtx, it.toString()) }
            if (local == null || bmp == null) {
                withContext(Dispatchers.Main) { message = "تعذّر فتح الصورة" }
                return@launch
            }
            val aspect = bmp.width.toFloat() / bmp.height
            val id = ProjectFactory.nextId()
            withContext(Dispatchers.Main) {
                val total = data.totalMs
                val start = positionMs.coerceIn(0L, maxOf(0L, total - 500L))
                val t = TextLayer(
                    id = id, text = "", shape = 9, imageUri = local.toString(), aspect = aspect,
                    size = 0.3f / maxOf(1f, aspect), shadow = false, bold = false,
                    startMs = start, endMs = minOf(total, start + 3000L)
                )
                mutate { it.copy(texts = it.texts + t) }
                selectedText = id
            }
        }
    }

    /** تلاشي الشفافية للمعاينة عند الزمن t على التايم لاين (0 = ظاهر، 1 = أسود). */
    fun fadeAlpha(t: Long): Float {
        var start = 0L
        for (c in data.clips) {
            val dur = c.effectiveMs
            if (t < start + dur || c === data.clips.last()) {
                val local = (t - start).coerceIn(0L, dur)
                var a = 0f
                if (c.fadeInMs > 0 && local < c.fadeInMs) a = maxOf(a, 1f - local.toFloat() / c.fadeInMs)
                if (c.fadeOutMs > 0 && local > dur - c.fadeOutMs) a = maxOf(a, (local - (dur - c.fadeOutMs)).toFloat() / c.fadeOutMs)
                return a.coerceIn(0f, 1f)
            }
            start += dur
        }
        return 0f
    }

    /** تجميد الإطار: يقسم المقطع عند المؤشر ويدخل صورة ثابتة من الإطار الحالي مدتها 3 ثواني. */
    fun freezeFrame() {
        val i = curClipIndex()
        val c = data.clips.getOrNull(i) ?: return
        if (c.isImage) { message = "المقطع ده صورة أصلًا"; return }
        val pos = c.startMs + curLocalMs()
        if (pos - c.startMs < 300 || c.endMs - pos < 300) {
            message = "حرّك المؤشر لمكان أبعد عن حافة المقطع"
            return
        }
        player.pause()
        busyText = "جاري تجميد الإطار..."
        viewModelScope.launch {
            val clip = withContext(Dispatchers.IO) {
                runCatching {
                    val bmp = MediaRepository.frameAt(appCtx, Uri.parse(c.uri), pos) ?: return@runCatching null
                    val f = File(repo.dir(projectId), "freeze_${System.currentTimeMillis()}.jpg")
                    f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                    VideoClip(
                        id = ProjectFactory.nextId(), uri = Uri.fromFile(f).toString(), isImage = true,
                        srcDurationMs = 30_000L, startMs = 0L, endMs = 3_000L,
                        width = bmp.width, height = bmp.height, fill = c.fill,
                        rotation = c.rotation, flipH = c.flipH,
                        lookId = c.lookId, lookStrength = c.lookStrength, adjust = c.adjust
                    )
                }.getOrNull()
            }
            busyText = null
            if (clip == null) { message = "تعذّر تجميد الإطار"; return@launch }
            mutate { d ->
                val list = d.clips.toMutableList()
                list[i] = c.copy(endMs = pos, fadeOutMs = 0L)
                list.add(i + 1, clip)
                list.add(i + 2, c.copy(id = ProjectFactory.nextId(), startMs = pos, fadeInMs = 0L))
                d.copy(clips = list)
            }
            selectClip(i + 1)
        }
    }

    fun duplicateText(id: Long) {
        val t = data.texts.firstOrNull { it.id == id } ?: return
        val nid = ProjectFactory.nextId()
        mutate { it.copy(texts = it.texts + t.copy(id = nid, x = (t.x + 0.05f).coerceAtMost(0.95f), y = (t.y + 0.05f).coerceAtMost(0.95f))) }
        selectedText = nid
    }

    // ---------------------------------------------------------------- frame capture & thumbs

    fun captureFrame() {
        val i = curClipIndex()
        val c = data.clips.getOrNull(i) ?: return
        val pos = c.startMs + curLocalMs()
        busyText = "جاري التقاط الصورة..."
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val u = Uri.parse(c.uri)
                    val bmp = if (c.isImage) BitmapLoader.load(appCtx, u, 4096) else MediaRepository.frameAt(appCtx, u, pos)
                    if (bmp == null) false else {
                        MediaRepository.saveImage(appCtx, bmp, ExportFormat.JPG, 95)
                        true
                    }
                }.getOrDefault(false)
            }
            busyText = null
            message = if (ok) "تم حفظ اللقطة في المعرض" else "تعذّر التقاط اللقطة"
        }
    }

    private fun buildLookThumbs() {
        val c = data.clips.firstOrNull() ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val u = Uri.parse(c.uri)
            val frame = if (c.isImage) BitmapLoader.load(appCtx, u, 160) else MediaRepository.frameAt(appCtx, u, c.startMs)
            if (frame == null) return@launch
            val k = 120f / maxOf(frame.width, frame.height)
            val small = if (k < 1f) Bitmap.createScaledBitmap(frame, (frame.width * k).toInt().coerceAtLeast(1), (frame.height * k).toInt().coerceAtLeast(1), true) else frame
            val out = Looks.all.associate { it.id to ImageProcessor.render(small, ImageEdit(lookId = it.id)) }
            withContext(Dispatchers.Main) { lookThumbs.putAll(out) }
        }
    }

    // ---------------------------------------------------------------- persistence

    private fun snapshot(): Project? {
        val p = project ?: return null
        val u = p.copy(video = data, updatedAt = System.currentTimeMillis())
        project = u
        return u
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(900)
            val u = snapshot() ?: return@launch
            withContext(Dispatchers.IO) { repo.save(u) }
        }
    }

    fun saveNow() {
        val u = snapshot() ?: return
        repo.save(u)
        val c = data.clips.firstOrNull() ?: return
        val key = "${c.uri}|${c.startMs}|${c.lookId}"
        if (key == thumbKey) return
        thumbKey = key
        kotlin.concurrent.thread {
            runCatching {
                val uri = Uri.parse(c.uri)
                val bmp = if (c.isImage) BitmapLoader.load(appCtx, uri, 480) else MediaRepository.frameAt(appCtx, uri, c.startMs)
                if (bmp != null) repo.saveThumb(u.id, bmp)
            }
        }
    }

    fun rename(name: String) {
        val p = project ?: return
        project = p.copy(name = name)
        saveNow()
    }

    // ---------------------------------------------------------------- export

    fun startExport(quality: Int, hevc: Boolean = false, watermark: Boolean = false) {
        if (data.clips.isEmpty()) return
        player.pause()
        saveNow()
        val d = if (watermark) {
            val (ow, oh) = data.outputSize()
            val wmLayers = com.binarybeast.mediastudio.data.Brand.watermarkLayers(appCtx, ow.toFloat() / oh)
            ImageCache.preload(appCtx, wmLayers)
            data.copy(texts = data.texts + wmLayers)
        } else data
        val (w, h) = d.outputSize()
        val bpp = when (quality) {
            0 -> 0.06f
            2 -> 0.16f
            else -> 0.10f
        }
        val bitrate = (w * h * 30 * bpp).toInt().coerceIn(500_000, 40_000_000)
        val file = File(appCtx.cacheDir, "nasaq_export_${System.currentTimeMillis()}.mp4")
        exportFile = file
        exportState = ExportState.Running(0)
        try {
            val composition = VideoExporter.buildComposition(d)
            val enc = DefaultEncoderFactory.Builder(appCtx)
                .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
                .build()
            val t = Transformer.Builder(appCtx)
                .setVideoMimeType(if (hevc) MimeTypes.VIDEO_H265 else MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(enc)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        exportState = ExportState.Done(file)
                    }

                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        file.delete()
                        if (hevc) {
                            // بعض الأجهزة مش بتدعم HEVC: نعيد المحاولة تلقائيًا بـ H.264
                            startExport(quality, false, watermark)
                        } else {
                            exportState = ExportState.Failed((exportException.message ?: "فشل التصدير") + "\nجرّب جودة أقل أو شيل بعض التأثيرات.")
                        }
                    }
                })
                .build()
            transformer = t
            t.start(composition, file.absolutePath)
            pollProgress(t)
        } catch (e: Throwable) {
            file.delete()
            exportState = ExportState.Failed(e.message ?: "فشل بدء التصدير")
        }
    }

    private fun pollProgress(t: Transformer) {
        viewModelScope.launch {
            val holder = ProgressHolder()
            while (exportState is ExportState.Running) {
                val st = t.getProgress(holder)
                if (st == Transformer.PROGRESS_STATE_AVAILABLE) {
                    exportState = ExportState.Running(holder.progress)
                }
                delay(300)
            }
        }
    }

    fun cancelExport() {
        transformer?.cancel()
        exportFile?.delete()
        exportState = ExportState.Idle
    }

    fun saveExport() {
        val st = exportState as? ExportState.Done ?: return
        if (st.savedUri != null) return
        viewModelScope.launch {
            try {
                val uri = withContext(Dispatchers.IO) { MediaRepository.saveVideo(appCtx, st.file) }
                exportState = ExportState.Done(st.file, uri)
            } catch (e: Exception) {
                message = "تعذّر الحفظ في المعرض"
            }
        }
    }

    fun resetExport() {
        exportState = ExportState.Idle
    }

    override fun onCleared() {
        saveNow()
        runCatching { transformer?.cancel() }
        player.release()
        music.release()
        super.onCleared()
    }
}
