@file:OptIn(UnstableApi::class)

package com.binarybeast.mediastudio.video

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.binarybeast.mediastudio.Graph
import com.binarybeast.mediastudio.data.ExportFormat
import com.binarybeast.mediastudio.data.ImageEdit
import com.binarybeast.mediastudio.data.Looks
import com.binarybeast.mediastudio.data.MediaRepository
import com.binarybeast.mediastudio.data.Project
import com.binarybeast.mediastudio.data.ProjectFactory
import com.binarybeast.mediastudio.data.TextLayer
import com.binarybeast.mediastudio.data.VideoClip
import com.binarybeast.mediastudio.data.VideoData
import com.binarybeast.mediastudio.image.BitmapLoader
import com.binarybeast.mediastudio.image.ImageCache
import com.binarybeast.mediastudio.image.ImageProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val progress: Int) : ExportState
    data class Done(val file: File, val savedUri: Uri? = null) : ExportState
    data class Failed(val message: String) : ExportState
}

class VideoEditorViewModel(app: Application, private val projectId: String) : AndroidViewModel(app) {

    private val repo = Graph.repo
    private val appCtx: Application = app

    val player: ExoPlayer = ExoPlayer.Builder(app).build()
    private val music: ExoPlayer = ExoPlayer.Builder(app).build()

    var project by mutableStateOf<Project?>(null)
        private set
    var data by mutableStateOf(VideoData())
        private set
    var loading by mutableStateOf(true)
        private set
    var failed by mutableStateOf(false)
        private set
    var selectedIndex by mutableStateOf(0)
        private set
    var selectedText by mutableStateOf<Long?>(null)
    var isPlaying by mutableStateOf(false)
        private set
    var positionMs by mutableStateOf(0L)
        private set
    var busyText by mutableStateOf<String?>(null)
        private set
    var message by mutableStateOf<String?>(null)
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set
    var exportState by mutableStateOf<ExportState>(ExportState.Idle)
        private set

    /** مصغّرات الفلاتر من لقطة من أول مقطع. */
    val lookThumbs = mutableStateMapOf<String, Bitmap>()

    private val undoStack = ArrayDeque<VideoData>()
    private val redoStack = ArrayDeque<VideoData>()
    private var gestureBase: VideoData? = null
    private var pendingRebuild = false
    private var lastSig: List<List<Any>> = emptyList()
    private var scrubbing = false
    private var saveJob: Job? = null
    private var thumbKey: String = ""
    private var transformer: Transformer? = null
    private var exportFile: File? = null

    val selectedClip: VideoClip? get() = data.clips.getOrNull(selectedIndex)

    // ---------------------------------------------------------------- player wiring

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(playing: Boolean) {
            this@VideoEditorViewModel.isPlaying = playing
            syncMusic()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val i = player.currentMediaItemIndex
            if (i in data.clips.indices) {
                applyFx(i)
                selectedIndex = i
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED) {
                player.pause()
                if (data.clips.isNotEmpty()) {
                    player.seekTo(0, 0)
                    applyFx(0)
                    selectedIndex = 0
                    positionMs = 0L
                }
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            message = "تعذّر تشغيل المعاينة لهذا المقطع"
        }
    }

    init {
        player.addListener(playerListener)
        viewModelScope.launch {
            val p = withContext(Dispatchers.IO) { repo.load(projectId) }
            val v = p?.video
            if (p == null || v == null) {
                failed = true
                loading = false
                return@launch
            }
            project = p
            data = v
            loading = false
            withContext(Dispatchers.IO) { ImageCache.preload(appCtx, v.texts) }
            rebuildPlayer(0, 0L)
            loadMusic()
            buildLookThumbs()
        }
        viewModelScope.launch {
            while (true) {
                delay(60)
                tick()
            }
        }
    }

    private fun tick() {
        if (scrubbing || loading) return
        val clips = data.clips
        val i = player.currentMediaItemIndex
        if (i !in clips.indices) return
        val c = clips[i]
        val local = player.currentPosition.coerceAtLeast(0L)
        positionMs = data.clipStartMs(i) + (local / c.speed).toLong()
    }

    private fun toMediaItem(c: VideoClip): MediaItem {
        val b = MediaItem.Builder().setUri(Uri.parse(c.uri)).setMediaId(c.id.toString())
        if (c.isImage) {
            b.setImageDurationMs(c.endMs - c.startMs)
        } else {
            b.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.startMs)
                    .setEndPositionMs(c.endMs)
                    .build()
            )
        }
        return b.build()
    }

    private fun sig(d: VideoData): List<List<Any>> =
        d.clips.map { listOf<Any>(it.id, it.uri, it.startMs, it.endMs, it.isImage) }

    private fun rebuildPlayer(index: Int, posMs: Long) {
        val clips = data.clips
        lastSig = sig(data)
        if (clips.isEmpty()) {
            player.clearMediaItems()
            return
        }
        val idx = index.coerceIn(0, clips.lastIndex)
        player.setMediaItems(clips.map { toMediaItem(it) }, idx, posMs.coerceAtLeast(0L))
        player.prepare()
        applyFx(idx)
    }

    private fun rebuildKeep() {
        rebuildPlayer(player.currentMediaItemIndex, player.currentPosition)
    }

    private var fxJob: kotlinx.coroutines.Job? = null
    private fun scheduleFx() {
        fxJob?.cancel()
        fxJob = viewModelScope.launch {
            kotlinx.coroutines.delay(140)
            applyFx(player.currentMediaItemIndex)
        }
    }

    private fun applyFx(i: Int) {
        val c = data.clips.getOrNull(i) ?: return
        player.setPlaybackSpeed(if (c.isImage) 1f else c.speed)
        player.volume = if (c.muted) 0f else c.volume.coerceIn(0f, 1f)
        player.setVideoEffects(VideoEffects.preview(c))
    }

    // ---------------------------------------------------------------- music

    private fun loadMusic() {
        val u = data.musicUri
        if (u == null) {
            music.stop()
            music.clearMediaItems()
            return
        }
        music.setMediaItem(MediaItem.fromUri(Uri.parse(u)))
        music.prepare()
        music.volume = data.musicVolume.coerceIn(0f, 1f)
        syncMusic()
    }

    private fun syncMusic() {
        if (data.musicUri == null) return
        music.volume = data.musicVolume.coerceIn(0f, 1f)
        if (player.isPlaying) {
            val md = data.musicDurationMs
            music.seekTo(if (md > 0) positionMs.coerceAtMost(md - 1) else positionMs)
            music.play()
        } else {
            music.pause()
        }
    }

    // ---------------------------------------------------------------- transport

    fun togglePlay() {
        if (data.clips.isEmpty()) return
        if (player.isPlaying) player.pause() else player.play()
    }

    fun pause() {
        player.pause()
    }

    fun scrubTo(t: Long) {
        scrubbing = true
        seekTimeline(t)
    }

    fun endScrub() {
        scrubbing = false
    }

    fun seekTimeline(t: Long) {
        val clips = data.clips
        if (clips.isEmpty()) return
        var acc = 0L
        for ((i, c) in clips.withIndex()) {
            if (t < acc + c.effectiveMs || i == clips.lastIndex) {
                val local = ((t - acc) * c.speed).toLong().coerceIn(0L, (c.endMs - c.startMs).coerceAtLeast(0L))
                if (player.currentMediaItemIndex != i) {
                    player.seekTo(i, local)
                    applyFx(i)
                } else {
                    player.seekTo(local)
                }
                selectedIndex = i
                positionMs = t
                if (data.musicUri != null && player.isPlaying) syncMusic()
                return
            }
            acc += c.effectiveMs
        }
    }

    fun selectClip(i: Int) {
        if (i !in data.clips.indices) return
        selectedIndex = i
        selectedText = null
        player.seekTo(i, 0L)
        applyFx(i)
        positionMs = data.clipStartMs(i)
    }

    // ---------------------------------------------------------------- mutation core

    private fun refreshFlags() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    private fun pushUndo(d: VideoData) {
        undoStack.addLast(d)
        if (undoStack.size > 60) undoStack.removeFirst()
        redoStack.clear()
    }

    private fun mutate(live: Boolean = false, f: (VideoData) -> VideoData) {
        val old = data
        val new = f(old)
        if (new == old) return
        if (!live) pushUndo(old) else if (gestureBase == null) gestureBase = old
        data = new
        afterChange(old, new, live)
        refreshFlags()
    }

    private fun afterChange(old: VideoData, new: VideoData, live: Boolean) {
        if (sig(new) != lastSig) {
            if (live) pendingRebuild = true else rebuildKeep()
        } else {
            if (live) scheduleFx() else applyFx(player.currentMediaItemIndex)
        }
        if (new.musicUri != old.musicUri) loadMusic() else music.volume = new.musicVolume.coerceIn(0f, 1f)
        selectedIndex = selectedIndex.coerceIn(0, maxOf(0, new.clips.lastIndex))
        scheduleSave()
    }

    fun endLive() {
        val base = gestureBase
        gestureBase = null
        if (base != null && base != data) pushUndo(base)
        if (pendingRebuild) {
            pendingRebuild = false
            rebuildKeep()
        } else if (fxJob?.isActive == true) {
            fxJob?.cancel()
            applyFx(player.currentMediaItemIndex)
        }
        refreshFlags()
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val old = data
        redoStack.addLast(old)
        restore(undoStack.removeLast(), old)
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val old = data
        undoStack.addLast(old)
        restore(redoStack.removeLast(), old)
    }

    private fun restore(v: VideoData, old: VideoData) {
        val idx = player.currentMediaItemIndex
        data = v
        selectedIndex = selectedIndex.coerceIn(0, maxOf(0, v.clips.lastIndex))
        rebuildPlayer(idx, 0L)
        if (v.musicUri != old.musicUri) loadMusic()
        refreshFlags()
        scheduleSave()
    }

    // ---------------------------------------------------------------- clip operations

    fun updateClip(index: Int, live: Boolean = false, f: (VideoClip) -> VideoClip) {
        mutate(live) { d -> d.copy(clips = d.clips.mapIndexed { i, c -> if (i == index) f(c) else c }) }
    }

    fun updateSelected(live: Boolean = false, f: (VideoClip) -> VideoClip) = updateClip(selectedIndex, live, f)

    fun updateAllClips(f: (VideoClip) -> VideoClip) {
        mutate { d -> d.copy(clips = d.clips.map(f)) }
    }

    fun splitAtPlayhead() {
        val i = player.currentMediaItemIndex
        val c = data.clips.getOrNull(i) ?: return
        val cut = c.startMs + player.currentPosition
        if (cut - c.startMs < 300 || c.endMs - cut < 300) {
            message = "حرّك المؤشر لمكان أبعد عن حافة المقطع"
            return
        }
        val a = c.copy(endMs = cut)
        val b = c.copy(id = ProjectFactory.nextId(), startMs = cut)
        mutate { d ->
            val list = d.clips.toMutableList()
            list[i] = a
            list.add(i + 1, b)
            d.copy(clips = list)
        }
        selectClip(i + 1)
    }

    fun duplicateSelected() {
        val i = selectedIndex
        val c = data.clips.getOrNull(i) ?: return
        mutate { d ->
            val list = d.clips.toMutableList()
            list.add(i + 1, c.copy(id = ProjectFactory.nextId()))
            d.copy(clips = list)
        }
        selectClip(i + 1)
    }

    fun deleteSelected() {
        val i = selectedIndex
        if (data.clips.size <= 1) {
            message = "لازم يفضل مقطع واحد على الأقل"
            return
        }
        mutate { d -> d.copy(clips = d.clips.filterIndexed { idx, _ -> idx != i }) }
        selectClip((i - 1).coerceAtLeast(0).coerceAtMost(data.clips.lastIndex))
    }

    fun moveSelected(delta: Int) {
        val i = selectedIndex
        val j = i + delta
        if (j !in data.clips.indices) return
        mutate { d ->
            val list = d.clips.toMutableList()
            val t = list[i]
            list[i] = list[j]
            list[j] = t
            d.copy(clips = list)
        }
        selectClip(j)
    }

    fun addClips(uris: List<Uri>) {
        if (uris.isEmpty()) return
        busyText = "جاري استيراد الملفات..."
        viewModelScope.launch {
            val clips = withContext(Dispatchers.IO) {
                uris.mapNotNull { u -> runCatching { ProjectFactory.makeClip(appCtx, projectId, u) }.getOrNull() }
            }
            busyText = null
            if (clips.isEmpty()) {
                message = "تعذّر قراءة الملفات المختارة"
                return@launch
            }
            mutate { d -> d.copy(clips = d.clips + clips) }
            selectClip(data.clips.size - clips.size)
            if (lookThumbs.isEmpty()) buildLookThumbs()
        }
    }

    fun setAspect(a: Float) = mutate { it.copy(aspect = a) }

    fun setResolution(r: Int) = mutate { it.copy(resolution = r) }

    // ---------------------------------------------------------------- music

    fun setMusic(uri: Uri) {
        busyText = "جاري إضافة الموسيقى..."
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val name = repo.displayName(uri)
                    val local = repo.importIfNeeded(projectId, uri, forceCopy = true)
                    Triple(local, name, MediaRepository.probeAudioDuration(appCtx, local))
                }.getOrNull()
            }
            busyText = null
            if (r == null) {
                message = "تعذّر قراءة ملف الصوت"
                return@launch
            }
            mutate { it.copy(musicUri = r.first.toString(), musicName = r.second, musicDurationMs = r.third) }
        }
    }

    fun removeMusic() = mutate { it.copy(musicUri = null, musicName = "", musicDurationMs = 0L) }

    fun setMusicVolume(v: Float, live: Boolean) = mutate(live) { it.copy(musicVolume = v) }

    // ---------------------------------------------------------------- text overlays

    fun addText(text: String, emoji: Boolean = false) {
        val id = ProjectFactory.nextId()
        val total = data.totalMs
        val start = positionMs.coerceIn(0L, maxOf(0L, total - 500L))
        val end = minOf(total, start + 3000L)
        val t = TextLayer(
            id = id, text = text, size = if (emoji) 0.16f else 0.07f,
            shadow = !emoji, bold = !emoji, startMs = start, endMs = end
        )
        mutate { it.copy(texts = it.texts + t) }
        selectedText = id
    }

    fun updateText(id: Long, live: Boolean = false, f: (TextLayer) -> TextLayer) {
        mutate(live) { d -> d.copy(texts = d.texts.map { if (it.id == id) f(it) else it }) }
    }

    fun deleteText(id: Long) {
        mutate { d -> d.copy(texts = d.texts.filter { it.id != id }) }
        if (selectedText == id) selectedText = null
    }

    /** شكل (مستطيل/دائرة/نجمة...) فوق الفيديو. */
    fun addShape(kind: Int) {
        val id = ProjectFactory.nextId()
        val total = data.totalMs
        val start = positionMs.coerceIn(0L, maxOf(0L, total - 500L))
        val end = minOf(total, start + 3000L)
        val t = TextLayer(
            id = id, text = "", shape = kind, size = if (kind == 7 || kind == 8) 0.04f else 0.2f,
            aspect = if (kind == 7 || kind == 8) 5f else 1f, shadow = false, bold = false,
            startMs = start, endMs = end
        )
        mutate { it.copy(texts = it.texts + t) }
        selectedText = id
    }

    /** صورة/لوجو فوق الفيديو. */
    fun addImageLayer(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val local = runCatching { repo.importIfNeeded(projectId, uri, forceCopy = true) }.getOrNull()
            val bmp = local?.let { ImageCache.load(appCtx, it.toString()) }
            if (local == null || bmp == null) {
                withContext(Dispatchers.Main) { message = "تعذّر فتح الصورة" }
                return@launch
            }
            val aspect = bmp.width.toFloat() / bmp.height
            val id = ProjectFactory.nextId()
            withContext(Dispatchers.Main) {
                val total = data.totalMs
                val start = positionMs.coerceIn(0L, maxOf(0L, total - 500L))
                val t = TextLayer(
                    id = id, text = "", shape = 9, imageUri = local.toString(), aspect = aspect,
                    size = 0.3f / maxOf(1f, aspect), shadow = false, bold = false,
                    startMs = start, endMs = minOf(total, start + 3000L)
                )
                mutate { it.copy(texts = it.texts + t) }
                selectedText = id
            }
        }
    }

    /** تلاشي الشفافية للمعاينة عند الزمن t على التايم لاين (0 = ظاهر، 1 = أسود). */
    fun fadeAlpha(t: Long): Float {
        var start = 0L
        for (c in data.clips) {
            val dur = c.effectiveMs
            if (t < start + dur || c === data.clips.last()) {
                val local = (t - start).coerceIn(0L, dur)
                var a = 0f
                if (c.fadeInMs > 0 && local < c.fadeInMs) a = maxOf(a, 1f - local.toFloat() / c.fadeInMs)
                if (c.fadeOutMs > 0 && local > dur - c.fadeOutMs) a = maxOf(a, (local - (dur - c.fadeOutMs)).toFloat() / c.fadeOutMs)
                return a.coerceIn(0f, 1f)
            }
            start += dur
        }
        return 0f
    }

    /** تجميد الإطار: يقسم المقطع عند المؤشر ويدخل صورة ثابتة من الإطار الحالي مدتها 3 ثواني. */
    fun freezeFrame() {
        val i = player.currentMediaItemIndex
        val c = data.clips.getOrNull(i) ?: return
        if (c.isImage) { message = "المقطع ده صورة أصلًا"; return }
        val pos = c.startMs + player.currentPosition
        if (pos - c.startMs < 300 || c.endMs - pos < 300) {
            message = "حرّك المؤشر لمكان أبعد عن حافة المقطع"
            return
        }
        player.pause()
        busyText = "جاري تجميد الإطار..."
        viewModelScope.launch {
            val clip = withContext(Dispatchers.IO) {
                runCatching {
                    val bmp = MediaRepository.frameAt(appCtx, Uri.parse(c.uri), pos) ?: return@runCatching null
                    val f = File(repo.dir(projectId), "freeze_${System.currentTimeMillis()}.jpg")
                    f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                    VideoClip(
                        id = ProjectFactory.nextId(), uri = Uri.fromFile(f).toString(), isImage = true,
                        srcDurationMs = 30_000L, startMs = 0L, endMs = 3_000L,
                        width = bmp.width, height = bmp.height, fill = c.fill,
                        rotation = c.rotation, flipH = c.flipH,
                        lookId = c.lookId, lookStrength = c.lookStrength, adjust = c.adjust
                    )
                }.getOrNull()
            }
            busyText = null
            if (clip == null) { message = "تعذّر تجميد الإطار"; return@launch }
            mutate { d ->
                val list = d.clips.toMutableList()
                list[i] = c.copy(endMs = pos, fadeOutMs = 0L)
                list.add(i + 1, clip)
                list.add(i + 2, c.copy(id = ProjectFactory.nextId(), startMs = pos, fadeInMs = 0L))
                d.copy(clips = list)
            }
            selectClip(i + 1)
        }
    }

    fun duplicateText(id: Long) {
        val t = data.texts.firstOrNull { it.id == id } ?: return
        val nid = ProjectFactory.nextId()
        mutate { it.copy(texts = it.texts + t.copy(id = nid, x = (t.x + 0.05f).coerceAtMost(0.95f), y = (t.y + 0.05f).coerceAtMost(0.95f))) }
        selectedText = nid
    }

    // ---------------------------------------------------------------- frame capture & thumbs

    fun captureFrame() {
        val i = player.currentMediaItemIndex
        val c = data.clips.getOrNull(i) ?: return
        val pos = c.startMs + player.currentPosition
        busyText = "جاري التقاط الصورة..."
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val u = Uri.parse(c.uri)
                    val bmp = if (c.isImage) BitmapLoader.load(appCtx, u, 4096) else MediaRepository.frameAt(appCtx, u, pos)
                    if (bmp == null) false else {
                        MediaRepository.saveImage(appCtx, bmp, ExportFormat.JPG, 95)
                        true
                    }
                }.getOrDefault(false)
            }
            busyText = null
            message = if (ok) "تم حفظ اللقطة في المعرض" else "تعذّر التقاط اللقطة"
        }
    }

    private fun buildLookThumbs() {
        val c = data.clips.firstOrNull() ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val u = Uri.parse(c.uri)
            val frame = if (c.isImage) BitmapLoader.load(appCtx, u, 160) else MediaRepository.frameAt(appCtx, u, c.startMs)
            if (frame == null) return@launch
            val k = 120f / maxOf(frame.width, frame.height)
            val small = if (k < 1f) Bitmap.createScaledBitmap(frame, (frame.width * k).toInt().coerceAtLeast(1), (frame.height * k).toInt().coerceAtLeast(1), true) else frame
            val out = Looks.all.associate { it.id to ImageProcessor.render(small, ImageEdit(lookId = it.id)) }
            withContext(Dispatchers.Main) { lookThumbs.putAll(out) }
        }
    }

    // ---------------------------------------------------------------- persistence

    private fun snapshot(): Project? {
        val p = project ?: return null
        val u = p.copy(video = data, updatedAt = System.currentTimeMillis())
        project = u
        return u
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(900)
            val u = snapshot() ?: return@launch
            withContext(Dispatchers.IO) { repo.save(u) }
        }
    }

    fun saveNow() {
        val u = snapshot() ?: return
        repo.save(u)
        val c = data.clips.firstOrNull() ?: return
        val key = "${c.uri}|${c.startMs}|${c.lookId}"
        if (key == thumbKey) return
        thumbKey = key
        kotlin.concurrent.thread {
            runCatching {
                val uri = Uri.parse(c.uri)
                val bmp = if (c.isImage) BitmapLoader.load(appCtx, uri, 480) else MediaRepository.frameAt(appCtx, uri, c.startMs)
                if (bmp != null) repo.saveThumb(u.id, bmp)
            }
        }
    }

    fun rename(name: String) {
        val p = project ?: return
        project = p.copy(name = name)
        saveNow()
    }

    // ---------------------------------------------------------------- export

    fun startExport(quality: Int, hevc: Boolean = false, watermark: Boolean = false) {
        if (data.clips.isEmpty()) return
        player.pause()
        saveNow()
        val d = if (watermark) data.copy(texts = data.texts + com.binarybeast.mediastudio.data.Brand.watermark()) else data
        val (w, h) = d.outputSize()
        val bpp = when (quality) {
            0 -> 0.06f
            2 -> 0.16f
            else -> 0.10f
        }
        val bitrate = (w * h * 30 * bpp).toInt().coerceIn(500_000, 40_000_000)
        val file = File(appCtx.cacheDir, "nasaq_export_${System.currentTimeMillis()}.mp4")
        exportFile = file
        exportState = ExportState.Running(0)
        try {
            val composition = VideoExporter.buildComposition(d)
            val enc = DefaultEncoderFactory.Builder(appCtx)
                .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
                .build()
            val t = Transformer.Builder(appCtx)
                .setVideoMimeType(if (hevc) MimeTypes.VIDEO_H265 else MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(enc)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        exportState = ExportState.Done(file)
                    }

                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        file.delete()
                        exportState = ExportState.Failed(exportException.message ?: "فشل التصدير")
                    }
                })
                .build()
            transformer = t
            t.start(composition, file.absolutePath)
            pollProgress(t)
        } catch (e: Throwable) {
            file.delete()
            exportState = ExportState.Failed(e.message ?: "فشل بدء التصدير")
        }
    }

    private fun pollProgress(t: Transformer) {
        viewModelScope.launch {
            val holder = ProgressHolder()
            while (exportState is ExportState.Running) {
                val st = t.getProgress(holder)
                if (st == Transformer.PROGRESS_STATE_AVAILABLE) {
                    exportState = ExportState.Running(holder.progress)
                }
                delay(300)
            }
        }
    }

    fun cancelExport() {
        transformer?.cancel()
        exportFile?.delete()
        exportState = ExportState.Idle
    }

    fun saveExport() {
        val st = exportState as? ExportState.Done ?: return
        if (st.savedUri != null) return
        viewModelScope.launch {
            try {
                val uri = withContext(Dispatchers.IO) { MediaRepository.saveVideo(appCtx, st.file) }
                exportState = ExportState.Done(st.file, uri)
            } catch (e: Exception) {
                message = "تعذّر الحفظ في المعرض"
            }
        }
    }

    fun resetExport() {
        exportState = ExportState.Idle
    }

    override fun onCleared() {
        saveNow()
        runCatching { transformer?.cancel() }
        player.release()
        music.release()
        super.onCleared()
    }
}
