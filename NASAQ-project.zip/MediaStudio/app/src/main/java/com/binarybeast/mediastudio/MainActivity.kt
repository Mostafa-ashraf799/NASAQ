package com.binarybeast.mediastudio

import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.binarybeast.mediastudio.ui.AppNav
import com.binarybeast.mediastudio.ui.Bg
import com.binarybeast.mediastudio.ui.MediaStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        val crashFile = java.io.File(filesDir, "crash.txt")
        val lastCrash = if (crashFile.exists()) runCatching { crashFile.readText() }.getOrNull() else null
        if (lastCrash != null) crashFile.delete()
        setContent {
            var crash by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(lastCrash) }
            crash?.let { txt ->
                androidx.compose.material3.AlertDialog(
                    onDismissRequest = { crash = null },
                    title = { androidx.compose.material3.Text("التطبيق وقف المرة اللي فاتت") },
                    text = {
                        androidx.compose.foundation.layout.Column(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                            androidx.compose.material3.Text("ابعت تفاصيل الخطأ للمطوّر عشان يتصلّح:", fontSize = 12.sp)
                            androidx.compose.material3.Text(txt.take(1500), fontSize = 10.sp)
                        }
                    },
                    confirmButton = {
                        androidx.compose.material3.TextButton(onClick = {
                            val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, txt)
                            }
                            startActivity(android.content.Intent.createChooser(i, "إرسال").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                            crash = null
                        }) { androidx.compose.material3.Text("إرسال") }
                    },
                    dismissButton = { androidx.compose.material3.TextButton(onClick = { crash = null }) { androidx.compose.material3.Text("إغلاق") } }
                )
            }
            MediaStudioTheme {
                // الواجهة عربية بالكامل → RTL
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Box(Modifier.fillMaxSize().background(Bg)) { AppNav() }
                }
            }
        }
    }
}
