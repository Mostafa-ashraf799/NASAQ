package com.binarybeast.mediastudio.ui

import androidx.annotation.DrawableRes
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import com.binarybeast.mediastudio.R

/** أيقونة مبنية على Vector Drawable (محوّلة من SVG بمجموعة Lucide). */
@Immutable
class NIcon(@DrawableRes val res: Int)

/** مجموعة أيقونات نسق الموحّدة (خط رفيع بزوايا مستديرة). */
object NI {
    val Delete = NIcon(R.drawable.ic_trash_2)
    val ContentCopy = NIcon(R.drawable.ic_copy)
    val Undo = NIcon(R.drawable.ic_undo_2)
    val Edit = NIcon(R.drawable.ic_pencil)
    val Back = NIcon(R.drawable.ic_arrow_right)
    val Redo = NIcon(R.drawable.ic_redo_2)
    val PlayArrow = NIcon(R.drawable.ic_play)
    val PhotoLibrary = NIcon(R.drawable.ic_images)
    val Mic = NIcon(R.drawable.ic_mic)
    val Flip = NIcon(R.drawable.ic_flip_horizontal_2)
    val FlipV = NIcon(R.drawable.ic_flip_vertical_2)
    val Tune = NIcon(R.drawable.ic_sliders_horizontal)
    val TextFields = NIcon(R.drawable.ic_type)
    val RotateRight = NIcon(R.drawable.ic_rotate_cw)
    val PushPin = NIcon(R.drawable.ic_pin)
    val Pause = NIcon(R.drawable.ic_pause)
    val MusicNote = NIcon(R.drawable.ic_music)
    val Image = NIcon(R.drawable.ic_image)
    val FilterVintage = NIcon(R.drawable.ic_aperture)
    val Download = NIcon(R.drawable.ic_download)
    val Crop = NIcon(R.drawable.ic_crop)
    val ContentCut = NIcon(R.drawable.ic_scissors)
    val Close = NIcon(R.drawable.ic_x)
    val Check = NIcon(R.drawable.ic_check)
    val AutoFixHigh = NIcon(R.drawable.ic_wand_sparkles)
    val AutoAwesome = NIcon(R.drawable.ic_sparkles)
    val AddPhotoAlternate = NIcon(R.drawable.ic_image_plus)
    val Add = NIcon(R.drawable.ic_plus)
    val VolumeUp = NIcon(R.drawable.ic_volume_2)
    val Stop = NIcon(R.drawable.ic_square)
    val Speed = NIcon(R.drawable.ic_gauge)
    val Search = NIcon(R.drawable.ic_search)
    val Save = NIcon(R.drawable.ic_save)
    val Replay5 = NIcon(R.drawable.ic_rewind)
    val Forward5 = NIcon(R.drawable.ic_fast_forward)
    val Refresh = NIcon(R.drawable.ic_refresh_cw)
    val PhotoCamera = NIcon(R.drawable.ic_camera)
    val Movie = NIcon(R.drawable.ic_clapperboard)
    val MoreVert = NIcon(R.drawable.ic_ellipsis_vertical)
    val FlipToFront = NIcon(R.drawable.ic_bring_to_front)
    val FlipToBack = NIcon(R.drawable.ic_send_to_back)
    val EmojiEmotions = NIcon(R.drawable.ic_smile)
    val Dashboard = NIcon(R.drawable.ic_layout_dashboard)
    val Compare = NIcon(R.drawable.ic_columns_2)
    val CloudUpload = NIcon(R.drawable.ic_cloud_upload)
    val CloudDownload = NIcon(R.drawable.ic_cloud_download)
    val Cloud = NIcon(R.drawable.ic_cloud)
    val Brush = NIcon(R.drawable.ic_brush)
    val AcUnit = NIcon(R.drawable.ic_snowflake)
}

@Composable
fun NIc(icon: NIcon, contentDescription: String?, modifier: Modifier = Modifier, tint: Color = LocalContentColor.current) {
    Icon(painterResource(icon.res), contentDescription, modifier, tint)
}
