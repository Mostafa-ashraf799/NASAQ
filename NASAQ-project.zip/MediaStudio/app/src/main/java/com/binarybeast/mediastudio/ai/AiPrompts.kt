package com.binarybeast.mediastudio.ai

/** برومتات النظام + دليل أدوات التطبيق + مكتبة برومتات جاهزة للمستخدم. */
object AiPrompts {

    /** بروتوكول الأدوات (نصي عشان يشتغل مع أي موديل أو مزوّد). */
    private val protocol = """
## TOOL-CALL PROTOCOL
To act inside NASAQ, put one or more tool calls in your reply, each in its own fenced block exactly like this:
```nasaq
{"tool":"set_adjust","args":{"brightness":0.1,"contrast":0.2}}
```
- You may emit several blocks in one reply; they run in order. After they run you receive a message starting with TOOL_RESULTS (and sometimes images). Continue from there.
- When the task is done, reply with plain text only (no blocks): a short summary of what you did and why.
- Never invent tool names. Use only the tools listed below. If a tool errors, read the error, fix the arguments, retry once, otherwise explain.
- Prefer a small number of well-chosen calls. Look at the image first (view_image) before judging colors/exposure, and look again after big edits to verify.
- Edits are written to the user's project immediately; the user can undo them with one tap. Do not ask permission for ordinary edits the user requested.
""".trimIndent()

    private val localTools = """
## LOCAL TOOLS (act on the project the user selected; you have NO access to the phone gallery or any other file)
- get_project_info {} -> type, size, current edit values, clip list (video) or page list (canvas).
- list_projects {} -> names/ids/types of NASAQ projects (not gallery photos).
- select_project {"id": "<project id>"} -> switch the working project.
- view_image {"max_side":1024,"page":1,"time_ms":0,"clip":0} -> you receive the CURRENT rendering of the project (image project, canvas page, or a video frame). Needs the user's "send images" permission.
- set_adjust {"brightness":-0.5..0.5,"contrast":-1..1,"saturation":-1..1,"warmth":-1..1,"hue":-180..180} (image) – absolute values, omit what you do not change.
- set_look {"id":"vivid|pop|bright|warm|cool|sunset|mint|dream|vintage|fade|matte|cinema|moody|dramatic|sepia|bw|noir|tealorange|golden|cyber|forest|rose|ice|lomo|kodak|hdr|pastel|original","strength":0..1}
- set_effects {"sharpen":0..1,"blur":0..1,"vignette":0..1,"fade":0..1,"grain":0..1,"pixelate":0..1,"border":0..0.2,"corner":0..0.5,"exposure":-1..1,"highlights":-1..1,"shadows":-1..1,"whites":-1..1,"blacks":-1..1,"tint":-1..1,"vibrance":-1..1,"clarity":-1..1,"dehaze":-1..1,"denoise":0..1}
- set_crop {"aspect":0 (free) or width/height e.g. 1.0, 0.8, 1.777,"zoom":1..4,"cx":0..1,"cy":0..1,"straighten":-45..45}
- transform {"rotate":90|-90|180,"flipH":true,"flipV":true}
- add_text {"text":"...","x":0..1,"y":0..1,"size":0.02..0.3 (fraction of image height),"color":"#RRGGBB","bold":true,"rotation":0,"shadow":true}
- clear_texts {}  /  reset_edits {} (remove all edits of the current image).
- set_clip {"index":0,"speed":0.25..4,"volume":0..2,"muted":false,"lookId":"cinema","lookStrength":0..1,"fadeInMs":0,"fadeOutMs":0,"zoom":1..4,"kenBurns":0|1|2,"startMs":0,"endMs":3000,"brightness":..,"contrast":..,"saturation":..,"warmth":..} (video clip, all optional)
- add_canvas_page {"after":1} -> adds a blank page to the selected Canvas project.
""".trimIndent()

    /** دليل كل أدوات التطبيق: بيعرّف الـ AI ينصح المستخدم ويستخدم كل أداة صح. */
    val toolGuide: String = """
# NASAQ (نسق) TOOL GUIDE
NASAQ is an Android photo + video + audio + canvas editor. All processing is on-device. Use this guide to advise the user and to choose values.

## IMAGE EDITOR
- Adjust (basic): brightness, contrast, saturation, warmth, hue. Typical fixes: dull photo -> contrast +0.15, saturation +0.2; dark photo -> brightness +0.1 and shadows +0.3; warm cast -> warmth -0.2.
- Looks (filters): 27 presets (vivid, cinema, tealorange, bw, noir, golden...). Strength 0..1 blends the look. Use cinema/tealorange for movie feel, vintage/lomo/kodak for film, pastel/dream for soft portraits.
- Effects: sharpen, blur, vignette, fade (lifted blacks), grain, pixelate, rounded corners, border.
- Advanced tone (Lightroom-like): exposure, highlights, shadows, whites, blacks, tint, vibrance, clarity (local contrast), dehaze, denoise (also smooths skin), chromatic aberration, tilt-shift focus, light leaks, film dust.
- Grading: Levels (black/white point + gamma), Curves (shadows/mids/highlights + per-channel), B&W channel mixer, Photo Filter (colored filter + density), Color Balance (shadows/mids/highlights x RGB), Gradient Map, Selective Color (8 hue ranges).
- Creative filters: invert, posterize, solarize, hard B&W, emboss, sketch, glitch, duotone, halftone, mirror, kaleidoscope, oil paint, plus GPU filters.
- Crop & geometry: aspect ratios, zoom/pan, straighten, perspective correction (horizontal/vertical), canvas expand, rotate, flip.
- Retouch (pixel tools, UI only): brush, eraser, clone stamp, healing, blur/sharpen/smudge/dodge/burn/sponge brushes, red-eye, spot removal, content-aware move, magic wand/selection tools, gradients.
- Layers: text, stickers/emoji, shapes (rectangle, circle, triangle, star, heart, line, arrow), image layers, solid/gradient layers, blend modes (multiply, screen, overlay, darken, lighten, add), masks (ellipse, rounded, fades, radial), glow, opacity, rotation.
- AI-ish on-device tools (no server): background removal (selfie segmentation), face detection, OCR text-to-layer, auto-enhance, image labeling, QR/barcode, document scan (perspective + B&W), panorama/multi-shot stitching, translate-text on image.
- Color management: soft-proof modes (protan/deutan/tritan/gray), print-safe colors, bleed + crop marks (mm), histogram + clipping warnings, metadata viewer.
- Export: JPG/PNG/WEBP, quality 50-100, scale %, NASAQ watermark (logo + name) optional.

## VIDEO EDITOR
- Timeline: split at playhead, trim (start/end), duplicate, delete, reorder, merge adjacent cuts of the same file (smooth cuts), markers, ripple edits, J-K-L shuttle, timecode, safe margins, fx bypass (compare before/after).
- Per-clip: speed 0.25-4x, volume 0-2, mute, rotation/flip, fill vs fit, zoom/pan, Ken Burns (slow zoom in/out), keyframes (zoom/pan with ease), fades in/out, looks, color adjust (brightness/contrast/saturation/warmth/hue), custom LUT (.cube), special color filters (night vision, cyanotype, gold, pink, red, channel swaps).
- Text/stickers on video with timing and entrance/exit animations (fade, slide, pop).
- Music track with volume; photo clips can be mixed with video clips.
- Export: 480/720/1080p, quality levels, optional HEVC, aspect ratio (auto/16:9/9:16/1:1...), NASAQ watermark. Camera/EDL export and shot matching exist as editing helpers.

## AUDIO EDITOR
- Trim, fade in/out, volume/gain, speed, pitch. EQ & filters (low/high cut, notch). Noise reduction, hum removal (50/60 Hz notch), de-esser, de-clicker, loudness normalization (LUFS target), spectrogram view, record from microphone, extract audio from video.

## CANVAS (multi-page documents)
- Pages share one size/background (1:1, story 9:16, 16:9, 4:5, A4 portrait/landscape...). Each page is edited like an image project (text, shapes, images, effects).
- Export: PNG/JPG images, PDF, Word (.docx), or a sequential video (one clip per page, Ken Burns optional).

## COLLAGE, SCAN & MISC
- Collage: 2-9 photos in ready layouts with gap/background. Document scanner: perspective crop + enhance. Cloud: import from Google Drive/OneDrive/Nextcloud/WebDAV via the Cloud tab.

## ADVICE RULES
- Be concrete: give exact numbers (e.g. "contrast +0.15"), name the exact tool and where to find it.
- Keep edits subtle unless the user asks for a dramatic look. Check skin tones, highlights clipping and noise after strong edits.
- For video: keep cuts tight, use speed ramps sparingly, add fades between unrelated clips.
- If the user asks for something NASAQ cannot do on-device, say so and suggest the closest alternative.
""".trimIndent()

    fun system(cfg: AiConfig, mcpTools: List<McpTool>, project: String): String {
        val sb = StringBuilder()
        sb.append("You are NASAQ Assistant (BETA), the built-in AI helper of the NASAQ (نسق) photo/video/audio editor for Android.\n")
        sb.append("Reply in the user's language and dialect (if they write Egyptian Arabic, answer in Egyptian Arabic). Be brief, practical and friendly.\n")
        sb.append("PRIVACY: you have no access to the user's gallery or files. You only see what the user explicitly attaches or what view_image shows from the selected project.\n\n")
        sb.append(protocol).append("\n\n").append(localTools).append("\n\n")
        if (mcpTools.isNotEmpty()) {
            sb.append("## EXTERNAL MCP TOOLS (call them as tool name \"mcp:<name>\" with the args object matching the schema)\n")
            mcpTools.forEach { sb.append("- mcp:${it.name}: ${it.description.take(300)} | schema: ${it.schema.take(600)}\n") }
            sb.append("Images returned by MCP tools are shown to the user and sent back to you. To send the current project image to an MCP tool, first call view_image, then describe/forward as the tool requires.\n\n")
        }
        sb.append(toolGuide).append("\n\n")
        sb.append("## CURRENT PROJECT\n").append(project).append("\n")
        if (!cfg.allowEdits) sb.append("\nNOTE: the user disabled editing. Only advise; do not call editing tools.\n")
        if (cfg.extraPrompt.isNotBlank()) sb.append("\n## USER INSTRUCTIONS\n").append(cfg.extraPrompt).append("\n")
        return sb.toString()
    }

    /** مكتبة برومتات جاهزة (تصنيف -> قائمة (عنوان، نص)). */
    val library: List<Pair<String, List<Pair<String, String>>>> = listOf(
        "تحليل" to listOf(
            "حلّل الصورة" to "حلّل الصورة الحالية: الإضاءة، الألوان، التركيب، الضوضاء، وقولي أهم 5 تعديلات محتاجها بأرقام.",
            "قيّم تركيب الكادر" to "قيّم تركيب الكادر (rule of thirds، الخطوط، المساحات الفاضية) واقترح قص أحسن بنسبة محددة.",
            "افحص الألوان" to "افحص توازن الألوان والـ white balance وقولي لو في لون غالب وإزاي أصلحه.",
            "هل الصورة جاهزة للطباعة؟" to "اعمل مراجعة للطباعة: الدقة، الحدة، الألوان الآمنة، والهوامش، وقولي أعمل إيه.",
        ),
        "تحسين تلقائي" to listOf(
            "حسّن الصورة" to "حسّن الصورة الحالية تحسين طبيعي وخفيف (إضاءة، تباين، تشبع) وطبّق التعديلات بنفسك، وبعدين شوفها تاني وتأكد.",
            "صورة داكنة" to "الصورة غامقة. افتّحها من غير ما تحرق الإضاءات واستعمل shadows و exposure.",
            "صورة باهتة" to "الصورة باهتة ومسطّحة. ادّيها حياة بتباين ووضوح (clarity) وتشبع بسيط.",
            "قلّل الضوضاء" to "قلّل الضوضاء مع الحفاظ على التفاصيل (denoise + sharpen خفيف).",
            "بورتريه ناعم" to "حسّن البورتريه: بشرة ناعمة بدون ما تبقى بلاستيك، دفء بسيط، وفينييت خفيف.",
        ),
        "ستايلات" to listOf(
            "ستايل سينمائي" to "اعمل للصورة ستايل سينمائي (cinema أو tealorange) بشدة مناسبة، مع grain خفيف وفينييت.",
            "ستايل فيلم قديم" to "خلّي الصورة شكلها فيلم قديم: vintage/kodak، fade، grain، وغبار خفيف.",
            "أبيض وأسود درامي" to "حوّلها أبيض وأسود درامي (noir) مع تباين عالي وفينييت.",
            "ألوان انستجرام" to "اعمل ألوان مشرقة ومناسبة لانستجرام: vivid خفيف، دفء، وحدة.",
            "ساعة ذهبية" to "اديها إحساس الساعة الذهبية (golden) بدفء من غير ما الألوان تتشبع زيادة.",
        ),
        "تصميم ونصوص" to listOf(
            "أضف عنوان" to "أضف عنوان جذاب على الصورة بحجم ومكان مناسبين ولون يظهر بوضوح. العنوان: ",
            "بوستر" to "حوّل الصورة لبوستر بسيط: عنوان كبير، وعنوان فرعي، وظل خفيف للنص. الموضوع: ",
            "قص للسوشيال" to "اقصّ الصورة لنسبة 4:5 (انستجرام) وخلّي الموضوع الرئيسي في المنتصف.",
            "قص ستوري" to "جهّز الصورة لستوري 9:16 بدون ما تقص الوجه أو الموضوع الأساسي.",
        ),
        "فيديو" to listOf(
            "حلّل الفيديو" to "حلّل الفيديو (شوف فريم من المقطع) وقولي إيه المشاكل: إضاءة، ألوان، اهتزاز، وإزاي أصلحها.",
            "مونتاج سريع" to "اقترح خطة مونتاج لـ ريلز مدته 30 ثانية من المقاطع الموجودة: ترتيب، سرعات، انتقالات، ونص.",
            "جرّد الألوان" to "اعمل color grade للمقطع الحالي (look + adjust) بحيث يبقى سينمائي من غير إفراط.",
            "بطيء/سريع" to "اقترح مقاطع تستاهل slow-motion ومقاطع تستاهل تتسرّع وطبّق السرعات.",
            "تلاشي بين المقاطع" to "ضيف fade in/out مناسب بين المقاطع كلها.",
            "ثابت مع حركة" to "لو المقطع صورة: ضيف Ken Burns بحركة بطيئة تناسب الصورة.",
        ),
        "صوت" to listOf(
            "إصلاح صوت" to "اقترح خطوات إصلاح تسجيل صوتي فيه ضوضاء وطنين وصدى: أي أداة من قسم إصلاح الصوت وبأي إعدادات.",
            "مستوى الصوت" to "إزاي أضبط مستوى الصوت للبودكاست/اليوتيوب؟ (LUFS مناسب وإعدادات التطبيع).",
            "تحسين صوت الصوت" to "اقترح إعدادات EQ لتحسين وضوح الصوت البشري.",
        ),
        "كانفس" to listOf(
            "خطة كانفس" to "اعمل خطة لكانفس من 5 صفحات لموضوع: ... مع نص كل صفحة وتنسيقها المقترح.",
            "صفحة غلاف" to "ضيف صفحة جديدة وصمّم غلاف بعنوان: ...",
            "تصدير مناسب" to "أنا عايز أطبع/أبعت/أنشر الكانفس. قولي أنسب صيغة تصدير (صور/PDF/Word/فيديو) ولماذا.",
        ),
        "مساعدة" to listOf(
            "إزاي أعمل..." to "اشرحلي بالخطوات داخل نسق إزاي أعمل: ",
            "أنهي أداة؟" to "عايز أحقق شكل معين: ... قولي أنهي أدوات في نسق أستخدم وبأي قيم.",
            "قارن قبل/بعد" to "قارن الصورة الحالية بعد التعديل وقولي لو في مبالغة أو حاجة تتظبط.",
        ),
    )
}
