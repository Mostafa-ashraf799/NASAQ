package com.binarybeast.mediastudio.image

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.binarybeast.mediastudio.data.TextLayer
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * رسم النصوص والستيكرز. نفس الكود بيُستخدم في:
 *  - المعاينة داخل محرر الصور والفيديو
 *  - تصدير الصور
 *  - تصدير الفيديو (بيتحوّل لـ Bitmap ويتحط كـ Overlay)
 * فبالتالي اللي بتشوفه هو اللي بيتصدّر.
 */
object TextRenderer {

    val fontNames = listOf("عادي", "سيريف", "كود", "يدوي", "كاجوال")

    private fun typeface(l: TextLayer): Typeface {
        val style = when {
            l.bold && l.italic -> Typeface.BOLD_ITALIC
            l.bold -> Typeface.BOLD
            l.italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        return when (l.font) {
            1 -> Typeface.create(Typeface.SERIF, style)
            2 -> Typeface.create(Typeface.MONOSPACE, style)
            3 -> Typeface.create("cursive", style)
            4 -> Typeface.create("casual", style)
            else -> Typeface.create(Typeface.SANS_SERIF, style)
        }
    }

    private fun basePaint(l: TextLayer, textPx: Float): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = typeface(l)
        textSize = textPx
        textAlign = Paint.Align.CENTER
    }

    private fun lines(l: TextLayer): List<String> = l.text.split("\n").ifEmpty { listOf("") }

    /** نصف العرض ونصف الارتفاع (بالبكسل) للنص شامل الخلفية. */
    fun halfExtents(l: TextLayer, textPx: Float): Pair<Float, Float> {
        if (l.shape == 10 || l.shape == 11) return Pair(textPx * 1.5f, textPx / 2f)
        if (l.shape != 0) {
            val sw = textPx * l.aspect.coerceAtLeast(0.05f)
            val sp = textPx * 0.05f
            return Pair(sw / 2f + sp, textPx / 2f + sp)
        }
        val p = basePaint(l, textPx)
        val fm = p.fontMetrics
        val lh = fm.descent - fm.ascent
        val w = lines(l).maxOf { p.measureText(it) }
        val h = lh * lines(l).size
        val pad = if (l.bgColor != 0) textPx * 0.3f else textPx * 0.05f
        return Pair(w / 2f + pad, h / 2f + pad)
    }

    fun halfExtentsFor(l: TextLayer, canvasH: Float) = halfExtents(l, l.size * canvasH)

    fun draw(canvas: Canvas, l: TextLayer, canvasW: Float, canvasH: Float) {
        if (l.hidden) return
        val fill = l.shape == 10 || l.shape == 11
        if (l.blend == 0 && l.mask == 0 || canvasW < 2f || canvasH < 2f) {
            renderLayer(canvas, l, canvasW, canvasH)
            return
        }
        // قناع و/أو نمط دمج: نرسم الطبقة لوحدها، نطبّق القناع، ثم نركّبها
        val off = Bitmap.createBitmap(canvasW.toInt(), canvasH.toInt(), Bitmap.Config.ARGB_8888)
        renderLayer(Canvas(off), l, canvasW, canvasH)
        if (l.mask != 0) applyMask(off, l, canvasW, canvasH, fill)
        val p = Paint()
        if (l.blend != 0) {
            val mode = when (l.blend) {
                1 -> android.graphics.PorterDuff.Mode.MULTIPLY
                2 -> android.graphics.PorterDuff.Mode.SCREEN
                3 -> android.graphics.PorterDuff.Mode.OVERLAY
                4 -> android.graphics.PorterDuff.Mode.DARKEN
                5 -> android.graphics.PorterDuff.Mode.LIGHTEN
                else -> android.graphics.PorterDuff.Mode.ADD
            }
            p.xfermode = android.graphics.PorterDuffXfermode(mode)
        }
        canvas.drawBitmap(off, 0f, 0f, p)
        off.recycle()
    }

    private fun renderLayer(c: Canvas, l: TextLayer, cw: Float, ch: Float) {
        if (l.shape == 10 || l.shape == 11) drawFill(c, l, cw, ch)
        else drawAt(c, l, l.x * cw, l.y * ch, l.size * ch)
    }

    /** طبقة لون / تدرّج تغطي الكانفس كله (زي Fill / Gradient Layer في فوتوشوب). */
    private fun drawFill(c: Canvas, l: TextLayer, cw: Float, ch: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val a = (l.opacity.coerceIn(0f, 1f) * 255).toInt()
        if (l.shape == 11) {
            val c2 = if (l.color2 == 0) 0xFFFF7A59.toInt() else l.color2
            val ang = Math.toRadians((l.rotation + 90.0))
            val dx = kotlin.math.cos(ang).toFloat() * ch / 2f
            val dy = kotlin.math.sin(ang).toFloat() * ch / 2f
            p.shader = android.graphics.LinearGradient(
                cw / 2f - dx, ch / 2f - dy, cw / 2f + dx, ch / 2f + dy,
                l.color or (0xFF shl 24), c2 or (0xFF shl 24), android.graphics.Shader.TileMode.CLAMP
            )
        } else p.color = l.color or (0xFF shl 24)
        p.alpha = a
        c.drawRect(0f, 0f, cw, ch, p)
    }

    /** يبني قناع الطبقة (alpha) على إطار الطبقة ثم يطبّقه بـ DST_IN. */
    private fun applyMask(bmp: Bitmap, l: TextLayer, cw: Float, ch: Float, fill: Boolean) {
        val m = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(m)
        val (hw, hh) = if (fill) Pair(cw / 2f, ch / 2f) else halfExtents(l, l.size * ch)
        val cx = if (fill) cw / 2f else l.x * cw
        val cy = if (fill) ch / 2f else l.y * ch
        val rot = if (fill) 0f else l.rotation
        val inv = l.maskInvert
        val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
        c.save()
        c.translate(cx, cy); c.rotate(rot)
        val r = RectF(-hw, -hh, hw, hh)
        when (l.mask) {
            1, 2 -> {
                if (inv) { c.drawRect(r.left - 4000f, r.top - 4000f, r.right + 4000f, r.bottom + 4000f, white) }
                val shape = Paint(Paint.ANTI_ALIAS_FLAG)
                if (inv) { shape.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR) } else shape.color = 0xFFFFFFFF.toInt()
                if (l.mask == 1) c.drawOval(r, shape) else c.drawRoundRect(r, min(hw, hh) * 0.35f, min(hw, hh) * 0.35f, shape)
            }
            3, 4, 5, 6 -> {
                val vertical = l.mask == 3 || l.mask == 4
                var forward = l.mask == 3 || l.mask == 5     // true: يبدأ معتم من البداية ويتلاشى للنهاية
                if (inv) forward = !forward
                val s0 = if (vertical) -hh else -hw
                val s1 = if (vertical) hh else hw
                val a = if (forward) 0xFFFFFFFF.toInt() else 0x00FFFFFF
                val b = if (forward) 0x00FFFFFF else 0xFFFFFFFF.toInt()
                val sh = if (vertical) android.graphics.LinearGradient(0f, s0, 0f, s1, a, b, android.graphics.Shader.TileMode.CLAMP)
                else android.graphics.LinearGradient(s0, 0f, s1, 0f, a, b, android.graphics.Shader.TileMode.CLAMP)
                val gp = Paint().apply { shader = sh }
                c.drawRect(-4000f, -4000f, 4000f, 4000f, gp)
            }
            else -> {
                val rad = max(hw, hh)
                val inner = if (inv) 0x00FFFFFF else 0xFFFFFFFF.toInt()
                val outer = if (inv) 0xFFFFFFFF.toInt() else 0x00FFFFFF
                val sh = android.graphics.RadialGradient(0f, 0f, rad, inner, outer, android.graphics.Shader.TileMode.CLAMP)
                c.drawRect(-4000f, -4000f, 4000f, 4000f, Paint().apply { shader = sh })
            }
        }
        c.restore()
        val mp = Paint()
        mp.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_IN)
        Canvas(bmp).drawBitmap(m, 0f, 0f, mp)
        m.recycle()
    }

    fun drawAt(canvas: Canvas, l: TextLayer, cx: Float, cy: Float, textPx: Float) {
        if (l.hidden) return
        if (l.shape != 0) {
            drawShape(canvas, l, cx, cy, textPx)
            return
        }
        if (l.text.isEmpty()) return
        val p = basePaint(l, textPx)
        val fm = p.fontMetrics
        val lh = fm.descent - fm.ascent
        val ls = lines(l)
        val w = ls.maxOf { p.measureText(it) }
        val h = lh * ls.size
        val alpha = (l.opacity.coerceIn(0f, 1f) * 255).toInt()

        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(l.rotation)

        if (l.bgColor != 0) {
            val pad = textPx * 0.3f
            val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = l.bgColor
                this.alpha = ((l.bgColor ushr 24) * l.opacity).toInt().coerceIn(0, 255)
            }
            canvas.drawRoundRect(RectF(-w / 2 - pad, -h / 2 - pad, w / 2 + pad, h / 2 + pad), pad, pad, bg)
        }

        if (l.outline) {
            val o = basePaint(l, textPx).apply {
                style = Paint.Style.STROKE
                strokeWidth = textPx * 0.14f
                strokeJoin = Paint.Join.ROUND
                color = if (isDark(l.color)) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
                this.alpha = alpha
            }
            ls.forEachIndexed { i, line ->
                canvas.drawText(line, 0f, -h / 2 - fm.ascent + i * lh, o)
            }
        }

        p.color = l.color
        p.alpha = ((l.color ushr 24) * l.opacity).toInt().coerceIn(0, 255)
        if (l.glow > 0f) {
            val g = basePaint(l, textPx).apply {
                color = l.color; this.alpha = alpha
                setShadowLayer(textPx * l.glow, 0f, 0f, l.color or (0xFF shl 24))
            }
            repeat(2) { ls.forEachIndexed { i, line -> canvas.drawText(line, 0f, -h / 2 - fm.ascent + i * lh, g) } }
        }
        if (l.shadow) p.setShadowLayer(textPx * 0.08f, 0f, textPx * 0.04f, 0xAA000000.toInt())
        ls.forEachIndexed { i, line ->
            canvas.drawText(line, 0f, -h / 2 - fm.ascent + i * lh, p)
        }
        canvas.restore()
    }

    private fun drawShape(canvas: Canvas, l: TextLayer, cx: Float, cy: Float, h: Float) {
        val w = h * l.aspect.coerceAtLeast(0.05f)
        val a = (((l.color ushr 24) * l.opacity.coerceIn(0f, 1f))).toInt().coerceIn(0, 255)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = l.color
            alpha = a
            style = if (l.outline) Paint.Style.STROKE else Paint.Style.FILL
            strokeWidth = max(2f, h * 0.08f)
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
        }
        if (l.glow > 0f && l.shape != 9) p.setShadowLayer(h * l.glow, 0f, 0f, l.color or (0xFF shl 24))
        else if (l.shadow && l.shape != 9) p.setShadowLayer(h * 0.08f, 0f, h * 0.04f, 0xAA000000.toInt())

        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(l.rotation)
        val r = RectF(-w / 2, -h / 2, w / 2, h / 2)
        when (l.shape) {
            1 -> canvas.drawRect(r, p)
            2 -> canvas.drawRoundRect(r, h * 0.2f, h * 0.2f, p)
            3 -> canvas.drawOval(r, p)
            4 -> {
                val path = android.graphics.Path()
                path.moveTo(0f, -h / 2)
                path.lineTo(w / 2, h / 2)
                path.lineTo(-w / 2, h / 2)
                path.close()
                canvas.drawPath(path, p)
            }
            5 -> {
                val path = android.graphics.Path()
                for (i in 0 until 10) {
                    val ang = Math.toRadians(-90.0 + i * 36.0)
                    val rad = if (i % 2 == 0) 0.5f else 0.21f
                    val px = (kotlin.math.cos(ang) * rad).toFloat() * w
                    val py = (kotlin.math.sin(ang) * rad).toFloat() * h
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                canvas.drawPath(path, p)
            }
            6 -> {
                val path = android.graphics.Path()
                path.moveTo(0f, h * 0.5f)
                path.cubicTo(-w * 0.62f, h * 0.08f, -w * 0.5f, -h * 0.55f, 0f, -h * 0.2f)
                path.cubicTo(w * 0.5f, -h * 0.55f, w * 0.62f, h * 0.08f, 0f, h * 0.5f)
                path.close()
                canvas.drawPath(path, p)
            }
            7 -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = max(3f, h * 0.28f)
                canvas.drawLine(-w / 2 + p.strokeWidth / 2, 0f, w / 2 - p.strokeWidth / 2, 0f, p)
            }
            8 -> {
                val sw = max(3f, h * 0.22f)
                val head = min(h * 0.95f, w * 0.5f)
                p.style = Paint.Style.STROKE
                p.strokeWidth = sw
                canvas.drawLine(-w / 2 + sw / 2, 0f, w / 2 - head * 0.8f, 0f, p)
                p.style = Paint.Style.FILL
                val path = android.graphics.Path()
                path.moveTo(w / 2, 0f)
                path.lineTo(w / 2 - head, -h / 2)
                path.lineTo(w / 2 - head, h / 2)
                path.close()
                canvas.drawPath(path, p)
            }
            9 -> {
                val bmp = l.imageUri?.let { ImageCache.get(it) }
                if (bmp != null) {
                    val ip = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = a }
                    canvas.drawBitmap(bmp, null, r, ip)
                } else {
                    p.style = Paint.Style.STROKE
                    canvas.drawRect(r, p)
                }
            }
        }
        canvas.restore()
    }

    private fun isDark(c: Int): Boolean {
        val r = (c shr 16) and 255
        val g = (c shr 8) and 255
        val b = c and 255
        return (0.299 * r + 0.587 * g + 0.114 * b) < 110
    }

    /**
     * يرسم الطبقة في Bitmap شفاف مربّع الشكل (عشان التدوير يتخبّى جواه).
     * بيُستخدم لتصدير الفيديو.
     */
    fun toBitmap(l: TextLayer, canvasH: Float): Bitmap {
        val textPx = l.size * canvasH
        val (hw, hh) = halfExtents(l, textPx)
        val side = ceil(hypot(hw * 2, hh * 2) + textPx * 0.3f).toInt().coerceIn(16, 4096)
        val bmp = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        drawAt(c, l, side / 2f, side / 2f, textPx)
        return bmp
    }

    /** أي طبقة تحت نقطة اللمس (x,y بالبكسل داخل كانفس بعرض w وارتفاع h)؟ بترجع id أو null. */
    fun hitTest(texts: List<TextLayer>, x: Float, y: Float, w: Float, h: Float): Long? {
        for (l in texts.asReversed()) {
            val (hw, hh) = halfExtentsFor(l, h)
            val dx = x - l.x * w
            val dy = y - l.y * h
            val rad = Math.toRadians(-l.rotation.toDouble())
            val c = kotlin.math.cos(rad).toFloat()
            val s = kotlin.math.sin(rad).toFloat()
            val lx = dx * c - dy * s
            val ly = dx * s + dy * c
            val pad = 24f
            if (kotlin.math.abs(lx) <= hw + pad && kotlin.math.abs(ly) <= hh + pad) return l.id
        }
        return null
    }

    @Suppress("unused")
    fun maxOfTwo(a: Float, b: Float) = max(a, b)
}
