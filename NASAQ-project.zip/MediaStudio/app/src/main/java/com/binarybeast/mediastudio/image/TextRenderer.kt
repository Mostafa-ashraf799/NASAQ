package com.binarybeast.mediastudio.image

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.binarybeast.mediastudio.data.TextLayer
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * رسم النصوص والستيكرز. نفس الكود بيُستخدم في:
 *  - المعاينة داخل محرر الصور والفيديو
 *  - تصدير الصور
 *  - تصدير الفيديو (بيتحوّل لـ Bitmap ويتحط كـ Overlay)
 * فبالتالي اللي بتشوفه هو اللي بيتصدّر.
 */
object TextRenderer {

    val fontNames = listOf("عادي", "سيريف", "كود", "يدوي", "كاجوال")

    private fun typeface(l: TextLayer): Typeface {
        val style = when {
            l.bold && l.italic -> Typeface.BOLD_ITALIC
            l.bold -> Typeface.BOLD
            l.italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        return when (l.font) {
            1 -> Typeface.create(Typeface.SERIF, style)
            2 -> Typeface.create(Typeface.MONOSPACE, style)
            3 -> Typeface.create("cursive", style)
            4 -> Typeface.create("casual", style)
            else -> Typeface.create(Typeface.SANS_SERIF, style)
        }
    }

    private fun basePaint(l: TextLayer, textPx: Float): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = typeface(l)
        textSize = textPx
        textAlign = Paint.Align.CENTER
    }

    private fun lines(l: TextLayer): List<String> = l.text.split("\n").ifEmpty { listOf("") }

    /** نصف العرض ونصف الارتفاع (بالبكسل) للنص شامل الخلفية. */
    fun halfExtents(l: TextLayer, textPx: Float): Pair<Float, Float> {
        if (l.shape != 0) {
            val sw = textPx * l.aspect.coerceAtLeast(0.05f)
            val sp = textPx * 0.05f
            return Pair(sw / 2f + sp, textPx / 2f + sp)
        }
        val p = basePaint(l, textPx)
        val fm = p.fontMetrics
        val lh = fm.descent - fm.ascent
        val w = lines(l).maxOf { p.measureText(it) }
        val h = lh * lines(l).size
        val pad = if (l.bgColor != 0) textPx * 0.3f else textPx * 0.05f
        return Pair(w / 2f + pad, h / 2f + pad)
    }

    fun halfExtentsFor(l: TextLayer, canvasH: Float) = halfExtents(l, l.size * canvasH)

    fun draw(canvas: Canvas, l: TextLayer, canvasW: Float, canvasH: Float) {
        drawAt(canvas, l, l.x * canvasW, l.y * canvasH, l.size * canvasH)
    }

    fun drawAt(canvas: Canvas, l: TextLayer, cx: Float, cy: Float, textPx: Float) {
        if (l.shape != 0) {
            drawShape(canvas, l, cx, cy, textPx)
            return
        }
        if (l.text.isEmpty()) return
        val p = basePaint(l, textPx)
        val fm = p.fontMetrics
        val lh = fm.descent - fm.ascent
        val ls = lines(l)
        val w = ls.maxOf { p.measureText(it) }
        val h = lh * ls.size
        val alpha = (l.opacity.coerceIn(0f, 1f) * 255).toInt()

        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(l.rotation)

        if (l.bgColor != 0) {
            val pad = textPx * 0.3f
            val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = l.bgColor
                this.alpha = ((l.bgColor ushr 24) * l.opacity).toInt().coerceIn(0, 255)
            }
            canvas.drawRoundRect(RectF(-w / 2 - pad, -h / 2 - pad, w / 2 + pad, h / 2 + pad), pad, pad, bg)
        }

        if (l.outline) {
            val o = basePaint(l, textPx).apply {
                style = Paint.Style.STROKE
                strokeWidth = textPx * 0.14f
                strokeJoin = Paint.Join.ROUND
                color = if (isDark(l.color)) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
                this.alpha = alpha
            }
            ls.forEachIndexed { i, line ->
                canvas.drawText(line, 0f, -h / 2 - fm.ascent + i * lh, o)
            }
        }

        p.color = l.color
        p.alpha = ((l.color ushr 24) * l.opacity).toInt().coerceIn(0, 255)
        if (l.shadow) p.setShadowLayer(textPx * 0.08f, 0f, textPx * 0.04f, 0xAA000000.toInt())
        ls.forEachIndexed { i, line ->
            canvas.drawText(line, 0f, -h / 2 - fm.ascent + i * lh, p)
        }
        canvas.restore()
    }

    private fun drawShape(canvas: Canvas, l: TextLayer, cx: Float, cy: Float, h: Float) {
        val w = h * l.aspect.coerceAtLeast(0.05f)
        val a = (((l.color ushr 24) * l.opacity.coerceIn(0f, 1f))).toInt().coerceIn(0, 255)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = l.color
            alpha = a
            style = if (l.outline) Paint.Style.STROKE else Paint.Style.FILL
            strokeWidth = max(2f, h * 0.08f)
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
        }
        if (l.shadow && l.shape != 9) p.setShadowLayer(h * 0.08f, 0f, h * 0.04f, 0xAA000000.toInt())

        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(l.rotation)
        val r = RectF(-w / 2, -h / 2, w / 2, h / 2)
        when (l.shape) {
            1 -> canvas.drawRect(r, p)
            2 -> canvas.drawRoundRect(r, h * 0.2f, h * 0.2f, p)
            3 -> canvas.drawOval(r, p)
            4 -> {
                val path = android.graphics.Path()
                path.moveTo(0f, -h / 2)
                path.lineTo(w / 2, h / 2)
                path.lineTo(-w / 2, h / 2)
                path.close()
                canvas.drawPath(path, p)
            }
            5 -> {
                val path = android.graphics.Path()
                for (i in 0 until 10) {
                    val ang = Math.toRadians(-90.0 + i * 36.0)
                    val rad = if (i % 2 == 0) 0.5f else 0.21f
                    val px = (kotlin.math.cos(ang) * rad).toFloat() * w
                    val py = (kotlin.math.sin(ang) * rad).toFloat() * h
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                canvas.drawPath(path, p)
            }
            6 -> {
                val path = android.graphics.Path()
                path.moveTo(0f, h * 0.5f)
                path.cubicTo(-w * 0.62f, h * 0.08f, -w * 0.5f, -h * 0.55f, 0f, -h * 0.2f)
                path.cubicTo(w * 0.5f, -h * 0.55f, w * 0.62f, h * 0.08f, 0f, h * 0.5f)
                path.close()
                canvas.drawPath(path, p)
            }
            7 -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = max(3f, h * 0.28f)
                canvas.drawLine(-w / 2 + p.strokeWidth / 2, 0f, w / 2 - p.strokeWidth / 2, 0f, p)
            }
            8 -> {
                val sw = max(3f, h * 0.22f)
                val head = min(h * 0.95f, w * 0.5f)
                p.style = Paint.Style.STROKE
                p.strokeWidth = sw
                canvas.drawLine(-w / 2 + sw / 2, 0f, w / 2 - head * 0.8f, 0f, p)
                p.style = Paint.Style.FILL
                val path = android.graphics.Path()
                path.moveTo(w / 2, 0f)
                path.lineTo(w / 2 - head, -h / 2)
                path.lineTo(w / 2 - head, h / 2)
                path.close()
                canvas.drawPath(path, p)
            }
            9 -> {
                val bmp = l.imageUri?.let { ImageCache.get(it) }
                if (bmp != null) {
                    val ip = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = a }
                    canvas.drawBitmap(bmp, null, r, ip)
                } else {
                    p.style = Paint.Style.STROKE
                    canvas.drawRect(r, p)
                }
            }
        }
        canvas.restore()
    }

    private fun isDark(c: Int): Boolean {
        val r = (c shr 16) and 255
        val g = (c shr 8) and 255
        val b = c and 255
        return (0.299 * r + 0.587 * g + 0.114 * b) < 110
    }

    /**
     * يرسم الطبقة في Bitmap شفاف مربّع الشكل (عشان التدوير يتخبّى جواه).
     * بيُستخدم لتصدير الفيديو.
     */
    fun toBitmap(l: TextLayer, canvasH: Float): Bitmap {
        val textPx = l.size * canvasH
        val (hw, hh) = halfExtents(l, textPx)
        val side = ceil(hypot(hw * 2, hh * 2) + textPx * 0.3f).toInt().coerceIn(16, 4096)
        val bmp = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        drawAt(c, l, side / 2f, side / 2f, textPx)
        return bmp
    }

    /** أي طبقة تحت نقطة اللمس (x,y بالبكسل داخل كانفس بعرض w وارتفاع h)؟ بترجع id أو null. */
    fun hitTest(texts: List<TextLayer>, x: Float, y: Float, w: Float, h: Float): Long? {
        for (l in texts.asReversed()) {
            val (hw, hh) = halfExtentsFor(l, h)
            val dx = x - l.x * w
            val dy = y - l.y * h
            val rad = Math.toRadians(-l.rotation.toDouble())
            val c = kotlin.math.cos(rad).toFloat()
            val s = kotlin.math.sin(rad).toFloat()
            val lx = dx * c - dy * s
            val ly = dx * s + dy * c
            val pad = 24f
            if (kotlin.math.abs(lx) <= hw + pad && kotlin.math.abs(ly) <= hh + pad) return l.id
        }
        return null
    }

    @Suppress("unused")
    fun maxOfTwo(a: Float, b: Float) = max(a, b)
}
