package com.binarybeast.mediastudio.image

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import org.opencv.android.Utils
import org.opencv.calib3d.Calib3d
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfDMatch
import org.opencv.core.MatOfKeyPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.features2d.DescriptorMatcher
import org.opencv.features2d.ORB
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo

/** دمج صور متعددة بمكتبة OpenCV: HDR (Mertens)، Focus Stacking، بانوراما، وصفحة معاينة (Contact Sheet). */
object MultiShot {

    fun load(ctx: Context, uris: List<Uri>, maxSide: Int): List<Bitmap> =
        uris.mapNotNull { runCatching { BitmapLoader.load(ctx, it, maxSide) }.getOrNull() }

    private fun rgb(b: Bitmap, w: Int, h: Int): Mat {
        val rgba = Mat(); Utils.bitmapToMat(b, rgba)
        val rgb = Mat(); Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
        rgba.release()
        if (rgb.cols() != w || rgb.rows() != h) {
            val r = Mat(); Imgproc.resize(rgb, r, Size(w.toDouble(), h.toDouble()), 0.0, 0.0, Imgproc.INTER_AREA)
            rgb.release(); return r
        }
        return rgb
    }

    private fun toBitmap(rgb: Mat): Bitmap {
        val rgba = Mat(); Imgproc.cvtColor(rgb, rgba, Imgproc.COLOR_RGB2RGBA)
        val bmp = Bitmap.createBitmap(rgba.cols(), rgba.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(rgba, bmp)
        rgba.release()
        return bmp
    }

    private fun alignedMats(bmps: List<Bitmap>): List<Mat> {
        val w = bmps[0].width; val h = bmps[0].height
        val src = ArrayList<Mat>(bmps.map { rgb(it, w, h) })
        val dst = ArrayList<Mat>()
        return try {
            Photo.createAlignMTB().process(src, dst)
            if (dst.size == src.size) dst else src
        } catch (t: Throwable) { src }
    }

    /** دمج تعريضات متعددة (Exposure Blending / HDR بدون Tone-mapping) بخوارزمية Mertens. */
    fun hdr(bmps: List<Bitmap>): Bitmap? {
        if (!CvTools.init() || bmps.size < 2) return null
        val mats = alignedMats(bmps)
        val fusion = Mat(); val out = Mat()
        return try {
            Photo.createMergeMertens().process(mats, fusion)
            fusion.convertTo(out, CvType.CV_8UC3, 255.0)
            toBitmap(out)
        } finally { mats.forEach { it.release() }; fusion.release(); out.release() }
    }

    /** Focus Stacking: بياخد أحدّ منطقة من كل صورة (قياس Laplacian). */
    fun focusStack(bmps: List<Bitmap>): Bitmap? {
        if (!CvTools.init() || bmps.size < 2) return null
        val mats = alignedMats(bmps)
        val h = mats[0].rows(); val w = mats[0].cols()
        val sum = Mat.zeros(h, w, CvType.CV_32FC3)
        val wsum = Mat.zeros(h, w, CvType.CV_32FC3)
        try {
            for (m in mats) {
                val f = Mat(); m.convertTo(f, CvType.CV_32FC3)
                val g = Mat(); Imgproc.cvtColor(m, g, Imgproc.COLOR_RGB2GRAY)
                val lap = Mat(); Imgproc.Laplacian(g, lap, CvType.CV_32F, 3)
                Core.absdiff(lap, Scalar(0.0), lap)
                Imgproc.GaussianBlur(lap, lap, Size(9.0, 9.0), 0.0)
                Core.pow(lap, 2.0, lap)
                Core.add(lap, Scalar(1e-3), lap)
                val w3 = Mat(); Core.merge(listOf(lap, lap, lap), w3)
                val fw = Mat(); Core.multiply(f, w3, fw)
                Core.add(sum, fw, sum); Core.add(wsum, w3, wsum)
                f.release(); g.release(); lap.release(); w3.release(); fw.release()
            }
            val res = Mat(); Core.divide(sum, wsum, res)
            val out = Mat(); res.convertTo(out, CvType.CV_8UC3)
            val bmp = toBitmap(out)
            res.release(); out.release()
            return bmp
        } finally { mats.forEach { it.release() }; sum.release(); wsum.release() }
    }

    /** بانوراما: مطابقة ORB + Homography + دمج بمنطقة تراكب متوسطة. الصور بالترتيب من اليسار لليمين. */
    fun panorama(bmps: List<Bitmap>): Pair<Bitmap?, String?> {
        if (!CvTools.init() || bmps.size < 2) return null to "محتاج صورتين على الأقل"
        fun fit(b: Bitmap): Mat {
            val k = minOf(1f, 1600f / maxOf(b.width, b.height))
            return rgb(b, (b.width * k).toInt(), (b.height * k).toInt())
        }
        var pano = fit(bmps[0])
        val orb = ORB.create(3000)
        val matcher = DescriptorMatcher.create(DescriptorMatcher.BRUTEFORCE_HAMMING)
        for (i in 1 until bmps.size) {
            val nm = fit(bmps[i])
            val gP = Mat(); val gN = Mat()
            Imgproc.cvtColor(pano, gP, Imgproc.COLOR_RGB2GRAY); Imgproc.cvtColor(nm, gN, Imgproc.COLOR_RGB2GRAY)
            val kpP = MatOfKeyPoint(); val kpN = MatOfKeyPoint(); val dP = Mat(); val dN = Mat()
            orb.detectAndCompute(gP, Mat(), kpP, dP); orb.detectAndCompute(gN, Mat(), kpN, dN)
            gP.release(); gN.release()
            if (dP.empty() || dN.empty()) return null to "مفيش تفاصيل كفاية للمطابقة في الصورة ${i + 1}"
            val knn = ArrayList<MatOfDMatch>()
            matcher.knnMatch(dN, dP, knn, 2)
            val pa = kpP.toArray(); val na = kpN.toArray()
            val srcPts = ArrayList<Point>(); val dstPts = ArrayList<Point>()
            for (m in knn) {
                val a = m.toArray()
                if (a.size >= 2 && a[0].distance < 0.75f * a[1].distance) {
                    srcPts.add(na[a[0].queryIdx].pt); dstPts.add(pa[a[0].trainIdx].pt)
                }
            }
            if (srcPts.size < 12) return null to "الصورة ${i + 1} مش متراكبة كفاية مع اللي قبلها"
            val H = Calib3d.findHomography(MatOfPoint2f(*srcPts.toTypedArray()), MatOfPoint2f(*dstPts.toTypedArray()), Calib3d.RANSAC, 4.0)
            if (H.empty()) return null to "فشلت المحاذاة للصورة ${i + 1}"
            // حدود الصورة الجديدة بعد التحويل
            val corners = MatOfPoint2f(Point(0.0, 0.0), Point(nm.cols().toDouble(), 0.0), Point(nm.cols().toDouble(), nm.rows().toDouble()), Point(0.0, nm.rows().toDouble()))
            val tc = MatOfPoint2f()
            Core.perspectiveTransform(corners, tc, H)
            val t = tc.toArray()
            val minX = minOf(0.0, t.minOf { it.x }); val minY = minOf(0.0, t.minOf { it.y })
            val maxX = maxOf(pano.cols().toDouble(), t.maxOf { it.x }); val maxY = maxOf(pano.rows().toDouble(), t.maxOf { it.y })
            val cw = (maxX - minX).toInt(); val ch = (maxY - minY).toInt()
            if (cw.toLong() * ch > 40_000_000L) return null to "النتيجة كبيرة جدًا — الصور مش متطابقة"
            val T = Mat(3, 3, CvType.CV_64F)
            T.put(0, 0, 1.0, 0.0, -minX, 0.0, 1.0, -minY, 0.0, 0.0, 1.0)
            val TH = T.matMul(H)
            val size = Size(cw.toDouble(), ch.toDouble())
            val pW = Mat(); val nW = Mat()
            Imgproc.warpPerspective(pano, pW, T, size)
            Imgproc.warpPerspective(nm, nW, TH, size)
            val onesP = Mat(pano.rows(), pano.cols(), CvType.CV_8UC1, Scalar(255.0))
            val onesN = Mat(nm.rows(), nm.cols(), CvType.CV_8UC1, Scalar(255.0))
            val mP = Mat(); val mN = Mat()
            Imgproc.warpPerspective(onesP, mP, T, size); Imgproc.warpPerspective(onesN, mN, TH, size)
            val res = pW.clone()
            nW.copyTo(res, mN)
            val overlap = Mat(); Core.bitwise_and(mP, mN, overlap)
            val avg = Mat(); Core.addWeighted(pW, 0.5, nW, 0.5, 0.0, avg)
            avg.copyTo(res, overlap)
            pano.release(); pano = res
            listOf(nm, dP, dN, T, TH, pW, nW, onesP, onesN, mP, mN, overlap, avg, H).forEach { it.release() }
        }
        val bmp = toBitmap(pano)
        pano.release()
        return bmp to null
    }

    /** Contact Sheet: شبكة صور مصغّرة مع أسماء الملفات. */
    fun contactSheet(bmps: List<Bitmap>, names: List<String>): Bitmap {
        val n = bmps.size
        val cols = when { n <= 2 -> n.coerceAtLeast(1); n <= 6 -> 3; n <= 12 -> 4; else -> 5 }
        val rows = (n + cols - 1) / cols
        val cell = 520; val pad = 24; val label = 44
        val w = cols * (cell + pad) + pad
        val h = rows * (cell + label + pad) + pad
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.WHITE)
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.DKGRAY; textSize = 26f; typeface = Typeface.DEFAULT }
        bmps.forEachIndexed { i, b ->
            val cx = pad + (i % cols) * (cell + pad)
            val cy = pad + (i / cols) * (cell + label + pad)
            val k = minOf(cell.toFloat() / b.width, cell.toFloat() / b.height)
            val dw = b.width * k; val dh = b.height * k
            val l = cx + (cell - dw) / 2f; val t = cy + (cell - dh) / 2f
            c.drawBitmap(b, null, android.graphics.RectF(l, t, l + dw, t + dh), p)
            val nm = names.getOrNull(i).orEmpty().let { if (it.length > 28) it.take(25) + "…" else it }
            c.drawText(nm, cx.toFloat(), (cy + cell + 32).toFloat(), tp)
        }
        return out
    }
}
