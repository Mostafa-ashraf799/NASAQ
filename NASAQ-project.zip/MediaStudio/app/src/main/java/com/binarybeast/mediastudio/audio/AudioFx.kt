@file:OptIn(UnstableApi::class)

package com.binarybeast.mediastudio.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import com.binarybeast.mediastudio.data.AudioData
import com.binarybeast.mediastudio.video.GainAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** تلاشي صوت تدريجي في البداية/النهاية على الزمن الناتج (بعد السرعة). PCM 16-bit فقط. */
class FadeAudioProcessor(
    private val fadeInMs: Long,
    private val fadeOutMs: Long,
    private val totalMs: Long,
    private val curve: Int = 0,
) : BaseAudioProcessor() {

    private var rate = 44100
    private var channels = 2
    private var frame = 0L

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        rate = inputAudioFormat.sampleRate
        channels = inputAudioFormat.channelCount.coerceAtLeast(1)
        return inputAudioFormat
    }

    override fun onFlush() {
        frame = 0L
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return
        val out = replaceOutputBuffer(remaining)
        val frameBytes = 2 * channels
        while (inputBuffer.remaining() >= frameBytes) {
            val t = frame * 1000.0 / rate
            var g = 1.0
            if (fadeInMs > 0 && t < fadeInMs) g = min(g, t / fadeInMs)
            if (fadeOutMs > 0 && t > totalMs - fadeOutMs) g = min(g, max(0.0, (totalMs - t) / fadeOutMs))
            if (curve == 1) g = g * g
            for (c in 0 until channels) {
                val s = inputBuffer.short.toInt()
                out.putShort((s * g).toInt().coerceIn(-32768, 32767).toShort())
            }
            frame++
        }
        // بايتات متبقية أقل من فريم: نمررها زي ما هي
        while (inputBuffer.hasRemaining()) out.put(inputBuffer.get())
        out.flip()
    }
}

/** صدى بسيط (feedback delay) بتأخير ثابت. PCM 16-bit فقط. */
class EchoAudioProcessor(private val amount: Float, private val delayMs: Int = 250) : BaseAudioProcessor() {
    private var channels = 2
    private var buf = ShortArray(0)
    private var pos = 0

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        channels = inputAudioFormat.channelCount.coerceAtLeast(1)
        val frames = (inputAudioFormat.sampleRate.toLong() * delayMs / 1000).toInt().coerceAtLeast(1)
        buf = ShortArray(frames * channels)
        pos = 0
        return inputAudioFormat
    }

    override fun onFlush() {
        buf.fill(0)
        pos = 0
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return
        val out = replaceOutputBuffer(remaining)
        val fb = amount.coerceIn(0f, 1f) * 0.6f
        while (inputBuffer.remaining() >= 2) {
            val x = inputBuffer.short.toInt()
            val d = buf[pos].toInt()
            val y = (x + fb * d).toInt().coerceIn(-32768, 32767)
            buf[pos] = y.toShort()
            pos = (pos + 1) % buf.size
            out.putShort(y.toShort())
        }
        out.flip()
    }
}

object AudioEffects {
    /** سلسلة المعالجة بالترتيب: سرعة/pitch → مستوى → تطبيع → فلاتر → ديناميكس → تعديل → فراغ/صدى → ستيريو → تلاشي → صمت. */
    fun processors(a: AudioData): List<AudioProcessor> {
        val list = ArrayList<AudioProcessor>()
        if (a.speed != 1f || a.pitch != 1f) {
            list.add(SonicAudioProcessor().apply {
                setSpeed(a.speed)
                setPitch(a.pitch)
            })
        }
        if (a.volume != 1f) list.add(GainAudioProcessor(a.volume))
        if (a.normalize && a.normGain != 1f) list.add(GainAudioProcessor(a.normGain))
        val specs = ArrayList<BiquadSpec>()
        val bands = floatArrayOf(60f, 230f, 910f, 3600f, 14000f)
        for (i in 0 until 5) {
            val g = a.eq.getOrElse(i) { 0f }
            if (g != 0f) specs.add(BiquadSpec(0, bands[i], 1.0f, g))
        }
        if (a.bass != 0f) specs.add(BiquadSpec(1, 110f, 0.8f, a.bass))
        if (a.treble != 0f) specs.add(BiquadSpec(2, 8000f, 0.8f, a.treble))
        when (a.voiceFilter) {
            1 -> { specs.add(BiquadSpec(4, 320f, 0.9f, 0f)); specs.add(BiquadSpec(3, 3300f, 0.9f, 0f)) }
            2 -> { specs.add(BiquadSpec(4, 450f, 0.8f, 0f)); specs.add(BiquadSpec(3, 5200f, 0.8f, 0f)); specs.add(BiquadSpec(0, 1800f, 1.2f, 4f)) }
            3 -> { specs.add(BiquadSpec(0, 3000f, 1.0f, 4f)); specs.add(BiquadSpec(4, 90f, 0.8f, 0f)); specs.add(BiquadSpec(2, 7000f, 0.8f, 2f)) }
        }
        if (a.humHz > 0) for (h in 1..4) specs.add(BiquadSpec(5, a.humHz * h.toFloat(), 30f, 0f))
        if (a.highPassHz > 25f) specs.add(BiquadSpec(4, a.highPassHz, 0.8f, 0f))
        if (a.lowPassHz < 19500f) specs.add(BiquadSpec(3, a.lowPassHz, 0.8f, 0f))
        if (specs.isNotEmpty()) list.add(FilterChainProcessor(specs))
        if (a.declick) list.add(DeClickProcessor())
        if (a.deEss > 0.01f) list.add(DeEsserProcessor(a.deEss))
        if (a.gate > 0.01f) list.add(GateProcessor(a.gate))
        if (a.comp > 0.01f || a.limiter) list.add(DynamicsProcessor(a.comp, a.limiter))
        if (a.robot > 0.01f || a.tremolo > 0.01f) list.add(ModProcessor(a.robot, a.tremolo))
        if (a.chorus > 0.01f) list.add(ChorusProcessor(a.chorus, a.chorusMode))
        if (a.reverb > 0.01f) list.add(ReverbProcessor(a.reverb))
        if (a.echo > 0.01f) list.add(EchoAudioProcessor(a.echo))
        if (a.channelMode != 0 || a.pan != 0f) list.add(StereoProcessor(a.channelMode, a.pan))
        if (a.fadeInMs > 0 || a.fadeOutMs > 0) {
            list.add(FadeAudioProcessor(a.fadeInMs, a.fadeOutMs, a.previewMs * a.loops.coerceAtLeast(1) , a.fadeCurve))
        }
        if (a.padStartMs > 0 || a.padEndMs > 0) list.add(PadAudioProcessor(a.padStartMs, a.padEndMs))
        return list
    }

    /** معامل التلاشي عند موضع المصدر srcMs (للمعاينة). */
    fun fadeGain(a: AudioData, srcMs: Long): Float {
        val total = a.previewMs
        val t = ((srcMs - a.startMs) / a.speed).toLong().coerceIn(0L, total)
        var g = 1f
        if (a.fadeInMs > 0 && t < a.fadeInMs) g = min(g, t.toFloat() / a.fadeInMs)
        if (a.fadeOutMs > 0 && t > total - a.fadeOutMs) g = min(g, max(0f, (total - t).toFloat() / a.fadeOutMs))
        return g
    }
}

/** استخراج شكل الموجة (قمم الصوت) بفك الترميز على خيط خلفي. */
object AudioWaveform {
    fun compute(ctx: Context, uri: Uri, bins: Int = 400): FloatArray? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    track = i; fmt = f; break
                }
            }
            if (track < 0 || fmt == null) return null
            if (!fmt.containsKey(MediaFormat.KEY_DURATION)) return null
            val durUs = fmt.getLong(MediaFormat.KEY_DURATION)
            if (durUs <= 0) return null
            ex.selectTrack(track)
            codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(fmt, null, null, 0)
            codec.start()

            val peaks = FloatArray(bins)
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            var guard = 0
            while (!outDone && guard < 2_000_000) {
                guard++
                if (!inDone) {
                    val i = codec.dequeueInputBuffer(5000)
                    if (i >= 0) {
                        val buf = codec.getInputBuffer(i)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 5000)
                if (o >= 0) {
                    val ob = codec.getOutputBuffer(o)
                    if (ob != null && info.size > 0) {
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val bin = ((info.presentationTimeUs.toDouble() / durUs) * bins).toInt().coerceIn(0, bins - 1)
                        var m = 0
                        while (sb.hasRemaining()) {
                            val v = abs(sb.get().toInt())
                            if (v > m) m = v
                        }
                        peaks[bin] = max(peaks[bin], m / 32768f)
                    }
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
            }
            val mx = peaks.maxOrNull() ?: 0f
            if (mx <= 0f) return null
            // سد الفراغات (بكتات اتخطت) بأقرب قيمة قبلها
            for (i in 1 until bins) if (peaks[i] == 0f) peaks[i] = peaks[i - 1] * 0.6f
            return FloatArray(bins) { peaks[it] / mx }
        } catch (e: Throwable) {
            return null
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { ex.release() }
        }
    }
}
