@file:OptIn(UnstableApi::class)

package com.binarybeast.mediastudio.video

import androidx.media3.common.Effect
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.ScaleAndRotateTransformation
import com.binarybeast.mediastudio.data.Looks
import com.binarybeast.mediastudio.data.VideoClip
import java.nio.ByteBuffer

/** معالج صوت بسيط بيضرب العينات في معامل (للتحكم في مستوى الصوت أو الكتم). PCM 16-bit فقط. */
class GainAudioProcessor(private val gain: Float) : BaseAudioProcessor() {

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return
        val out = replaceOutputBuffer(remaining)
        while (inputBuffer.remaining() >= 2) {
            val s = inputBuffer.short.toInt()
            val v = (s * gain).toInt().coerceIn(-32768, 32767)
            out.putShort(v.toShort())
        }
        out.flip()
    }
}

/** تحويل إعدادات المقطع إلى Effects تستخدمها المعاينة (ExoPlayer) والتصدير (Transformer). */
object VideoEffects {

    fun geometry(c: VideoClip): List<Effect> {
        if (c.rotation % 360 == 0 && !c.flipH && !c.flipV) return emptyList()
        return listOf(
            ScaleAndRotateTransformation.Builder()
                .setRotationDegrees(c.rotation.toFloat())
                .setScale(if (c.flipH) -1f else 1f, if (c.flipV) -1f else 1f)
                .build()
        )
    }

    fun color(c: VideoClip): List<Effect> {
        val look = Looks.byId(c.lookId)
        val k = c.lookStrength.coerceIn(0f, 1f)
        val eff = look.adjust * k + c.adjust
        val fx = ArrayList<Effect>()

        if (look.mono && k >= 0.5f) fx.add(RgbFilter.createGrayscaleFilter())

        var r = 1f + (look.r - 1f) * k
        var g = 1f + (look.g - 1f) * k
        var b = 1f + (look.b - 1f) * k
        if (look.sepia && k > 0f) {
            fx.add(RgbFilter.createGrayscaleFilter())
            r *= 1f + 0.08f * k
            g *= 1f - 0.16f * k
            b *= 1f - 0.40f * k
        }
        r *= 1f + 0.2f * eff.warmth
        b *= 1f - 0.2f * eff.warmth
        if (c.tint != 0f) {
            g *= 1f - 0.2f * c.tint
            r *= 1f + 0.08f * c.tint
            b *= 1f + 0.08f * c.tint
        }
        if (r != 1f || g != 1f || b != 1f) {
            fx.add(
                RgbAdjustment.Builder()
                    .setRedScale(r.coerceIn(0f, 3f))
                    .setGreenScale(g.coerceIn(0f, 3f))
                    .setBlueScale(b.coerceIn(0f, 3f))
                    .build()
            )
        }
        if (eff.saturation != 0f || eff.hue != 0f) {
            fx.add(
                HslAdjustment.Builder()
                    .adjustSaturation((eff.saturation * 100f).coerceIn(-100f, 100f))
                    .adjustHue(eff.hue.coerceIn(-360f, 360f))
                    .build()
            )
        }
        if (eff.contrast != 0f) fx.add(Contrast(eff.contrast.coerceIn(-1f, 1f)))
        if (eff.brightness != 0f) fx.add(Brightness(eff.brightness.coerceIn(-1f, 1f)))
        vfxMatrix(c.vfx)?.let { m ->
            fx.add(object : RgbMatrix {
                override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray = m
            })
        }
        return fx
    }

    /** مصفوفة 4x4 (column-major) تحوّل RGBA. */
    private fun lumMix(kr: Float, kg: Float, kb: Float): FloatArray {
        val k = floatArrayOf(kr, kg, kb)
        val m = FloatArray(16)
        val w = floatArrayOf(0.299f, 0.587f, 0.114f)
        for (col in 0 until 3) for (row in 0 until 3) m[col * 4 + row] = k[row] * w[col]
        m[15] = 1f
        return m
    }

    private fun vfxMatrix(id: Int): FloatArray? = when (id) {
        1 -> lumMix(0.15f, 1.5f, 0.2f)
        2 -> lumMix(0.25f, 0.65f, 1.2f)
        3 -> lumMix(1.25f, 0.98f, 0.55f)
        4 -> lumMix(1.2f, 0.7f, 0.9f)
        5 -> lumMix(1.3f, 0.05f, 0.05f)
        6 -> floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 0f, 1f)
        7 -> floatArrayOf(0f, 1f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
        8 -> floatArrayOf(
            0.393f, 0.349f, 0.272f, 0f,
            0.769f, 0.686f, 0.534f, 0f,
            0.189f, 0.168f, 0.131f, 0f,
            0f, 0f, 0f, 1f
        )
        9 -> {
            val s = 1.9f
            val lr = 0.299f * (1 - s); val lg = 0.587f * (1 - s); val lb = 0.114f * (1 - s)
            floatArrayOf(
                lr + s, lr, lr, 0f,
                lg, lg + s, lg, 0f,
                lb, lb, lb + s, 0f,
                0f, 0f, 0f, 1f
            )
        }
        else -> null
    }

    /** تكبير ثابت + إزاحة + حركة Ken Burns (تقريب/تبعيد تدريجي على مدة المقطع). */
    fun motion(c: VideoClip): List<Effect> {
        if (c.zoom <= 1.001f && c.kenBurns == 0) return emptyList()
        val durUs = ((c.endMs - c.startMs).coerceAtLeast(1L)) * 1000L
        val base = c.zoom.coerceIn(1f, 4f)
        val kb = c.kenBurns
        val px = c.panX
        val py = c.panY
        return listOf(
            MatrixTransformation { presentationTimeUs ->
                val p = (presentationTimeUs.toFloat() / durUs).coerceIn(0f, 1f)
                val sec = presentationTimeUs / 1_000_000.0
                val z = when (kb) {
                    1 -> base * (1f + 0.25f * p)
                    2 -> base * (1.25f - 0.25f * p)
                    3, 4 -> base * 1.25f
                    5 -> base * (1f + 0.07f * (0.5f + 0.5f * Math.sin(2.0 * Math.PI * 1.4 * sec).toFloat()))
                    6 -> base * 1.07f
                    else -> base
                }
                var tx = -px * (z - 1f)
                var ty = py * (z - 1f)
                when (kb) {
                    3 -> tx += (z - 1f) * (1f - 2f * p) * 0.9f
                    4 -> tx -= (z - 1f) * (1f - 2f * p) * 0.9f
                    6 -> {
                        tx += (0.02 * Math.sin(2.0 * Math.PI * 7.0 * sec)).toFloat()
                        ty += (0.02 * Math.cos(2.0 * Math.PI * 9.0 * sec)).toFloat()
                    }
                }
                val m = android.graphics.Matrix()
                m.postScale(z, z)
                m.postTranslate(tx, ty)
                m
            }
        )
    }

    /** للمعاينة: تدوير/قلب + حركة + ألوان. */
    fun preview(c: VideoClip): List<Effect> = geometry(c) + motion(c) + color(c)

    /** معالجات الصوت للمقطع: سرعة + مستوى الصوت (الكتم = صوت صفر عشان نحافظ على مسار الصوت). */
    fun audio(c: VideoClip): List<AudioProcessor> {
        if (c.isImage) return emptyList()
        val list = ArrayList<AudioProcessor>()
        if (c.speed != 1f) {
            list.add(SonicAudioProcessor().apply {
                setSpeed(c.speed)
                setPitch(1f)
            })
        }
        val gain = if (c.muted) 0f else c.volume
        if (gain != 1f) list.add(GainAudioProcessor(gain))
        return list
    }
}
