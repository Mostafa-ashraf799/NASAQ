@file:OptIn(UnstableApi::class)

package com.binarybeast.mediastudio.video

import androidx.media3.common.Effect
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.ScaleAndRotateTransformation
import com.binarybeast.mediastudio.data.Looks
import com.binarybeast.mediastudio.data.VideoClip
import java.nio.ByteBuffer

/** معالج صوت بسيط بيضرب العينات في معامل (للتحكم في مستوى الصوت أو الكتم). PCM 16-bit فقط. */
class GainAudioProcessor(private val gain: Float) : BaseAudioProcessor() {

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return
        val out = replaceOutputBuffer(remaining)
        while (inputBuffer.remaining() >= 2) {
            val s = inputBuffer.short.toInt()
            val v = (s * gain).toInt().coerceIn(-32768, 32767)
            out.putShort(v.toShort())
        }
        out.flip()
    }
}

/** تحويل إعدادات المقطع إلى Effects تستخدمها المعاينة (ExoPlayer) والتصدير (Transformer). */
object VideoEffects {

    fun geometry(c: VideoClip): List<Effect> {
        if (c.rotation % 360 == 0 && !c.flipH) return emptyList()
        return listOf(
            ScaleAndRotateTransformation.Builder()
                .setRotationDegrees(c.rotation.toFloat())
                .setScale(if (c.flipH) -1f else 1f, 1f)
                .build()
        )
    }

    fun color(c: VideoClip): List<Effect> {
        val look = Looks.byId(c.lookId)
        val k = c.lookStrength.coerceIn(0f, 1f)
        val eff = look.adjust * k + c.adjust
        val fx = ArrayList<Effect>()

        if (look.mono && k >= 0.5f) fx.add(RgbFilter.createGrayscaleFilter())

        var r = 1f + (look.r - 1f) * k
        var g = 1f + (look.g - 1f) * k
        var b = 1f + (look.b - 1f) * k
        if (look.sepia && k > 0f) {
            fx.add(RgbFilter.createGrayscaleFilter())
            r *= 1f + 0.08f * k
            g *= 1f - 0.16f * k
            b *= 1f - 0.40f * k
        }
        r *= 1f + 0.2f * eff.warmth
        b *= 1f - 0.2f * eff.warmth
        if (r != 1f || g != 1f || b != 1f) {
            fx.add(
                RgbAdjustment.Builder()
                    .setRedScale(r.coerceIn(0f, 3f))
                    .setGreenScale(g.coerceIn(0f, 3f))
                    .setBlueScale(b.coerceIn(0f, 3f))
                    .build()
            )
        }
        if (eff.saturation != 0f || eff.hue != 0f) {
            fx.add(
                HslAdjustment.Builder()
                    .adjustSaturation((eff.saturation * 100f).coerceIn(-100f, 100f))
                    .adjustHue(eff.hue.coerceIn(-360f, 360f))
                    .build()
            )
        }
        if (eff.contrast != 0f) fx.add(Contrast(eff.contrast.coerceIn(-1f, 1f)))
        if (eff.brightness != 0f) fx.add(Brightness(eff.brightness.coerceIn(-1f, 1f)))
        return fx
    }

    /** تكبير ثابت + إزاحة + حركة Ken Burns (تقريب/تبعيد تدريجي على مدة المقطع). */
    fun motion(c: VideoClip): List<Effect> {
        if (c.zoom <= 1.001f && c.kenBurns == 0) return emptyList()
        val durUs = ((c.endMs - c.startMs).coerceAtLeast(1L)) * 1000L
        val base = c.zoom.coerceIn(1f, 4f)
        val kb = c.kenBurns
        val px = c.panX
        val py = c.panY
        return listOf(
            MatrixTransformation { presentationTimeUs ->
                val p = (presentationTimeUs.toFloat() / durUs).coerceIn(0f, 1f)
                val z = when (kb) {
                    1 -> base * (1f + 0.25f * p)
                    2 -> base * (1.25f - 0.25f * p)
                    else -> base
                }
                val m = android.graphics.Matrix()
                m.postScale(z, z)
                m.postTranslate(-px * (z - 1f), py * (z - 1f))
                m
            }
        )
    }

    /** للمعاينة: تدوير/قلب + حركة + ألوان. */
    fun preview(c: VideoClip): List<Effect> = geometry(c) + motion(c) + color(c)

    /** معالجات الصوت للمقطع: سرعة + مستوى الصوت (الكتم = صوت صفر عشان نحافظ على مسار الصوت). */
    fun audio(c: VideoClip): List<AudioProcessor> {
        if (c.isImage) return emptyList()
        val list = ArrayList<AudioProcessor>()
        if (c.speed != 1f) {
            list.add(SonicAudioProcessor().apply {
                setSpeed(c.speed)
                setPitch(1f)
            })
        }
        val gain = if (c.muted) 0f else c.volume
        if (gain != 1f) list.add(GainAudioProcessor(gain))
        return list
    }
}
