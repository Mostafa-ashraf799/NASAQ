package com.binarybeast.mediastudio.ui

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** شريط صغير فوق كل الشاشات بيعرّف المستخدم إن في نقل ملفات شغال في الخلفية. */
@Composable
fun TransferOverlay(onOpenAs: (CloudOpenKind, List<Uri>) -> Unit) {
    val items = Transfers.items
    if (items.isEmpty()) return
    var open by remember { mutableStateOf(false) }
    val active = items.count { it.state == 0 }
    val failed = items.count { it.state == 2 }
    Box(Modifier.fillMaxSize().statusBarsPadding().padding(top = 6.dp), contentAlignment = Alignment.TopCenter) {
        Row(
            Modifier.clip(RoundedCornerShape(50)).background(Surface2).clickable { open = true }
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (active > 0) CircularProgressIndicator(Modifier.size(16.dp), color = Accent, strokeWidth = 2.dp)
            Text(
                when {
                    active > 0 -> "  $active عملية نقل جارية"
                    failed > 0 -> "  انتهى النقل ($failed فشل)"
                    else -> "  اكتمل النقل"
                },
                fontSize = 12.sp, color = Accent
            )
        }
    }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            containerColor = Surface1,
            title = { Text("نقل الملفات") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items.forEach { it ->
                        Column(Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(if (it.upload) Icons.Default.CloudUpload else Icons.Default.CloudDownload, null, tint = Accent, modifier = Modifier.size(18.dp))
                                Text("  " + it.name, fontSize = 13.sp, maxLines = 1, modifier = Modifier.weight(1f))
                                Text(
                                    when (it.state) { 0 -> if (it.progress >= 0) "${it.progress}%" else "..."; 1 -> "تم"; else -> "فشل" },
                                    fontSize = 11.sp, color = if (it.state == 2) androidx.compose.ui.graphics.Color(0xFFFF6B6B) else TextDim
                                )
                            }
                            if (it.state == 0) {
                                if (it.progress >= 0) LinearProgressIndicator(progress = { it.progress / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp), color = Accent)
                                else LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), color = Accent)
                            }
                            if (it.state == 1 && !it.upload && it.uri != null && it.kind != null) {
                                TextButton(onClick = { open = false; onOpenAs(it.kind, listOf(it.uri)) }) { Text("افتح في المحرر", color = Accent) }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { open = false }) { Text("إغلاق", color = Accent) } },
            dismissButton = { TextButton(onClick = { Transfers.clearFinished(); if (Transfers.items.isEmpty()) open = false }) { Text("مسح المنتهي", color = TextDim) } }
        )
    }
}
