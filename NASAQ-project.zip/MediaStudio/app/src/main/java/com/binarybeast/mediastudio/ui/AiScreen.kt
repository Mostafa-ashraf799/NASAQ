package com.binarybeast.mediastudio.ui

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.binarybeast.mediastudio.Graph
import com.binarybeast.mediastudio.ai.*
import com.binarybeast.mediastudio.data.CanvasStore
import com.binarybeast.mediastudio.data.Project
import com.binarybeast.mediastudio.data.ProjectFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

internal class ChatItem(val kind: String, val text: String, val images: List<String> = emptyList())

/** حالة المحادثة بتفضل حية حتى لو خرجت من التبويب. */
internal object AiSession {
    val items = mutableStateListOf<ChatItem>()
    val history = mutableListOf<AiMsg>()
    var projectId by mutableStateOf<String?>(null)
    var running by mutableStateOf(false)
    var attach by mutableStateOf(false)
    var snapshot by mutableStateOf<List<Project>>(emptyList())
    var job: Job? = null
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    fun send(ctx: android.content.Context, cfg: AiConfig, text: String) {
        val t = text.trim()
        if (running || t.isEmpty()) return
        running = true
        job = scope.launch {
            val tools = AiTools(ctx.applicationContext, cfg, projectId)
            var imgs = emptyList<String>()
            try {
                withContext(Dispatchers.IO) {
                    if (attach && cfg.sendImages && projectId != null) tools.currentB64(1024)?.let { imgs = listOf(it) }
                    snapshot = projectId?.let { id ->
                        val p = Graph.repo.load(id)
                        if (p == null) emptyList() else listOf(p) + (if (p.canvas != null) CanvasStore.pages(id) else emptyList())
                    } ?: emptyList()
                }
                items.add(ChatItem("user", t, imgs))
                history.add(AiMsg("user", t, imgs))
                AiAgent.run(ctx.applicationContext, cfg, tools, history) { ev ->
                    withContext(Dispatchers.Main) {
                        items.add(ChatItem(ev.kind, ev.text, ev.images))
                        if (tools.projectId != projectId) projectId = tools.projectId
                    }
                }
            } finally { running = false }
        }
    }

    fun stop() { job?.cancel(); running = false }
    fun clear() { stop(); items.clear(); history.clear() }
}

@Composable
fun BetaBadge(modifier: Modifier = Modifier) {
    Text(
        "BETA", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary,
        modifier = modifier.clip(RoundedCornerShape(6.dp)).background(Accent).padding(horizontal = 6.dp, vertical = 2.dp)
    )
}

@Composable
fun AiScreen(onOpenProject: (Project) -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    var cfg by remember { mutableStateOf(AiSettings.load(ctx)) }
    var input by remember { mutableStateOf("") }
    var showLibrary by remember { mutableStateOf(false) }
    var showPicker by remember { mutableStateOf(false) }
    var projectName by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val s = AiSession

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) cfg = AiSettings.load(ctx) }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    LaunchedEffect(s.items.size) { if (s.items.isNotEmpty()) listState.animateScrollToItem(s.items.size - 1) }
    LaunchedEffect(s.projectId) {
        projectName = s.projectId?.let { id -> withContext(Dispatchers.IO) { Graph.repo.load(id)?.name } } ?: ""
    }

    fun send(t: String) {
        if (!cfg.apiReady) { onSettings(); return }
        input = ""
        s.send(ctx, cfg, t)
    }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().imePadding()) {
        // ---------------- header
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp, top = 10.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.AutoAwesome, null, tint = MaterialTheme.colorScheme.onPrimary)
            }
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("NASAQ Ai", fontSize = 20.sp, fontWeight = FontWeight.Bold); BetaBadge()
                }
                Text(if (cfg.apiReady) cfg.model else "غير مربوط — افتح الإعدادات", fontSize = 11.sp, color = TextDim, maxLines = 1)
            }
            IconButton(onClick = { s.snapshot.forEach { Graph.repo.save(it) }; s.items.add(ChatItem("tool", "↩ اتراجع عن تعديلات الـ AI الأخيرة")); s.snapshot = emptyList() },
                enabled = s.snapshot.isNotEmpty() && !s.running) { Icon(Icons.Default.Undo, "تراجع") }
            IconButton(onClick = { s.clear() }) { Icon(Icons.Default.Delete, "مسح") }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "إعدادات") }
        }

        // ---------------- project + image toggle
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(Surface1).clickable { showPicker = true }.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("المشروع الشغّال", fontSize = 10.sp, color = TextDim)
                    Text(projectName.ifBlank { "اختار مشروع" }, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                }
                Icon(Icons.Default.ArrowDropDown, null, tint = TextDim)
            }
            Row(
                Modifier.clip(RoundedCornerShape(16.dp)).background(Surface1).padding(start = 14.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("ابعت الصورة", fontSize = 12.sp)
                Switch(s.attach, { s.attach = it }, modifier = Modifier.height(28.dp))
            }
        }

        // ---------------- messages
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (s.items.isEmpty()) {
                EmptyState(cfg.apiReady, onSettings) { input = it }
            } else {
                LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(s.items.size) { i -> Bubble(s.items[i], ctx, onOpenProject) }
                    if (s.running) item {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.size(18.dp), color = Accent, strokeWidth = 2.dp); Text("بيشتغل...", color = TextDim, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // ---------------- composer
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("📚 المكتبة", false, { showLibrary = true })
            AiPrompts.library.forEach { (_, list) -> list.firstOrNull()?.let { (l, tx) -> Chip(l, false, { input = tx }) } }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).clip(RoundedCornerShape(28.dp)).background(Surface1).padding(start = 6.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), maxLines = 5,
                placeholder = { Text("اكتب طلبك لنسق...", color = TextDim) },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Transparent, unfocusedBorderColor = Color.Transparent)
            )
            val canSend = input.isNotBlank() && !s.running
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(if (s.running) Danger else if (canSend) Accent else Surface2)
                    .clickable { if (s.running) s.stop() else if (canSend) send(input) },
                contentAlignment = Alignment.Center
            ) {
                Icon(if (s.running) Icons.Default.Stop else Icons.Default.Send, null, tint = if (canSend || s.running) MaterialTheme.colorScheme.onPrimary else TextDim)
            }
        }
    }

    if (showLibrary) AlertDialog(
        onDismissRequest = { showLibrary = false }, containerColor = Surface1, title = { Text("مكتبة البرومتات") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                AiPrompts.library.forEach { (cat, list) ->
                    SectionLabel(cat)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        list.forEach { (label, text) -> Chip(label, false, { input = text; showLibrary = false }, Modifier.fillMaxWidth()) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showLibrary = false }) { Text("إغلاق", color = Accent) } }
    )
    if (showPicker) {
        var list by remember { mutableStateOf<List<Project>>(emptyList()) }
        LaunchedEffect(Unit) { list = withContext(Dispatchers.IO) { Graph.repo.list().filter { it.parentId == null } } }
        AlertDialog(
            onDismissRequest = { showPicker = false }, containerColor = Surface1, title = { Text("اختار المشروع") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Chip("بدون مشروع", s.projectId == null, { s.projectId = null; showPicker = false }, Modifier.fillMaxWidth())
                    list.forEach { p -> Chip("${p.name} • ${p.summary}", s.projectId == p.id, { s.projectId = p.id; showPicker = false }, Modifier.fillMaxWidth()) }
                }
            },
            confirmButton = { TextButton(onClick = { showPicker = false }) { Text("إغلاق", color = Accent) } }
        )
    }
}

@Composable
private fun EmptyState(ready: Boolean, onSettings: () -> Unit, onPrompt: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(Surface2), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.AutoAwesome, null, tint = Accent, modifier = Modifier.size(38.dp))
        }
        Text("إزاي أقدر أساعدك؟", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp))
        if (!ready) {
            Text("اربط مزوّد ذكاء اصطناعي الأول عشان الشات يشتغل.", color = TextDim, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp, bottom = 16.dp))
            Box(
                Modifier.clip(RoundedCornerShape(16.dp)).background(Accent).clickable(onClick = onSettings).padding(horizontal = 28.dp, vertical = 14.dp)
            ) { Text("فتح إعدادات الـ AI", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onPrimary) }
        } else {
            Text("اختار مشروع من فوق واطلب تحليل أو تعديل، أو جرّب واحد من دول:", color = TextDim, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp, bottom = 14.dp))
            val picks = listOf(0 to 0, 1 to 0, 2 to 0, 2 to 1, 4 to 1, 6 to 0).mapNotNull { (c, i) -> AiPrompts.library.getOrNull(c)?.second?.getOrNull(i) }
            picks.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { (label, text) ->
                        Box(
                            Modifier.weight(1f).heightIn(min = 64.dp).clip(RoundedCornerShape(16.dp)).background(Surface1).clickable { onPrompt(text) }.padding(14.dp),
                            contentAlignment = Alignment.CenterStart
                        ) { Text(label, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatItem, ctx: android.content.Context, onOpenProject: (Project) -> Unit) {
    val scope = rememberCoroutineScope()
    when (m.kind) {
        "tool" -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            Text(
                if (m.text.startsWith("↩")) m.text else "🔧 ${m.text}", color = TextDim, fontSize = 11.sp,
                modifier = Modifier.clip(RoundedCornerShape(50)).background(Surface1).padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }
        "error" -> Text(
            "⚠ ${m.text}", color = Danger, fontSize = 13.sp,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Danger.copy(alpha = 0.12f)).padding(12.dp)
        )
        else -> {
            val mine = m.kind == "user"
            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Top) {
                if (!mine) Box(Modifier.padding(end = 8.dp, top = 2.dp).size(28.dp).clip(CircleShape).background(Surface2), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Accent, modifier = Modifier.size(16.dp))
                }
                Column(Modifier.widthIn(max = 520.dp), horizontalAlignment = if (mine) Alignment.End else Alignment.Start, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (m.text.isNotBlank() && m.kind != "image") SelectionContainer {
                        Text(
                            m.text, fontSize = 15.sp, lineHeight = 22.sp,
                            color = if (mine) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = if (mine) 18.dp else 4.dp, bottomEnd = if (mine) 4.dp else 18.dp))
                                .background(if (mine) Accent else Surface1).padding(horizontal = 14.dp, vertical = 10.dp)
                        )
                    }
                    m.images.forEach { b64 ->
                        val bmp = remember(b64) {
                            runCatching {
                                val bytes = Base64.decode(b64, Base64.DEFAULT)
                                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = 2 })?.asImageBitmap()
                            }.getOrNull()
                        }
                        if (bmp != null) Image(bmp, null, Modifier.widthIn(max = 260.dp).heightIn(max = 260.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Fit)
                        if (m.kind == "image") SmallButton("فتح كمشروع صورة", {
                            scope.launch {
                                val p = withContext(Dispatchers.IO) {
                                    runCatching {
                                        val f = File(ctx.cacheDir, "ai_${System.currentTimeMillis()}.jpg")
                                        f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
                                        ProjectFactory.createImageProject(ctx, "نتيجة AI", android.net.Uri.fromFile(f))
                                    }.getOrNull()
                                }
                                if (p != null) onOpenProject(p) else toast(ctx, "تعذّر فتح الصورة")
                            }
                        })
                    }
                }
            }
        }
    }
}
