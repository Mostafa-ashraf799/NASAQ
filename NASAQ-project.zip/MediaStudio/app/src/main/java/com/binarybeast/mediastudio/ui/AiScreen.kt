package com.binarybeast.mediastudio.ui

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binarybeast.mediastudio.Graph
import com.binarybeast.mediastudio.ai.*
import com.binarybeast.mediastudio.data.CanvasStore
import com.binarybeast.mediastudio.data.Project
import com.binarybeast.mediastudio.data.ProjectFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private class ChatItem(val kind: String, val text: String, val images: List<String> = emptyList())

@Composable
fun BetaBadge(modifier: Modifier = Modifier) {
    Text(
        "BETA", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary,
        modifier = modifier.clip(RoundedCornerShape(6.dp)).background(Accent).padding(horizontal = 6.dp, vertical = 2.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiScreen(onBack: () -> Unit, onOpenProject: (Project) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var cfg by remember { mutableStateOf(AiSettings.load(ctx)) }
    val items = remember { mutableStateListOf<ChatItem>() }
    val history = remember { mutableListOf<AiMsg>() }
    var input by remember { mutableStateOf("") }
    var running by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }
    var projectId by remember { mutableStateOf<String?>(null) }
    var projectName by remember { mutableStateOf("بدون مشروع") }
    var attach by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showLibrary by remember { mutableStateOf(false) }
    var showPicker by remember { mutableStateOf(false) }
    var snapshot by remember { mutableStateOf<List<Project>>(emptyList()) }
    val listState = rememberLazyListState()
    BackHandler(onBack = onBack)

    LaunchedEffect(items.size) { if (items.isNotEmpty()) listState.animateScrollToItem(items.size - 1) }
    LaunchedEffect(projectId) {
        projectName = projectId?.let { id -> withContext(Dispatchers.IO) { Graph.repo.load(id)?.name } } ?: "بدون مشروع"
    }

    fun send(text: String) {
        val t = text.trim()
        if (running || t.isEmpty()) return
        if (!cfg.apiReady) { showSettings = true; return }
        input = ""
        running = true
        job = scope.launch {
            val tools = AiTools(ctx, cfg, projectId)
            var imgs = emptyList<String>()
            try {
                withContext(Dispatchers.IO) {
                    if (attach && cfg.sendImages && projectId != null) tools.currentB64(1024)?.let { imgs = listOf(it) }
                    snapshot = projectId?.let { id ->
                        val p = Graph.repo.load(id)
                        if (p == null) emptyList() else listOf(p) + (if (p.canvas != null) CanvasStore.pages(id) else emptyList())
                    } ?: emptyList()
                }
                items.add(ChatItem("user", t, imgs))
                history.add(AiMsg("user", t, imgs))
                AiAgent.run(ctx, cfg, tools, history) { ev ->
                    withContext(Dispatchers.Main) { items.add(ChatItem(ev.kind, ev.text, ev.images)) }
                    if (tools.projectId != projectId) withContext(Dispatchers.Main) { projectId = tools.projectId }
                }
            } finally { running = false }
        }
    }

    Scaffold(
        containerColor = Bg,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("مساعد نسق"); BetaBadge()
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = {
                        snapshot.forEach { Graph.repo.save(it) }
                        items.add(ChatItem("tool", "↩ اتراجع عن تعديلات الـ AI الأخيرة"))
                        snapshot = emptyList()
                    }, enabled = snapshot.isNotEmpty() && !running) { Icon(Icons.Default.Undo, "تراجع") }
                    IconButton(onClick = { items.clear(); history.clear() }) { Icon(Icons.Default.Delete, "مسح المحادثة") }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "إعدادات") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Surface1)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            // شريط المشروع + إرفاق الصورة
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Chip("المشروع: $projectName", projectId != null, { showPicker = true }, Modifier.weight(1f, fill = false))
                Chip(if (attach) "هترسل الصورة الحالية" else "إرسال الصورة الحالية", attach, { attach = !attach })
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (items.isEmpty()) item {
                    Column(Modifier.fillMaxWidth().padding(top = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("اسأل أو اطلب تعديل", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text(
                            if (cfg.apiReady) "اختار مشروع من فوق، وفعّل إرسال الصورة لو عايزه يحلّلها، وبعدين اكتب طلبك أو اختار من مكتبة البرومتات."
                            else "الخطوة الأولى: ادخل الإعدادات واربط مزوّد API (أو سيرفر MCP).",
                            color = TextDim, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp)
                        )
                        if (!cfg.apiReady) SmallButton("فتح الإعدادات", { showSettings = true }, Modifier.padding(top = 12.dp))
                    }
                }
                items(items.size) { i -> Bubble(items[i], ctx, onOpenProject) }
                if (running) item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(20.dp), color = Accent, strokeWidth = 2.dp); Text("بيشتغل...", color = TextDim)
                } }
            }
            // برومتات سريعة
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("📚 مكتبة البرومتات", false, { showLibrary = true })
                AiPrompts.library.first().second.take(3).forEach { (l, tx) -> Chip(l, false, { input = tx }) }
            }
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), maxLines = 5,
                    placeholder = { Text("اكتب طلبك...", color = TextDim) }
                )
                if (running) {
                    IconButton(onClick = { job?.cancel(); running = false }) { Icon(Icons.Default.Stop, "إيقاف", tint = Danger, modifier = Modifier.size(32.dp)) }
                } else {
                    IconButton(onClick = { send(input) }, enabled = input.isNotBlank()) {
                        Icon(Icons.Default.Send, "إرسال", tint = if (input.isNotBlank()) Accent else TextDim, modifier = Modifier.size(32.dp))
                    }
                }
            }
        }
    }

    if (showSettings) AiSettingsDialog(cfg, onDismiss = { showSettings = false }, onSave = { cfg = it; AiSettings.save(ctx, it); showSettings = false }, onCopyGuide = {
        clipboard.setText(AnnotatedString(AiPrompts.toolGuide)); toast(ctx, "اتنسخ دليل الأدوات")
    })
    if (showLibrary) AlertDialog(
        onDismissRequest = { showLibrary = false }, containerColor = Surface1, title = { Text("مكتبة البرومتات") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                AiPrompts.library.forEach { (cat, list) ->
                    SectionLabel(cat)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        list.forEach { (label, text) -> Chip(label, false, { input = text; showLibrary = false }, Modifier.fillMaxWidth()) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showLibrary = false }) { Text("إغلاق", color = Accent) } }
    )
    if (showPicker) {
        var list by remember { mutableStateOf<List<Project>>(emptyList()) }
        LaunchedEffect(Unit) { list = withContext(Dispatchers.IO) { Graph.repo.list().filter { it.parentId == null } } }
        AlertDialog(
            onDismissRequest = { showPicker = false }, containerColor = Surface1, title = { Text("اختار المشروع") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Chip("بدون مشروع", projectId == null, { projectId = null; showPicker = false }, Modifier.fillMaxWidth())
                    list.forEach { p -> Chip("${p.name} • ${p.summary}", projectId == p.id, { projectId = p.id; showPicker = false }, Modifier.fillMaxWidth()) }
                }
            },
            confirmButton = { TextButton(onClick = { showPicker = false }) { Text("إغلاق", color = Accent) } }
        )
    }
}

@Composable
private fun Bubble(m: ChatItem, ctx: android.content.Context, onOpenProject: (Project) -> Unit) {
    val scope = rememberCoroutineScope()
    when (m.kind) {
        "tool" -> Text(if (m.text.startsWith("↩")) m.text else "🔧 ${m.text}", color = TextDim, fontSize = 12.sp)
        "error" -> Text("⚠ ${m.text}", color = Danger, fontSize = 14.sp)
        else -> {
            val mine = m.kind == "user"
            Column(
                Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start, verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (m.text.isNotBlank() && m.kind != "image") SelectionContainer {
                    Text(
                        m.text, fontSize = 15.sp, color = if (mine) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.widthIn(max = 520.dp).clip(RoundedCornerShape(16.dp))
                            .background(if (mine) Accent else Surface2).padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }
                m.images.forEach { b64 ->
                    val bmp = remember(b64) {
                        runCatching {
                            val bytes = Base64.decode(b64, Base64.DEFAULT)
                            val o = BitmapFactory.Options().apply { inSampleSize = 2 }
                            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)?.asImageBitmap()
                        }.getOrNull()
                    }
                    if (bmp != null) {
                        Image(bmp, null, Modifier.widthIn(max = 260.dp).heightIn(max = 260.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Fit)
                    }
                    if (m.kind == "image") SmallButton("فتح كمشروع صورة", {
                        scope.launch {
                            val p = withContext(Dispatchers.IO) {
                                runCatching {
                                    val f = File(ctx.cacheDir, "ai_${System.currentTimeMillis()}.jpg")
                                    f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
                                    ProjectFactory.createImageProject(ctx, "نتيجة AI", android.net.Uri.fromFile(f))
                                }.getOrNull()
                            }
                            if (p != null) onOpenProject(p) else toast(ctx, "تعذّر فتح الصورة")
                        }
                    })
                }
            }
        }
    }
}

private data class Preset(val name: String, val proto: Int, val base: String, val model: String)

private val presets = listOf(
    Preset("OpenAI", 0, "https://api.openai.com/v1", "gpt-4o-mini"),
    Preset("Gemini", 0, "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.0-flash"),
    Preset("OpenRouter", 0, "https://openrouter.ai/api/v1", "openai/gpt-4o-mini"),
    Preset("Anthropic", 1, "https://api.anthropic.com", "claude-sonnet-5-5"),
    Preset("Ollama محلي", 0, "http://192.168.1.10:11434/v1", "llava"),
)

@Composable
private fun AiSettingsDialog(cfg: AiConfig, onDismiss: () -> Unit, onSave: (AiConfig) -> Unit, onCopyGuide: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var c by remember { mutableStateOf(cfg) }
    var testing by remember { mutableStateOf(false) }
    var testMsg by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Surface1,
        title = { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { Text("إعدادات الـ AI"); BetaBadge() } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("البيانات بتتخزن على جهازك بس. الصور بتتبعت للمزوّد اللي انت تحدده وبس لما توافق.", fontSize = 12.sp, color = TextDim)
                SectionLabel("إعداد سريع")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    presets.forEach { p -> Chip(p.name, false, { c = c.copy(proto = p.proto, baseUrl = p.base, model = p.model) }) }
                }
                SectionLabel("نوع الـ API")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("OpenAI-compatible", c.proto == 0, { c = c.copy(proto = 0) })
                    Chip("Anthropic", c.proto == 1, { c = c.copy(proto = 1) })
                }
                OutlinedTextField(c.baseUrl, { c = c.copy(baseUrl = it) }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Base URL") }, placeholder = { Text(c.effectiveBase, color = TextDim) })
                OutlinedTextField(c.apiKey, { c = c.copy(apiKey = it) }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("API Key") }, visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(c.model, { c = c.copy(model = it) }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("الموديل (لازم يدعم الصور لو هتبعت صور)") })
                SectionLabel("سيرفر MCP (اختياري)")
                OutlinedTextField(c.mcpUrl, { c = c.copy(mcpUrl = it) }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("MCP URL (HTTP)") })
                OutlinedTextField(c.mcpToken, { c = c.copy(mcpToken = it) }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("MCP Token (اختياري)") }, visualTransformation = PasswordVisualTransformation())
                SectionLabel("الصلاحيات")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("يسمح للـ AI يعدّل المشروع المختار", Modifier.weight(1f), fontSize = 14.sp)
                    Switch(c.allowEdits, { c = c.copy(allowEdits = it) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("يسمح بإرسال صور المشروع للـ AI", Modifier.weight(1f), fontSize = 14.sp)
                    Switch(c.sendImages, { c = c.copy(sendImages = it) })
                }
                Text("الـ AI ملوش أي وصول للمعرض أو ملفات الجهاز. بيشوف المشروع المختار فقط.", fontSize = 12.sp, color = TextDim)
                OutlinedTextField(c.extraPrompt, { c = c.copy(extraPrompt = it) }, Modifier.fillMaxWidth(), minLines = 2, maxLines = 5, label = { Text("تعليمات إضافية للـ AI (اختياري)") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallButton(if (testing) "بيختبر..." else "اختبار الاتصال", {
                        if (testing) return@SmallButton
                        testing = true; testMsg = ""
                        scope.launch {
                            val msg = withContext(Dispatchers.IO) {
                                val sb = StringBuilder()
                                if (c.apiReady) {
                                    sb.append(try { "API ✓ " + AiClient.chat(c, "Reply with the single word: ok", listOf(AiMsg("user", "ping"))).take(40) } catch (t: Throwable) { "API ✗ ${t.message}" })
                                } else sb.append("API: ناقص الموديل أو المفتاح")
                                if (c.mcpUrl.isNotBlank()) {
                                    sb.append("\n").append(try { "MCP ✓ ${McpClient(c.mcpUrl, c.mcpToken).tools().size} أداة" } catch (t: Throwable) { "MCP ✗ ${t.message}" })
                                }
                                sb.toString()
                            }
                            testMsg = msg; testing = false
                        }
                    })
                    SmallButton("نسخ دليل الأدوات", onCopyGuide)
                }
                if (testMsg.isNotBlank()) Text(testMsg, fontSize = 13.sp)
            }
        },
        confirmButton = { TextButton(onClick = { onSave(c) }) { Text("حفظ", color = Accent, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = TextDim) } }
    )
}
