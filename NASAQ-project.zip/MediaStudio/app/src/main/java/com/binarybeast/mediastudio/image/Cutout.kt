package com.binarybeast.mediastudio.image

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * جلسة قص خلفية قابلة للضبط:
 *  - وضع "شخص": قناع ML Kit.
 *  - وضع "لون الخلفية": يملأ من الحواف بلون الخلفية المقدّر (يشتغل مع أي جسم على خلفية متجانسة).
 *  - حدة/نعومة/تكبير-تصغير/تنعيم للحواف + فرشاة يدوية (محو/استعادة).
 */
class Cutout(val base: Bitmap) {
    val w = base.width
    val h = base.height
    private val px = IntArray(w * h).also { base.getPixels(it, 0, w, 0, 0, w, h) }
    private var personConf: FloatArray? = null
    private var smartConf: FloatArray? = null
    private var smartTol = -1f
    /** -1 = محو، +1 = استعادة، 0 = بدون. */
    private val manual = ByteArray(w * h)

    val hasPerson: Boolean get() = personConf != null

    suspend fun loadPerson(): Boolean {
        val m = BackgroundRemover.mask(base) ?: return false
        val (conf, mw, mh) = m
        val out = FloatArray(w * h)
        for (y in 0 until h) {
            val fy = (y + 0.5f) * mh / h - 0.5f
            val y0 = fy.toInt().coerceIn(0, mh - 1)
            val y1 = (y0 + 1).coerceAtMost(mh - 1)
            val ty = (fy - y0).coerceIn(0f, 1f)
            for (x in 0 until w) {
                val fx = (x + 0.5f) * mw / w - 0.5f
                val x0 = fx.toInt().coerceIn(0, mw - 1)
                val x1 = (x0 + 1).coerceAtMost(mw - 1)
                val tx = (fx - x0).coerceIn(0f, 1f)
                val a = conf[y0 * mw + x0] * (1 - tx) + conf[y0 * mw + x1] * tx
                val b = conf[y1 * mw + x0] * (1 - tx) + conf[y1 * mw + x1] * tx
                out[y * w + x] = a * (1 - ty) + b * ty
            }
        }
        personConf = out
        return true
    }

    private fun dist(c1: Int, r2: Float, g2: Float, b2: Float): Float {
        val dr = ((c1 shr 16) and 255) - r2
        val dg = ((c1 shr 8) and 255) - g2
        val db = (c1 and 255) - b2
        return sqrt(dr * dr + dg * dg + db * db)
    }

    /** يقدّر لون الخلفية من الحواف (وسيط) ويملأ من الحواف للداخل. tol: 0..1 */
    private fun smart(tol: Float): FloatArray {
        smartConf?.let { if (smartTol == tol) return it }
        val rs = ArrayList<Int>(); val gs = ArrayList<Int>(); val bs = ArrayList<Int>()
        fun add(i: Int) { val c = px[i]; rs.add((c shr 16) and 255); gs.add((c shr 8) and 255); bs.add(c and 255) }
        val step = max(1, min(w, h) / 200)
        var x = 0
        while (x < w) { add(x); add((h - 1) * w + x); x += step }
        var y = 0
        while (y < h) { add(y * w); add(y * w + w - 1); y += step }
        rs.sort(); gs.sort(); bs.sort()
        val mr = rs[rs.size / 2].toFloat(); val mg = gs[gs.size / 2].toFloat(); val mb = bs[bs.size / 2].toFloat()
        val thr = 12f + tol * 150f
        val bg = BooleanArray(w * h)
        val q = IntArray(w * h)
        var head = 0; var tail = 0
        fun seed(i: Int) { if (!bg[i] && dist(px[i], mr, mg, mb) < thr) { bg[i] = true; q[tail++] = i } }
        for (xx in 0 until w) { seed(xx); seed((h - 1) * w + xx) }
        for (yy in 0 until h) { seed(yy * w); seed(yy * w + w - 1) }
        while (head < tail) {
            val i = q[head++]
            val cx = i % w; val cy = i / w
            if (cx > 0) seed(i - 1)
            if (cx < w - 1) seed(i + 1)
            if (cy > 0) seed(i - w)
            if (cy < h - 1) seed(i + w)
        }
        val out = FloatArray(w * h)
        for (i in out.indices) {
            if (!bg[i]) {
                // قرب اللون من الخلفية يخفّف الألفا (حواف أنعم)
                val d = dist(px[i], mr, mg, mb)
                out[i] = ((d - thr) / (thr * 0.6f + 8f) + 0.6f).coerceIn(0f, 1f).let { if (d < thr * 1.6f) it else 1f }
            }
        }
        smartConf = out
        smartTol = tol
        return out
    }

    fun brush(cx: Float, cy: Float, radius: Float, restore: Boolean) {
        val r = max(1f, radius)
        val x0 = max(0, (cx - r).toInt()); val x1 = min(w - 1, (cx + r).toInt())
        val y0 = max(0, (cy - r).toInt()); val y1 = min(h - 1, (cy + r).toInt())
        val v: Byte = if (restore) 1 else -1
        val r2 = r * r
        for (y in y0..y1) for (x in x0..x1) {
            val dx = x - cx; val dy = y - cy
            if (dx * dx + dy * dy <= r2) manual[y * w + x] = v
        }
    }

    fun clearManual() = manual.fill(0)

    private fun morph(a: FloatArray, r: Int, grow: Boolean): FloatArray {
        if (r <= 0) return a
        val tmp = FloatArray(a.size)
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                var v = a[row + x]
                val lo = max(0, x - r); val hi = min(w - 1, x + r)
                for (k in lo..hi) { val t = a[row + k]; v = if (grow) max(v, t) else min(v, t) }
                tmp[row + x] = v
            }
        }
        val out = FloatArray(a.size)
        for (x in 0 until w) {
            for (y in 0 until h) {
                var v = tmp[y * w + x]
                val lo = max(0, y - r); val hi = min(h - 1, y + r)
                for (k in lo..hi) { val t = tmp[k * w + x]; v = if (grow) max(v, t) else min(v, t) }
                out[y * w + x] = v
            }
        }
        return out
    }

    private fun blur(a: FloatArray, r: Int): FloatArray {
        if (r <= 0) return a
        var src = a
        repeat(2) {
            val tmp = FloatArray(a.size)
            for (y in 0 until h) {
                val row = y * w
                var sum = 0f; var cnt = 0
                for (k in 0..min(r, w - 1)) { sum += src[row + k]; cnt++ }
                for (x in 0 until w) {
                    tmp[row + x] = sum / cnt
                    val add = x + r + 1; val rem = x - r
                    if (add < w) { sum += src[row + add]; cnt++ }
                    if (rem >= 0) { sum -= src[row + rem]; cnt-- }
                }
            }
            val out = FloatArray(a.size)
            for (x in 0 until w) {
                var sum = 0f; var cnt = 0
                for (k in 0..min(r, h - 1)) { sum += tmp[k * w + x]; cnt++ }
                for (y in 0 until h) {
                    out[y * w + x] = sum / cnt
                    val add = y + r + 1; val rem = y - r
                    if (add < h) { sum += tmp[add * w + x]; cnt++ }
                    if (rem >= 0) { sum -= tmp[rem * w + x]; cnt-- }
                }
            }
            src = out
        }
        return src
    }

    /**
     * mode: 0 شخص، 1 لون الخلفية. threshold 0.1..0.9، soft 0.02..0.4، grow -8..8 (سالب = تصغير)، feather 0..8.
     */
    fun compose(mode: Int, threshold: Float, soft: Float, grow: Int, feather: Int, tol: Float): Bitmap {
        val conf = if (mode == 0 && personConf != null) personConf!! else smart(tol)
        val lo = threshold - soft; val span = max(0.001f, soft * 2f)
        var a = FloatArray(conf.size)
        for (i in a.indices) {
            val t = ((conf[i] - lo) / span).coerceIn(0f, 1f)
            a[i] = t * t * (3f - 2f * t)
        }
        if (grow > 0) a = morph(a, grow, true) else if (grow < 0) a = morph(a, -grow, false)
        for (i in a.indices) {
            val m = manual[i].toInt()
            if (m < 0) a[i] = 0f else if (m > 0) a[i] = 1f
        }
        a = blur(a, feather)
        val out = IntArray(px.size)
        for (i in out.indices) {
            val c = px[i]
            val oa = (c ushr 24) and 255
            out[i] = (c and 0x00FFFFFF) or ((a[i] * oa).toInt().coerceIn(0, 255) shl 24)
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }
}
