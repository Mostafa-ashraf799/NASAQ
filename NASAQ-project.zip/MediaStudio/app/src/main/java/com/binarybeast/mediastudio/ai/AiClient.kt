package com.binarybeast.mediastudio.ai

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL

data class AiMsg(val role: String, val text: String, val images: List<String> = emptyList())

internal object Http {
    fun post(url: String, headers: Map<String, String>, body: String, timeoutMs: Int = 120_000): Triple<Int, String, Map<String, String>> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 20_000
            c.readTimeout = timeoutMs
            c.doOutput = true
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use(BufferedReader::readText) ?: ""
            val hs = HashMap<String, String>()
            c.headerFields.forEach { (k, v) -> if (k != null && v != null && v.isNotEmpty()) hs[k.lowercase()] = v.first() }
            return Triple(code, text, hs)
        } finally { c.disconnect() }
    }
}

/** عميل الـ API: OpenAI-compatible أو Anthropic. بنستخدم بروتوكول أدوات نصي عشان يشتغل مع أي موديل. */
object AiClient {

    fun chat(cfg: AiConfig, system: String, history: List<AiMsg>): String {
        // الصور بتتبعت لآخر 3 رسايل فيها صور بس عشان الحجم
        val withImg = history.indices.filter { history[it].images.isNotEmpty() }.takeLast(3).toSet()
        return if (cfg.proto == 1) anthropic(cfg, system, history, withImg) else openai(cfg, system, history, withImg)
    }

    private fun openai(cfg: AiConfig, system: String, h: List<AiMsg>, withImg: Set<Int>): String {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system))
        h.forEachIndexed { i, m ->
            val o = JSONObject().put("role", m.role)
            if (i in withImg) {
                val parts = JSONArray().put(JSONObject().put("type", "text").put("text", m.text))
                m.images.forEach { b ->
                    parts.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b")))
                }
                o.put("content", parts)
            } else o.put("content", m.text)
            msgs.put(o)
        }
        val body = JSONObject().put("model", cfg.model).put("messages", msgs).toString()
        val headers = HashMap<String, String>()
        headers["Content-Type"] = "application/json"
        if (cfg.apiKey.isNotBlank()) headers["Authorization"] = "Bearer ${cfg.apiKey}"
        val (code, text, _) = Http.post(cfg.effectiveBase + "/chat/completions", headers, body)
        if (code !in 200..299) throw RuntimeException("HTTP $code: ${text.take(400)}")
        val msg = JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message")
        val c = msg.opt("content")
        return when (c) {
            is String -> c
            is JSONArray -> (0 until c.length()).joinToString("") { c.getJSONObject(it).optString("text") }
            else -> ""
        }
    }

    private fun anthropic(cfg: AiConfig, system: String, h: List<AiMsg>, withImg: Set<Int>): String {
        val msgs = JSONArray()
        h.forEachIndexed { i, m ->
            val o = JSONObject().put("role", m.role)
            if (i in withImg) {
                val parts = JSONArray()
                m.images.forEach { b ->
                    parts.put(JSONObject().put("type", "image").put("source",
                        JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", b)))
                }
                parts.put(JSONObject().put("type", "text").put("text", m.text))
                o.put("content", parts)
            } else o.put("content", m.text)
            msgs.put(o)
        }
        val body = JSONObject().put("model", cfg.model).put("max_tokens", 4096).put("system", system).put("messages", msgs).toString()
        val headers = mapOf("Content-Type" to "application/json", "x-api-key" to cfg.apiKey, "anthropic-version" to "2023-06-01")
        val (code, text, _) = Http.post(cfg.effectiveBase + "/v1/messages", headers, body)
        if (code !in 200..299) throw RuntimeException("HTTP $code: ${text.take(400)}")
        val arr = JSONObject(text).getJSONArray("content")
        return (0 until arr.length()).joinToString("") { arr.getJSONObject(it).optString("text") }
    }
}

class McpTool(val name: String, val description: String, val schema: String)
class McpResult(val text: String, val images: List<String>)

/** عميل MCP عبر HTTP (Streamable HTTP / JSON-RPC). الأدوات بتتعرض للـ AI وبينادي عليها بدون ما يلمس المعرض. */
class McpClient(private val url: String, private val token: String) {
    private var session: String? = null
    private var inited = false
    private var nextId = 1

    private fun headers(): Map<String, String> {
        val h = HashMap<String, String>()
        h["Content-Type"] = "application/json"
        h["Accept"] = "application/json, text/event-stream"
        if (token.isNotBlank()) h["Authorization"] = if (token.startsWith("Bearer ", true)) token else "Bearer $token"
        session?.let { h["Mcp-Session-Id"] = it }
        return h
    }

    private fun parse(text: String, id: Int): JSONObject? {
        val t = text.trim()
        if (t.isEmpty()) return null
        if (t.startsWith("{")) return JSONObject(t)
        var found: JSONObject? = null
        for (line in t.lines()) {
            val l = line.trim()
            if (!l.startsWith("data:")) continue
            val j = runCatching { JSONObject(l.removePrefix("data:").trim()) }.getOrNull() ?: continue
            if (j.optInt("id", -1) == id || j.has("result") || j.has("error")) { found = j; if (j.optInt("id", -1) == id) break }
        }
        return found
    }

    private fun rpc(method: String, params: JSONObject?): JSONObject {
        val id = nextId++
        val req = JSONObject().put("jsonrpc", "2.0").put("id", id).put("method", method)
        if (params != null) req.put("params", params)
        val (code, text, hs) = Http.post(url, headers(), req.toString(), 90_000)
        if (code !in 200..299) throw RuntimeException("MCP HTTP $code: ${text.take(300)}")
        hs["mcp-session-id"]?.let { session = it }
        val j = parse(text, id) ?: throw RuntimeException("MCP: رد فاضي")
        if (j.has("error")) throw RuntimeException("MCP: " + j.getJSONObject("error").optString("message"))
        return j.optJSONObject("result") ?: JSONObject()
    }

    private fun ensure() {
        if (inited) return
        rpc(
            "initialize", JSONObject().put("protocolVersion", "2025-03-26").put("capabilities", JSONObject())
                .put("clientInfo", JSONObject().put("name", "NASAQ").put("version", "1.3"))
        )
        runCatching {
            Http.post(url, headers(), JSONObject().put("jsonrpc", "2.0").put("method", "notifications/initialized").toString(), 20_000)
        }
        inited = true
    }

    fun tools(): List<McpTool> {
        ensure()
        val arr = rpc("tools/list", JSONObject()).optJSONArray("tools") ?: return emptyList()
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            McpTool(o.optString("name"), o.optString("description"), (o.optJSONObject("inputSchema") ?: JSONObject()).toString())
        }
    }

    fun call(name: String, args: JSONObject): McpResult {
        ensure()
        val r = rpc("tools/call", JSONObject().put("name", name).put("arguments", args))
        val content = r.optJSONArray("content") ?: JSONArray()
        val sb = StringBuilder()
        val imgs = ArrayList<String>()
        for (i in 0 until content.length()) {
            val c = content.getJSONObject(i)
            when (c.optString("type")) {
                "text" -> sb.append(c.optString("text")).append('\n')
                "image" -> { imgs.add(c.optString("data")); sb.append("[image returned]\n") }
                else -> sb.append(c.toString().take(500)).append('\n')
            }
        }
        if (r.optBoolean("isError")) sb.insert(0, "ERROR: ")
        return McpResult(sb.toString().trim().take(6000), imgs)
    }
}
