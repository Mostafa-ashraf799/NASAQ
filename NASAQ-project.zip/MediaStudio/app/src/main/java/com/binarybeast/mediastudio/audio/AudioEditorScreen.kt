package com.binarybeast.mediastudio.audio

import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Forward5
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Replay5
import androidx.compose.material.icons.filled.Undo
import android.app.Application
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.binarybeast.mediastudio.data.AudioData
import com.binarybeast.mediastudio.data.formatDuration
import com.binarybeast.mediastudio.ui.Accent
import com.binarybeast.mediastudio.ui.Bg
import com.binarybeast.mediastudio.ui.Chip
import com.binarybeast.mediastudio.ui.LabeledSlider
import com.binarybeast.mediastudio.ui.SectionLabel
import com.binarybeast.mediastudio.ui.SmallButton
import com.binarybeast.mediastudio.ui.Surface1
import com.binarybeast.mediastudio.ui.Surface2
import com.binarybeast.mediastudio.ui.TextDim
import com.binarybeast.mediastudio.ui.TextInputDialog
import com.binarybeast.mediastudio.ui.isWideLayout
import com.binarybeast.mediastudio.ui.rememberCloudUpload
import com.binarybeast.mediastudio.ui.shareUri
import com.binarybeast.mediastudio.ui.toast
import com.binarybeast.mediastudio.video.ExportState

@Composable
fun AudioEditorScreen(projectId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val vm: AudioEditorViewModel = viewModel(
        key = "audio_$projectId",
        factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                AudioEditorViewModel(ctx.applicationContext as Application, projectId) as T
        }
    )
    var showRename by remember { mutableStateOf(false) }
    val uploadToCloud = rememberCloudUpload()

    BackHandler { vm.pause(); vm.saveNow(); onBack() }
    DisposableEffect(Unit) { onDispose { vm.pause(); vm.saveNow() } }
    LaunchedEffect(vm.message) { vm.message?.let { toast(ctx, it); vm.message = null } }

    val view = LocalView.current
    val exporting = vm.exportState is ExportState.Running
    DisposableEffect(exporting) {
        view.keepScreenOn = exporting
        onDispose { view.keepScreenOn = false }
    }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.pause(); vm.saveNow(); onBack() }) { Icon(Icons.Default.ArrowBack, "رجوع") }
            Text(
                vm.project?.name ?: "",
                modifier = Modifier.weight(1f).clickable { showRename = true }.padding(horizontal = 4.dp),
                maxLines = 1, fontSize = 16.sp
            )
            IconButton(onClick = { vm.undo() }, enabled = vm.canUndo) {
                Icon(Icons.Default.Undo, "تراجع", tint = if (vm.canUndo) MaterialTheme.colorScheme.onSurface else TextDim.copy(alpha = 0.4f))
            }
            IconButton(onClick = { vm.redo() }, enabled = vm.canRedo) {
                Icon(Icons.Default.Redo, "إعادة", tint = if (vm.canRedo) MaterialTheme.colorScheme.onSurface else TextDim.copy(alpha = 0.4f))
            }
            SmallButton("تصدير", onClick = { vm.pause(); vm.startExport() }, icon = Icons.Default.Download)
            Spacer(Modifier.width(6.dp))
        }

        val a = vm.data
        if (vm.loading || a == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                if (vm.failed) Text("تعذر فتح المشروع", color = TextDim) else CircularProgressIndicator(color = Accent)
            }
        } else if (isWideLayout()) {
            Row(Modifier.weight(1f).fillMaxWidth()) {
                Column(Modifier.weight(1f).fillMaxHeight().padding(12.dp), verticalArrangement = Arrangement.Center) {
                    Player(vm, a)
                }
                Column(
                    Modifier.width(400.dp).fillMaxHeight().background(Surface1)
                        .verticalScroll(rememberScrollState()).padding(12.dp)
                ) { Controls(vm, a) }
            }
        } else {
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp)) {
                Player(vm, a)
                Spacer(Modifier.height(8.dp))
                Controls(vm, a)
            }
        }
    }

    if (showRename) {
        TextInputDialog(
            title = "اسم المشروع", initial = vm.project?.name ?: "",
            onConfirm = { if (it.isNotBlank()) vm.rename(it); showRename = false },
            onDismiss = { showRename = false }
        )
    }
    ExportDialogs(
        vm,
        onShare = { uri -> shareUri(ctx, uri, "audio/mp4") },
        onCloud = { uri -> uploadToCloud(listOf(uri)) }
    )
}

// ---------------------------------------------------------------- player

@Composable
private fun Player(vm: AudioEditorViewModel, a: AudioData) {
    Column(Modifier.fillMaxWidth()) {
        Text(a.name.ifBlank { "صوت" }, fontSize = 15.sp, maxLines = 1)
        Waveform(vm, a)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            RangeSlider(
                value = a.startMs.toFloat()..a.endMs.toFloat(),
                onValueChange = { r ->
                    val e = maxOf(r.endInclusive.toLong(), r.start.toLong() + 300L).coerceAtMost(a.srcDurationMs)
                    val s = minOf(r.start.toLong(), e - 300L).coerceAtLeast(0L)
                    vm.update(true) { it.copy(startMs = s, endMs = e) }
                },
                onValueChangeFinished = { vm.endLive() },
                valueRange = 0f..a.srcDurationMs.toFloat(),
                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Surface2)
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("من ${formatDuration(a.startMs)}", color = TextDim, fontSize = 12.sp)
            Text("المدة الناتجة ${formatDuration(a.effectiveMs)}", color = TextDim, fontSize = 12.sp)
            Text("إلى ${formatDuration(a.endMs)}", color = TextDim, fontSize = 12.sp)
        }
        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.nudge(-5000) }) { Icon(Icons.Default.Replay5, "رجوع 5 ثواني") }
            Box(
                Modifier.padding(horizontal = 12.dp).size(60.dp).clip(CircleShape).background(Accent)
                    .clickable { vm.togglePlay() },
                contentAlignment = Alignment.Center
            ) {
                Icon(if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "تشغيل", tint = Color.White, modifier = Modifier.size(34.dp))
            }
            IconButton(onClick = { vm.nudge(5000) }) { Icon(Icons.Default.Forward5, "تقديم 5 ثواني") }
        }
        Text(
            "${formatDuration(vm.positionMs)} / ${formatDuration(a.srcDurationMs)}",
            color = TextDim, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 4.dp)
        )
    }
}

@Composable
private fun Waveform(vm: AudioEditorViewModel, a: AudioData) {
    val peaks = vm.peaks
    val src = a.srcDurationMs.coerceAtLeast(1L)
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Canvas(
            Modifier
                .fillMaxWidth().height(140.dp).padding(vertical = 6.dp)
                .clip(RoundedCornerShape(12.dp)).background(Surface1)
                .pointerInput(src) {
                    detectTapGestures { o -> vm.seekTo((o.x / size.width * src).toLong().coerceIn(0L, src)) }
                }
                .pointerInput(src) {
                    detectDragGestures { change, _ ->
                        vm.seekTo((change.position.x / size.width * src).toLong().coerceIn(0L, src))
                    }
                }
        ) {
            val mid = size.height / 2f
            val n = peaks?.size ?: 0
            if (peaks == null || n == 0) {
                drawLine(Accent.copy(alpha = 0.5f), Offset(0f, mid), Offset(size.width, mid), strokeWidth = 2f)
            } else {
                val bw = size.width / n
                for (i in 0 until n) {
                    val t = (i + 0.5f) / n * src
                    val inside = t >= a.startMs && t <= a.endMs
                    val h = (peaks[i] * size.height * 0.9f).coerceAtLeast(3f)
                    drawRect(
                        color = if (inside) Accent else TextDim.copy(alpha = 0.35f),
                        topLeft = Offset(i * bw + bw * 0.15f, mid - h / 2f),
                        size = Size(bw * 0.7f, h)
                    )
                }
            }
            val px = vm.positionMs.toFloat() / src * size.width
            drawLine(Color.White, Offset(px, 0f), Offset(px, size.height), strokeWidth = 3f)
        }
    }
}

// ---------------------------------------------------------------- controls

@Composable
private fun Controls(vm: AudioEditorViewModel, a: AudioData) {
    Column(Modifier.fillMaxWidth()) {
        SectionLabel("السرعة")
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0.5f, 0.75f, 1f, 1.5f, 2f).forEach { s ->
                Chip("${s}x", a.speed == s, { vm.update { it.copy(speed = s) } })
            }
        }
        LabeledSlider("سرعة مخصصة", a.speed, 0.5f..2f, { v -> vm.update(true) { it.copy(speed = v) } }, { vm.endLive() }, { "%.2fx".format(it) })
        LabeledSlider("درجة الصوت (Pitch)", a.pitch, 0.5f..2f, { v -> vm.update(true) { it.copy(pitch = v) } }, { vm.endLive() }, { "%.2fx".format(it) })
        LabeledSlider("مستوى الصوت", a.volume, 0f..2f, { v -> vm.update(true) { it.copy(volume = v) } }, { vm.endLive() }, { "%.0f%%".format(it * 100) })
        if (a.volume > 1f) {
            Text("التضخيم فوق 100% بيظهر في الملف المُصدَّر (المعاينة بحد أقصى 100%).", color = TextDim, fontSize = 11.sp)
        }
        LabeledSlider("صدى (Echo)", a.echo, 0f..1f, { v -> vm.update(true) { it.copy(echo = v) } }, { vm.endLive() }, { "%.0f%%".format(it * 100) })
        if (a.echo > 0.01f) {
            Text("الصدى بيظهر في الملف المُصدَّر (مش في المعاينة).", color = TextDim, fontSize = 11.sp)
        }
        val maxFade = (a.effectiveMs / 2).coerceIn(200L, 10_000L).toFloat()
        SectionLabel("تلاشي (Fade)")
        LabeledSlider("تدريجي في البداية", a.fadeInMs.toFloat().coerceAtMost(maxFade), 0f..maxFade,
            { v -> vm.update(true) { it.copy(fadeInMs = v.toLong()) } }, { vm.endLive() }, { "%.1f ث".format(it / 1000f) })
        LabeledSlider("تدريجي في النهاية", a.fadeOutMs.toFloat().coerceAtMost(maxFade), 0f..maxFade,
            { v -> vm.update(true) { it.copy(fadeOutMs = v.toLong()) } }, { vm.endLive() }, { "%.1f ث".format(it / 1000f) })
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallButton("إعادة ضبط", {
                vm.update { it.copy(speed = 1f, pitch = 1f, volume = 1f, fadeInMs = 0L, fadeOutMs = 0L, echo = 0f) }
            })
            SmallButton("تحديد الكل", { vm.update { it.copy(startMs = 0L, endMs = it.srcDurationMs) } })
        }
    }
}

// ---------------------------------------------------------------- export dialogs

@Composable
private fun ExportDialogs(vm: AudioEditorViewModel, onShare: (Uri) -> Unit, onCloud: (Uri) -> Unit) {
    when (val st = vm.exportState) {
        is ExportState.Running -> AlertDialog(
            onDismissRequest = {},
            containerColor = Surface1,
            title = { Text("جاري التصدير...") },
            text = {
                Column {
                    LinearProgressIndicator(progress = { st.progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Accent)
                    Text("${st.progress}%", color = TextDim, modifier = Modifier.padding(top = 8.dp))
                }
            },
            confirmButton = { TextButton(onClick = { vm.cancelExport() }) { Text("إلغاء", color = TextDim) } }
        )
        is ExportState.Done -> com.binarybeast.mediastudio.ui.ExportDoneDialog(
            file = st.file, mime = "audio/mp4", savedUri = st.savedUri, label = "الموسيقى (Music/NASAQ)",
            onSave = { vm.saveExport() }, onCloud = onCloud, onDismiss = { vm.resetExport() }
        )
        is ExportState.Failed -> AlertDialog(
            onDismissRequest = { vm.resetExport() },
            containerColor = Surface1,
            title = { Text("فشل التصدير") },
            text = { Text(st.message, color = TextDim) },
            confirmButton = { TextButton(onClick = { vm.resetExport() }) { Text("حسنًا", color = Accent) } }
        )
        ExportState.Idle -> Unit
    }
}
