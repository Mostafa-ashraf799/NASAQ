package com.binarybeast.mediastudio.audio

import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Forward5
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Replay5
import androidx.compose.material.icons.filled.Undo
import android.app.Application
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.binarybeast.mediastudio.data.AudioData
import com.binarybeast.mediastudio.data.formatDuration
import com.binarybeast.mediastudio.ui.Accent
import com.binarybeast.mediastudio.ui.Bg
import com.binarybeast.mediastudio.ui.Chip
import com.binarybeast.mediastudio.ui.LabeledSlider
import com.binarybeast.mediastudio.ui.SectionLabel
import com.binarybeast.mediastudio.ui.SmallButton
import com.binarybeast.mediastudio.ui.Surface1
import com.binarybeast.mediastudio.ui.Surface2
import com.binarybeast.mediastudio.ui.TextDim
import com.binarybeast.mediastudio.ui.TextInputDialog
import com.binarybeast.mediastudio.ui.isWideLayout
import com.binarybeast.mediastudio.ui.rememberCloudUpload
import com.binarybeast.mediastudio.ui.shareUri
import com.binarybeast.mediastudio.ui.toast
import com.binarybeast.mediastudio.video.ExportState

@Composable
fun AudioEditorScreen(projectId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val vm: AudioEditorViewModel = viewModel(
        key = "audio_$projectId",
        factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                AudioEditorViewModel(ctx.applicationContext as Application, projectId) as T
        }
    )
    var showRename by remember { mutableStateOf(false) }
    val uploadToCloud = rememberCloudUpload()

    BackHandler { vm.pause(); vm.saveNow(); onBack() }
    DisposableEffect(Unit) { onDispose { vm.pause(); vm.saveNow() } }
    LaunchedEffect(vm.message) { vm.message?.let { toast(ctx, it); vm.message = null } }

    val view = LocalView.current
    val exporting = vm.exportState is ExportState.Running
    DisposableEffect(exporting) {
        view.keepScreenOn = exporting
        onDispose { view.keepScreenOn = false }
    }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.pause(); vm.saveNow(); onBack() }) { Icon(Icons.Default.ArrowBack, "رجوع") }
            Text(
                vm.project?.name ?: "",
                modifier = Modifier.weight(1f).clickable { showRename = true }.padding(horizontal = 4.dp),
                maxLines = 1, fontSize = 16.sp
            )
            IconButton(onClick = { vm.undo() }, enabled = vm.canUndo) {
                Icon(Icons.Default.Undo, "تراجع", tint = if (vm.canUndo) MaterialTheme.colorScheme.onSurface else TextDim.copy(alpha = 0.4f))
            }
            IconButton(onClick = { vm.redo() }, enabled = vm.canRedo) {
                Icon(Icons.Default.Redo, "إعادة", tint = if (vm.canRedo) MaterialTheme.colorScheme.onSurface else TextDim.copy(alpha = 0.4f))
            }
            SmallButton("تصدير", onClick = { vm.pause(); vm.startExport() }, icon = Icons.Default.Download)
            Spacer(Modifier.width(6.dp))
        }

        val a = vm.data
        if (vm.loading || a == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                if (vm.failed) Text("تعذر فتح المشروع", color = TextDim) else CircularProgressIndicator(color = Accent)
            }
        } else if (isWideLayout()) {
            Row(Modifier.weight(1f).fillMaxWidth()) {
                Column(Modifier.weight(1f).fillMaxHeight().padding(12.dp), verticalArrangement = Arrangement.Center) {
                    Player(vm, a)
                }
                Column(
                    Modifier.width(400.dp).fillMaxHeight().background(Surface1)
                        .verticalScroll(rememberScrollState()).padding(12.dp)
                ) { Controls(vm, a) }
            }
        } else {
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp)) {
                Player(vm, a)
                Spacer(Modifier.height(8.dp))
                Controls(vm, a)
            }
        }
    }

    if (showRename) {
        TextInputDialog(
            title = "اسم المشروع", initial = vm.project?.name ?: "",
            onConfirm = { if (it.isNotBlank()) vm.rename(it); showRename = false },
            onDismiss = { showRename = false }
        )
    }
    ExportDialogs(
        vm,
        onShare = { uri -> shareUri(ctx, uri, "audio/mp4") },
        onCloud = { uri -> uploadToCloud(listOf(uri)) }
    )
}

// ---------------------------------------------------------------- player

@Composable
private fun Player(vm: AudioEditorViewModel, a: AudioData) {
    Column(Modifier.fillMaxWidth()) {
        Text(a.name.ifBlank { "صوت" }, fontSize = 15.sp, maxLines = 1)
        Waveform(vm, a)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            RangeSlider(
                value = a.startMs.toFloat()..a.endMs.toFloat(),
                onValueChange = { r ->
                    val e = maxOf(r.endInclusive.toLong(), r.start.toLong() + 300L).coerceAtMost(a.srcDurationMs)
                    val s = minOf(r.start.toLong(), e - 300L).coerceAtLeast(0L)
                    vm.update(true) { it.copy(startMs = s, endMs = e) }
                },
                onValueChangeFinished = { vm.endLive() },
                valueRange = 0f..a.srcDurationMs.toFloat(),
                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Surface2)
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("من ${formatDuration(a.startMs)}", color = TextDim, fontSize = 12.sp)
            Text("المدة الناتجة ${formatDuration(a.effectiveMs)}", color = TextDim, fontSize = 12.sp)
            Text("إلى ${formatDuration(a.endMs)}", color = TextDim, fontSize = 12.sp)
        }
        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.nudge(-5000) }) { Icon(Icons.Default.Replay5, "رجوع 5 ثواني") }
            Box(
                Modifier.padding(horizontal = 12.dp).size(60.dp).clip(CircleShape).background(Accent)
                    .clickable { vm.togglePlay() },
                contentAlignment = Alignment.Center
            ) {
                Icon(if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "تشغيل", tint = Color.White, modifier = Modifier.size(34.dp))
            }
            IconButton(onClick = { vm.nudge(5000) }) { Icon(Icons.Default.Forward5, "تقديم 5 ثواني") }
        }
        Text(
            "${formatDuration(vm.positionMs)} / ${formatDuration(a.srcDurationMs)}",
            color = TextDim, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 4.dp)
        )
    }
}

@Composable
private fun Waveform(vm: AudioEditorViewModel, a: AudioData) {
    val peaks = vm.peaks
    val src = a.srcDurationMs.coerceAtLeast(1L)
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Canvas(
            Modifier
                .fillMaxWidth().height(140.dp).padding(vertical = 6.dp)
                .clip(RoundedCornerShape(12.dp)).background(Surface1)
                .pointerInput(src) {
                    detectTapGestures { o -> vm.seekTo((o.x / size.width * src).toLong().coerceIn(0L, src)) }
                }
                .pointerInput(src) {
                    detectDragGestures { change, _ ->
                        vm.seekTo((change.position.x / size.width * src).toLong().coerceIn(0L, src))
                    }
                }
        ) {
            val mid = size.height / 2f
            val n = peaks?.size ?: 0
            if (peaks == null || n == 0) {
                drawLine(Accent.copy(alpha = 0.5f), Offset(0f, mid), Offset(size.width, mid), strokeWidth = 2f)
            } else {
                val bw = size.width / n
                for (i in 0 until n) {
                    val t = (i + 0.5f) / n * src
                    val inside = t >= a.startMs && t <= a.endMs
                    val h = (peaks[i] * size.height * 0.9f).coerceAtLeast(3f)
                    drawRect(
                        color = if (inside) Accent else TextDim.copy(alpha = 0.35f),
                        topLeft = Offset(i * bw + bw * 0.15f, mid - h / 2f),
                        size = Size(bw * 0.7f, h)
                    )
                }
            }
            val px = vm.positionMs.toFloat() / src * size.width
            drawLine(Color.White, Offset(px, 0f), Offset(px, size.height), strokeWidth = 3f)
        }
    }
}

// ---------------------------------------------------------------- controls

@Composable
private fun Controls(vm: AudioEditorViewModel, a: AudioData) {
    Column(Modifier.fillMaxWidth()) {
        SectionLabel("السرعة")
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0.5f, 0.75f, 1f, 1.5f, 2f).forEach { s ->
                Chip("${s}x", a.speed == s, { vm.update { it.copy(speed = s) } })
            }
        }
        LabeledSlider("سرعة مخصصة", a.speed, 0.5f..2f, { v -> vm.update(true) { it.copy(speed = v) } }, { vm.endLive() }, { "%.2fx".format(it) })
        LabeledSlider("درجة الصوت (Pitch)", a.pitch, 0.5f..2f, { v -> vm.update(true) { it.copy(pitch = v) } }, { vm.endLive() }, { "%.2fx".format(it) })
        LabeledSlider("مستوى الصوت", a.volume, 0f..2f, { v -> vm.update(true) { it.copy(volume = v) } }, { vm.endLive() }, { "%.0f%%".format(it * 100) })
        if (a.volume > 1f) {
            Text("التضخيم فوق 100% بيظهر في الملف المُصدَّر (المعاينة بحد أقصى 100%).", color = TextDim, fontSize = 11.sp)
        }
        LabeledSlider("صدى (Echo)", a.echo, 0f..1f, { v -> vm.update(true) { it.copy(echo = v) } }, { vm.endLive() }, { "%.0f%%".format(it * 100) })
        if (a.echo > 0.01f) {
            Text("الصدى بيظهر في الملف المُصدَّر (مش في المعاينة).", color = TextDim, fontSize = 11.sp)
        }
        val maxFade = (a.effectiveMs / 2).coerceIn(200L, 10_000L).toFloat()
        SectionLabel("تلاشي (Fade)")
        LabeledSlider("تدريجي في البداية", a.fadeInMs.toFloat().coerceAtMost(maxFade), 0f..maxFade,
            { v -> vm.update(true) { it.copy(fadeInMs = v.toLong()) } }, { vm.endLive() }, { "%.1f ث".format(it / 1000f) })
        LabeledSlider("تدريجي في النهاية", a.fadeOutMs.toFloat().coerceAtMost(maxFade), 0f..maxFade,
            { v -> vm.update(true) { it.copy(fadeOutMs = v.toLong()) } }, { vm.endLive() }, { "%.1f ث".format(it / 1000f) })
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallButton("إعادة ضبط", {
                vm.update { it.copy(speed = 1f, pitch = 1f, volume = 1f, fadeInMs = 0L, fadeOutMs = 0L, echo = 0f) }
            })
            SmallButton("تحديد الكل", { vm.update { it.copy(startMs = 0L, endMs = it.srcDurationMs) } })
        }
        AdvancedControls(vm, a)
    }
}

private val EqNames = listOf("60Hz", "230Hz", "910Hz", "3.6k", "14k")

@Composable
private fun AdvancedControls(vm: AudioEditorViewModel, a: AudioData) {
    fun pct(v: Float) = "%.0f%%".format(v * 100)
    fun db(v: Float) = "%+.0f dB".format(v)
    SectionLabel("إعدادات جاهزة")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("بودكاست", false, { vm.update { it.copy(highPassHz = 80f, voiceFilter = 3, comp = 0.5f, gate = 0.2f, limiter = true, bass = 2f) } })
        Chip("موسيقى", false, { vm.update { it.copy(bass = 3f, treble = 2f, comp = 0.2f, limiter = true, channelMode = 2) } })
        Chip("سينمائي", false, { vm.update { it.copy(bass = 5f, reverb = 0.35f, comp = 0.3f, channelMode = 2) } })
        Chip("راديو", false, { vm.update { it.copy(voiceFilter = 2, comp = 0.6f, limiter = true) } })
        Chip("تليفون", false, { vm.update { it.copy(voiceFilter = 1) } })
        Chip("صوت كرتون", false, { vm.update { it.copy(pitch = 1.5f) } })
        Chip("صوت عميق", false, { vm.update { it.copy(pitch = 0.75f, bass = 4f) } })
        Chip("روبوت", false, { vm.update { it.copy(robot = 0.8f) } })
        Chip("قاعة كبيرة", false, { vm.update { it.copy(reverb = 0.7f) } })
    }
    SectionLabel("مستوى ونقاء")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("تطبيع المستوى", a.normalize, { vm.setNormalize(!a.normalize) })
        Chip("ليميتر", a.limiter, { vm.update { it.copy(limiter = !it.limiter) } })
        Chip("مونو", a.channelMode == 1, { vm.update { it.copy(channelMode = if (it.channelMode == 1) 0 else 1) } })
        Chip("ستيريو واسع", a.channelMode == 2, { vm.update { it.copy(channelMode = if (it.channelMode == 2) 0 else 2) } })
    }
    LabeledSlider("بان (شمال ↔ يمين)", a.pan, -1f..1f, { v -> vm.update(true) { it.copy(pan = v) } }, { vm.endLive() }, { "%+.0f".format(it * 100) })
    LabeledSlider("بوابة ضوضاء", a.gate, 0f..1f, { v -> vm.update(true) { it.copy(gate = v) } }, { vm.endLive() }, ::pct)
    LabeledSlider("كومبريسور", a.comp, 0f..1f, { v -> vm.update(true) { it.copy(comp = v) } }, { vm.endLive() }, ::pct)
    SectionLabel("إكوالايزر")
    for (i in 0 until 5) {
        LabeledSlider(EqNames[i], a.eq.getOrElse(i) { 0f }, -12f..12f,
            { v -> vm.update(true) { d -> d.copy(eq = d.eq.toMutableList().also { l -> l[i] = v }) } }, { vm.endLive() }, ::db)
    }
    LabeledSlider("باس", a.bass, 0f..12f, { v -> vm.update(true) { it.copy(bass = v) } }, { vm.endLive() }, ::db)
    LabeledSlider("تريبل", a.treble, 0f..12f, { v -> vm.update(true) { it.copy(treble = v) } }, { vm.endLive() }, ::db)
    LabeledSlider("قطع الترددات العالية (Low-pass)", a.lowPassHz, 1000f..20000f, { v -> vm.update(true) { it.copy(lowPassHz = v) } }, { vm.endLive() }, { if (it >= 19500f) "مقفول" else "%.0f Hz".format(it) })
    LabeledSlider("قطع الترددات المنخفضة (High-pass)", a.highPassHz, 20f..2000f, { v -> vm.update(true) { it.copy(highPassHz = v) } }, { vm.endLive() }, { if (it <= 25f) "مقفول" else "%.0f Hz".format(it) })
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("بدون فلتر", a.voiceFilter == 0, { vm.update { it.copy(voiceFilter = 0) } })
        Chip("تليفون", a.voiceFilter == 1, { vm.update { it.copy(voiceFilter = 1) } })
        Chip("راديو", a.voiceFilter == 2, { vm.update { it.copy(voiceFilter = 2) } })
        Chip("وضوح صوت", a.voiceFilter == 3, { vm.update { it.copy(voiceFilter = 3) } })
    }
    SectionLabel("مؤثرات")
    LabeledSlider("ريفيرب", a.reverb, 0f..1f, { v -> vm.update(true) { it.copy(reverb = v) } }, { vm.endLive() }, ::pct)
    LabeledSlider("روبوت", a.robot, 0f..1f, { v -> vm.update(true) { it.copy(robot = v) } }, { vm.endLive() }, ::pct)
    LabeledSlider("ترمولو", a.tremolo, 0f..1f, { v -> vm.update(true) { it.copy(tremolo = v) } }, { vm.endLive() }, ::pct)
    LabeledSlider(if (a.chorusMode == 0) "كورس" else "فلانجر", a.chorus, 0f..1f, { v -> vm.update(true) { it.copy(chorus = v) } }, { vm.endLive() }, ::pct)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("كورس", a.chorusMode == 0, { vm.update { it.copy(chorusMode = 0) } })
        Chip("فلانجر", a.chorusMode == 1, { vm.update { it.copy(chorusMode = 1) } })
    }
    Text("التأثيرات دي بتظهر في الملف المُصدَّر (مش في المعاينة).", color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    SectionLabel("تركيب وتحرير")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("عكس الصوت", a.reverse, { vm.update { it.copy(reverse = !it.reverse) } })
        Chip("تلاشي أُسّي", a.fadeCurve == 1, { vm.update { it.copy(fadeCurve = if (it.fadeCurve == 1) 0 else 1) } })
    }
    Text("تكرار الصوت", color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(1, 2, 3, 4, 5, 10).forEach { n -> Chip("×$n", a.loops == n, { vm.update { it.copy(loops = n) } }) }
    }
    LabeledSlider("صمت في البداية", a.padStartMs.toFloat(), 0f..5000f, { v -> vm.update(true) { it.copy(padStartMs = v.toLong()) } }, { vm.endLive() }, { "%.1f ث".format(it / 1000f) })
    LabeledSlider("صمت في النهاية", a.padEndMs.toFloat(), 0f..5000f, { v -> vm.update(true) { it.copy(padEndMs = v.toLong()) } }, { vm.endLive() }, { "%.1f ث".format(it / 1000f) })
    SectionLabel("حذف جزء من النص")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SmallButton("علّم البداية هنا", { vm.cutMark = vm.positionMs })
        SmallButton("احذف حتى هنا", {
            val m = vm.cutMark
            if (m == null) vm.message = "علّم البداية الأول" else { vm.cutOut(m, vm.positionMs); vm.cutMark = null }
        })
        if (a.cuts.isNotEmpty()) SmallButton("استرجاع المحذوف (${a.cuts.size})", { vm.clearCuts() })
    }
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SmallButton("قص الصمت من الأطراف", { vm.trimSilenceEnds(-38f) })
        SmallButton("مسح الصمت تلقائيًا", { vm.autoCutSilence(-38f) })
        SmallButton("مسح الصمت (حسّاس)", { vm.autoCutSilence(-30f) })
    }
    if (vm.cutMark != null) Text("بداية الحذف: ${formatDuration(vm.cutMark!!)} — حرّك المؤشر للنهاية واضغط احذف.", color = TextDim, fontSize = 11.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SmallButton("إعادة ضبط كل التأثيرات", {
            vm.update { it.copy(normalize = false, normGain = 1f, eq = List(5) { 0f }, bass = 0f, treble = 0f, voiceFilter = 0, robot = 0f,
                reverb = 0f, chorus = 0f, tremolo = 0f, lowPassHz = 20000f, highPassHz = 20f, gate = 0f, comp = 0f, limiter = false,
                channelMode = 0, pan = 0f, reverse = false, loops = 1, padStartMs = 0L, padEndMs = 0L, fadeCurve = 0, cuts = emptyList()) }
        })
    }
}

// ---------------------------------------------------------------- export dialogs

@Composable
private fun ExportDialogs(vm: AudioEditorViewModel, onShare: (Uri) -> Unit, onCloud: (Uri) -> Unit) {
    when (val st = vm.exportState) {
        is ExportState.Running -> AlertDialog(
            onDismissRequest = {},
            containerColor = Surface1,
            title = { Text("جاري التصدير...") },
            text = {
                Column {
                    LinearProgressIndicator(progress = { st.progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Accent)
                    Text("${st.progress}%", color = TextDim, modifier = Modifier.padding(top = 8.dp))
                }
            },
            confirmButton = { TextButton(onClick = { vm.cancelExport() }) { Text("إلغاء", color = TextDim) } }
        )
        is ExportState.Done -> com.binarybeast.mediastudio.ui.ExportDoneDialog(
            file = st.file, mime = "audio/mp4", savedUri = st.savedUri, label = "الموسيقى (Music/NASAQ)",
            onSave = { vm.saveExport() }, onCloud = onCloud, onDismiss = { vm.resetExport() }
        )
        is ExportState.Failed -> AlertDialog(
            onDismissRequest = { vm.resetExport() },
            containerColor = Surface1,
            title = { Text("فشل التصدير") },
            text = { Text(st.message, color = TextDim) },
            confirmButton = { TextButton(onClick = { vm.resetExport() }) { Text("حسنًا", color = Accent) } }
        )
        ExportState.Idle -> Unit
    }
}
