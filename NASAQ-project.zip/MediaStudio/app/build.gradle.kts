plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.binarybeast.mediastudio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.binarybeast.nasaq"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "1.3.0"
        // نحدّد المعماريات عشان حجم الـ APK (OpenCV بيزوّد حجم كبير لكل معمارية)
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    // مفتاح توقيع ثابت: كل بناء على GitHub Actions بيطلع بنفس التوقيع،
    // فالتحديث فوق النسخة المثبتة بيشتغل من غير ما تمسح التطبيق.
    signingConfigs {
        create("nasaq") {
            storeFile = file("nasaq.jks")
            storePassword = "nasaq123"
            keyAlias = "nasaq"
            keyPassword = "nasaq123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("nasaq")
        }
        release {
            isMinifyEnabled = false
            // موقّع بمفتاح الـ debug عشان الـ APK يتثبت مباشرة من GitHub Actions.
            // للنشر على Play Store استبدله بمفتاحك الخاص.
            signingConfig = signingConfigs.getByName("nasaq")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.3")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("io.coil-kt:coil-video:2.7.0")

    val media3 = "1.4.1"
    implementation("androidx.media3:media3-common:$media3")
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-ui:$media3")
    implementation("androidx.media3:media3-effect:$media3")
    implementation("androidx.media3:media3-transformer:$media3")

    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("com.google.mlkit:segmentation-selfie:16.0.0-beta6")
    implementation("com.google.mlkit:face-detection:16.1.7")
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")
    implementation("com.google.zxing:core:3.5.3")
    implementation("org.opencv:opencv:4.9.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:image-labeling:17.0.9")
    implementation("jp.co.cyberagent.android:gpuimage:2.1.0")
    implementation("com.google.guava:guava:33.0.0-android")
}
